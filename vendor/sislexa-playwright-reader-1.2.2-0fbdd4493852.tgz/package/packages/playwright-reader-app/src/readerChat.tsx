import { useEffect, useState, type ComponentType, type ReactNode } from 'react'
import type { ReaderChatPort, ReaderChatContext } from './contracts'

/** The host supplies the public U04 SharedChat component and its store binding. */
export interface ReaderSharedChatBinding<Props extends object> {
  props: Props
  updateBrowserContext(context: ReaderChatContext): void
  dispose(): void
}

export function createReaderChatAdapter<Props extends object>(options: {
  conversations: Omit<ReaderChatPort, 'render'>
  SharedChat: ComponentType<Props & { skin: 'widget' }>
  bind(conversationId: string): ReaderSharedChatBinding<Props>
}): ReaderChatPort {
  const { SharedChat, bind } = options
  function Widget({ conversationId, context }: { conversationId: string; context: ReaderChatContext }): JSX.Element | null {
    const [binding, setBinding] = useState<ReaderSharedChatBinding<Props> | null>(null)
    useEffect(() => {
      const next = bind(conversationId)
      next.updateBrowserContext(context)
      setBinding(next)
      return () => next.dispose()
    }, [conversationId])
    useEffect(() => { binding?.updateBrowserContext(context) }, [binding, context])
    return binding ? <SharedChat {...binding.props} skin="widget" /> : null
  }
  return {
    ...options.conversations,
    render(conversationId, context): ReactNode {
      return conversationId && context
        ? <Widget key={conversationId} conversationId={conversationId} context={context} />
        : null
    }
  }
}
