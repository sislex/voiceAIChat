import type { Conversation } from '@shared/types'
import type { BrowserSessionPort, BrowserSessionState, PlaywrightReaderHostPort, ReaderChatPort } from './contracts'
export const isPlaywrightReaderConversation=(c:Conversation):boolean=>c.assistantKind==='playwright-reader'
export interface PlaywrightReaderState{status:'idle'|'loading'|'ready'|'error';conversations:readonly Conversation[];activeId:string|null;mobilePane:'chat'|'browser';session:BrowserSessionState;error:string|null}
export interface PlaywrightReaderStore{getState():Readonly<PlaywrightReaderState>;subscribe(fn:()=>void):()=>void;load():Promise<void>;activate(id:string|null):Promise<void>;navigate(url:string):Promise<void>;stop():Promise<void>;setMobilePane(pane:'chat'|'browser'):void;dispose():void}
const idle:BrowserSessionState={status:'idle',url:null,capabilities:{chromium:false,navigate:false,screencast:false}}
export function createPlaywrightReaderStore(chat: ReaderChatPort, host: PlaywrightReaderHostPort): PlaywrightReaderStore {
  let state: PlaywrightReaderState = { status: 'idle', conversations: [], activeId: null, mobilePane: 'chat', session: idle, error: null }
  let session: BrowserSessionPort | null = null
  let generation = 0, loadGeneration = 0, disposed = false
  let off: (() => void) | undefined
  let pending: Promise<void> | null = null
  let requestedId: string | null = null
  const listeners = new Set<() => void>()
  const emit = (patch: Partial<PlaywrightReaderState>) => {
    if (!disposed) { state = { ...state, ...patch }; listeners.forEach(fn => fn()) }
  }
  const clear = () => {
    const previous = session, unsubscribe = off
    session = null
    off = undefined
    unsubscribe?.()
    previous?.dispose()
  }
  return {
    getState: () => state,
    subscribe(fn) { if (!disposed) listeners.add(fn); return () => { listeners.delete(fn) } },
    async load() {
      if (disposed) return
      const token = ++loadGeneration
      emit({ status: 'loading' })
      try {
        const all = await chat.list()
        if (token === loadGeneration) emit({ status: 'ready', conversations: all.filter(isPlaywrightReaderConversation) })
      } catch {
        if (token === loadGeneration) emit({ status: 'error', error: 'Не удалось загрузить разговоры' })
      }
    },
    activate(id) {
      if (disposed) return Promise.resolve()
      if (id === requestedId && (session || pending)) return pending ?? Promise.resolve()
      requestedId = id
      const token = ++generation
      clear()
      emit({ activeId: null, session: idle, error: null })
      if (!id) { pending = null; return Promise.resolve() }
      const current = () => !disposed && token === generation
      const activation = (async () => {
        try {
          const conversation = await chat.get(id)
          if (!current()) return
          if (!conversation || conversation.id !== id || !isPlaywrightReaderConversation(conversation)) {
            emit({ error: 'Разговор Playwright Reader не найден' })
            return
          }
          const next = host.session(id)
          session = next
          off = next.subscribe(value => { if (current()) emit({ session: value, error: value.error ?? null }) })
          emit({ activeId: id, session: next.getState() })
          await next.start(id)
        } catch {
          if (current()) {
            clear()
            emit({ session: { ...idle, status: 'error' }, error: 'Не удалось запустить браузерную сессию' })
          }
        }
      })()
      pending = activation
      void activation.finally(() => { if (pending === activation) pending = null })
      return activation
    },
    async navigate(url) {
      if (disposed || !session || !state.session.capabilities.navigate) throw new Error('Навигация недоступна: backend capability отключена')
      await session.navigate(url)
    },
    async stop() { if (!disposed) await session?.stop() },
    setMobilePane: pane => emit({ mobilePane: pane }),
    dispose() {
      if (disposed) return
      disposed = true
      generation++
      loadGeneration++
      clear()
      listeners.clear()
    }
  }
}
