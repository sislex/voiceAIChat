import { defineConfig } from 'vitest/config'
import react from '@vitejs/plugin-react'
import { sharedSource } from '../../scripts/shared-path.mjs'
import { createGateway, localConfig } from './gateway.mjs'
const config = localConfig()
export default defineConfig({
  plugins: [react(), { name: 'studio-local-dependencies', configureServer(server) { server.middlewares.use(createGateway(config)) } }],
  resolve: { alias: [{ find: /^@shared\//, replacement: sharedSource() }] },
  server: { host: '127.0.0.1', port: config.port, strictPort: true },
  test: { environment: 'node', environmentMatchGlobs: [['src/**/*.dom.test.tsx', 'jsdom']], setupFiles: ['@voicechat/ui-foundation/test/setup'], include: ['src/**/*.test.{ts,tsx}', '*.test.mjs'] }
})
