import { describe, expect, it, vi } from 'vitest'
import { createStudioClient } from './api'

describe('standalone studio HTTP contract', () => {
  it('keeps binary reads authenticated and encodes gallery and image names', async () => {
    const fetcher = vi.fn<typeof fetch>().mockResolvedValue(new Response(new Uint8Array([0, 255, 128])))
    const client = createStudioClient(fetcher, () => 'vc_csrf=a%2Bb')
    expect(await client.api['imgstudio:read']({ conversationId: 'a/b', path: 'x +.png' })).toEqual({ path: 'x +.png', dataBase64: 'AP+A' })
    const [url, init] = fetcher.mock.calls[0]!
    expect(url).toBe('/api/image-studio/a%2Fb/file?path=x%20%2B.png')
    expect(init?.credentials).toBe('include')
    expect(new Headers(init?.headers).get('x-vc-csrf')).toBe('a+b')
    expect(new Headers(init?.headers).has('authorization')).toBe(false)
  })
  it('creates only image galleries and does not send empty JSON on logout', async () => {
    const fetcher = vi.fn<typeof fetch>().mockImplementation(async () => new Response('{}'))
    const client = createStudioClient(fetcher, () => 'vc_csrf=csrf')
    await client.createGallery('Gallery')
    expect(JSON.parse(String(fetcher.mock.calls[0]![1]?.body))).toEqual({ title: 'Gallery', scope: 'images', assistantKind: 'images' })
    await client.logout()
    expect(new Headers(fetcher.mock.calls[1]![1]?.headers).has('content-type')).toBe(false)
    expect(fetcher.mock.calls[1]![1]?.method).toBe('POST')
  })
  it('preserves authorization failures for the shell and gallery', async () => {
    const client = createStudioClient(vi.fn<typeof fetch>().mockResolvedValue(new Response('{}', { status: 401 })), () => '')
    await expect(client.me()).rejects.toMatchObject({ status: 401 })
  })
})
