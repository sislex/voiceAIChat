import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { App } from './App'
import { HttpError, type StudioClient } from './api'
vi.mock('@voicechat/image-studio-app/components/ImageStudioPane', () => ({ ImageStudioPane: ({ conversationId }: { conversationId: string }) => <div data-testid="studio-panel">{conversationId}</div> }))
afterEach(() => { cleanup(); history.replaceState(null, '', '/'); sessionStorage.clear() })
function client(overrides: Partial<StudioClient> = {}): StudioClient {
  return { api: {} as StudioClient['api'], me: vi.fn().mockResolvedValue({ user: { name: 'artist' } }), galleries: vi.fn().mockResolvedValue([{ id: 'image-1', title: 'Первая', assistantKind: 'images' }, { id: 'chat-1', title: 'Chat', assistantKind: 'chat' }]), createGallery: vi.fn().mockResolvedValue({ id: 'image-2', title: 'Вторая', assistantKind: 'images' }), logout: vi.fn().mockResolvedValue(undefined), ...overrides }
}
describe('standalone studio', () => {
  it('offers Identity sign-in without rendering chat or gallery for anonymous users', async () => {
    const api = client({ me: vi.fn().mockRejectedValue(new HttpError(401, 'Войдите снова')) })
    render(<App client={api} />)
    expect(await screen.findByRole('link', { name: 'Войти' })).toHaveAttribute('href', '/login/')
    expect(api.galleries).not.toHaveBeenCalled()
    expect(screen.queryByTestId('studio-panel')).not.toBeInTheDocument()
  })
  it('shows only image galleries, creates one and clears the panel after logout', async () => {
    const api = client()
    render(<App client={api} />)
    expect(await screen.findByTestId('studio-panel')).toHaveTextContent('image-1')
    expect(screen.queryByRole('option', { name: 'Chat' })).not.toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: 'Новая галерея' }))
    fireEvent.change(screen.getByLabelText('Название галереи'), { target: { value: 'Вторая' } })
    fireEvent.click(screen.getByRole('button', { name: 'Создать' }))
    await waitFor(() => expect(screen.getByTestId('studio-panel')).toHaveTextContent('image-2'))
    expect(api.createGallery).toHaveBeenCalledWith('Вторая')
    fireEvent.click(screen.getByRole('button', { name: 'Выйти' }))
    await screen.findByRole('link', { name: 'Войти' })
    expect(screen.queryByTestId('studio-panel')).not.toBeInTheDocument()
  })
  it('preserves a gallery deep link including its viewer path', async () => {
    history.replaceState(null, '', '/#/images/image-1/cat.png')
    render(<App client={client()} />)
    await screen.findByTestId('studio-panel')
    expect(location.hash).toBe('#/images/image-1/cat.png')
  })
  it('keeps the signed-in account visible when gallery access is denied', async () => {
    render(<App client={client({ galleries: vi.fn().mockRejectedValue(new HttpError(403, 'Студия недоступна для вашего тарифа')) })} />)
    expect(await screen.findByRole('alert')).toHaveTextContent('Студия недоступна')
    expect(screen.getByText('artist')).toBeInTheDocument()
  })
})
