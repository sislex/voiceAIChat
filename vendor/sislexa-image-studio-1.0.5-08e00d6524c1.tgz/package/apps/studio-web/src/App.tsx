import { useCallback, useEffect, useState } from 'react'
import { ImageStudioPane } from '@voicechat/image-studio-app/components/ImageStudioPane'
import { Button, Dialog, UiProviders } from '@voicechat/ui-kit'
import type { Conversation, SessionUser } from '@shared/types'
import { createStudioClient, HttpError, type StudioClient } from './api'

const defaultClient = createStudioClient()
function galleryInHash() {
  try { return decodeURIComponent(location.hash.match(/^#\/images\/([^/]+)/)?.[1] ?? '') } catch { return '' }
}
export function App({ client = defaultClient }: { client?: StudioClient }) {
  const [user, setUser] = useState<SessionUser | null>(null)
  const [galleries, setGalleries] = useState<Conversation[]>([])
  const [active, setActive] = useState(galleryInHash)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [creating, setCreating] = useState(false)
  const [busy, setBusy] = useState(false)
  const [title, setTitle] = useState('')
  const select = (id: string) => { location.hash = `/images/${encodeURIComponent(id)}`; setActive(id) }
  const fail = useCallback((cause: unknown) => {
    if (cause instanceof HttpError && cause.status === 401) { setUser(null); setGalleries([]) }
    setError(cause instanceof Error ? cause.message : 'Не удалось загрузить студию.')
  }, [])
  const load = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const { user: current } = await client.me()
      setUser(current)
      if (!current) { setGalleries([]); return }
      const items = (await client.galleries()).filter(item => item.assistantKind === 'images')
      setGalleries(items)
      const requested = galleryInHash() || sessionStorage.getItem('studio-return-gallery') || ''
      sessionStorage.removeItem('studio-return-gallery')
      if (items.some(item => item.id === requested)) {
        if (!galleryInHash()) select(requested)
        else setActive(requested)
      } else if (items[0]) select(items[0].id)
      else setActive('')
    } catch (cause) { fail(cause) } finally { setLoading(false) }
  }, [client, fail])
  useEffect(() => { void load() }, [load])
  useEffect(() => {
    const change = () => setActive(galleryInHash())
    addEventListener('hashchange', change)
    return () => removeEventListener('hashchange', change)
  }, [])
  const gallery = galleries.find(item => item.id === active)
  return <UiProviders><div className="studio-app">
    <header className="studio-header"><div className="studio-brand"><span aria-hidden="true">✦</span><div><h1>Image Studio</h1><p>Sislexa</p></div></div>
      {user && <div className="studio-account"><span>{user.name}</span><Button variant="ghost" disabled={busy} onClick={async () => {
        setBusy(true); setError('')
        try { await client.logout(); setUser(null); setGalleries([]); setActive(''); location.hash = '' } catch (cause) { fail(cause) } finally { setBusy(false) }
      }}>Выйти</Button></div>}
    </header>
    {error && <div className="studio-error" role="alert">{error} <Button onClick={() => void load()}>Повторить</Button></div>}
    {loading ? <main className="studio-welcome" role="status">Загружаем студию…</main> : !user ? <main className="studio-welcome"><h2>Ваши идеи в картинках</h2><p>Создавайте, загружайте и редактируйте изображения в своих галереях.</p><a className="studio-login" href="/login/" onClick={() => { if (active) sessionStorage.setItem('studio-return-gallery', active) }}>Войти</a></main> : <>
      <nav className="studio-galleries" aria-label="Галереи"><label htmlFor="gallery">Галерея</label><select id="gallery" value={gallery?.id ?? ''} onChange={event => select(event.target.value)} disabled={!galleries.length}><option value="" disabled>Выберите галерею</option>{galleries.map(item => <option key={item.id} value={item.id}>{item.title || 'Без названия'}</option>)}</select><Button onClick={() => { setTitle(''); setCreating(true) }}>Новая галерея</Button></nav>
      <main className="studio-content">{gallery ? <ImageStudioPane key={gallery.id} conversationId={gallery.id} api={client.api} otherChats={galleries.filter(item => item.id !== gallery.id).map(({ id, title }) => ({ id, title }))} /> : <div className="studio-welcome"><h2>{galleries.length ? 'Выберите галерею' : 'Создайте первую галерею'}</h2><p>Здесь появятся ваши изображения и инструменты для работы с ними.</p><Button onClick={() => { setTitle(''); setCreating(true) }}>Создать галерею</Button></div>}</main>
    </>}
    {creating && <Dialog title="Новая галерея" padded onClose={() => { if (!busy) setCreating(false) }}><form className="studio-create" onSubmit={async event => {
      event.preventDefault(); if (!title.trim() || busy) return
      setBusy(true); setError('')
      try { const created = await client.createGallery(title.trim()); setGalleries(items => [created, ...items]); select(created.id); setCreating(false) } catch (cause) { fail(cause) } finally { setBusy(false) }
    }}><label htmlFor="gallery-title">Название галереи</label><input id="gallery-title" autoFocus maxLength={200} value={title} onChange={event => setTitle(event.target.value)} disabled={busy} /><Button type="submit" disabled={busy || !title.trim()}>{busy ? 'Создаём…' : 'Создать'}</Button></form></Dialog>}
  </div></UiProviders>
}
