import { request as httpRequest } from 'node:http'
import { request as httpsRequest } from 'node:https'

// This gateway is local development infrastructure: it never injects a service credential.
export function createGateway({ coreUrl, apiUrl, port }) {
  const core = new URL(coreUrl), api = new URL(apiUrl)
  for (const url of [core, api]) {
    if (url.username || url.password || url.pathname !== '/' || url.search || url.hash ||
        !(url.protocol === 'https:' || (url.protocol === 'http:' && ['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname)))) {
      throw new Error('Dependencies must be HTTPS origins or loopback HTTP origins without credentials')
    }
  }
  const hosts = new Set([`127.0.0.1:${port}`, `localhost:${port}`])
  return function gateway(req, res, next) {
    const fail = (status, error) => { res.writeHead(status, { 'content-type': 'application/json', 'cache-control': 'no-store' }); res.end(JSON.stringify({ error })) }
    if (!hosts.has(req.headers.host) || (req.headers.origin && req.headers.origin !== `http://${req.headers.host}`)) return fail(403, 'local_origin_required')
    let url
    try { url = new URL(req.url, `http://${req.headers.host}`) } catch { return fail(400, 'invalid_url') }
    if (url.pathname === '/account' || url.pathname === '/account/') {
      res.writeHead(302, { location: '/', 'cache-control': 'no-store' }); res.end(); return
    }
    const imageRoute = url.pathname.startsWith('/api/image-studio/') || url.pathname.startsWith('/g/')
    const sessionRoute = /^\/api\/session\/(?:me|login|logout|2fa|signup(?:\/resend)?|verify|register|reset(?:\/request|\/email)?|invite\/[^/]+)$/.test(url.pathname)
    const coreRoute = sessionRoute || url.pathname === '/api/conversations' || url.pathname.startsWith('/login/')
    if (!imageRoute && !coreRoute) {
      if (/^\/(?:api|internal|v1|mcp|ws|applications)(?:\/|$)/.test(url.pathname)) return fail(404, 'not_found')
      return next()
    }
    const upstream = imageRoute ? api : core
    const headers = { ...req.headers }
    for (const key of Object.keys(headers)) {
      if (key.startsWith('x-forwarded-') || ['forwarded', 'connection', 'proxy-authorization', 'proxy-connection'].includes(key)) delete headers[key]
    }
    // The local origin is retained so Core can enforce cookie/Origin/CSRF checks.
    headers['x-forwarded-proto'] = 'http'
    headers['x-forwarded-host'] = req.headers.host
    const proxy = (upstream.protocol === 'https:' ? httpsRequest : httpRequest)({ hostname: upstream.hostname, port: upstream.port || undefined, method: req.method, path: url.pathname + url.search, headers }, response => {
      const out = { ...response.headers, 'cache-control': 'no-store' }
      delete out.connection
      if (out['set-cookie']) out['set-cookie'] = out['set-cookie'].map(cookie => cookie.replace(/^__Secure-/, '').replace(/;\s*Secure\b/ig, '').replace(/;\s*Domain=[^;]+/ig, ''))
      if (typeof out.location === 'string' && out.location.startsWith(upstream.origin + '/')) out.location = out.location.slice(upstream.origin.length)
      res.writeHead(response.statusCode || 502, out)
      response.on('error', () => res.destroy())
      response.pipe(res)
    })
    proxy.on('error', () => { if (!res.headersSent) fail(502, 'local_dependency_unavailable'); else res.destroy() })
    req.on('aborted', () => proxy.destroy())
    res.on('close', () => { if (!res.writableFinished) proxy.destroy() })
    req.pipe(proxy)
  }
}

export function localConfig(env = process.env) {
  const port = Number(env.STUDIO_PORT || 18897)
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid STUDIO_PORT')
  return { port, coreUrl: env.STUDIO_CORE_URL || 'http://127.0.0.1:8787', apiUrl: env.STUDIO_API_URL || 'http://127.0.0.1:8796' }
}
