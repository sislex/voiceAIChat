import { afterEach, describe, expect, it } from 'vitest'
import { createServer, request } from 'node:http'
import { createGateway } from './gateway.mjs'
const servers = []
async function listen(handler) { const server = createServer(handler); servers.push(server); await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); return server }
afterEach(async () => { await Promise.all(servers.splice(0).map(server => new Promise(resolve => { server.closeAllConnections(); server.close(resolve) }))) })
function get(port, path, headers = {}) {
  return new Promise((resolve, reject) => {
    const req = request({ hostname: '127.0.0.1', port, path, headers }, res => { let body = ''; res.on('data', chunk => body += chunk); res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body })) })
    req.on('error', reject); req.end()
  })
}
describe('local gateway boundaries', () => {
  it('serves the studio locally, uses separate dependencies and rejects unrelated APIs and foreign origins', async () => {
    const seen = []
    const dependency = label => async (req, res) => { seen.push({ label, url: req.url, headers: req.headers }); res.setHeader('set-cookie', '__Secure-vc_session=test; HttpOnly; Secure; Domain=example.test; Path=/'); res.end(label) }
    const core = await listen(dependency('core')), api = await listen(dependency('image'))
    let gateway
    const local = await listen((req, res) => gateway(req, res, () => res.end('standalone studio')))
    const port = local.address().port
    gateway = createGateway({ coreUrl: `http://127.0.0.1:${core.address().port}`, apiUrl: `http://127.0.0.1:${api.address().port}`, port })
    expect((await get(port, '/')).body).toBe('standalone studio')
    expect((await get(port, '/api/session/me', { cookie: 'vc_session=user', 'x-vc-csrf': 'csrf' })).body).toBe('core')
    const image = await get(port, '/api/image-studio/c/files')
    expect(image.body).toBe('image')
    expect(image.headers['set-cookie']).toEqual(['vc_session=test; HttpOnly; Path=/'])
    expect(seen[0].headers.cookie).toBe('vc_session=user')
    expect(seen[0].headers['x-vc-csrf']).toBe('csrf')
    expect(seen[1].headers.authorization).toBeUndefined()
    expect((await get(port, '/account/')).headers.location).toBe('/')
    for (const path of ['/api/admin/users', '/internal/image-studio', '/v1/health', '/ws', '/applications/chat/']) expect((await get(port, path)).status).toBe(404)
    expect((await get(port, '/api/session/me', { origin: 'https://evil.example' })).status).toBe(403)
    expect((await get(port, '/', { host: 'evil.example' })).status).toBe(403)
    expect(seen).toHaveLength(2)
  })
  it('rejects credentials in dependency settings and plaintext remote origins', () => {
    for (const coreUrl of ['http://example.com', 'https://secret@example.com', 'https://example.com/path']) expect(() => createGateway({ coreUrl, apiUrl: 'http://127.0.0.1:8796', port: 18897 })).toThrow()
  })
})
