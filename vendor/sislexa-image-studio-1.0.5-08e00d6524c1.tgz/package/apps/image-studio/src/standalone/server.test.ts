import { get, request as httpRequest } from 'node:http'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, expect, it } from 'vitest'
import type { FastifyInstance } from 'fastify'
import { INTERNAL_IMAGE_STUDIO_SERVICE_PATH } from '@voicechat/shared'
import { buildImageStudioServer } from './server.js'
import { loadImageStudioStandaloneConfig } from './config.js'
import { fakeCore } from '../test/fakeCore.js'

let app: FastifyInstance | undefined
let dir: string | undefined
afterEach(async () => { await app?.close(); if (dir) rmSync(dir, { recursive: true, force: true }) })

it('не запускает standalone без секрета внутреннего API', async () => {
  await expect(buildImageStudioServer({ config: loadImageStudioStandaloneConfig({}) })).rejects.toThrow('VC_INTERNAL_TOKEN')
})

it('не запускает standalone без секрета MCP', async () => {
  await expect(buildImageStudioServer({ config: loadImageStudioStandaloneConfig({ VC_INTERNAL_TOKEN: 'internal' }) })).rejects.toThrow('VC_MCP_SECRET')
})

it('без ядра закрывает приватный API, но оставляет здоровье и публичную маршрутизацию', async () => {
  dir = mkdtempSync(join(tmpdir(), 'studio-auth-'))
  app = (await buildImageStudioServer({ config: loadImageStudioStandaloneConfig({ VC_DATA_DIR: dir, VC_INTERNAL_TOKEN: 'internal', VC_MCP_SECRET: 'mcp' }),
    core: fakeCore().core, fetchImpl: async () => { throw new Error('core offline') } })).app
  const response = await app.inject({ url: '/api/image-studio/x/files' })
  expect(response.statusCode).toBe(503)
  expect(response.json()).toEqual({ error: 'core_unavailable' })
  expect((await app.inject('/v1/health')).json()).toMatchObject({ ok: true, service: 'image-studio', version: null, application: { applicationId: 'image-studio', version: null } })
  expect((await app.inject('/g/missing/')).statusCode).toBe(404)
  const badMethod = await app.inject({ method: 'POST', url: INTERNAL_IMAGE_STUDIO_SERVICE_PATH,
    headers: { authorization: 'Bearer internal' }, payload: { method: 'constructor', args: [] } })
  expect(badMethod.statusCode).toBe(400)
})


it('cancels generation and closes unfinished uploads/downloads on shutdown', async () => {
  dir = mkdtempSync(join(tmpdir(), 'studio-close-'))
  const fixture = fakeCore()
  const conversation = await fixture.createConversation('alice', 'Shutdown', 'images')
  let started!: () => void
  const generationStarted = new Promise<void>(resolve => { started = resolve })
  let cancelled = false
  fixture.core.generate = async (_user, input) => new Promise<Buffer>((_resolve, reject) => {
    input.onCancel?.(() => { cancelled = true; reject(new Error('cancelled')) })
    started()
  })
  const server = await buildImageStudioServer({
    config: loadImageStudioStandaloneConfig({ VC_DATA_DIR: dir, VC_INTERNAL_TOKEN: 'internal', VC_MCP_SECRET: 'mcp' }),
    core: fixture.core, fetchImpl: async () => Response.json({ ok: true, user: { name: 'alice', role: 'developer' } })
  })
  app = server.app
  const png = Buffer.alloc(8 * 1024 * 1024)
  Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]).copy(png)
  await server.studio.store.writeBuffer(conversation.id, 'slow.png', png)
  const base = await app.listen({ host: '127.0.0.1', port: 0 })
  const request = get(`${base}/api/image-studio/${conversation.id}/file?path=slow.png`)
  request.on('error', () => {})
  const download = await new Promise<import('node:http').IncomingMessage>((resolve, reject) => {
    request.once('response', response => { response.pause(); resolve(response) })
    request.once('error', reject)
  })
  const uploadReceived = new Promise<void>(resolve => app!.server.once('request', () => resolve()))
  const upload = httpRequest(`${base}/api/image-studio/${conversation.id}/file`, {
    method: 'POST', headers: { 'content-type': 'application/json', 'content-length': '1000000' }
  })
  upload.on('error', () => {})
  upload.write('{')
  await uploadReceived
  const running = fetch(`${base}/api/image-studio/${conversation.id}/generate`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ prompt: 'wait' })
  }).then(response => response.status, () => 503)
  let timeout: ReturnType<typeof setTimeout> | undefined
  try {
    await generationStarted
    await Promise.race([app.close(), new Promise<never>((_resolve, reject) => {
      timeout = setTimeout(() => reject(new Error('Shutdown retained an active connection')), 2000)
    })])
    expect(cancelled).toBe(true)
    expect([410, 503]).toContain(await running)
  } finally {
    clearTimeout(timeout)
    download.destroy(); request.destroy(); upload.destroy(); app.server.closeAllConnections()
  }
})
