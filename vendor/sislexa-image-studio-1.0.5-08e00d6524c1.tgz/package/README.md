# Sislexa image-studio

Independent application source, tests, versioned release archives and Docker images.
Node 22.13 or newer is required for managed provider token registries.

```sh
npm ci
npm run gate
npm start
```

Set dependency endpoints and credentials in your process environment or use
`SISLEXA_COMPONENT_CONFIG` pointing to an installation JSON. Examples live in
`config/`; paths must be absolute and token files private (0600). The process does
not load `.env` implicitly. Legacy token env variables remain supported for migration.
Provider-issued tokens are scoped, expiring and immediately revocable. Component
credentials do not replace user authentication. See [operations](docs/operations.md).

`dependency-snapshots.json` records immutable shared-library archives and source
provenance. No neighboring checkout or private npm registry is needed. `npm pack`
requires a clean commit and embeds its full SHA. Consumers pin version, SHA and integrity.

## Standalone browser studio

The repository also owns `apps/studio-web`: a complete Image Studio page with
gallery selection, creation, image tools and Identity sign-in. It bundles its own
React runtime and does not load the Core chat shell. The existing host-loaded
panel remains available for integrations.

```sh
STUDIO_CORE_URL=http://127.0.0.1:18787 \
STUDIO_API_URL=http://127.0.0.1:18896 npm run studio
```

Open http://127.0.0.1:18897/. Dependencies must already be running; the example
uses a private SSH forward to production Core and a local Image Studio API.
Use `npm run dev:studio` with the same variables for Vite hot reload.
See [operations](docs/operations.md#standalone-browser-studio) for routing and data ownership.
