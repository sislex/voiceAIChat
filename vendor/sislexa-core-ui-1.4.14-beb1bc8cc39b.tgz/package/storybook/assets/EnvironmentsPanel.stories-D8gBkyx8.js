import{j as C}from"./jsx-runtime-BYYWji4R.js";import{userEvent as o,within as S}from"./index-DeN4tkzB.js";import{a as we}from"./fakeApi-Cg9lBluw.js";import{EnvironmentsPanel as j}from"./EnvironmentsPanel-CL2a3rRr.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-Cwn0-pDj.js";import"./types-DFdjDDUq.js";import"./tools-D2dVYbOd.js";import"./agentProtocol-ChPLBt7B.js";import"./projects-B9njsDhM.js";import"./projectTypes-C-9aONcK.js";import"./ci-DFdZK10C.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./dateFormat-Mm5g7L0f.js";import"./release-C-C1sGXa.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./environmentsBridge-BFm_ME7X.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";const r={id:"test-stand",projectId:"p1",name:"Проверка",mode:"managed",state:"draft",storageId:"storage-1",machines:["machine-1"],checkoutPath:"/storage/stand/app",composeProject:"sx-test-stand",port:null,createdBy:"owner",createdAt:1,updatedAt:1},ke=[{agentId:"machine-1",name:"Готовая машина",path:"",reposRoot:"",storageId:"storage-1",storage:{id:"storage-1",machineId:"machine-1",rootPath:"/storage",status:"ready",formatVersion:1}},{agentId:"machine-2",name:"Хранилище недоступно",path:"",reposRoot:"",storageId:"storage-2",storage:{id:"storage-2",machineId:"machine-2",rootPath:"/storage",status:"offline",formatVersion:1}}],P=[{key:"VC_ADMIN_PASSWORD",label:"Пароль администратора",secret:!0,required:!0,generated:!1,set:!0,value:null,source:"user",updatedBy:"owner",updatedAt:1},{key:"VC_PUBLIC_URL",label:"Публичный адрес",secret:!1,required:!1,generated:!1,set:!0,value:"https://stand.example",source:"user",updatedBy:"owner",updatedAt:1}],Ae={environmentId:r.id,machineId:"machine-1",checkedAt:1,ready:!1,port:17800,checks:[{id:"docker",status:"passed",message:"Docker доступен"},{id:"memory",status:"warning",message:"Рекомендуется 8 ГБ"},{id:"disk",status:"failed",message:"Недостаточно места"}]},s=Date.UTC(2026,9,2,9,0),n=e=>e.repeat(40),k="https://github.com/sislex/sislexa-kanban",A="https://github.com/sislex/make",B="https://github.com/sislex/sielexa-ui",I={mode:"external",storageId:null,state:"ready",composeProject:null,port:null,id:"production",projectId:"p1",name:"Production",machines:["prod-89.125.68.35"],checkoutPath:"/root/ChatAI/voiceAIChat",createdBy:"admin",createdAt:s,updatedAt:s},Ie={...I,id:"staging",name:"Staging",machines:["makbook-m1"],checkoutPath:"/Users/alex/stage"},ge=[{core:null,id:"c2",environmentId:"production",revision:2,note:"Kanban 0.1.2 на проверку",createdBy:"admin",createdAt:s-6e5,modules:[{repository:k,version:"0.1.2",commit:n("b")},{repository:A,version:"1.3.1",commit:n("e")},{repository:B,version:"0.1.4",commit:n("d")}]},{core:null,id:"c1",environmentId:"production",revision:1,note:"Initial observation",createdBy:"admin",createdAt:s-864e5,modules:[{repository:k,version:"0.1.1",commit:n("a")},{repository:A,version:"1.3.1",commit:n("e")},{repository:B,version:"0.1.3",commit:n("3")}]}],ye=[{repository:k,name:"Kanban",services:["kanban"],desired:{version:"0.1.2",commit:n("b")},actual:{version:"0.1.1",commit:n("a")},action:"switch",reason:null},{repository:A,name:"Make",services:["make-api","make-worker"],desired:{version:"1.3.1",commit:n("e")},actual:{version:"1.3.1",commit:n("e")},action:"none",reason:null}],Ee={repository:B,name:"UI Kit",services:[],desired:{version:"0.1.4",commit:n("d")},actual:{version:"0.1.3",commit:n("3")},action:"needs_core_release",reason:"Module is embedded in Core"},E=(e,a="")=>({service:"kanban",from:`ghcr.io/sislex/kanban:${n("a")}`,to:`ghcr.io/sislex/kanban:${n("b")}`,status:e,log:a}),R={kind:"apply",id:"op1",environmentId:"production",configurationId:"c2",previousConfigurationId:"c1",status:"succeeded",steps:[E("passed",`pulling
switching
healthy`)],startedBy:"admin",startedAt:s-3e5,finishedAt:s-24e4,error:null},i={...R,id:"op2",status:"health_check",steps:[E("running",`pulling
switching`)],startedAt:s-2e4,finishedAt:null},Se={baseBranch:"main",applications:[{repository:k,name:"Kanban",applicationId:"kanban",current:null,releases:[{version:"0.1.3",commit:n("c"),publishedAt:"2026-10-02T08:00:00Z"},{version:"0.1.2",commit:n("b"),publishedAt:"2026-10-01T08:00:00Z"}]},{repository:A,name:"Make",applicationId:"make",current:null,releases:[{version:"1.3.2",commit:n("f"),publishedAt:"2026-10-01T09:30:00Z"},{version:"1.3.1",commit:n("e"),publishedAt:"2026-09-30T18:00:00Z"}]}]};function c(e={}){const a={observation:{environmentId:"production",machineId:I.machines[0],observedAt:s,core:{version:"0.1.360",commit:n("9")},services:[]},core:{desired:null,actual:{version:"0.1.360",commit:n("9")},action:"none"},modules:e.modules??ye},m=e.configurations??ge;return{"environments:list":async()=>e.list??[I,Ie],"environments:configurations":async()=>m,"environments:saveConfiguration":async({modules:M,note:be})=>({...m[0],id:"c3",revision:3,modules:M,note:be}),"environments:observe":async()=>a.observation,"environments:diff":async()=>a,"environments:apply":async()=>({...i,status:"pending",steps:[E("pending")]}),"environments:operations":async()=>e.operations??[R],"environments:rollback":async()=>({...i,id:"op3",configurationId:"c1",status:"pending",steps:[E("pending")]})}}function he(){const e=we();return e["releases:composition"]=async()=>Se,e}const Xe={title:"Operations/Releases/EnvironmentsPanel",component:j,args:{projectId:"p1",baseBranch:"main",owner:!0,environments:c(),api:he(),onComposeCore:()=>{}},render:e=>C.jsx("div",{style:{maxWidth:960,padding:16},children:C.jsx(j,{...e})})},d={},p={args:{environments:c({operations:[i,R]})}},l={args:{environments:c({modules:[...ye,Ee]})}},u={args:{environments:c({list:[],configurations:[],operations:[]})}},v={args:{owner:!1,onComposeCore:void 0}},g={parameters:{viewport:{defaultViewport:"mobile1"}}},y={play:async({canvasElement:e})=>{const a=S(e);await o.click(await a.findByRole("button",{name:"Изменить версии"})),await o.selectOptions(await a.findByLabelText("Выбрать версию Kanban"),`0.1.3@${n("c")}`)}},fe={...c({list:[r,I],configurations:[],operations:[]}),"environments:create":async({id:e,name:a,machineId:m,storageId:M})=>({...r,id:e,name:a,machines:[m],storageId:M}),"environments:readiness":async()=>Ae,"environments:settings":async()=>P,"environments:saveSettings":async()=>P,"environments:provision":async()=>({...i,kind:"provision",id:"provision",status:"preparing",steps:[{kind:"stage",service:"readiness",from:null,to:"ready",status:"running",log:""}]}),"environments:remove":async()=>({...i,kind:"remove",id:"remove",status:"removing",steps:[{kind:"stage",service:"down",from:null,to:"stopped",status:"running",log:""}]})},x=he();x["projects:get"]=async()=>({machines:ke});const t={args:{environments:fe,api:x}},h={args:{environments:{...fe,"environments:list":async()=>[{...r,state:"ready",port:17800}],"environments:configurations":async()=>[{...ge[0],environmentId:r.id}]},api:x}},f={...t,play:async({canvasElement:e})=>{await o.click(await S(e).findByRole("button",{name:"Новое окружение"}))}},b={...t,play:async({canvasElement:e})=>{await o.click(await S(e).findByRole("button",{name:"Проверить машину"}))}},w={...t,play:async({canvasElement:e})=>{await o.click(await S(e).findByRole("button",{name:"Настройки и секреты"}))}};var O,_,D;d.parameters={...d.parameters,docs:{...(O=d.parameters)==null?void 0:O.docs,source:{originalSource:"{}",...(D=(_=d.parameters)==null?void 0:_.docs)==null?void 0:D.source}}};var K,T,V;p.parameters={...p.parameters,docs:{...(K=p.parameters)==null?void 0:K.docs,source:{originalSource:`{
  args: {
    environments: environments({
      operations: [running, succeeded]
    })
  }
}`,...(V=(T=p.parameters)==null?void 0:T.docs)==null?void 0:V.source}}};var U,N,L;l.parameters={...l.parameters,docs:{...(U=l.parameters)==null?void 0:U.docs,source:{originalSource:`{
  args: {
    environments: environments({
      modules: [...modules, embedded]
    })
  }
}`,...(L=(N=l.parameters)==null?void 0:N.docs)==null?void 0:L.source}}};var Z,$,q;u.parameters={...u.parameters,docs:{...(Z=u.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    environments: environments({
      list: [],
      configurations: [],
      operations: []
    })
  }
}`,...(q=($=u.parameters)==null?void 0:$.docs)==null?void 0:q.source}}};var W,F,z;v.parameters={...v.parameters,docs:{...(W=v.parameters)==null?void 0:W.docs,source:{originalSource:`{
  args: {
    owner: false,
    onComposeCore: undefined
  }
}`,...(z=(F=v.parameters)==null?void 0:F.docs)==null?void 0:z.source}}};var G,H,J;g.parameters={...g.parameters,docs:{...(G=g.parameters)==null?void 0:G.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(J=(H=g.parameters)==null?void 0:H.docs)==null?void 0:J.source}}};var Q,X,Y;y.parameters={...y.parameters,docs:{...(Q=y.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByRole('button', {
      name: 'Изменить версии'
    }));
    await userEvent.selectOptions(await canvas.findByLabelText('Выбрать версию Kanban'), \`0.1.3@\${sha('c')}\`);
  }
}`,...(Y=(X=y.parameters)==null?void 0:X.docs)==null?void 0:Y.source}}};var ee,ne,ae;t.parameters={...t.parameters,docs:{...(ee=t.parameters)==null?void 0:ee.docs,source:{originalSource:`{
  args: {
    environments: managedApi,
    api: projectApi
  }
}`,...(ae=(ne=t.parameters)==null?void 0:ne.docs)==null?void 0:ae.source}}};var se,te,oe;h.parameters={...h.parameters,docs:{...(se=h.parameters)==null?void 0:se.docs,source:{originalSource:`{
  args: {
    environments: {
      ...managedApi,
      'environments:list': async () => [{
        ...managedEnvironment,
        state: 'ready',
        port: 17800
      }],
      'environments:configurations': async () => [{
        ...configurations[0]!,
        environmentId: managedEnvironment.id
      }]
    },
    api: projectApi
  }
}`,...(oe=(te=h.parameters)==null?void 0:te.docs)==null?void 0:oe.source}}};var re,ie,ce;f.parameters={...f.parameters,docs:{...(re=f.parameters)==null?void 0:re.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Новое окружение'
    }));
  }
}`,...(ce=(ie=f.parameters)==null?void 0:ie.docs)==null?void 0:ce.source}}};var me,de,pe;b.parameters={...b.parameters,docs:{...(me=b.parameters)==null?void 0:me.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Проверить машину'
    }));
  }
}`,...(pe=(de=b.parameters)==null?void 0:de.docs)==null?void 0:pe.source}}};var le,ue,ve;w.parameters={...w.parameters,docs:{...(le=w.parameters)==null?void 0:le.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Настройки и секреты'
    }));
  }
}`,...(ve=(ue=w.parameters)==null?void 0:ue.docs)==null?void 0:ve.source}}};const Ye=["SwitchOneService","Applying","EmbeddedModules","NotObserved","ReadOnlyMember","Mobile","EditVersions","ManagedDraft","ManagedReady","CreateManaged","MachineReadiness","SettingsAndSecrets"];export{p as Applying,f as CreateManaged,y as EditVersions,l as EmbeddedModules,b as MachineReadiness,t as ManagedDraft,h as ManagedReady,g as Mobile,u as NotObserved,v as ReadOnlyMember,w as SettingsAndSecrets,d as SwitchOneService,Ye as __namedExportsOrder,Xe as default};
