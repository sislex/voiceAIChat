# Sislexa voice

Independent application source, tests, versioned release archives and Docker images.
Node 22.13 or newer is required for managed provider token registries.

```sh
npm ci
npm run gate
npm run start:stt
# In a second terminal, with a different PORT and data directory:
npm run start:tts
```

Set dependency endpoints and credentials in your process environment or use
`SISLEXA_COMPONENT_CONFIG` pointing to an installation JSON. Examples live in
`config/`; paths must be absolute and token files private (0600). The process does
not load `.env` implicitly. Legacy token env variables remain supported for migration.
Provider-issued tokens are scoped, expiring and immediately revocable. Component
credentials do not replace user authentication. See [operations](docs/operations.md).

`dependency-snapshots.json` records immutable shared-library archives and source
provenance. No neighboring checkout or private npm registry is needed. `npm pack`
requires a clean commit and embeds its full SHA. Consumers pin version, SHA and integrity.
