import { defineConfig } from 'vitest/config'
import { sharedSource } from '../../scripts/shared-path.mjs'
export default defineConfig({ resolve: { alias: [{find: /^@shared\//, replacement: sharedSource()}] }, test: {include: ['src/**/*.test.ts']} })
