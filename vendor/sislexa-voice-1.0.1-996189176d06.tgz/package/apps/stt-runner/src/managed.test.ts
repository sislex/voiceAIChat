import { it, expect } from 'vitest'
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createComponentRuntime } from '@sislexa/component-runtime'
import { buildRunner as build } from './server.js'
import { loadSttRunnerConfig as config } from './config.js'
it('enforces provider scopes and immediate revocation without sharing the legacy secret', async () => {
 const root=mkdtempSync(join(tmpdir(),'managed-stt-runner-'))
 const configFile=join(root,'config.json')
 const installation={schemaVersion:1,environmentId:'test',registryDirectory:join(root,'registry'),grants:[{consumerId:'core',scopes:['stt-runner.read'],maxTtlSeconds:3600}],legacyScopes:[],dependencies:[]}
 writeFileSync(configFile,JSON.stringify(installation),{mode:0o600})
 const issuer=await createComponentRuntime({contractFile:fileURLToPath(new URL('../component-contract.json',import.meta.url)),configFile,metadata:{applicationId:'stt-runner',version:'1.0.0',apiVersion:'1.1.0',dataVersion:'1.0.0',commit:'a'.repeat(40)}})
 const token=issuer.registry!.issue('core',['stt-runner.read'],60)
 const app=await build({config:config({SISLEXA_COMPONENT_CONFIG:configFile,VC_DATA_DIR:root,VC_TTS_DATA_DIR:root,VC_MCP_SECRET:'test-only',VC_PIPER_BIN:'/missing/piper',VC_SAY_BIN:'/missing/say'})})
 try {
  expect((await app.inject('/v1/component')).statusCode).toBe(200)
  expect((await app.inject({method:'GET',url:'/v1/models'})).statusCode).toBe(401)
  expect((await app.inject({method:'GET',url:'/v1/models',headers:{authorization:'Bearer '+token.token}})).statusCode).toBe(200)
  expect((await app.inject({method:'POST',url:'/v1/models/small/download',headers:{authorization:'Bearer '+token.token}})).statusCode).toBe(403)
  issuer.registry!.revoke(token.principal.tokenId)
  expect((await app.inject({method:'GET',url:'/v1/models',headers:{authorization:'Bearer '+token.token}})).statusCode).toBe(401)
 } finally {await app.close();issuer.close();rmSync(root,{recursive:true,force:true})}
})
