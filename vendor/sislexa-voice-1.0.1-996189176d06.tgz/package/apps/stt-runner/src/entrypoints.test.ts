import { it, expect } from 'vitest'
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createServer } from 'node:net'
import { spawn } from 'node:child_process'
it.each(['stt-runner', 'tts-runner'])('starts the real %s entrypoint with managed config and no legacy token', async id => {
  const root = mkdtempSync(join(tmpdir(), 'voice-entry-'))
  const reservation = createServer()
  await new Promise<void>(resolve => reservation.listen(0, '127.0.0.1', resolve))
  const address = reservation.address()
  if (!address || typeof address === 'string') throw Error('Expected TCP listener')
  const port = address.port
  await new Promise<void>(resolve => reservation.close(() => resolve()))
  const configFile = join(root, 'config.json')
  writeFileSync(configFile, JSON.stringify({ schemaVersion: 1, environmentId: 'test', registryDirectory: join(root, 'provider'), grants: [], legacyScopes: [], dependencies: [] }), { mode: 0o600 })
  const child = spawn(process.execPath, ['--import', 'tsx', fileURLToPath(new URL(`../../${id}/src/index.ts`, import.meta.url))], {
    stdio: 'ignore', env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', SISLEXA_COMPONENT_CONFIG: configFile, VC_DATA_DIR: root, VC_TTS_DATA_DIR: root, VC_STT_RUNNER_TOKEN: '', VC_TTS_RUNNER_TOKEN: '' },
  })
  const exited = new Promise<void>(resolve => child.once('exit', () => resolve()))
  try {
    let status = 0
    for (let attempt = 0; attempt < 60; attempt++) {
      if (child.exitCode !== null) throw Error('Managed entrypoint exited before readiness')
      try { status = (await fetch(`http://127.0.0.1:${port}/v1/component`)).status } catch {}
      if (status === 200) break
      await new Promise(resolve => setTimeout(resolve, 50))
    }
    expect(status).toBe(200)
    expect((await fetch(`http://127.0.0.1:${port}/v1/health`)).status).toBe(401)
  } finally {
    child.kill('SIGTERM')
    const timer = setTimeout(() => child.kill('SIGKILL'), 2000)
    await exited; clearTimeout(timer); rmSync(root, { recursive: true, force: true })
  }
})
