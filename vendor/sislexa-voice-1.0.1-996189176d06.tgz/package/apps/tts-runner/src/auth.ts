import type { ComponentRuntime } from '@sislexa/component-runtime'
import { timingSafeEqual } from 'node:crypto'
import type { FastifyInstance } from 'fastify'
export function registerTtsAuth(app:FastifyInstance,token:string,component?:ComponentRuntime):void {
 app.addHook('onRequest',async(req,reply)=>{if(!req.url.startsWith('/v1/'))return;if (['/v1/component', '/v1/component/authorize', '/v1/ready'].includes(req.url.split('?')[0]!)) return
    if (component) {
      const path = req.url.split('?')[0]!
      const scope = path === '/v1/health' || (req.method === 'GET' && (path === '/v1/models' || path === '/v1/voices')) ? 'read'
        : path.startsWith('/v1/models/') || path.startsWith('/v1/voices/') ? 'manage' : 'run'
      const verdict = component.authorize(req.headers.authorization, 'tts-runner.' + scope)
      if (!verdict.ok) return reply.code(verdict.status).send({ error: 'component_access_denied' })
      return
    }
    const got=req.headers.authorization?.replace(/^Bearer\s+/i,'')??'';const a=Buffer.from(got),b=Buffer.from(token);if(a.length!==b.length||!timingSafeEqual(a,b))return reply.code(401).send({error:'unauthorized'})})
}
