import * as fs from 'node:fs'
import { dirname, join, basename } from 'node:path'
import { createHash } from 'node:crypto'
import { execFileSync } from 'node:child_process'
import { get as httpGet } from 'node:http'
import { get as httpsGet } from 'node:https'
import { lookup } from 'node:dns'
import { isIP } from 'node:net'
import type { AgentToServer } from '@sislexa/agent-contracts'

export type UpdateResult = Extract<AgentToServer, { t: 'agent.updateResult' }>
export interface SelfUpdateDeps {
  fs: Pick<typeof fs, 'readFileSync' | 'writeFileSync' | 'renameSync' | 'rmSync'>
  fetch(url: URL): Promise<Buffer>
  check(file: string): void
  exit(code: number): void
  now(): number
}

/** Download from the control origin using the configured TLS policy. */
export function downloadAgent(url: URL): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const pinned = process.env.VC_VPN_CONTROL_IP
    const controlLookup: typeof lookup = pinned && isIP(pinned)
      ? ((_host: string, options: { all?: boolean }, callback: (...args: unknown[]) => void) => {
          const address = { address: pinned, family: isIP(pinned) }
          if (options.all) callback(null, [address])
          else callback(null, address.address, address.family)
        }) as typeof lookup
      : lookup
    const request = (url.protocol === 'https:' ? httpsGet : httpGet)(url, {
      rejectUnauthorized: !process.env.VC_AGENT_INSECURE_TLS,
      lookup: controlLookup
    }, response => {
      if (response.statusCode !== 200) { response.resume(); reject(new Error('download_failed')); return }
      const chunks: Buffer[] = []
      let size = 0
      response.on('data', (chunk: Buffer) => {
        size += chunk.length
        if (size > 64 * 1024 * 1024) request.destroy(new Error('download_too_large'))
        else chunks.push(chunk)
      })
      response.on('error', reject)
      response.on('end', () => resolve(Buffer.concat(chunks)))
    })
    const timeout = setTimeout(() => request.destroy(new Error('download_timeout')), 60_000)
    request.on('close', () => clearTimeout(timeout))
    request.on('error', reject)
  })
}

export class SelfUpdater {
  readonly supervisor: 'systemd' | 'launchd' | undefined
  private readonly deps: SelfUpdateDeps
  private readonly directory: string
  private busy = false
  constructor(private readonly options: { serverUrl: string; version: string; file?: string; supervisor?: string }, deps: Partial<SelfUpdateDeps> = {}) {
    this.supervisor = options.supervisor === 'systemd' || options.supervisor === 'launchd' ? options.supervisor : undefined
    this.directory = dirname(options.file ?? process.argv[1] ?? '')
    this.deps = { fs, fetch: downloadAgent, check: file => { execFileSync(process.execPath, ['--check', file], { timeout: 30_000, stdio: 'pipe' }) }, exit: code => process.exit(code), now: Date.now, ...deps }
  }
  private path(name: string): string { return join(this.directory, name) }
  private read(name: string): string | undefined {
    try { return this.deps.fs.readFileSync(this.path(name), 'utf8') as string }
    catch (error) { if ((error as NodeJS.ErrnoException).code === 'ENOENT') return undefined; throw error }
  }
  private write(name: string, value: unknown): void {
    const file = this.path(name)
    this.deps.fs.writeFileSync(file + '.tmp', JSON.stringify(value), { mode: 0o600 })
    this.deps.fs.renameSync(file + '.tmp', file)
  }
  /** An old binary must not confirm a new one. */
  async registered(report: (result: UpdateResult) => Promise<void>): Promise<void> {
    if (!this.supervisor) return
    try {
      if (this.read('update-rolled-back.json')) {
        await report({ t: 'agent.updateResult', status: 'rolled_back', message: 'Previous agent restored after registration timeout' })
        this.deps.fs.rmSync(this.path('update-rolled-back.json'), { force: true })
      }
      const pending = this.read('update-pending.json')
      if (pending && JSON.parse(pending).to === this.options.version) this.deps.fs.rmSync(this.path('update-pending.json'), { force: true })
    } catch { /* Keep unconfirmed state for the supervisor to recover. */ }
  }
  async update(request: { version: string; sha256: string }, report: (result: UpdateResult) => Promise<void>): Promise<void> {
    const result = (status: UpdateResult['status'], message: string) => report({ t: 'agent.updateResult', status, message })
    if (!this.supervisor) { await result('skipped_unsupervised', 'A systemd or launchd supervisor is required'); return }
    if (this.busy) { await result('failed', 'update_busy'); return }
    this.busy = true
    let rotated = false
    let installed = false
    try {
      if (basename(this.options.file ?? process.argv[1] ?? '') !== 'voicechat-agent.cjs') throw new Error('unsupported_bundle_path')
      if (!/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(request.version) || !/^[a-f\d]{64}$/i.test(request.sha256)) throw new Error('invalid_update')
      if (this.read('update-pending.json')) throw new Error('update_pending')
      const attempts: Record<string, number> = JSON.parse(this.read('update-attempts.json') ?? '{}')
      const now = this.deps.now()
      if (attempts[request.version] !== undefined && now - attempts[request.version] < 3_600_000) throw new Error('rate_limited')
      attempts[request.version] = now
      this.write('update-attempts.json', attempts)
      const url = new URL('/api/agents/script', this.options.serverUrl.replace(/^ws/, 'http'))
      const bytes = await this.deps.fetch(url)
      if (createHash('sha256').update(bytes).digest('hex') !== request.sha256.toLowerCase()) throw new Error('sha256_mismatch')
      this.deps.fs.writeFileSync(this.path('voicechat-agent.new.cjs'), bytes, { mode: 0o600 })
      this.deps.check(this.path('voicechat-agent.new.cjs'))
      this.deps.fs.renameSync(this.path('voicechat-agent.cjs'), this.path('voicechat-agent.cjs.prev'))
      rotated = true
      this.write('update-pending.json', { from: this.options.version, to: request.version, at: this.deps.now() })
      this.deps.fs.renameSync(this.path('voicechat-agent.new.cjs'), this.path('voicechat-agent.cjs'))
      installed = true
    } catch (error) {
      if (rotated) {
        this.deps.fs.renameSync(this.path('voicechat-agent.cjs.prev'), this.path('voicechat-agent.cjs'))
        this.deps.fs.rmSync(this.path('update-pending.json'), { force: true })
      }
      this.deps.fs.rmSync(this.path('voicechat-agent.new.cjs'), { force: true })
      // Only fixed failure codes leave the machine; errors may contain private data.
      const message = error instanceof Error && /^(unsupported_bundle_path|invalid_update|update_pending|rate_limited|sha256_mismatch)$/.test(error.message) ? error.message : 'update_failed'
      await result('failed', message)
    } finally { if (!installed) this.busy = false }
    if (installed) {
      try { await result('applied', 'Agent installed; restarting') }
      finally { this.deps.exit(0) }
    }
  }
}
