import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// Tests must not see the developer's or integrator's real ~/.voicechat: a live dev-process registry there starts
// recovery timers inside startConnection and breaks timer-count assertions.
process.env.HOME = mkdtempSync(join(tmpdir(), 'agent-test-home-'))
