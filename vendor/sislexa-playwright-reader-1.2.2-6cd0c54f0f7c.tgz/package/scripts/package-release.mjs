// Pack only clean owner-built inputs; consumers never compile the panel.
import { execFileSync } from 'node:child_process'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { join } from 'node:path'
const commit = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
if (execFileSync('git', ['status', '--porcelain'], { encoding: 'utf8' }).trim()) throw Error('Release requires a clean committed checkout')
mkdirSync('artifacts', { recursive: true })
const packages = []
for (const args of [[], ['-w', '@voicechat/playwright-reader-contracts'], ['-w', '@voicechat/browser-contracts']]) {
  const [packed] = JSON.parse(execFileSync('npm', ['pack', ...args, '--pack-destination', 'artifacts', '--json'], { encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 }))
  const bytes = readFileSync(join('artifacts', packed.filename))
  packages.push({ name: packed.name, version: packed.version, filename: packed.filename, integrity: packed.integrity,
    sha256: createHash('sha256').update(bytes).digest('hex'), repository: 'https://github.com/sislex/playwrightreader', commit })
}
writeFileSync('artifacts/integrity.json', JSON.stringify({ schemaVersion: 1, packages }, null, 2) + '\n')
