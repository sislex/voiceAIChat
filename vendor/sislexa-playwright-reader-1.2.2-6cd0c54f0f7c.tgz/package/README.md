# Sislexa playwright-reader

Independent repository for the playwright-reader API, its UI panel, and its public contracts.
The Chat/core repository is a remote runtime dependency, not a source dependency.

```sh
npm ci
npm run gate
# Set the values documented in .env.example in your shell, then:
npm start
```

The API listens on port 8797. `npm run dev:ui` rebuilds the host-loaded panel;
it does not provide authentication or the Chat host shell. Configure core and
other remote dependencies by URL and supply their credentials. This initial
extraction retains the existing delegated user authentication and internal token
protocol. Provider-specific token grants are a subsequent platform stage.

`dependency-snapshots.json` pins shared peer libraries by package version, source
commit, and archive integrity. Their source remains owned by the shared platform.
The repository works without a neighboring checkout or a private package registry.
Root `npm pack` creates the release consumed by Chat's compatibility adapters.
See [operations](docs/operations.md) for deployment and release requirements.

Browser frame helpers re-export the canonical Browser contract leaf directly.
The package boundary gate rejects Core Shared re-exports from the worker; owner
fixtures may still carry older Shared versions and cannot validate that boundary.
The UI gate also owns the four address-scheme regressions formerly run by Core.
