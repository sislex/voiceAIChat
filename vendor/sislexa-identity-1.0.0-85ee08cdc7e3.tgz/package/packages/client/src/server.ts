import type {FastifyInstance,FastifyRequest} from 'fastify'
import {IDENTITY_PATHS, type IdentitySessionResponse, type IdentityEvent} from '@voicechat/identity-contracts'
import {registerAuthGuard,previewRunUser,readCookie,SESSION_COOKIE, type AuthenticateFn, type AuthOptions} from '../../../apps/server/src/users/auth.js'
import {verifyToken} from '../../../apps/server/src/users/accounts.js'
import type {AuthDatabase} from '../../../apps/server/src/ports.js'
import {identityRpc,type IdentityTransport} from './rpc.js'
export async function registerRemoteIdentity(app:FastifyInstance,db:AuthDatabase,transport:IdentityTransport,secret:string,options:AuthOptions={}){
 app.decorateRequest('user',null)
 const authenticate:AuthenticateFn=async(req)=>{
  if(options.previewRunKeys&&!req.headers.authorization&&!readCookie(req,SESSION_COOKIE)&&!readCookie(req,'vc_preview_session')){const user=await previewRunUser(db,req,req.url.split('?')[0]!,options.previewRunKeys);if(user)return {ok:true,user}}
  return identityRpc(transport,IDENTITY_PATHS.verify,{request:{method:req.method,url:req.url,headers:req.headers}})
 }
 const sidOf=(req:FastifyRequest)=>verifyToken(req.headers.authorization?.replace(/^Bearer /,'' )??readCookie(req,SESSION_COOKIE),secret)?.sid??null
 registerAuthGuard(app,db,authenticate,sidOf)
 const proxy=async(req:FastifyRequest,reply:import('fastify').FastifyReply)=>{
  const headers:Record<string,string|string[]|undefined>={}
  for(const name of ['authorization','cookie','x-vc-csrf','user-agent','host','origin','x-forwarded-proto','x-forwarded-host','x-vc-client-version'])headers[name]=req.headers[name]
  if(req.body!==undefined)headers['content-type']='application/json'
  const result=await identityRpc<IdentitySessionResponse>(transport,IDENTITY_PATHS.session,{method:req.method,url:req.url,headers,ip:req.ip,body:req.body,corsAllowed:req.corsAllowed===true})
  for(const name of ['content-type','set-cookie','retry-after','cache-control']){const value=result.headers[name];if(value!==undefined)reply.header(name,value)}
  return reply.code(result.status).send(result.body)
 }
 for(const url of ['/api/session','/api/session/*'])app.route({method:['GET','POST','PATCH','DELETE','PUT'],url,handler:proxy})
 let after=0,epoch='',stopped=false,pending=false
 const poll=async()=>{if(stopped||pending)return;pending=true;try{
  const response=await(transport.fetchImpl??fetch)(new URL(IDENTITY_PATHS.events+'?after='+after+'&epoch='+encodeURIComponent(epoch),transport.url),{headers:{authorization:'Bearer '+transport.token},redirect:'error',signal:AbortSignal.timeout(5000)})
  if(!response.ok)return
  const result=await response.json() as {epoch:string;sequence:number;events:IdentityEvent[]}
  if(epoch&&epoch!==result.epoch)after=0
  epoch=result.epoch
  for(const event of result.events)options.sessions?.emit(event.user,event.revokedSid)
  after=result.sequence
 }catch{/* Authorization remains fail-closed while event delivery retries. */}finally{pending=false}}
 const timer=setInterval(()=>void poll(),1000);timer.unref();void poll()
 app.addHook('onClose',async()=>{stopped=true;clearInterval(timer)})
 return {authenticate}
}
