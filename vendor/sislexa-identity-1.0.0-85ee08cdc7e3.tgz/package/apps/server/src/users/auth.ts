// Аутентификация запросов приложения (web). Глобальный preHandler защищает
// /api/* (кроме публичных путей) по Bearer-токену; роль и блокировка берутся из
// БД (таблица users). Плюс роуты сессии (login/me/logout) и guard requireAdmin.

import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import { SlidingWindowLimiter } from '@voicechat/shared'

/** По имени — 10 за 10 минут; по IP — 30: за одним NAT сидит офис, и чужой брутфорс не должен запирать всех. */
const LOGIN_LIMIT = 10
const LOGIN_IP_LIMIT = 30
const LOGIN_WINDOW_MS = 10 * 60_000
import { REST, type SessionInfo, type SessionUser, type UserRole, SESSION_SHORT_TTL_MS, SESSION_TTL_MS, checkPasswordPolicy } from '@voicechat/shared'
import { deviceKey, findTrustedDevice, isNewDevice, isTrusted, localGeo, overLimit, parseUserAgent, type GeoResolver } from '@voicechat/sessions-core'
import { createGeoResolver } from './geo.js'
import type { SessionHub } from './sessionHub.js'
import type { AuthDatabase as VoiceChatDb } from '../ports.js'
import { newSessionId, signToken, verifyToken, verifyTokenName } from './accounts.js'
import { newTotpSecret, otpauthUrl, verifyTotp } from './totp.js'
import { createMailer, type Mailer } from './mailer.js'
import { PREVIEW_RUN_COOKIE } from '@voicechat/shared'
import { createHash, randomBytes } from 'node:crypto'
import type { ProjectFeature } from '@voicechat/shared'

const PREVIEW_SESSION_COOKIE = 'vc_preview_session'
const PREVIEW_COOKIE_PATH = '/api/preview'

/** Cookie-сессия (auth-roadmap п.5): HttpOnly-токен на весь /api + читаемый CSRF-токен для мутаций. */
export const SESSION_COOKIE = 'vc_session'
export const CSRF_COOKIE = 'vc_csrf'
/**
 * Долгоживущий секрет устройства. На нём держится «доверенное устройство»:
 * приметы запроса (User-Agent, подсеть) подделываются, секрет — нет. Отдельная
 * cookie, а не сессионная: переживает выход и перелогин, иначе доверие
 * приходилось бы подтверждать после каждого logout.
 */
export const DEVICE_COOKIE = 'vc_device'
const DEVICE_COOKIE_MAX_AGE = 400 * 24 * 60 * 60
/** Срок жизни сессии для ролей, которые заходят эпизодически. */
const ROLE_SHORT_TTL_MS = 7 * 24 * 60 * 60_000
/** Сколько устройств разрешено держать доверенными одновременно. */
const TRUSTED_DEVICES_LIMIT = 5
export const CSRF_HEADER = 'x-vc-csrf'
/**
 * Префикс защищённого имени cookie — и это не косметика.
 *
 * Браузер различает cookie по ХОСТУ, а не по схеме и порту: один и тот же прод
 * виден и как `https://<ip>` (через Caddy), и как `http://<ip>:8787` (порт
 * сервера напрямую). Cookie, выставленная по https, получает флаг `Secure`, а
 * незащищённый origin по правилу «Leave Secure Cookies Alone» (RFC 6265bis
 * §5.4) не может ни прочитать её, ни перезаписать одноимённую. Инцидент
 * 31.08.2026: после входа по https вход по http перестал сохраняться совсем —
 * `Set-Cookie` браузер молча отбрасывал, Bearer жил только в памяти страницы, и
 * ЛЮБАЯ перезагрузка возвращала экран входа. Снаружи это выглядело как «сессия
 * не работает», хотя сервер и клиент были исправны.
 *
 * Префикс `__Secure-` браузер запрещает выставлять с незащищённого origin,
 * поэтому имена двух схем гарантированно разные и затенять друг друга не могут.
 */
const SECURE_COOKIE_PREFIX = '__Secure-'
function isHttps(req: FastifyRequest): boolean {
  return String(req.headers['x-forwarded-proto'] ?? req.protocol) === 'https'
}
function secureFlag(req: FastifyRequest): string {
  return isHttps(req) ? '; Secure' : ''
}
function sessionSameSite(req: FastifyRequest): 'Strict' | 'None' {
  // Cross-origin credentialed cookies require SameSite=None and browsers accept
  // that attribute only with Secure. Unknown origins never receive relaxed cookies.
  return isHttps(req) && req.corsAllowed === true ? 'None' : 'Strict'
}
/** Имя cookie для схемы запроса: по https — с префиксом `__Secure-`, по http — обычное. */
function cookieNameFor(req: FastifyRequest, base: string): string {
  return isHttps(req) ? SECURE_COOKIE_PREFIX + base : base
}
/**
 * Значение cookie по базовому имени: сначала защищённое имя, потом обычное.
 * Читаем оба, чтобы схема не зависела от того, какой origin выставил cookie
 * последним, и чтобы правка не разлогинила всех, кто уже вошёл по старому имени.
 */
export function readCookie(req: Pick<FastifyRequest, 'headers'>, base: string): string | undefined {
  return cookieOf(req, SECURE_COOKIE_PREFIX + base) ?? cookieOf(req, base)
}
/** `maxAgeSec: null` — сессионная cookie без Max-Age (живёт до закрытия браузера). */
export function sessionCookies(req: FastifyRequest, token: string, csrf: string, maxAgeSec: number | null): string[] {
  const age = maxAgeSec === null ? '' : `; Max-Age=${maxAgeSec}`
  return [
    `${cookieNameFor(req, SESSION_COOKIE)}=${token}; Path=/; HttpOnly; SameSite=${sessionSameSite(req)}${age}${secureFlag(req)}`,
    `${cookieNameFor(req, CSRF_COOKIE)}=${csrf}; Path=/; SameSite=${sessionSameSite(req)}${age}${secureFlag(req)}`
  ]
}
/**
 * Разовое лечение старой пары имён при входе по https: у тех, кто успел войти до
 * разведения имён, в браузере лежит `Secure`-cookie с ОБЫЧНЫМ именем, и она
 * затеняет http-версию навсегда — сам http её удалить не может. Защищённый
 * origin может, поэтому один вход по https чинит адрес без ручной чистки cookie.
 */
export function clearLegacySessionCookies(req: FastifyRequest): string[] {
  if (!isHttps(req)) return []
  return [
    `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`,
    `${CSRF_COOKIE}=; Path=/; SameSite=Strict; Max-Age=0`
  ]
}
/** Cookie секрета устройства: SameSite=Lax, чтобы переживать переходы по ссылкам из писем. */
export function deviceCookie(req: FastifyRequest, secret: string): string {
  return `${cookieNameFor(req, DEVICE_COOKIE)}=${secret}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${DEVICE_COOKIE_MAX_AGE}${secureFlag(req)}`
}

export function clearSessionCookies(req: FastifyRequest): string[] {
  // Гасим и защищённое имя, и обычное: после смены схемы в браузере может лежать
  // любое из двух, а выход обязан завершать сессию, а не половину её признаков.
  return [
    `${cookieNameFor(req, SESSION_COOKIE)}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secureFlag(req)}`,
    `${cookieNameFor(req, CSRF_COOKIE)}=; Path=/; SameSite=Strict; Max-Age=0${secureFlag(req)}`,
    ...clearLegacySessionCookies(req)
  ]
}
function cookieOf(req: Pick<FastifyRequest, 'headers'>, name: string): string | undefined {
  const header = req.headers.cookie
  if (typeof header !== 'string') return undefined
  for (const item of header.split(';')) { const [k, ...rest] = item.trim().split('='); if (k === name) return rest.join('=') }
  return undefined
}

function previewCookie(req: FastifyRequest, token: string, maxAge?: number): string {
  // `__Secure-` требует флага Secure — на https он и так уместен: iframe превью
  // живёт на том же защищённом origin.
  return `${cookieNameFor(req, PREVIEW_SESSION_COOKIE)}=${token}; Path=${PREVIEW_COOKIE_PATH}; HttpOnly; SameSite=Strict${maxAge === undefined ? '' : `; Max-Age=${maxAge}`}${secureFlag(req)}`
}

declare module 'fastify' {
  interface FastifyRequest {
    /** Origin прошёл явный CORS allowlist общего bootstrap. */
    corsAllowed: boolean
    /** Пользователь сессии (устанавливается preHandler для защищённых путей). */
    user: SessionUser | null
    sessionSid?: string | null
  }
}

/** id владельца данных = логин пользователя (гарантирован на защищённых роутах). */
export function uid(req: FastifyRequest): string {
  if (!req.user) throw new Error('нет аутентифицированного пользователя')
  return req.user.name
}

export type ProjectPermission =
  | 'project:view'
  | 'task:create'
  | 'task:update'
  | 'workflow:start'
  | 'task:merge'
  | 'release:prepare'
  | 'production:deploy'
  | 'users:manage'
  | 'project:settings'
  | 'project:create'
  /** Правка файлов, коммит и push в рабочей копии задачи или сессии (панель кода). */
  | 'repository:write'

const DEVELOPER_PERMISSIONS = new Set<ProjectPermission>([
  // `repository:write` есть у разработчика намеренно: закоммитить и отправить свою
  // ветку — его обычная работа. Растянуть на это `task:merge` было бы неверно: тот
  // отвечает за попадание в main, а панель кода в main не пушит вовсе.
  'project:view', 'task:create', 'task:update', 'workflow:start', 'task:merge', 'repository:write'
])

/**
 * Полномочия, доступные любой роли. Свой проект может завести кто угодно: создатель
 * становится его владельцем (`project_members.role='owner'`), а что он вправе делать
 * внутри — по-прежнему решают DEVELOPER_PERMISSIONS и проектное владение. Раньше
 * создание попадало под `project:settings`, то есть было доступно только глобальному
 * admin, и «свой проект» получить было нельзя.
 */
const ANY_ROLE_PERMISSIONS = new Set<ProjectPermission>(['project:create'])

/** Централизованная матрица проектных полномочий; admin разрешены и будущие действия. */
export function hasProjectPermission(role: SessionUser['role'], permission: ProjectPermission): boolean {
  if (ANY_ROLE_PERMISSIONS.has(permission)) return true
  return role === 'admin' || (role === 'developer' && DEVELOPER_PERMISSIONS.has(permission))
}

/** Fastify guard для проектных операций. Аутентификацию раньше проверяет глобальный hook. */
export function requireProjectPermission(permission: ProjectPermission) {
  return async (req: FastifyRequest, reply: FastifyReply): Promise<void> => {
    if (!req.user || !hasProjectPermission(req.user.role, permission)) {
      await reply.code(403).send({ error: 'forbidden', permission })
    }
  }
}

/** Guard «только admin» для административных роутов. */
export const requireAdmin = requireProjectPermission('users:manage')

/** Единая классификация защищённых HTTP-операций; маршруты не дублируют матрицу ролей. */
export function projectPermissionForRequest(method: string, url: string): ProjectPermission | null {
  if (url.startsWith('/api/admin/')) return 'users:manage'
  if (/^\/api\/projects\/[^/]+\/machines\/available$/.test(url)) return 'project:settings'
  if (method === 'GET') return null
  // Создание своего проекта доступно любой роли и обязано проверяться раньше общего
  // правила про `/api/projects` ниже: то возвращает `project:settings`, и создание
  // снова стало бы админской операцией.
  if (method === 'POST' && url === '/api/projects') return 'project:create'
  if (/^\/api\/projects\/[^/]+\/releases\/deploy$/.test(url)) return 'production:deploy'
  if (/^\/api\/projects\/[^/]+\/releases(?:\/|$)/.test(url)) return 'release:prepare'
  if (/^\/api\/projects\/[^/]+\/git(?:\/|$)/.test(url)) return 'repository:write'
  // Компоненты проекта в Make: правка файла идёт теми же git-маршрутами, а здесь
  // остаются запуск Storybook на машине и тикет с веткой — та же цена ошибки.
  if (/^\/api\/projects\/[^/]+\/components(?:\/|$)/.test(url)) return 'repository:write'
  if (/^\/api\/projects\/[^/]+\/tasks\/[^/]+\/merge$/.test(url) || /^\/api\/merge\/runs\/[^/]+\/(retry|machine)$/.test(url)) return 'task:merge'
  if (/\/ci\/run(?:-on-machine)?$/.test(url) || /^\/api\/ci\/runs\/[^/]+\/(?:retry|retry-from-step|discard-and-retry)$/.test(url)) return 'workflow:start'
  if (method === 'POST' && /^\/api\/projects\/[^/]+\/tasks$/.test(url)) return 'task:create'
  if (method === 'PATCH' && /^\/api\/projects\/[^/]+\/tasks\/[^/]+$/.test(url)) return 'task:update'
  // Состав и роли участников проверяются проектной ролью owner в БД. Глобальный
  // admin сам по себе не получает эти права, а owner не обязан быть admin.
  if (url === '/api/projects' || /^\/api\/projects\/[^/]+$/.test(url) || /^\/api\/projects\/[^/]+\/(?:members|invitations|machines|default-machine|columns)(?:\/|$)/.test(url)) return 'project:settings'
  return null
}

/**
 * Классификация URL по подсистеме проекта. Возможности задаёт ТИП проекта, и
 * скрытия в интерфейсе недостаточно: без этой карты REST по-прежнему принимал бы
 * запуск CI-рана или создание релиза в проекте, где подсистема выключена.
 *
 * Гейтятся только адреса, где проект есть в пути. URL вида `/api/ci/runs/:id/retry`
 * и `/api/qa/runs/:id` работают с уже созданным раном — их создание перекрыто выше,
 * поэтому отдельная проверка там не нужна (и негде взять projectId без запроса).
 * Чтение не отделяется от записи намеренно: в проекте без подсистемы её списки
 * бессмысленны, а UI их и не показывает.
 */
export function projectFeatureForRequest(_method: string, url: string): ProjectFeature | null {
  if (!/^\/api\/projects\/[^/]+\//.test(url)) return null
  if (/^\/api\/projects\/[^/]+\/(?:releases|production)(?:\/|$)/.test(url)) return 'releases'
  if (/^\/api\/projects\/[^/]+\/(?:machines|default-machine)(?:\/|$)/.test(url)) return 'machines'
  if (/^\/api\/projects\/[^/]+\/git(?:\/|$)/.test(url)) return 'git'
  if (/^\/api\/projects\/[^/]+\/components(?:\/|$)/.test(url)) return 'git'
  if (/^\/api\/projects\/[^/]+\/tasks\/[^/]+\/merge(?:\/|$)/.test(url)) return 'git'
  if (/^\/api\/projects\/[^/]+\/tasks\/[^/]+\/qa(?:\/|$)/.test(url)) return 'qa'
  if (/^\/api\/projects\/[^/]+\/tasks\/[^/]+\/preview(?:\/|$)/.test(url)) return 'preview'
  if (/^\/api\/projects\/[^/]+\/(?:ci|improvements)(?:\/|$)/.test(url)) return 'ci'
  if (/^\/api\/projects\/[^/]+\/tasks\/[^/]+\/(?:ci|improvements|preparation)(?:\/|$)/.test(url)) return 'ci'
  return null
}

/** Токен из заголовка Authorization: Bearer <token>. */
function bearer(req: Pick<FastifyRequest, 'headers'>): string | undefined {
  const h = req.headers['authorization']
  if (typeof h !== 'string') return undefined
  const m = /^Bearer\s+(.+)$/i.exec(h)
  return m ? m[1] : undefined
}

/** Отдельная HttpOnly-cookie для same-origin iframe; на прочих API не действует. */
function previewSession(req: Pick<FastifyRequest, 'headers'>, url: string): string | undefined {
  // Точный путь прокси плюс сброс cookie-контейнера превью (кнопка «Сессия» Reader).
  // Превью и экспорт Make лежат под тем же префиксом: iframe и ссылка «Скачать» шлют только cookie.
  if (url !== PREVIEW_COOKIE_PATH && url !== PREVIEW_COOKIE_PATH + '/reset-cookies' && !url.startsWith(PREVIEW_COOKIE_PATH + '/make')) return undefined
  // Оба имени: на https cookie превью называется `__Secure-vc_preview_session`.
  return readCookie(req, PREVIEW_SESSION_COOKIE) || undefined
}

/**
 * Пользователь ключа Chromium: cookie читается только на точном пути прокси,
 * поэтому ключ не работает ни на одном другом маршруте API.
 */
export async function previewRunUser(
  db: VoiceChatDb,
  req: Pick<FastifyRequest, 'headers'>,
  url: string,
  keys: NonNullable<AuthOptions['previewRunKeys']>
): Promise<SessionUser | null> {
  if (url !== PREVIEW_COOKIE_PATH) return null
  const name = keys.userOf(readCookie(req, PREVIEW_RUN_COOKIE) || undefined)
  if (!name) return null
  const user = await db.identity.getUser(name)
  if (!user || user.blocked) return null
  return { name: user.name, role: user.role }
}

/** Публичные пути (без токена): health, сессия, скачивание бинарей/установщиков агента. */
export function isPublic(url: string): boolean {
  return (
    url === REST.health ||
    url.startsWith('/api/session/') ||
    url === REST.agentApp ||
    url === REST.loginApplicationArtifacts ||
    url === REST.loginApplicationDownload ||
    url === REST.loginEnrollmentRedeem ||
    url === REST.agentScript ||
    url === REST.agentInstallAndroid ||
    url === REST.agentInstallWindows ||
    url === REST.agentInstallLinux ||
    url === REST.agentInstallMacos ||
    url === REST.desktopApp ||
    url === REST.agentLatestVersion
  )
}

/** Разрешает токен в актуального пользователя БД: null, если нет/заблокирован. */
export async function resolveUser(db: VoiceChatDb, token: string | undefined, secret: string): Promise<SessionUser | null> {
  const name = verifyTokenName(token, secret)
  if (!name) return null
  const u = await db.identity.getUser(name)
  if (!u || u.blocked) return null
  return { name: u.name, role: u.role, ...(u.mustChangePassword ? { mustChangePassword: true } : {}) }
}

/**
 * Как `resolveUser`, но с учётом отзыва токена и таблицы сессий (auth-roadmap п.4) — для WS и любых мест вне preHandler.
 * Ленивую регистрацию старых токенов не делает: это забота HTTP-входа, WS всегда идёт после него.
 */
export async function resolveActiveUser(db: VoiceChatDb, token: string | undefined, secret: string): Promise<SessionUser | null> {
  if (!token || await db.identity.isSessionRevoked(token)) return null
  const parsed = verifyToken(token, secret)
  if (!parsed) return null
  if (parsed.sid) {
    const s = await db.identity.getSession(parsed.sid)
    if (s ? s.expiresAt < Date.now() : await db.identity.hasSessionRow(parsed.sid)) return null
  }
  return resolveUser(db, token, secret)
}

/** Всё, что нужно аутентификации от запроса: метод, путь и заголовки — без остального FastifyRequest. */
export type AuthRequestLike = Pick<FastifyRequest, 'method' | 'url' | 'headers'>
export type AuthVerdict = { ok: true; user: SessionUser } | { ok: false; status: 401 | 403; error: string }
export type AuthenticateFn = (req: AuthRequestLike) => Promise<AuthVerdict>

export interface AuthOptions {
  /** Отправка писем (регистрация с подтверждением email); без SMTP — «консольный» мейлер из createMailer. */
  mailer?: Mailer
  /** Публичный адрес приложения для ссылок в письмах; иначе берём Origin/Host запроса. */
  publicUrl?: string | null
  /** Определение места входа по IP; по умолчанию офлайн — только локальная сеть. */
  geo?: GeoResolver
  /** Куда сообщать об изменениях списка сессий (живое обновление по WS). */
  sessions?: SessionHub
  /**
   * Ключи изолированного Chromium к прокси превью: он открывает dev-сервер
   * машины от лица владельца рана, но Bearer-токена у навигации браузера нет.
   * Ключ действует только на пути прокси (`previewRunUser`).
   */
  previewRunKeys?: { userOf(key: string | undefined): string | null }
}

/** Настройка открытой регистрации хранится в app_config: `signup.enabled` ('1'/'0') и `signup.role`. */
export async function readSignupConfig(db: VoiceChatDb): Promise<{ enabled: boolean; role: UserRole }> {
  const role = await db.settings.getAppConfig('signup.role')
  return { enabled: await db.settings.getAppConfig('signup.enabled') === '1', role: role === 'admin' || role === 'developer' || role === 'tester' || role === 'observer' ? role : 'developer' }
}

/**
 * Что отдаём клиенту: хеш секрета устройства наружу не уходит. Он нужен только
 * серверу для решения о доверии, а в ответе стал бы подсказкой для подбора.
 */
function publicSession(session: SessionInfo): SessionInfo {
  const { deviceSecret: _hidden, ...rest } = session
  return rest
}

/**
 * Письмо о массовом закрытии входов. Такое действие необратимо и часто идёт от
 * чужих рук: если это был не владелец, письмо — единственный канал, который у
 * него остался, ведь все сессии уже погашены.
 */
async function notifyBulkRevoke(
  deps: { mailer: Mailer; log: FastifyInstance['log']; baseUrl: string },
  input: { user: string; email: string | null | undefined; kind: 'logout_all' | 'panic'; revoked: number; ip: string }
): Promise<void> {
  if (!input.email) return
  const when = `${new Date().toLocaleString('ru-RU', { timeZone: 'UTC' })} UTC`
  const what = input.kind === 'panic'
    ? 'закрыты все входы и запрошена смена пароля'
    : `завершены другие сессии (${input.revoked})`
  try {
    await deps.mailer.send({
      to: input.email,
      subject: 'Входы в ChatAI закрыты',
      text: `В вашей учётной записи ${what}.\nКогда: ${when}\nIP: ${input.ip}\n\nЕсли это были не вы — смените пароль: ${deps.baseUrl}/#/security/password`
    })
  } catch (error) {
    // Письмо — предупреждение, а не часть операции: сбой почты её не отменяет.
    deps.log.error({ error, user: input.user }, 'auth: письмо о закрытии входов не отправлено')
  }
}

/** Секрет устройства из cookie: голый секрет наружу не хранится, только хеш. */
function deviceSecretOf(req: FastifyRequest): string | undefined {
  const raw = readCookie(req, DEVICE_COOKIE)
  return raw && raw.length >= 16 ? raw.slice(0, 128) : undefined
}

function hashDeviceSecret(secret: string): string {
  return createHash('sha256').update(secret).digest('hex')
}

/**
 * Откуда вошли. Отдельного заголовка у клиентов нет, поэтому смотрим на UA:
 * Electron-оболочка и компаньон-агент представляются явно, всё прочее — веб.
 */
function platformOf(ua: string): string {
  if (/Electron/i.test(ua)) return 'desktop'
  if (/VoiceChatAgent/i.test(ua)) return 'agent'
  const profile = parseUserAgent(ua)
  return profile.legacy ? 'unknown' : 'web'
}

/** Версия клиента, если он её сообщает: помогает отличить залипший старый бандл. */
function clientVersionOf(req: FastifyRequest): string | null {
  const raw = req.headers['x-vc-client-version']
  const value = Array.isArray(raw) ? raw[0] : raw
  return value ? String(value).slice(0, 32) : null
}

export async function registerAuth(app: FastifyInstance, db: VoiceChatDb, secret: string, options: AuthOptions = {}): Promise<{ authenticate: AuthenticateFn }> {
  const mailer = options.mailer ?? createMailer({}, (m, extra) => app.log.warn(extra ?? {}, m))
  const geo = options.geo ?? createGeoResolver({
    url: process.env.VC_GEOIP_URL ?? null,
    onError: (message) => app.log.warn({ err: message }, 'geoip: место входа определить не удалось')
  })
  const baseUrl = (req: FastifyRequest): string => (options.publicUrl ?? `${String(req.headers['x-forwarded-proto'] ?? req.protocol)}://${String(req.headers['x-forwarded-host'] ?? req.headers.host ?? 'localhost')}`).replace(/\/$/, '')
  app.decorateRequest('user', null)
  // Сессии (auth-roadmap п.4): токен действителен, пока есть живая запись в `sessions` (не отозвана, не истекла).
  // Токены без записи (выданы до таблицы) регистрируются лениво — так старые входы не рвутся при обновлении.
  const activeUser = async (token: string | undefined, path?: string): Promise<SessionUser | null> => {
    if (!token || await db.identity.isSessionRevoked(token)) return null
    const parsed = verifyToken(token, secret)
    if (!parsed) return null
    if (parsed.sid) {
      const s = await db.identity.getSession(parsed.sid)
      if (s) { if (s.expiresAt < Date.now()) return null; await db.identity.touchSession(parsed.sid, Math.max(SESSION_SHORT_TTL_MS, s.expiresAt - s.lastSeen), path) }
      else if (await db.identity.hasSessionRow(parsed.sid)) return null // отозвана или истекла
      else if (await db.identity.getUser(parsed.name)) await db.identity.createSession(parsed.sid, parsed.name, { ip: '', userAgent: 'legacy', ttlMs: SESSION_TTL_MS })
    }
    return resolveUser(db, token, secret)
  }
  const tokenOf = (req: FastifyRequest): string | undefined => bearer(req) ?? readCookie(req, SESSION_COOKIE)
  /** Мутации сессионных роутов по cookie требуют CSRF (общий preHandler их не покрывает — префикс публичный). */
  const csrfOk = (req: FastifyRequest): boolean => Boolean(bearer(req)) || (Boolean(readCookie(req, CSRF_COOKIE)) && req.headers[CSRF_HEADER] === readCookie(req, CSRF_COOKIE))
  const sidOf = (req: FastifyRequest): string | null => verifyToken(tokenOf(req), secret)?.sid ?? null
  await db.identity.pruneSessions()

  /**
   * Аутентификация по методу, пути и заголовкам — без остального FastifyRequest: ту же проверку
   * заказывает отдельный сервис Make через `/internal/whoami`, пересылая cookie/Bearer запроса.
   * Одна авторизация на все сервисы — значит, один код, а не его копия в каждом процессе.
   */
  const authenticate: AuthenticateFn = async (req) => {
    const url = req.url.split('?')[0]!
    // На точном пути превью Strict-cookie панели имеет приоритет: форма вложенного сайта
    // не владеет CSRF оболочки. Обычные API по-прежнему требуют CSRF своей cookie-сессии.
    // Cookie авторизует мутации только с CSRF-заголовком, равным читаемой cookie: чужой сайт cookie отправит, заголовок — нет.
    let token = bearer(req)
    let viaCookie = false
    if (!token) token = previewSession(req, url)
    if (!token) { token = readCookie(req, SESSION_COOKIE); viaCookie = Boolean(token) }
    const runUser = await (token || !options.previewRunKeys ? null : previewRunUser(db, req, url, options.previewRunKeys))
    // Путь запоминаем в сессии: в списке устройств он отвечает на вопрос «а что
    // это устройство вообще делает», когда вход выглядит подозрительно.
    const user = await (runUser ?? activeUser(token, url))
    if (!user) return { ok: false, status: 401, error: 'unauthorized' }
    // Временный пароль (п.11): до смены пароля запрещаем всё, кроме чтения — сессионные роуты публичны и сюда не попадают.
    if (user.mustChangePassword && !['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return { ok: false, status: 403, error: 'password_change_required' }
    if (viaCookie && !['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
      const csrf = readCookie(req, CSRF_COOKIE)
      if (!csrf || req.headers[CSRF_HEADER] !== csrf) return { ok: false, status: 403, error: 'csrf' }
    }
    return { ok: true, user }
  }

  registerAuthGuard(app, db, authenticate, sidOf)

  // Rate-limit входа (auth-roadmap п.1): 10 попыток за 10 минут отдельно по IP и по имени; успешный вход счётчик не сбрасывает —
  // окно скользящее, и брутфорс с одного адреса упирается в 429 независимо от того, угадал ли он пароль по пути.
  const loginByIp = new SlidingWindowLimiter(LOGIN_IP_LIMIT, LOGIN_WINDOW_MS)
  const loginByName = new SlidingWindowLimiter(LOGIN_LIMIT, LOGIN_WINDOW_MS)
  const registerLimiter = new SlidingWindowLimiter(5, 60 * 60_000)
  // Изменения сессий не должны стать инструментом: перебирать чужие sid или
  // раз за разом гасить всё подряд смысла нет, а нагрузку это создаёт.
  const sessionOpsLimiter = new SlidingWindowLimiter(30, 5 * 60_000)
  app.decorate('resetLoginLimiters', () => { loginByIp.reset(); loginByName.reset(); sessionOpsLimiter.reset() })
  /** Общая проверка частоты для мутаций сессий; null — можно продолжать. */
  const sessionOpsBlocked = (req: FastifyRequest, user: string): { retryAfterSec: number } | null => {
    const hit = sessionOpsLimiter.hit(`${user}:${req.ip}`)
    return hit.ok ? null : { retryAfterSec: hit.retryAfterSec }
  }
  /** Ожидающие второго шага тикеты и незавершённые настройки 2FA — в памяти процесса, живут минуты. */
  const pendingTwoFactor = new Map<string, { name: string; expires: number; attempts: number; remember: boolean }>()
  const pendingSetup = new Map<string, { secret: string; expires: number }>()
  const issueSession = async (req: FastifyRequest, reply: FastifyReply, name: string, role: SessionUser['role'], remember = true, twoFactor = false): Promise<{ token: string; user: SessionUser; csrf: string }> => {
    const row = await db.identity.getUser(name)
    const user: SessionUser = { name, role, ...(row?.mustChangePassword ? { mustChangePassword: true } : {}) }
    const sid = newSessionId()
    const token = signToken(user, secret, sid)
    // «Запомнить меня» (п.15): 30 дней и cookie с Max-Age; иначе 12 часов и сессионная cookie (умирает с браузером).
    // Роль укорачивает срок: наблюдатель и тестировщик заходят эпизодически, и
    // месячная сессия у них живёт дольше, чем сам повод её открыть.
    const roleTtl = role === 'observer' || role === 'tester' ? ROLE_SHORT_TTL_MS : SESSION_TTL_MS
    const ttl = Math.min(remember ? roleTtl : SESSION_SHORT_TTL_MS, roleTtl)
    const ua = String(req.headers['user-agent'] ?? '')
    // Новое устройство (п.16): решает ядро модуля сессий по ключу устройства —
    // тот не меняется от обновления браузера и от соседнего адреса провайдера,
    // поэтому предупреждение приходит на смену устройства, а не на смену версии.
    const known = await db.identity.listSessions(name)
    const isNew = isNewDevice(known, { userAgent: ua, ip: req.ip })
    // Секрет устройства: из cookie, если браузер её уже носит, иначе новый.
    const deviceSecret = deviceSecretOf(req) ?? randomBytes(24).toString('base64url')
    const key = deviceKey({ userAgent: ua, ip: req.ip })
    await db.identity.createSession(sid, name, {
      ip: req.ip,
      userAgent: ua,
      ttlMs: ttl,
      deviceKey: key,
      deviceSecret: hashDeviceSecret(deviceSecret),
      platform: platformOf(ua),
      clientVersion: clientVersionOf(req),
      geo: localGeo(req.ip),
      twoFactor
    })
    // Имя устройства человек даёт один раз — новая сессия того же устройства
    // подхватывает его, иначе после каждого перелогина список полон безымянных.
    const inherited = await db.identity.deviceLabel(name, key)
    if (inherited) await db.identity.updateSession(sid, { label: inherited })
    // Лимит одновременных сессий: превышение гасит самые давно неактивные, но
    // никогда — только что выданную. Ноль или отсутствие настройки — без лимита.
    const limit = Number(await db.settings.getAppConfig('sessions.maxPerUser')) || 0
    for (const victim of overLimit(await db.identity.listSessions(name), limit || null, sid)) {
      await db.identity.revokeSessionById(victim.sid, undefined, 'evicted')
      await db.identity.logSecurityEvent({ user: name, type: 'session_evicted', ip: victim.ip, userAgent: victim.userAgent, details: `лимит ${limit} сессий`, sid: victim.sid })
      options.sessions?.emit(name, victim.sid)
    }
    // Публичный адрес уточняем в фоне: вход не должен ждать внешний сервис, а
    // список сессий читают уже после — к этому моменту место обычно на месте.
    if (!localGeo(req.ip)) {
      // Резолвер по контракту ядра может быть и синхронным — приводим к промису.
      void Promise.resolve(geo.resolve(req.ip))
        .then(async (place) => { if (place) await db.identity.updateSession(sid, { geo: place }) })
        .catch(() => undefined)
    }
    await db.identity.markLogin(name)
    await db.identity.logSecurityEvent({ user: name, type: 'login', ip: req.ip, userAgent: ua, sid })
    options.sessions?.emit(name)
    if (isNew) {
      const at = Date.now()
      await db.identity.logSecurityEvent({ user: name, type: 'login_new_device', ip: req.ip, userAgent: ua, details: 'вход с нового устройства', sid })
      const email = row?.email
      if (email && (await db.settings.getSettings(name)).loginNewDeviceEmails && await db.identity.reserveLoginDeviceEmail(name, req.ip, ua, at)) {
        const passwordLink = `${baseUrl(req)}/#/security/password`
        const sessionsLink = `${baseUrl(req)}/#/security/sessions`
        const when = `${new Date(at).toLocaleString('ru-RU', { timeZone: 'UTC' })} UTC`
        try {
          await mailer.send({
            to: email,
            subject: 'Новый вход в ChatAI',
            text: `Здравствуйте, ${name}!\n\nЗафиксирован вход с нового устройства.\nКогда: ${when}\nIP: ${req.ip}\nUser-Agent: ${ua || 'не указан'}\n\nЕсли это были не вы, смените пароль: ${passwordLink}\nИ отзовите другие сессии: ${sessionsLink}`
          })
        } catch (error) {
          app.log.error({ error, user: name }, 'auth: письмо о новом устройстве не отправлено')
        }
      }
    }
    const csrf = newSessionId()
    reply.header('set-cookie', [previewCookie(req, token), ...sessionCookies(req, token, csrf, remember ? Math.floor(ttl / 1000) : null), deviceCookie(req, deviceSecret), ...clearLegacySessionCookies(req)])
    return { token, user, csrf }
  }
  app.post<{ Body: { name?: string; password?: string; remember?: boolean } }>(
    REST.sessionLogin,
    async (req, reply) => {
      const { name, password } = req.body ?? {}
      const remember = req.body?.remember !== false
      const byIp = loginByIp.hit(req.ip)
      const byName = name ? loginByName.hit(name.trim().toLowerCase()) : { ok: true, remaining: LOGIN_LIMIT, retryAfterSec: 0 }
      if (!byIp.ok || !byName.ok) {
        const retry = Math.max(byIp.retryAfterSec, byName.retryAfterSec)
        return reply.code(429).header('retry-after', String(retry)).send({ error: `Слишком много попыток входа — подождите ${retry} с`, retryAfterSec: retry })
      }
      // Блокировка после неудач (auth-roadmap п.3): пока действует замок, пароль даже не проверяем — ответ одинаковый.
      const existing = name ? await db.identity.getUser(name) : null
      if (existing?.lockedUntil && existing.lockedUntil > Date.now()) {
        const retry = Math.max(1, Math.ceil((existing.lockedUntil - Date.now()) / 1000))
        return reply.code(423).header('retry-after', String(retry)).send({ error: `Вход временно закрыт после неудачных попыток — попробуйте через ${Math.ceil(retry / 60)} мин`, retryAfterSec: retry })
      }
      const u = name ? await db.identity.verifyUserPassword(name, password ?? '') : null
      if (!u) {
        if (existing) {
          const state = await db.identity.recordLoginFailure(existing.name)
          await db.identity.logSecurityEvent({ user: existing.name, type: state?.lockedUntil || state?.blocked ? 'login_locked' : 'login_failed', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: state?.blocked ? 'блокировка после неудач' : state?.lockedUntil ? 'временный замок' : 'неверный пароль' })
          if (state?.blocked && !existing.blocked) app.log.warn({ user: existing.name, ip: req.ip }, 'auth: аккаунт заблокирован автоматически после неудачных входов')
          else if (state?.lockedUntil) app.log.warn({ user: existing.name, ip: req.ip, until: state.lockedUntil }, 'auth: временный замок после неудачных входов')
        }
        return reply.code(401).send({ error: 'неверный логин или пароль' })
      }
      if (u.blocked) return reply.code(403).send({ error: u.lockReason === 'auto' ? 'учётная запись заблокирована после многократных неудачных входов — обратитесь к администратору' : 'учётная запись заблокирована' })
      await db.identity.resetLoginFailures(u.name)
      loginByName.forget(u.name.trim().toLowerCase())
      // 2FA (п.6): пароль верен, но сессию выдаём только после кода — клиенту уходит одноразовый тикет на 5 минут.
      // Исключение — устройство, которое пользователь сам пометил доверенным:
      // второй фактор защищает от входа с чужого устройства, а на своём он
      // превращается в ежедневный налог и подталкивает выключить 2FA совсем.
      if (await db.identity.getUserTotpSecret(u.name)) {
        const secret = deviceSecretOf(req)
        const trusted = findTrustedDevice(await db.identity.listSessions(u.name), { deviceSecret: secret ? hashDeviceSecret(secret) : null })
        if (!trusted) {
          const ticket = newSessionId()
          pendingTwoFactor.set(ticket, { name: u.name, expires: Date.now() + 5 * 60_000, attempts: 0, remember })
          return { requires2fa: true, ticket }
        }
        // Доверенное устройство однажды прошло проверку — сессия наследует признак.
        return issueSession(req, reply, u.name, u.role, remember, true)
      }
      return issueSession(req, reply, u.name, u.role, remember)
    }
  )

  // Второй шаг входа (п.6): тикет + код TOTP → полноценная сессия. Тикет одноразовый, 5 попыток.
  app.post<{ Body: { ticket?: string; code?: string } }>(REST.session2fa, async (req, reply) => {
    const { ticket, code } = req.body ?? {}
    const pending = ticket ? pendingTwoFactor.get(ticket) : undefined
    if (!pending || pending.expires < Date.now()) { if (ticket) pendingTwoFactor.delete(ticket); return reply.code(401).send({ error: 'сессия входа истекла — введите пароль ещё раз' }) }
    const secret = await db.identity.getUserTotpSecret(pending.name)
    const u = await db.identity.getUser(pending.name)
    if (!secret || !u || u.blocked) { pendingTwoFactor.delete(ticket!); return reply.code(401).send({ error: 'unauthorized' }) }
    if (!verifyTotp(secret, String(code ?? ''))) {
      pending.attempts += 1
      await db.identity.logSecurityEvent({ user: pending.name, type: 'login_2fa_failed', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? '') })
      if (pending.attempts >= 5) pendingTwoFactor.delete(ticket!)
      return reply.code(401).send({ error: 'неверный код подтверждения' })
    }
    pendingTwoFactor.delete(ticket!)
    return issueSession(req, reply, u.name, u.role, pending.remember, true)
  })
  // Настройка 2FA: setup выдаёт секрет и otpauth-ссылку (ещё не включено), enable включает после верного кода, disable — по коду.
  app.post(REST.session2faSetup, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    const secretValue = newTotpSecret()
    pendingSetup.set(user.name, { secret: secretValue, expires: Date.now() + 10 * 60_000 })
    return { secret: secretValue, otpauth: otpauthUrl(user.name, secretValue), enabled: Boolean(await db.identity.getUserTotpSecret(user.name)) }
  })
  app.post<{ Body: { code?: string } }>(REST.session2faEnable, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    const setup = pendingSetup.get(user.name)
    if (!setup || setup.expires < Date.now()) return reply.code(400).send({ error: 'сначала запросите новый секрет' })
    if (!verifyTotp(setup.secret, String(req.body?.code ?? ''))) return reply.code(400).send({ error: 'неверный код — проверьте время на устройстве и повторите' })
    await db.identity.setUserTotpSecret(user.name, setup.secret)
    pendingSetup.delete(user.name)
    await db.identity.logSecurityEvent({ user: user.name, type: 'twofactor_enabled', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? '') })
    app.log.info({ user: user.name }, 'auth: включён второй фактор')
    return { ok: true }
  })
  app.post<{ Body: { code?: string } }>(REST.session2faDisable, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    const secretValue = await db.identity.getUserTotpSecret(user.name)
    if (!secretValue) return { ok: true }
    if (!verifyTotp(secretValue, String(req.body?.code ?? ''))) return reply.code(400).send({ error: 'неверный код' })
    await db.identity.setUserTotpSecret(user.name, null)
    await db.identity.logSecurityEvent({ user: user.name, type: 'twofactor_disabled', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? '') })
    app.log.info({ user: user.name }, 'auth: второй фактор выключен')
    return { ok: true }
  })
  app.get(REST.session2fa, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    return { enabled: Boolean(await db.identity.getUserTotpSecret(user.name)) }
  })

  // Выпускает preview-cookie из действующего Bearer-токена. Login покрывает только
  // свежий вход; сессии из localStorage (и после перезапуска браузера — cookie
  // сессионная) без этого роута остаются без cookie, и iframe получает 401.
  // Путь публичный (префикс /api/session/), поэтому Bearer проверяется здесь.
  app.post(REST.sessionPreview, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    reply.header('set-cookie', previewCookie(req, signToken(user, secret)))
    return { ok: true }
  })

  app.get(REST.sessionMe, async (req) => {
    const user = await activeUser(tokenOf(req))
    // CSRF возвращается только уже аутентифицированному клиенту. Это позволяет
    // cross-origin Electron renderer восстановить контекст после перезапуска,
    // не раскрывая HttpOnly session token и не отключая double-submit защиту.
    // Вместе с пользователем — непросмотренные уведомления безопасности (п.16): клиент покажет тостом и отметит.
    const csrf = user ? readCookie(req, CSRF_COOKIE) : undefined
    return user ? { user, csrf, notices: await db.identity.unseenSecurityNotices(user.name) } : { user: null }
  })
  app.post(REST.sessionNoticesSeen, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    await db.identity.markNoticesSeen(user.name)
    return { ok: true }
  })

  app.post(REST.sessionLogout, async (req, reply) => {
    const token = tokenOf(req)
    const who = await activeUser(token)
    if (!who) return reply.code(401).send({ error: 'unauthorized' })
    // Выход по cookie — только с CSRF-заголовком: иначе любой запрос с приложенными браузером cookie (в т.ч. старая вкладка
    // без Bearer или чужой сайт) отзовёт общую сессию. Сессионные роуты публичны и общим preHandler не проверяются.
    if (!bearer(req)) {
      const csrf = readCookie(req, CSRF_COOKIE)
      if (!csrf || req.headers[CSRF_HEADER] !== csrf) return reply.code(403).send({ error: 'csrf' })
    }
    await db.identity.revokeSession(token!)
    const sid = sidOf(req)
    if (sid) await db.identity.revokeSessionById(sid)
    options.sessions?.emit(who.name, sid ?? undefined)
    await db.identity.logSecurityEvent({ user: who.name, type: 'logout', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? '') })
    reply.header('set-cookie', [previewCookie(req, '', 0), ...clearSessionCookies(req)])
    return { ok: true }
  })

  // Саморегистрация по инвайту (auth-roadmap п.8): проверка ссылки и создание учётки с политикой пароля → сразу сессия.
  app.get<{ Params: { token: string } }>('/api/session/invite/:token', async (req, reply) => {
    const inv = await db.identity.inviteUsable(req.params.token)
    if (!inv) return reply.code(404).send({ error: 'Приглашение недействительно или истекло' })
    return { role: inv.role, expiresAt: inv.expiresAt, note: inv.note }
  })
  app.post<{ Body: { token?: string; name?: string; password?: string } }>(REST.sessionRegister, async (req, reply) => {
    const { token, name, password } = req.body ?? {}
    if (!registerLimiter.hit(req.ip).ok) return reply.code(429).send({ error: 'Слишком много регистраций — попробуйте позже' })
    const inv = token ? await db.identity.inviteUsable(token) : null
    if (!inv) return reply.code(404).send({ error: 'Приглашение недействительно или истекло' })
    const login = (name ?? '').trim()
    if (!/^[a-zA-Z0-9._-]{3,32}$/.test(login)) return reply.code(400).send({ error: 'Логин: 3–32 символа, латиница, цифры, точка, дефис, подчёркивание' })
    if (await db.identity.getUser(login)) return reply.code(409).send({ error: 'Такой логин уже занят' })
    const violation = checkPasswordPolicy(password ?? '', { name: login })
    if (violation) return reply.code(400).send({ error: violation })
    const u = await db.identity.createUser(login, password ?? '', inv.role)
    await db.identity.consumeInvite(inv.token)
    await db.identity.logSecurityEvent({ user: login, type: 'registered', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: `по инвайту ${inv.createdBy}, роль ${inv.role}` })
    return issueSession(req, reply, u.name, u.role)
  })

  // Сброс пароля кодом администратора (auth-roadmap п.10): без входа, код одноразовый и срочный, политика пароля та же.
  app.post<{ Body: { name?: string; code?: string; password?: string } }>(REST.sessionReset, async (req, reply) => {
    const { name, code, password } = req.body ?? {}
    if (!registerLimiter.hit(`reset:${req.ip}`).ok) return reply.code(429).send({ error: 'Слишком много попыток — попробуйте позже' })
    const login = (name ?? '').trim()
    const violation = checkPasswordPolicy(password ?? '', { name: login })
    if (violation) return reply.code(400).send({ error: violation })
    if (!login || !code || !await db.identity.redeemResetCode(login, String(code).trim(), password!)) return reply.code(401).send({ error: 'Неверный логин или код, либо код истёк' })
    const u = (await db.identity.getUser(login))!
    await db.identity.revokeUserSessions(login)
    await db.identity.logSecurityEvent({ user: login, type: 'password_reset', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: 'по коду администратора' })
    return issueSession(req, reply, u.name, u.role)
  })
  // Смена своего пароля (пп.11–12): текущий пароль обязателен; остальные сессии отзываются.
  app.post<{ Body: { current?: string; next?: string } }>(REST.sessionPassword, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    const { current, next } = req.body ?? {}
    if (!await db.identity.verifyUserPassword(user.name, current ?? '')) return reply.code(400).send({ error: 'Текущий пароль неверен' })
    const violation = checkPasswordPolicy(next ?? '', { name: user.name })
    if (violation) return reply.code(400).send({ error: violation })
    if (current === next) return reply.code(400).send({ error: 'Новый пароль совпадает с текущим' })
    await db.identity.setUserPassword(user.name, next!)
    await db.identity.revokeUserSessions(user.name, sidOf(req))
    await db.identity.logSecurityEvent({ user: user.name, type: 'password_changed', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? '') })
    return { ok: true }
  })

  // Открытая регистрация с подтверждением email: заявка → письмо со ссылкой #/verify/<token> → учётка и сессия.
  const signupLimiter = new SlidingWindowLimiter(5, 60 * 60_000)
  const passwordResetByIp = new SlidingWindowLimiter(5, 60 * 60_000)
  const passwordResetByEmail = new SlidingWindowLimiter(3, 60 * 60_000)
  const resetRequested = { ok: true as const, message: 'Если адрес подтверждён, письмо со ссылкой отправлено.' }

  // Email-вариант сброса (п.10): одинаковый ответ не раскрывает существование адреса; ограничения считаются и по IP, и по адресу.
  app.post<{ Body: { email?: string } }>(REST.sessionResetRequest, async (req, reply) => {
    const email = String(req.body?.email ?? '').trim().toLowerCase()
    const byIp = passwordResetByIp.hit(req.ip)
    const byEmail = passwordResetByEmail.hit(email || 'invalid')
    if (!byIp.ok || !byEmail.ok) {
      const retry = Math.max(byIp.retryAfterSec, byEmail.retryAfterSec)
      return reply.code(429).header('retry-after', String(retry)).send({ error: `Слишком много запросов — попробуйте через ${retry} с`, retryAfterSec: retry })
    }
    const user = email ? await db.identity.getUserByEmail(email) : null
    if (!user || user.blocked) return resetRequested
    const token = randomBytes(32).toString('base64url')
    await db.identity.createPasswordResetToken(user.name, token, 60 * 60_000)
    const link = `${baseUrl(req)}/#/reset/${encodeURIComponent(token)}`
    try {
      await mailer.send({
        to: email,
        subject: 'Сброс пароля ChatAI',
        text: `Здравствуйте, ${user.name}!\n\nЧтобы установить новый пароль, откройте ссылку (действует 1 час):\n${link}\n\nЕсли вы не запрашивали сброс — просто проигнорируйте письмо.`,
        html: `<p>Здравствуйте, <b>${user.name}</b>!</p><p>Чтобы установить новый пароль, откройте ссылку (действует 1 час):</p><p><a href="${link}">Сменить пароль</a></p><p>Если вы не запрашивали сброс — просто проигнорируйте письмо.</p>`
      })
    } catch (error) {
      app.log.error({ error, user: user.name }, 'auth: письмо сброса пароля не отправлено')
    }
    return resetRequested
  })

  app.post<{ Body: { token?: string; password?: string } }>(REST.sessionResetEmail, async (req, reply) => {
    const token = String(req.body?.token ?? '')
    const name = token ? await db.identity.passwordResetTokenUser(token) : null
    if (!name) return reply.code(400).send({ error: 'Ссылка сброса недействительна или уже использована' })
    const violation = checkPasswordPolicy(String(req.body?.password ?? ''), { name })
    if (violation) return reply.code(400).send({ error: violation })
    const result = await db.identity.redeemPasswordResetToken(token, String(req.body?.password ?? ''))
    if (result === 'expired') return reply.code(410).send({ error: 'Ссылка сброса истекла. Запросите новое письмо.' })
    if (result !== 'ok') return reply.code(400).send({ error: 'Ссылка сброса недействительна или уже использована' })
    await db.identity.revokeUserSessions(name)
    await db.identity.logSecurityEvent({ user: name, type: 'password_reset', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: 'по подтверждённому email' })
    reply.header('set-cookie', [previewCookie(req, '', 0), ...clearSessionCookies(req)])
    return { ok: true }
  })

  const sendVerification = async (req: FastifyRequest, name: string, email: string, token: string): Promise<void> => {
    const link = `${baseUrl(req)}/#/verify/${encodeURIComponent(token)}`
    await mailer.send({
      to: email,
      subject: 'Подтверждение регистрации в ChatAI',
      text: `Здравствуйте, ${name}!\n\nЧтобы завершить регистрацию, откройте ссылку (действует 24 часа):\n${link}\n\nЕсли вы не регистрировались — просто проигнорируйте это письмо.`,
      html: `<p>Здравствуйте, <b>${name}</b>!</p><p>Чтобы завершить регистрацию, нажмите кнопку (ссылка действует 24 часа):</p><p><a href="${link}" style="display:inline-block;padding:10px 18px;background:#4f7cff;color:#fff;border-radius:8px;text-decoration:none">Подтвердить email</a></p><p style="color:#666;font-size:12px">Или скопируйте адрес: ${link}<br>Если вы не регистрировались — проигнорируйте письмо.</p>`
    })
  }
  app.get(REST.sessionSignup, async () => ({ enabled: (await readSignupConfig(db)).enabled }))
  app.post<{ Body: { name?: string; email?: string; password?: string } }>(REST.sessionSignup, async (req, reply) => {
    if (!(await readSignupConfig(db)).enabled) return reply.code(404).send({ error: 'Регистрация закрыта — попросите приглашение у администратора' })
    if (!signupLimiter.hit(req.ip).ok) return reply.code(429).send({ error: 'Слишком много регистраций — попробуйте позже' })
    const { name, email, password } = req.body ?? {}
    const login = (name ?? '').trim()
    const mail = (email ?? '').trim().toLowerCase()
    if (!/^[a-zA-Z0-9._-]{3,32}$/.test(login)) return reply.code(400).send({ error: 'Логин: 3–32 символа, латиница, цифры, точка, дефис, подчёркивание' })
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(mail) || mail.length > 254) return reply.code(400).send({ error: 'Некорректный email' })
    const violation = checkPasswordPolicy(password ?? '', { name: login })
    if (violation) return reply.code(400).send({ error: violation })
    // Занятый логин или email не раскрываем сразу пользователю? Логин — раскрываем (он публичен), email — отвечаем одинаково.
    if (await db.identity.getUser(login)) return reply.code(409).send({ error: 'Такой логин уже занят' })
    if (!await db.identity.getUserByEmail(mail)) {
      const token = randomBytes(24).toString('base64url')
      await db.identity.createEmailVerification({ token, name: login, email: mail, password: password!, ttlMs: 24 * 60 * 60_000 })
      await db.identity.logSecurityEvent({ user: login, type: 'signup_requested', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: mail })
      try { await sendVerification(req, login, mail, token) } catch (error) { app.log.error({ error }, 'signup: письмо не отправлено'); return reply.code(502).send({ error: 'Не удалось отправить письмо — попробуйте позже или обратитесь к администратору' }) }
    }
    return { ok: true, mailSent: mailer.configured }
  })
  app.post<{ Body: { email?: string } }>(REST.sessionSignupResend, async (req, reply) => {
    if (!(await readSignupConfig(db)).enabled) return reply.code(404).send({ error: 'Регистрация закрыта' })
    if (!signupLimiter.hit(`resend:${req.ip}`).ok) return reply.code(429).send({ error: 'Слишком часто — попробуйте позже' })
    const mail = (req.body?.email ?? '').trim().toLowerCase()
    const pending = mail ? await db.identity.pendingVerificationByEmail(mail) : null
    if (pending) {
      // Новый токен взамен старого: заявку пересоздать нельзя без пароля, поэтому продлеваем через новую ссылку на ту же запись.
      const token = randomBytes(24).toString('base64url')
      const row = await db.identity.getPendingVerificationRaw(mail)
      if (row) await db.identity.replaceVerificationToken(mail, token, 24 * 60 * 60_000)
      try { await sendVerification(req, pending.name, mail, token) } catch (error) { app.log.error({ error }, 'signup: письмо не отправлено') }
    }
    return { ok: true }
  })
  app.post<{ Body: { token?: string } }>(REST.sessionVerify, async (req, reply) => {
    const { token } = req.body ?? {}
    const cfg = await readSignupConfig(db)
    const u = token ? await db.identity.redeemEmailVerification(String(token), cfg.role) : null
    if (!u) return reply.code(400).send({ error: 'Ссылка недействительна или истекла — зарегистрируйтесь ещё раз' })
    await db.identity.logSecurityEvent({ user: u.name, type: 'signup_verified', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: u.email ?? '' })
    // Приглашения, отправленные на этот адрес до регистрации, теперь адресованы
    // конкретному пользователю. Автоприёма нет: вступление он подтверждает сам.
    if (u.email) await db.projects.attachInvitationsToNewUser(u.name, u.email)
    return issueSession(req, reply, u.name, u.role)
  })

  // Перенос старой localStorage-сессии в cookie (п.5): Bearer → HttpOnly cookie + CSRF, токен из localStorage клиент удаляет.
  app.post(REST.sessionCookie, async (req, reply) => {
    const token = bearer(req)
    if (!await activeUser(token)) return reply.code(401).send({ error: 'unauthorized' })
    const csrf = newSessionId()
    reply.header('set-cookie', [previewCookie(req, token!), ...sessionCookies(req, token!, csrf, Math.floor(SESSION_TTL_MS / 1000)), ...clearLegacySessionCookies(req)])
    return { ok: true, csrf }
  })

  // Сессии пользователя (auth-roadmap п.4): список, «выйти везде» (кроме текущей), отзыв одной.
  app.get<{ Querystring: { ended?: string } }>(REST.sessionList, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    const current = sidOf(req)
    const sessions = (await db.identity.listSessions(user.name)).map((s) => publicSession({ ...s, current: s.sid === current }))
    // Завершённые отдаём только по запросу: обычному списку они не нужны, а
    // лишний запрос в БД на каждое открытие окна — тоже плата.
    if (req.query?.ended !== '1') return { sessions }
    return { sessions, ended: (await db.identity.listEndedSessions(user.name)).map(publicSession) }
  })
  app.post<{ Body: { includeCurrent?: boolean } | undefined }>(REST.sessionLogoutAll, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    const limited = sessionOpsBlocked(req, user.name)
    if (limited) return reply.code(429).header('retry-after', String(limited.retryAfterSec)).send({ error: 'Слишком много операций с сессиями — подождите', retryAfterSec: limited.retryAfterSec })
    // `includeCurrent` — «выйти везде, включая это устройство»: после кражи
    // пароля человек хочет обнулить всё разом, а не оставлять себе исключение.
    const includeCurrent = req.body?.includeCurrent === true
    const current = sidOf(req)
    // Список берём до отзыва: каждой убитой вкладке нужен адресный кадр, иначе
    // «выйти везде» оставляет их выглядящими рабочими до следующего запроса —
    // ровно тот разрыв, который закрывает session.revoked в остальных местах.
    const doomed = (await db.identity.listSessions(user.name)).filter((s) => includeCurrent || s.sid !== current)
    const revoked = await db.identity.revokeUserSessions(user.name, includeCurrent ? null : current, undefined, 'logout_all')
    if (includeCurrent) {
      const token = tokenOf(req)
      if (token) await db.identity.revokeSession(token)
      reply.header('set-cookie', clearSessionCookies(req))
    }
    await db.identity.logSecurityEvent({ user: user.name, type: 'logout_all', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: `отозвано сессий: ${revoked}${includeCurrent ? ', включая текущую' : ''}` })
    if (revoked > 0) void notifyBulkRevoke({ mailer, log: app.log, baseUrl: baseUrl(req) }, { user: user.name, email: (await db.identity.getUser(user.name))?.email, kind: 'logout_all', revoked, ip: req.ip })
    for (const session of doomed) options.sessions?.emit(user.name, session.sid)
    if (doomed.length === 0) options.sessions?.emit(user.name)
    return { revoked }
  })
  /**
   * «Это не я»: человек увидел чужой вход и жмёт одну кнопку. Полумеры здесь
   * вредны — гасим все сессии без исключений (включая свою) и требуем сменить
   * пароль при следующем входе: чужая сессия жива ровно потому, что пароль уже
   * у кого-то есть.
   */
  app.post(REST.sessionPanic, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    const limited = sessionOpsBlocked(req, user.name)
    if (limited) return reply.code(429).header('retry-after', String(limited.retryAfterSec)).send({ error: 'Слишком много операций с сессиями — подождите', retryAfterSec: limited.retryAfterSec })
    const doomed = await db.identity.listSessions(user.name)
    const revoked = await db.identity.revokeUserSessions(user.name, null, undefined, 'panic')
    const token = tokenOf(req)
    if (token) await db.identity.revokeSession(token)
    await db.identity.setMustChangePassword(user.name, true)
    reply.header('set-cookie', [previewCookie(req, '', 0), ...clearSessionCookies(req)])
    await db.identity.logSecurityEvent({ user: user.name, type: 'session_panic', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: `отозвано сессий: ${revoked}, требуется смена пароля` })
    void notifyBulkRevoke({ mailer, log: app.log, baseUrl: baseUrl(req) }, { user: user.name, email: (await db.identity.getUser(user.name))?.email, kind: 'panic', revoked, ip: req.ip })
    for (const session of doomed) options.sessions?.emit(user.name, session.sid)
    return { revoked }
  })
  app.delete<{ Params: { sid: string } }>('/api/session/:sid', async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    const s = await db.identity.getSession(req.params.sid)
    if (!s || s.user !== user.name) return reply.code(404).send({ error: 'not found' })
    await db.identity.revokeSessionById(s.sid, undefined, 'revoked')
    await db.identity.logSecurityEvent({ user: user.name, type: 'session_revoked', ip: req.ip, userAgent: s.userAgent, details: s.label ?? '', sid: s.sid })
    options.sessions?.emit(user.name, s.sid)
    return { ok: true }
  })
  /** Снять доверие со всех своих устройств разом — «я не уверен ни в одном». */
  app.post(REST.sessionUntrustAll, async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    const limited = sessionOpsBlocked(req, user.name)
    if (limited) return reply.code(429).header('retry-after', String(limited.retryAfterSec)).send({ error: 'Слишком много операций с сессиями — подождите', retryAfterSec: limited.retryAfterSec })
    const affected = await db.identity.untrustAllSessions(user.name)
    if (affected > 0) {
      await db.identity.logSecurityEvent({ user: user.name, type: 'session_untrusted', ip: req.ip, userAgent: String(req.headers['user-agent'] ?? ''), details: `снято доверие с устройств: ${affected}` })
      options.sessions?.emit(user.name)
    }
    return { affected }
  })
  // История устройства: что этот вход делал. Отвечает на вопрос «а точно ли это
  // я», когда подпись и место сами по себе ничего не проясняют.
  app.get<{ Params: { sid: string } }>(REST.sessionHistory(':sid').replace('%3Asid', ':sid'), async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    const s = await db.identity.getSession(req.params.sid) ?? (await db.identity.listEndedSessions(user.name, 100)).find((x) => x.sid === req.params.sid)
    if (!s || s.user !== user.name) return reply.code(404).send({ error: 'not found' })
    return { events: await db.identity.listSessionHistory(user.name, { sid: s.sid, userAgent: s.userAgent, ip: s.ip }) }
  })
  // Имя устройства и отметка «доверенное» — только для своей сессии.
  app.patch<{ Params: { sid: string }; Body: { label?: string | null; trusted?: boolean; scope?: 'session' | 'device' } }>('/api/session/:sid', async (req, reply) => {
    const user = await activeUser(tokenOf(req))
    if (!user) return reply.code(401).send({ error: 'unauthorized' })
    if (!csrfOk(req)) return reply.code(403).send({ error: 'csrf' })
    const limited = sessionOpsBlocked(req, user.name)
    if (limited) return reply.code(429).header('retry-after', String(limited.retryAfterSec)).send({ error: 'Слишком много операций с сессиями — подождите', retryAfterSec: limited.retryAfterSec })
    const s = await db.identity.getSession(req.params.sid)
    // Чужая и несуществующая сессия отвечают одинаково: по ответу не должно быть
    // видно, существует ли сессия с таким sid у кого-то другого.
    if (!s || s.user !== user.name) return reply.code(404).send({ error: 'not found' })
    const patch: { label?: string | null; trusted?: boolean } = {}
    let renamedDevice = 0
    if (req.body?.label !== undefined) {
      const label = typeof req.body.label === 'string' ? req.body.label.trim() : ''
      patch.label = label || null
      // Имя относится к устройству, а не к вкладке: по умолчанию переименовываем
      // все его живые сессии, чтобы список не показывал одно устройство дважды
      // под разными именами.
      if (req.body.scope !== 'session' && s.deviceKey) renamedDevice = await db.identity.renameDevice(user.name, s.deviceKey, patch.label)
    }
    if (typeof req.body?.trusted === 'boolean') patch.trusted = req.body.trusted
    if (Object.keys(patch).length === 0) return reply.code(400).send({ error: 'нечего менять' })
    // Доверие пропускает второй фактор — значит выдавать его сессии, которая
    // сама его не проходила, бессмысленно: так проверка обходится навсегда.
    if (patch.trusted === true && await db.identity.getUserTotpSecret(user.name) && !s.twoFactor) {
      return reply.code(409).send({ error: 'Сделать доверенным можно только устройство, вход с которого подтверждён кодом' })
    }
    // Доверенных устройств не может быть сколько угодно: каждое — это дырка в
    // втором факторе, и список из двадцати «своих» ноутбуков её обесценивает.
    if (patch.trusted === true && !isTrusted(s)) {
      const trustedNow = (await db.identity.sessionStats(user.name)).trusted
      if (trustedNow >= TRUSTED_DEVICES_LIMIT) {
        return reply.code(409).send({ error: `Доверенных устройств не может быть больше ${TRUSTED_DEVICES_LIMIT} — снимите доверие с ненужного` })
      }
    }
    await db.identity.updateSession(s.sid, patch)
    const ua = String(req.headers['user-agent'] ?? '')
    void renamedDevice
    if (patch.label !== undefined) await db.identity.logSecurityEvent({ user: user.name, type: 'session_renamed', ip: req.ip, userAgent: ua, details: patch.label ?? 'имя снято', sid: s.sid })
    if (patch.trusted !== undefined) await db.identity.logSecurityEvent({ user: user.name, type: patch.trusted ? 'session_trusted' : 'session_untrusted', ip: req.ip, userAgent: s.userAgent, details: s.label ?? '', sid: s.sid })
    options.sessions?.emit(user.name)
    return { ok: true }
  })
  return { authenticate }
}

export function registerAuthGuard(app: FastifyInstance, db: Pick<VoiceChatDb, 'projects'>, authenticate: AuthenticateFn, sidOf: (req: FastifyRequest) => string | null): void {
  app.addHook('preHandler', async (req, reply) => {
    const url = req.url.split('?')[0]
    if (!url.startsWith('/api/')) return // статика/SPA/ws — не трогаем
    if (isPublic(url)) return
    const verdict = await authenticate(req)
    if (!verdict.ok) {
      await reply.code(verdict.status).send({ error: verdict.error })
      return reply
    }
    const { user } = verdict
    req.user = user
    req.sessionSid = sidOf(req)
    const permission = projectPermissionForRequest(req.method, url)
    if (permission) {
      const projectId = /^\/api\/projects\/([^/]+)/.exec(url)?.[1]
      const ownerPermission =
        permission === 'project:settings' ||
        permission === 'release:prepare' ||
        permission === 'production:deploy'
      // Проектные owner-права берутся только из project_members. Это разрешает
      // каждому владельцу критические операции независимо от глобальной роли и
      // не превращает глобального admin во владельца чужого проекта.
      const allowed = ownerPermission && projectId
        ? await db.projects.isProjectOwner(user.name, decodeURIComponent(projectId))
        : hasProjectPermission(user.role, permission)
      if (!allowed) {
        await reply.code(403).send({ error: 'forbidden', permission })
        return reply
      }
    }
    // Возможности типа проекта: читаются живьём, поэтому правка типа немедленно
    // закрывает подсистему и в интерфейсе, и в API.
    const feature = projectFeatureForRequest(req.method, url)
    if (feature) {
      const projectId = /^\/api\/projects\/([^/]+)/.exec(url)?.[1]
      if (projectId && !(await db.projects.projectFeatures(decodeURIComponent(projectId)))[feature]) {
        await reply.code(409).send({ error: 'feature_unavailable', feature })
        return reply
      }
    }
  })
}
