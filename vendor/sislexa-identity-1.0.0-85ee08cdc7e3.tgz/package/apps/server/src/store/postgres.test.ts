import {expect,it} from 'vitest'
import pg from 'pg'
import {randomUUID} from 'node:crypto'
import {openIdentityStore} from './open.js'
import {hashPassword} from '../users/passwords.js'
const url=process.env.VC_TEST_DB_URL
it.skipIf(!url)('upgrades an existing PostgreSQL identity without changing password hashes and serializes initializers',async()=>{
 const schema='identity_'+randomUUID().replaceAll('-',''),admin=new pg.Client({connectionString:url})
 await admin.connect();await admin.query('CREATE SCHEMA '+schema)
 const hash=hashPassword('Preserved-password-937!'),target=new URL(url!);target.searchParams.set('options','-c search_path='+schema)
 const cleanup={chat:{deleteConversationsOfUser:async()=>{}},machines:{deleteAgentsOfUser:async()=>{}},settings:{deleteUserSettings:async()=>{}},tasks:{unassignUser:async()=>{}},projects:{detachDeletedUser:async()=>{}}}
 let stores:Awaited<ReturnType<typeof openIdentityStore>>[]=[]
 try{
  await admin.query(`CREATE TABLE ${schema}.users(name TEXT PRIMARY KEY,password_hash TEXT NOT NULL,role TEXT NOT NULL,blocked BIGINT NOT NULL DEFAULT 0,created_at BIGINT NOT NULL)`)
  await admin.query(`INSERT INTO ${schema}.users VALUES($1,$2,$3,0,1)`,['alice',hash,'developer'])
  stores=await Promise.all([1,2].map(()=>openIdentityStore({filename:':unused:',databaseUrl:target.href,cleanup})))
  expect(await stores[0]!.store.verifyUserPassword('alice','Preserved-password-937!')).toMatchObject({name:'alice'})
  expect((await admin.query(`SELECT password_hash FROM ${schema}.users WHERE name=$1`,['alice'])).rows[0].password_hash).toBe(hash)
  expect(await stores[1]!.store.getUser('alice')).toMatchObject({mustChangePassword:false,totpEnabled:false})
 }finally{await Promise.all(stores.map(s=>s.close()));await admin.query('DROP SCHEMA '+schema+' CASCADE');await admin.end()}
})
