import {UiProviders,Button,useConfirm,useToast} from '@voicechat/ui-kit'
import {makeSessionBridge} from '@voicechat/identity-client/sessionBridge'
import {authHeaders} from '@voicechat/identity-client/browser'
import {SessionsDialog,createSessionsStore} from '@voicechat/sessions-app'
import {TwoFactorDialog,ChangePasswordDialog} from '@voicechat/identity-login'
import type {SessionUser} from '@voicechat/shared'
import '../../login/src/login.css'
import React,{useState,useEffect,useMemo} from 'react'
import {createRoot} from 'react-dom/client'
import {AccountPage} from './AccountPage'
import type {RendererApi} from '@shared/ipc'
import type {ProfileTab} from '@voicechat/profile-app'
import '@voicechat/ui-kit/styles.css'
import '@voicechat/profile-app/styles.css'
import '@voicechat/sessions-app/styles.css'
import './styles.css'
import './account.css'
const paths:Record<string,string>={'me:profile':'/api/me/profile','me:security':'/api/me/security','usage:report':'/api/me/usage','llm:access':'/api/llm-access','agents:list':'/api/agents'}
const api=new Proxy({} as RendererApi,{get:(_target,key)=>async(params?:Record<string,unknown>)=>{const path=paths[String(key)];if(!path)throw Error('Unsupported account operation');const url=new URL(path,location.origin);for(const[k,v]of Object.entries(params??{}))if(v!==undefined)url.searchParams.set(k,String(v));const r=await fetch(url,{headers:authHeaders()});if(r.status===401){location.assign('/login/');throw Error('Войдите в аккаунт')}if(!r.ok)throw Error('Account HTTP '+r.status);return r.json()}})
const session=makeSessionBridge('',{reconnect(){},on(){return()=>{}}})
const signedOut=()=>location.assign('/login/')
function SessionDevices({onClose}:{onClose:()=>void}){
 const confirm=useConfirm(),toast=useToast()
 const store=useMemo(()=>createSessionsStore({client:{list:session.sessions!,revoke:session.revokeSession!,revokeOthers:()=>session.logoutAll!(),revokeAll:()=>session.logoutAll!({includeCurrent:true}),rename:session.renameSession!,setTrusted:session.trustSession!,listEnded:session.endedSessions!,panic:session.panicSessions!,history:session.sessionHistory!,untrustAll:session.untrustAllSessions!},host:{onSignedOut:signedOut,copy:text=>navigator.clipboard.writeText(text),onVisible:cb=>{addEventListener('focus',cb);return()=>removeEventListener('focus',cb)}},notify:{success:message=>toast.success(message),error:message=>toast.error(message)}}),[])
 useEffect(()=>()=>store.actions.dispose(),[store])
 return <SessionsDialog store={store} onClose={onClose} confirm={request=>confirm({title:request.title,message:request.text,variant:request.variant})}/>
}
function Account(){
 const [tab,setTab]=useState<ProfileTab>('overview'),[dialog,setDialog]=useState<'sessions'|'password'|'2fa'|null>(null),[user,setUser]=useState<SessionUser|null>(null)
 const toast=useToast()
 useEffect(()=>{let disposed=false;const refresh=()=>{void session.me().then(value=>{if(disposed)return;if(!value)signedOut();else setUser(value)}).catch(()=>{if(!disposed)toast.error('Не удалось проверить сессию')})};refresh();const timer=setInterval(refresh,30000);return()=>{disposed=true;clearInterval(timer)}},[])
 if(!user)return <p role="status">Проверяю сессию…</p>
 return <><nav aria-label="Безопасность аккаунта"><Button onClick={()=>setDialog('sessions')}>Сессии и устройства</Button><Button onClick={()=>setDialog('password')}>Сменить пароль</Button><Button onClick={()=>setDialog('2fa')}>Двухфакторная защита</Button><Button onClick={()=>void session.logout().then(signedOut).catch(e=>toast.error(String(e)))}>Выйти</Button></nav><AccountPage api={api} tab={tab} onChangeTab={setTab} onOpenSessions={()=>setDialog('sessions')} onClose={()=>location.assign('/')} onExportCsv={(filename,text)=>{const url=URL.createObjectURL(new Blob([text],{type:'text/csv'}));const a=document.createElement('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}}/>{dialog==='sessions'&&<SessionDevices onClose={()=>setDialog(null)}/>} {dialog==='2fa'&&<TwoFactorDialog api={session.twoFactor!} onClose={()=>setDialog(null)}/>} {(dialog==='password'||user.mustChangePassword)&&<ChangePasswordDialog userName={user.name} change={session.changePassword!} forced={user.mustChangePassword} onDone={()=>location.reload()} onClose={()=>setDialog(null)} onLogout={()=>void session.logout().then(signedOut)}/>}</>
}
createRoot(document.getElementById('root')!).render(<UiProviders><Account/></UiProviders>)
