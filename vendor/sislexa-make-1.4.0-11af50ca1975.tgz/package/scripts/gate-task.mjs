import { execFileSync, spawn } from 'node:child_process'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

export const MAX_TESTS = 100
export const MAX_MS = 60_000
export function startDeadline(onTimeout) {
  const timer = setTimeout(onTimeout, MAX_MS)
  return () => clearTimeout(timer)
}
export function testSelection(files) {
  const flatten = tasks => tasks.flatMap(task => task.type === 'test' ? [task] : flatten(task.tasks ?? []))
  return { count: flatten(files).length, paths: files.map(file => file.filepath) }
}
/** A budget breach exits 2 (contract in Core docs/plans/dev-lane-v1.md «Общий контракт»). */
export class BudgetError extends Error {}
export function assertBudget(count, elapsed) {
  if (count > MAX_TESTS || elapsed >= MAX_MS) throw new BudgetError(`Task gate budget exceeded: ${count}/${MAX_TESTS} tests, ${elapsed}/${MAX_MS} ms. Narrow the task or use the supervisor gate.`)
}
export function changedFiles(base = 'HEAD') {
  const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).split('\0').filter(Boolean)
  return [...new Set([...git('diff', '--name-only', '-z', base, '--'), ...git('ls-files', '--others', '--exclude-standard', '-z')])]
}
export async function runTaskGate(files = changedFiles()) {
  files = [...files]
  if (files.some(file => /(?:standalone\/|dev:component)/.test(file))) files.push('apps/make/src/standalone/dev.test.ts')
  const started = Date.now()
  const summary = () => console.log(`GATE-TASK: tests=${count} seconds=${((Date.now() - started) / 1000).toFixed(1)}`)
  const slow = () => { console.log('GATE-TASK-SLOW:'); for (const path of selections.flat()) console.log(path) }
  const stopDeadline = startDeadline(() => { console.error('Task gate exceeded 60 s'); summary(); slow(); process.exit(2) })
  const contexts = []
  const selections = []
  let count = 0
  const directories = ['apps/make', 'packages/make-contracts', 'packages/make-app', 'scripts']
  try {
    const { createVitest } = await import('vitest/node')
    for (const directory of directories) {
      const ctx = await createVitest('test', {
        root: resolve(directory), config: resolve(directory, 'vitest.config.ts'),
        watch: false, related: files.map(file => resolve(file)), passWithNoTests: true,
      })
      contexts.push(ctx)
      const collected = await ctx.collect()
      const selection = testSelection(collected.tests)
      selections.push(selection.paths)
      if (collected.errors.length || collected.tests.some(file => file.result?.state === 'fail')) throw new Error('Test collection failed')
      count += selection.count
      assertBudget(count, Date.now() - started)
    }
    console.log(`Task gate: ${count}/${MAX_TESTS} related tests; 60 s total budget; no browser suite`)
    for (let i = 0; i < contexts.length; i++) {
      const ctx = contexts[i]
      const directory = directories[i]
      if (directory !== 'scripts' && (ctx.state.getFiles().length || files.some(file => file.startsWith(`${directory}/`)))) {
        await new Promise((accept, reject) => {
          const child = spawn(process.execPath, [resolve('scripts/typecheck.mjs')], { cwd: resolve(directory), stdio: 'inherit' })
          const kill = () => child.kill('SIGTERM')
          process.once('exit', kill)
          child.on('error', reject)
          child.on('exit', code => { process.removeListener('exit', kill); code === 0 ? accept() : reject(new Error(`Typecheck failed: ${directory}`)) })
        })
      }
      if (selections[i].length) await ctx.start(selections[i])
      if (ctx.state.getFiles().some(file => file.result?.state === 'fail') || ctx.state.getUnhandledErrors().length) throw new Error('Related tests failed')
      assertBudget(count, Date.now() - started)
    }
    summary()
  } catch (error) {
    summary()
    if (error instanceof BudgetError) slow()
    throw error
  } finally {
    await Promise.all(contexts.map(ctx => ctx.close()))
    stopDeadline()
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const args = process.argv.slice(2)
  const at = args.indexOf('--base')
  const files = at >= 0 ? changedFiles(args[at + 1]) : args.length ? args : undefined
  runTaskGate(files).catch(error => { console.error(error.message); process.exitCode = error instanceof BudgetError ? 2 : 1 })
}
