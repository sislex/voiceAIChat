import { mt, useMakeLocale } from '../i18n'
// Mock collection table editor (roadmap-4, item 29). The component receives file text and emits
// updated text through onChange; MakePane handles saving with the same manual and automatic
// controls as the code editor.
import { useMemo, useState } from 'react'
import { Button, IconButton } from '@voicechat/ui-kit'
import { mockJsonToTable, newMockRow, serializeMockJson, tableToMockJson, type MockTable } from '@shared/mockTable'

interface Props {
  path: string
  value: string
  onChange: (next: string) => void
  readOnly?: boolean
}

/** Whether the file supports table view: an array of objects, directly or under $body. */
export function mockTableFor(path: string, value: string): MockTable | null {
  if (!/^mock\/.*\.json$/i.test(path)) return null
  try { return mockJsonToTable(JSON.parse(value)) } catch { return null }
}

export function MakeMockTable({ path, value, onChange, readOnly }: Props): JSX.Element {
  useMakeLocale()
  const table = useMemo(() => mockTableFor(path, value), [path, value])
  const [newColumn, setNewColumn] = useState('')
  if (!table) return <p className="make-mock-table-empty">{mt("thisFileIsNotACollectionExpectedJsonWith")}{' '}<code>$body</code>.</p>
  const commit = (next: MockTable): void => onChange(serializeMockJson(tableToMockJson(next)))
  const setCell = (row: number, col: string, text: string): void => {
    const rows = table.rows.map((r, i) => (i === row ? { ...r, [col]: text } : r))
    commit({ ...table, rows })
  }
  const addRow = (): void => commit({ ...table, rows: [...table.rows, newMockRow(table)] })
  const removeRow = (row: number): void => commit({ ...table, rows: table.rows.filter((_, i) => i !== row) })
  const addColumn = (): void => {
    const name = newColumn.trim()
    if (!name || table.columns.includes(name)) return
    commit({ ...table, columns: [...table.columns, name], rows: table.rows.map((r) => ({ ...r, [name]: '' })) })
    setNewColumn('')
  }
  const removeColumn = (col: string): void => commit({ ...table, columns: table.columns.filter((c) => c !== col), rows: table.rows.map((r) => { const { [col]: _drop, ...rest } = r; return rest }) })
  return (
    <div className="make-mock-table" data-testid="make-mock-table">
      <table>
        <thead>
          <tr>
            {table.columns.map((c) => (
              <th key={c}><span>{c}</span>{!readOnly && c !== 'id' && <IconButton size="sm" aria-label={mt("deleteColumnValue", { p0: c })} title={mt("deleteColumn")} onClick={() => removeColumn(c)}>✕</IconButton>}</th>
            ))}
            {!readOnly && <th className="make-mock-table-actions" aria-label={mt("actions")} />}
          </tr>
        </thead>
        <tbody>
          {table.rows.map((r, i) => (
            <tr key={i}>
              {table.columns.map((c) => (
                <td key={c}><input aria-label={mt("valueInRowValue", { p0: c, p1: i + 1 })} value={r[c] ?? ''} readOnly={readOnly} onChange={(e) => setCell(i, c, e.target.value)} /></td>
              ))}
              {!readOnly && <td className="make-mock-table-actions"><IconButton size="sm" aria-label={mt("deleteRowValue", { p0: i + 1 })} title={mt("deleteRow")} onClick={() => removeRow(i)}>✕</IconButton></td>}
            </tr>
          ))}
        </tbody>
      </table>
      {!readOnly && (
        <div className="make-mock-table-foot">
          <Button size="sm" variant="secondary" onClick={addRow}>{mt("row")}</Button>
          <form className="make-mock-table-col" onSubmit={(e) => { e.preventDefault(); addColumn() }}>
            <input aria-label={mt("newColumnName")} placeholder={mt("newColumn")} value={newColumn} onChange={(e) => setNewColumn(e.target.value)} />
            <Button size="sm" variant="ghost" type="submit" disabled={!newColumn.trim()}>{mt("column")}</Button>
          </form>
          <span className="make-mock-table-hint">{mt("numbersTrueFalseNullAndJsonObjectsRetainTheir")}</span>
        </div>
      )}
    </div>
  )
}
