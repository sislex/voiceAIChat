import { beforeEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { render } from '@voicechat/ui-foundation/test/uiRender'
import { createFakeApi } from '@voicechat/ui-foundation/test/fakeApi'
import { MAKE_SCAFFOLD } from '@shared/make'
import { makeTabsKey } from '@voicechat/ui-foundation/persistence'

vi.mock('../lib/makeA11y', async (orig) => ({ ...(await orig<typeof import('../lib/makeA11y')>()), runAxeInFrame: vi.fn(async () => [{ id: 'image-alt', impact: 'critical', help: 'Images must have alternate text', helpUrl: 'https://dequeuniversity.com/rules/axe/image-alt', nodes: 1, target: 'img' }]) }))
vi.mock('../lib/makeScreenshot', () => ({ captureIframeScreenshot: vi.fn(async (_t: unknown, name: string) => new File(['png'], name, { type: 'image/png' })) }))
import { MakePane } from './MakePane'
import type { MakePresenceClient } from '@shared/make'

const CONV = 'make-1'
beforeEach(() => { sessionStorage.clear() })

const openMore = async (): Promise<void> => { await userEvent.click(screen.getByRole('button', { name: 'Ещё' })) }

function renderPane(overrides: Partial<Parameters<typeof MakePane>[0]> = {}) {
  const api = createFakeApi([])
  const listeners: Array<(m: { conversationId: string; rev: number; paths: string[] }) => void> = []
  const make = { onChanged: (cb: (m: { conversationId: string; rev: number; paths: string[] }) => void) => { listeners.push(cb); return () => {} } }
  const onInsertToChat = vi.fn()
  render(<MakePane conversationId={CONV} api={api} make={make} onInsertToChat={onInsertToChat} previewBase={`/api/preview/make/${CONV}/`} {...overrides} />)
  return { api, emit: (m: { conversationId: string; rev: number; paths: string[] }) => listeners.forEach((l) => l(m)), onInsertToChat }
}

describe('MakePane', () => {
  // @testCase T1
  it('confirms middle-click and close-others for all dirty tabs and restores session order', async () => {
    const api = createFakeApi([])
    await api['make:write']({ conversationId: CONV, path: 'a.txt', content: 'clean' })
    renderPane({ api, autosaveDelayMs: 60_000 })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    fireEvent.change(await screen.findByLabelText('Содержимое index.html'), { target: { value: 'draft A' } })
    const tree = screen.getByRole('navigation', { name: 'Файлы проекта' })
    await userEvent.click(within(tree).getByRole('button', { name: /^styles[.]css/ }))
    fireEvent.change(await screen.findByLabelText('Содержимое styles.css'), { target: { value: 'draft B' } })
    await userEvent.click(within(tree).getByRole('button', { name: 'a.txt' }))
    await screen.findByLabelText('Содержимое a.txt')
    await waitFor(() => expect(JSON.parse(sessionStorage.getItem(makeTabsKey(CONV))!)).toEqual(['index.html', 'styles.css', 'a.txt']))
    await userEvent.click(screen.getByRole('button', { name: 'Закрыть остальные' }))
    const dialog = await screen.findByRole('dialog')
    expect(dialog).toHaveTextContent('index.html, styles.css')
    await userEvent.click(within(dialog).getByRole('button', { name: 'Отмена' }))
    const tabs = screen.getByRole('tablist', { name: 'Открытые файлы' })
    fireEvent(within(tabs).getByRole('tab', { name: /styles.css/ }).parentElement!, new MouseEvent('auxclick', { bubbles: true, button: 1 }))
    await userEvent.click(within(await screen.findByRole('dialog')).getAllByRole('button', { name: 'Закрыть' }).at(-1)!)
    expect(within(tabs).queryByRole('tab', { name: /styles.css/ })).toBeNull()
    await userEvent.click(screen.getByRole('button', { name: 'Закрыть остальные' }))
    await userEvent.click(within(await screen.findByRole('dialog')).getAllByRole('button', { name: 'Закрыть' }).at(-1)!)
    await waitFor(() => expect(JSON.parse(sessionStorage.getItem(makeTabsKey(CONV))!)).toEqual(['a.txt']))
    cleanup(); renderPane({ api })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    expect(await screen.findByLabelText('Содержимое a.txt')).toHaveValue('clean')
  })

  // @testCase T3
  it('opens both historical versions as read-only tabs while retaining the working draft', async () => {
    const api = createFakeApi([])
    await api['make:write']({ conversationId: CONV, path: 'index.html', content: 'first' })
    const first = (await api['make:snapshot']({ conversationId: CONV, label: 'first' })).snapshots[0]!.id
    await api['make:write']({ conversationId: CONV, path: 'index.html', content: 'second' })
    const second = (await api['make:snapshot']({ conversationId: CONV, label: 'second' })).snapshots[0]!.id
    const write = vi.spyOn(api, 'make:write')
    const compare = vi.spyOn(api, 'make:snapshotDiff')
    renderPane({ api, autosaveDelayMs: 60_000 })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    fireEvent.change(await screen.findByLabelText('Содержимое index.html'), { target: { value: 'working draft' } })
    await userEvent.click(screen.getByRole('tab', { name: 'История' }))
    await userEvent.selectOptions(screen.getByLabelText('Первый снимок'), first)
    await userEvent.selectOptions(screen.getByLabelText('Второй снимок'), second)
    await userEvent.click(screen.getByRole('button', { name: 'Сравнить снимки' }))
    const diff = await screen.findByTestId('make-pair-diff')
    expect(compare).toHaveBeenCalledWith({ conversationId: CONV, snapshotId: first, compareSnapshotId: second })
    await userEvent.click(within(within(diff).getByText('index.html').closest('li')!).getByRole('button', { name: 'Первый снимок' }))
    const historical = await screen.findByLabelText(`Содержимое snapshot:${first}:index.html`)
    expect(historical).toHaveValue('first')
    expect(historical).toHaveAttribute('readonly')
    fireEvent.change(historical, { target: { value: 'attempted overwrite' } })
    fireEvent.keyDown(historical, { key: 's', ctrlKey: true })
    expect(screen.getByRole('button', { name: 'Сохранить' })).toBeDisabled()
    expect(write).not.toHaveBeenCalled()
    await userEvent.click(screen.getByRole('tab', { name: 'История' }))
    await userEvent.click(within(within(screen.getByTestId('make-pair-diff')).getByText('index.html').closest('li')!).getByRole('button', { name: 'Второй снимок' }))
    expect(await screen.findByLabelText(`Содержимое snapshot:${second}:index.html`)).toHaveValue('second')
    await userEvent.click(within(screen.getByRole('tablist', { name: 'Открытые файлы' })).getByRole('tab', { name: /^index.html[^·]*$/ }))
    expect(await screen.findByLabelText('Содержимое index.html')).toHaveValue('working draft')
    expect(write).not.toHaveBeenCalled()
  })

  // @testCase T6
  it('keeps a failed save dirty and reports a timestamp only after retry succeeds', async () => {
    const api = createFakeApi([])
    const original = api['make:write']
    const write = vi.spyOn(api, 'make:write').mockRejectedValueOnce(new Error('disk unavailable')).mockImplementation(original)
    renderPane({ api, autosaveDelayMs: 60_000 })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const editor = await screen.findByLabelText('Содержимое index.html')
    fireEvent.change(editor, { target: { value: 'new source' } })
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }))
    await screen.findByText('Ошибка сохранения · есть изменения')
    expect(editor).toHaveValue('new source')
    expect(document.querySelector('.make-editor time')).toBeNull()
    const unload = new Event('beforeunload', { cancelable: true }); window.dispatchEvent(unload)
    expect(unload.defaultPrevented).toBe(true)
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }))
    await waitFor(() => expect(document.querySelector('.make-editor time')).not.toBeNull())
    expect(write).toHaveBeenCalledTimes(2)
    const clean = new Event('beforeunload', { cancelable: true }); window.dispatchEvent(clean)
    expect(clean.defaultPrevented).toBe(false)
  })

  // @testCase T1
  it('preserves independent drafts and confirms closing inactive dirty tabs', async () => {
    renderPane({ autosaveDelayMs: 60_000 })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    fireEvent.change(await screen.findByLabelText('Содержимое index.html'), { target: { value: '<h1>Draft A</h1>' } })
    const tree = screen.getByRole('navigation', { name: 'Файлы проекта' })
    await userEvent.click(within(tree).getByRole('button', { name: /^styles[.]css/ }))
    fireEvent.change(await screen.findByLabelText('Содержимое styles.css'), { target: { value: 'body { color: red; }' } })
    const tabs = screen.getByRole('tablist', { name: 'Открытые файлы' })
    expect(within(tabs).getAllByLabelText('не сохранено')).toHaveLength(2)
    await userEvent.click(within(tabs).getByRole('tab', { name: /index.html/ }))
    expect(await screen.findByLabelText('Содержимое index.html')).toHaveValue('<h1>Draft A</h1>')
    await userEvent.click(within(tabs).getByRole('button', { name: 'Закрыть styles.css' }))
    expect(await screen.findByText('Отбросить несохранённые изменения?')).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: 'Отмена' }))
    await userEvent.click(within(tabs).getByRole('tab', { name: /styles.css/ }))
    expect(await screen.findByLabelText('Содержимое styles.css')).toHaveValue('body { color: red; }')
    const unload = new Event('beforeunload', { cancelable: true })
    window.dispatchEvent(unload)
    expect(unload.defaultPrevented).toBe(true)
  })

  // @testCase T6
  it('does not mark another file saved when a write finishes after switching tabs', async () => {
    const api = createFakeApi([])
    const write = api['make:write']
    let finish: (() => void) | undefined
    api['make:write'] = async (args) => {
      await new Promise<void>((resolve) => { finish = resolve })
      return write(args)
    }
    renderPane({ api, autosaveDelayMs: 60_000 })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    fireEvent.change(await screen.findByLabelText('Содержимое index.html'), { target: { value: 'draft A' } })
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }))
    const tree = screen.getByRole('navigation', { name: 'Файлы проекта' })
    await userEvent.click(within(tree).getByRole('button', { name: /^styles[.]css/ }))
    fireEvent.change(await screen.findByLabelText('Содержимое styles.css'), { target: { value: 'draft B' } })
    finish!()
    await waitFor(() => expect(screen.getByLabelText('Содержимое styles.css')).toHaveValue('draft B'))
    await waitFor(() => expect(screen.getAllByText('не сохранено').length).toBeGreaterThan(0))
    expect((await api['make:read']({ conversationId: CONV, path: 'styles.css' })).content).toBe(MAKE_SCAFFOLD['styles.css'])
  })

  // @testCase TC-11
  it('открывается на превью с iframe проекта; пресеты ширины и обновление меняют src', async () => {
    renderPane()
    expect(await screen.findByRole('button', { name: 'Настройки проекта: HTML+CSS+JS · своя система' })).toBeInTheDocument()
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    expect(frame.getAttribute('src')).toBe(`/api/preview/make/${CONV}/index.html?rev=0&makeScheme=auto`)
    expect(frame.getAttribute('sandbox')).toContain('allow-scripts')
    expect(frame.getAttribute('sandbox')).toContain('allow-downloads')
    await userEvent.click(screen.getByRole('button', { name: 'Телефон' }))
    expect((screen.getByTitle('Превью проекта') as HTMLIFrameElement).style.width).toBe('390px')
    await userEvent.click(screen.getByRole('button', { name: 'Обновить превью' }))
    expect(screen.getByTitle('Превью проекта').getAttribute('src')).toContain('rev=1')
  })

  // @testCase TC-REG-01
  it('открывает настройки из бейджа и обновляет его после сохранения Bootstrap', async () => {
    renderPane()
    await userEvent.click(await screen.findByRole('button', { name: 'Настройки проекта: HTML+CSS+JS · своя система' }))
    const dialog = await screen.findByTestId('make-notes')
    await userEvent.selectOptions(within(dialog).getByRole('combobox', { name: 'Стилевая база' }), 'bootstrap')
    await userEvent.click(within(dialog).getByRole('button', { name: 'Сохранить' }))
    expect(await screen.findByRole('button', { name: /Настройки проекта: .*Bootstrap/ })).toBeInTheDocument()
  })

  it('режим «Код»: дерево файлов, редактор, сохранение через кнопку и Ctrl+S', async () => {
    const { api } = renderPane()
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const tree = screen.getByRole('navigation', { name: 'Файлы проекта' })
    expect(within(tree).getByRole('button', { name: /^index\.html/ })).toBeInTheDocument()
    const editor = await screen.findByLabelText('Содержимое index.html') as HTMLTextAreaElement
    expect(editor.value).toBe(MAKE_SCAFFOLD['index.html'])
    expect(screen.getByText('сохранено')).toBeInTheDocument()
    await userEvent.clear(editor)
    await userEvent.type(editor, '<h1>Привет</h1>')
    expect(screen.getByText('не сохранено')).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }))
    await waitFor(() => expect(screen.getByText('сохранено')).toBeInTheDocument())
    expect((await api['make:read']({ conversationId: CONV, path: 'index.html' })).content).toBe('<h1>Привет</h1>')

    await userEvent.click(within(tree).getByRole('button', { name: /^styles\.css/ }))
    const css = await screen.findByLabelText('Содержимое styles.css')
    await userEvent.type(css, 'h1{{')
    await userEvent.keyboard('{Control>}s{/Control}')
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'styles.css' })).content).toBe(MAKE_SCAFFOLD['styles.css'] + 'h1{'))
  })

  it('сводка расхода проекта в шапке (п.24)', () => {
    renderPane({ usage: { turns: 3, inputTokens: 12000, outputTokens: 800, costUsd: 0.4321, estimated: true, unpriced: 0 } })
    const chip = screen.getByTestId('make-cost')
    expect(chip).toHaveTextContent('≈ $0.43')
    expect(chip).toHaveTextContent('3 хода')
    expect(chip.getAttribute('title')).toContain('↓ 12.0k')
  })

  it('публикация: адрес и пароль уходят в make:publish, ссылка показывает /s/<slug>/, просмотры видны (п.25)', async () => {
    const { api } = renderPane()
    await userEvent.click(await screen.findByRole('button', { name: 'Опубликовать' }))
    await userEvent.click(within(screen.getByTestId('make-publish')).getByRole('button', { name: 'Опубликовать' }))
    await screen.findByTestId('make-public-url')
    await userEvent.type(screen.getByLabelText('Адрес публикации'), 'demo-site')
    await userEvent.type(screen.getByLabelText('Пароль публикации'), 'qwerty')
    await userEvent.click(screen.getByRole('button', { name: 'Обновить публикацию' }))
    await waitFor(() => expect(screen.getByTestId('make-public-url')).toHaveTextContent('/s/demo-site/'))
    expect((await api['make:state']({ conversationId: CONV })).published).toMatchObject({ slug: 'demo-site', passwordProtected: true })
    expect(screen.getByTestId('make-public-views')).toHaveTextContent('7')
    await userEvent.click(screen.getByRole('button', { name: 'Снять пароль' }))
    await waitFor(async () => expect((await api['make:state']({ conversationId: CONV })).published?.passwordProtected).toBe(false))
  })

  it('комментарии к превью: кнопка 💬 открывает панель, выбранный элемент комментируется, счётчик открытых (п.32)', async () => {
    const { api } = renderPane()
    await userEvent.click(await screen.findByRole('button', { name: '💬' }))
    const panel = screen.getByTestId('make-comments')
    expect(within(panel).getByLabelText('Текст комментария')).toBeDisabled()
    // The iframe inspector sends the selected element in a message.
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    window.dispatchEvent(new MessageEvent('message', { data: { type: 'vc-make.selected', selector: 'h1', tag: 'h1', text: 'Привет', html: '<h1>Привет</h1>' }, source: frame.contentWindow }))
    await waitFor(() => expect(within(panel).getByLabelText('Текст комментария')).toBeEnabled())
    await userEvent.type(within(panel).getByLabelText('Текст комментария'), 'Крупнее')
    await userEvent.click(within(panel).getByRole('button', { name: 'Добавить' }))
    await waitFor(() => expect(within(panel).getByText('Крупнее')).toBeInTheDocument())
    expect((await api['make:comments']({ conversationId: CONV })).comments[0]).toMatchObject({ selector: 'h1', elementLabel: '<h1> Привет' })
    expect(screen.getByRole('button', { name: '💬 1' })).toBeInTheDocument()
    await userEvent.click(within(panel).getByRole('button', { name: 'Решено' }))
    await waitFor(() => expect(screen.getByRole('button', { name: '💬' })).toBeInTheDocument())
  })

  it('read-only ссылка внутри ChatAI: создать и отозвать из диалога публикации (п.33)', async () => {
    const { api } = renderPane()
    await userEvent.click(await screen.findByRole('button', { name: 'Опубликовать' }))
    await userEvent.click(within(screen.getByTestId('make-share')).getByRole('button', { name: 'Создать ссылку для чтения' }))
    await waitFor(() => expect(screen.getByTestId('make-share-url')).toHaveTextContent('#/make-shared/share123'))
    expect((await api['make:state']({ conversationId: CONV })).shared?.token).toBe('share123')
    await userEvent.click(within(screen.getByTestId('make-share')).getByRole('button', { name: 'Отозвать' }))
    await waitFor(() => expect(within(screen.getByTestId('make-share')).getByRole('button', { name: 'Создать ссылку для чтения' })).toBeInTheDocument())
  })

  it('make.changed с .comments.json перечитывает комментарии без перезагрузки превью (roadmap-2 п.7)', async () => {
    const { api, emit } = renderPane()
    await userEvent.click(await screen.findByRole('button', { name: '💬' }))
    await api['make:commentAdd']({ conversationId: CONV, selector: 'h1', elementLabel: '<h1>', text: 'Из другой вкладки' })
    emit({ conversationId: CONV, rev: 0, paths: ['.comments.json'] })
    await waitFor(() => expect(within(screen.getByTestId('make-comments')).getByText('Из другой вкладки')).toBeInTheDocument())
    expect(screen.getByRole('button', { name: '💬 1' })).toBeInTheDocument()
  })

  it('визуальный diff хода: «до» на старте, «после» по окончании, только если файлы менялись (roadmap-2 п.8)', async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true })
    const origCreate = URL.createObjectURL
    let n = 0
    URL.createObjectURL = () => `blob:shot-${++n}`
    URL.revokeObjectURL = () => undefined
    try {
      const api = createFakeApi([])
      const listeners: Array<(m: { conversationId: string; rev: number; paths: string[] }) => void> = []
      const make = { onChanged: (cb: (m: { conversationId: string; rev: number; paths: string[] }) => void) => { listeners.push(cb); return () => {} } }
      const { rerender } = render(<MakePane conversationId={CONV} api={api} make={make} previewBase={`/api/preview/make/${CONV}/`} turnActive={false} />)
      await screen.findByTitle('Превью проекта')
      rerender(<MakePane conversationId={CONV} api={api} make={make} previewBase={`/api/preview/make/${CONV}/`} turnActive />)
      await waitFor(() => expect(n).toBe(1))
      listeners.forEach((l) => l({ conversationId: CONV, rev: 2, paths: ['index.html'] }))
      rerender(<MakePane conversationId={CONV} api={api} make={make} previewBase={`/api/preview/make/${CONV}/`} turnActive={false} />)
      await vi.advanceTimersByTimeAsync(1500)
      expect(await screen.findByTestId('make-turn-diff')).toBeInTheDocument()
      expect(screen.getByAltText('Превью до правок').getAttribute('src')).toBe('blob:shot-1')
      expect(screen.getByAltText('Превью после правок').getAttribute('src')).toBe('blob:shot-2')
      await userEvent.click(screen.getByRole('button', { name: 'Скрыть сравнение' }))
      expect(screen.queryByTestId('make-turn-diff')).toBeNull()
    } finally { URL.createObjectURL = origCreate; vi.useRealTimers() }
  })

  it('во время хода ассистента записанный файл открывается в редакторе и вкладка подсвечивается (roadmap-2 п.10)', async () => {
    const api = createFakeApi([])
    const listeners: Array<(m: { conversationId: string; rev: number; paths: string[] }) => void> = []
    const make = { onChanged: (cb: (m: { conversationId: string; rev: number; paths: string[] }) => void) => { listeners.push(cb); return () => {} } }
    const { rerender } = render(<MakePane conversationId={CONV} api={api} make={make} previewBase={`/api/preview/make/${CONV}/`} turnActive={false} />)
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await screen.findByLabelText('Содержимое index.html')
    rerender(<MakePane conversationId={CONV} api={api} make={make} previewBase={`/api/preview/make/${CONV}/`} turnActive />)
    await api['make:write']({ conversationId: CONV, path: 'styles.css', content: 'h1 { color: green }' })
    listeners.forEach((l) => l({ conversationId: CONV, rev: 3, paths: ['styles.css'] }))
    const editor = await screen.findByLabelText('Содержимое styles.css') as HTMLTextAreaElement
    expect(editor.value).toBe('h1 { color: green }')
    expect(screen.getByTestId('make-file-tab-flash')).toHaveTextContent('styles.css')
  })

  it('история публикаций в диалоге: «Вернуть» переключает публикацию на прежний снимок (roadmap-2 п.11)', async () => {
    const api = createFakeApi([])
    await api['make:publish']({ conversationId: CONV })
    const snap = (await api['make:snapshot']({ conversationId: CONV, label: 'v1' })).snapshots[0]!
    await api['make:publish']({ conversationId: CONV, snapshotId: snap.id })
    render(<MakePane conversationId={CONV} api={api} make={{ onChanged: () => () => {} }} previewBase={`/api/preview/make/${CONV}/`} />)
    await userEvent.click(await screen.findByRole('button', { name: 'Опубликован' }))
    const hist = await screen.findByTestId('make-publish-history')
    await userEvent.click(within(hist).getByText(/История публикаций \(2\)/))
    expect(within(hist).getByText(/снимок «v1»/)).toBeInTheDocument()
    await userEvent.click(within(hist).getByRole('button', { name: 'Вернуть' }))
    await waitFor(async () => expect((await api['make:state']({ conversationId: CONV })).published?.snapshotId).toBeNull())
  })

  it('библиотека: «Сохранить весь кит» отдаёт компоненты со сториз и файл токенов (roadmap-2 п.13)', async () => {
    const api = createFakeApi([])
    await api['make:write']({ conversationId: CONV, path: 'src/components/Btn.tsx', content: 'export const Btn = () => null' })
    await api['make:write']({ conversationId: CONV, path: 'src/components/Btn.stories.tsx', content: 'export default { title: "Btn" }' })
    const spy = vi.spyOn(api, 'make:libraryExport')
    render(<MakePane conversationId={CONV} api={api} make={{ onChanged: () => () => {} }} previewBase={`/api/preview/make/${CONV}/`} />)
    await userEvent.click(await screen.findByRole('tab', { name: 'Код' }))
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Библиотека' }))
    await userEvent.click(await screen.findByRole('button', { name: /Сохранить весь кит \(3 файл\.\)/ }))
    await waitFor(() => expect(spy).toHaveBeenCalledWith(expect.objectContaining({ paths: ['src/components/Btn.stories.tsx', 'src/components/Btn.tsx', 'styles.css'] })))
    expect(await screen.findByText('кит')).toBeInTheDocument()
  })

  it('presence: чип с числом вкладок и read-only при чужом редактировании файла (roadmap-2 п.14)', async () => {
    const api = createFakeApi([])
    const listeners: Array<(m: { conversationId: string; clients: MakePresenceClient[] }) => void> = []
    const make = { onChanged: () => () => {}, onPresence: (cb: (m: { conversationId: string; clients: MakePresenceClient[] }) => void) => { listeners.push(cb); return () => {} } }
    render(<MakePane conversationId={CONV} api={api} make={make} previewBase={`/api/preview/make/${CONV}/`} />)
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const editor = await screen.findByLabelText('Содержимое index.html') as HTMLTextAreaElement
    expect(screen.queryByTestId('make-presence')).toBeNull()
    listeners.forEach((l) => l({ conversationId: CONV, clients: [{ clientId: 'other', user: 'admin', path: 'index.html', editing: true, at: Date.now() }] }))
    expect(await screen.findByTestId('make-presence')).toHaveTextContent('👥 2')
    expect(screen.getByTestId('make-lock')).toBeInTheDocument()
    expect(editor.readOnly).toBe(true)
    listeners.forEach((l) => l({ conversationId: CONV, clients: [{ clientId: 'other', user: 'admin', path: 'styles.css', editing: true, at: Date.now() }] }))
    await waitFor(() => expect(screen.queryByTestId('make-lock')).toBeNull())
    expect(editor.readOnly).toBe(false)
  })

  it('тесты компонентов: кнопка «Тесты», результаты из раннера, «Исправить» с упавшими (roadmap-4 п.3)', async () => {
    const api = createFakeApi([])
    await api['make:write']({ conversationId: CONV, path: 'src/components/Button.test.tsx', content: "test('рендер', async () => {})\ntest('клик', async () => {})" })
    const onAsk = vi.fn()
    render(<MakePane conversationId={CONV} api={api} make={{ onChanged: () => () => {} }} previewBase={`/api/preview/make/${CONV}/`} onAskAssistant={onAsk} />)
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    await userEvent.click(await screen.findByRole('button', { name: /^Тесты \(2\)/ }))
    const frame = await screen.findByTitle('Тесты src/components/Button.test.tsx') as HTMLIFrameElement
    expect(frame.src).toContain('__tests__?file=src%2Fcomponents%2FButton.test.tsx')
    const send = (data: object) => window.dispatchEvent(new MessageEvent('message', { data, source: frame.contentWindow }))
    send({ type: 'vc-make.test', file: './src/components/Button.test.tsx', name: 'рендер', status: 'passed', ms: 12 })
    send({ type: 'vc-make.test', file: './src/components/Button.test.tsx', name: 'клик', status: 'failed', ms: 3, error: 'expected 1 toBe 2' })
    send({ type: 'vc-make.tests-done', passed: 1, failed: 1 })
    const panel = await screen.findByTestId('make-tests')
    await waitFor(() => expect(within(panel).getByText('✗ клик')).toBeInTheDocument())
    expect(within(panel).getByText('expected 1 toBe 2')).toBeInTheDocument()
    await userEvent.click(within(panel).getByRole('button', { name: 'Исправить' }))
    expect(onAsk).toHaveBeenCalledWith(expect.stringContaining('Button.test.tsx › клик: expected 1 toBe 2'))
  })

  it('«Только спросить» переключает режим вопроса через onAskOnlyChange (roadmap-4 п.4)', async () => {
    const onAskOnlyChange = vi.fn()
    render(<MakePane conversationId={CONV} api={createFakeApi([])} make={{ onChanged: () => () => {} }} previewBase={`/api/preview/make/${CONV}/`} askOnly={false} onAskOnlyChange={onAskOnlyChange} />)
    await userEvent.click(await screen.findByRole('button', { name: 'Только спросить' }))
    expect(onAskOnlyChange).toHaveBeenCalledWith(true)
  })

  it('«Сверить с запросом» шлёт скриншот «после» и исходный запрос ассистенту (roadmap-4 п.5)', async () => {
    vi.useFakeTimers({ shouldAdvanceTime: true })
    const origCreate = URL.createObjectURL; const origFetch = globalThis.fetch
    URL.createObjectURL = () => 'blob:x'; URL.revokeObjectURL = () => undefined
    globalThis.fetch = (async () => new Response(new Blob(['png'], { type: 'image/png' }))) as typeof fetch
    try {
      const api = createFakeApi([])
      const listeners: Array<(m: { conversationId: string; rev: number; paths: string[] }) => void> = []
      const make = { onChanged: (cb: (m: { conversationId: string; rev: number; paths: string[] }) => void) => { listeners.push(cb); return () => {} } }
      const onAttachImage = vi.fn(); const onAsk = vi.fn()
      const props = { conversationId: CONV, api, make, previewBase: `/api/preview/make/${CONV}/`, onAttachImage, onAskAssistant: onAsk, lastRequest: 'Сделай кнопку синей' }
      const { rerender } = render(<MakePane {...props} turnActive={false} />)
      await screen.findByTitle('Превью проекта')
      rerender(<MakePane {...props} turnActive />)
      await vi.advanceTimersByTimeAsync(50)
      listeners.forEach((l) => l({ conversationId: CONV, rev: 2, paths: ['styles.css'] }))
      rerender(<MakePane {...props} turnActive={false} />)
      await vi.advanceTimersByTimeAsync(1500)
      await userEvent.click(await screen.findByRole('button', { name: 'Сверить с запросом' }))
      await waitFor(() => expect(onAttachImage).toHaveBeenCalled())
      expect(onAsk).toHaveBeenCalledWith(expect.stringContaining('Сделай кнопку синей'))
    } finally { URL.createObjectURL = origCreate; globalThis.fetch = origFetch; vi.useRealTimers() }
  })

  it('после хода показываются чипы «Что дальше», клик отправляет промпт (roadmap-4 п.8)', async () => {
    const onAsk = vi.fn()
    const api = createFakeApi([])
    const props = { conversationId: CONV, api, make: { onChanged: () => () => {} }, previewBase: `/api/preview/make/${CONV}/`, onAskAssistant: onAsk }
    const { rerender } = render(<MakePane {...props} turnActive={false} />)
    await screen.findByTitle('Превью проекта')
    expect(screen.queryByTestId('make-next')).toBeNull()
    rerender(<MakePane {...props} turnActive />)
    rerender(<MakePane {...props} turnActive={false} />)
    const strip = await screen.findByTestId('make-next')
    const chips = within(strip).getAllByRole('button').filter((b) => b.className.includes('make-next-chip'))
    expect(chips.length).toBe(3)
    await userEvent.click(chips[0]!)
    expect(onAsk).toHaveBeenCalled()
    expect(screen.queryByTestId('make-next')).toBeNull()
  })

  it('onEditorContext сообщает хосту открытый файл и сбрасывает его при размонтировании (п.21)', async () => {
    const onEditorContext = vi.fn()
    const { unmount } = render(<MakePane conversationId={CONV} api={createFakeApi([])} make={{ onChanged: () => () => {} }} onEditorContext={onEditorContext} previewBase={`/api/preview/make/${CONV}/`} />)
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await waitFor(() => expect(onEditorContext).toHaveBeenCalledWith({ path: 'index.html' }))
    await userEvent.click(within(screen.getByRole('navigation', { name: 'Файлы проекта' })).getByRole('button', { name: /^styles\.css/ }))
    await waitFor(() => expect(onEditorContext).toHaveBeenLastCalledWith({ path: 'styles.css' }))
    unmount()
    expect(onEditorContext).toHaveBeenLastCalledWith(null)
  })

  it('make.changed перезагружает превью и содержимое файла, если редактор не грязный', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    await api['make:write']({ conversationId: CONV, path: 'index.html', content: '<p>от ассистента</p>' })
    emit({ conversationId: CONV, rev: 7, paths: ['index.html'] })
    await waitFor(() => expect(screen.getByTitle('Превью проекта').getAttribute('src')).toContain('rev=7'))
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await waitFor(() => expect((screen.getByLabelText('Содержимое index.html') as HTMLTextAreaElement).value).toBe('<p>от ассистента</p>'))
  })

  it('«История»: снимки и откат; выбранный элемент превью уходит в чат', async () => {
    const { onInsertToChat } = renderPane()
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    await userEvent.click(screen.getByRole('tab', { name: 'История' }))
    expect(screen.getByText('Снимков пока нет')).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: '+ Снимок' }))
    const nameInput = await screen.findByLabelText('Название снимка')
    await userEvent.clear(nameInput)
    await userEvent.type(nameInput, 'Мой снимок')
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }))
    expect(await screen.findByText('Мой снимок')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: 'Вернуть' })).toBeInTheDocument()

    await userEvent.click(screen.getByRole('tab', { name: 'Превью' }))
    const selected = { type: 'vc-make.selected', selector: 'main > h1', tag: 'h1', text: 'Новый проект', html: '<h1>Новый проект</h1>' }
    window.dispatchEvent(new MessageEvent('message', { data: selected, source: (await screen.findByTitle('Превью проекта') as HTMLIFrameElement).contentWindow ?? frame.contentWindow }))
    await screen.findByTestId('make-selected')
    await userEvent.click(screen.getByRole('button', { name: 'В чат' }))
    expect(onInsertToChat).toHaveBeenCalledWith(expect.stringContaining('main > h1'))
  })

  it('публикация: ссылка появляется в диалоге, снятие требует подтверждения', async () => {
    renderPane()
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('button', { name: 'Опубликовать' }))
    await userEvent.click(within(screen.getByTestId('make-publish')).getByRole('button', { name: 'Опубликовать' }))
    expect((await screen.findByTestId('make-public-url')).textContent).toContain('/p/tok123/')
    await userEvent.click(screen.getByRole('button', { name: 'Снять с публикации' }))
    await userEvent.click(await screen.findByRole('button', { name: 'Снять' }))
    await waitFor(() => expect(screen.queryByTestId('make-public-url')).not.toBeInTheDocument())
  })

  it('проверка проекта показывает результат; шаблон применяется после подтверждения', async () => {
    const { api } = renderPane()
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await userEvent.click(screen.getByRole('button', { name: 'Проверить' }))
    expect(await screen.findByTestId('make-issues')).toHaveTextContent('Проверка пройдена')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Шаблоны проекта' }))
    await userEvent.click(within(screen.getByTestId('make-templates')).getAllByRole('button', { name: 'Применить' })[1]!)
    await waitFor(() => expect(screen.getAllByRole('button', { name: 'Применить' }).length).toBeGreaterThan(3))
    await userEvent.click(screen.getAllByRole('button', { name: 'Применить' }).at(-1)!)
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'index.html' })).content).toBe('<h1>landing</h1>'))
  })

  it('загрузка с диска: картинка уходит бинарно в img/, текст — как текст', async () => {
    const { api } = renderPane()
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const input = screen.getByTestId('make-upload-input') as HTMLInputElement
    await userEvent.upload(input, [
      new File([new Uint8Array([1, 2, 3])], 'My Logo.png', { type: 'image/png' }),
      new File(['body{}'], 'theme.css', { type: 'text/css' })
    ])
    await waitFor(async () => {
      const paths = (await api['make:state']({ conversationId: CONV })).files.map((f) => f.path)
      expect(paths).toEqual(expect.arrayContaining(['img/My-Logo.png', 'theme.css']))
    })
    expect((await api['make:read']({ conversationId: CONV, path: 'theme.css' })).content).toBe('body{}')
    await userEvent.click((await screen.findAllByRole('button', { name: /My-Logo\.png/ }))[0]!)
    expect(await screen.findByTestId('make-binary')).toContainElement(screen.getByRole('img', { name: 'Просмотр img/My-Logo.png' }))
  })

  it('drag-and-drop файлов в дерево загружает их; редактор подсвечивает синтаксис', async () => {
    const { api } = renderPane()
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const zone = screen.getByTestId('make-code')
    const file = new File(['h1{color:red}'], 'drop.css', { type: 'text/css' })
    const dataTransfer = { types: ['Files'], files: [file], dropEffect: 'none' }
    fireEvent.dragOver(zone, { dataTransfer })
    expect(await screen.findByText(/Отпустите, чтобы загрузить/)).toBeInTheDocument()
    fireEvent.drop(zone, { dataTransfer })
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'drop.css' })).content).toBe('h1{color:red}'))
    await userEvent.click((await screen.findAllByRole('button', { name: /drop\.css/ }))[0]!)
    await screen.findByLabelText('Содержимое drop.css')
    expect(document.querySelector('.make-highlight .hljs-selector-tag')?.textContent).toBe('h1')
  })

  it('поиск: фильтр дерева по имени и поиск по содержимому на Enter', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'css/theme.css', content: 'body{color:teal}' })
    emit({ conversationId: CONV, rev: next.rev, paths: ['css/theme.css'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const input = screen.getByRole('searchbox', { name: 'Поиск по файлам проекта' })
    await userEvent.type(input, 'theme')
    expect(screen.queryAllByRole('button', { name: /^index\.html/ })).toHaveLength(0)
    expect(screen.getAllByRole('button', { name: /theme\.css/ }).length).toBeGreaterThan(0)
    await userEvent.clear(input)
    await userEvent.type(input, 'teal{Enter}')
    const region = await screen.findByTestId('make-matches')
    expect(region).toHaveTextContent('Найдено: 1')
    await userEvent.click(within(region).getByRole('button', { name: /css\/theme\.css/ }))
    expect(await screen.findByLabelText('Содержимое css/theme.css')).toBeInTheDocument()
  })

  it('«Компоненты»: список сториз из *.stories.jsx, выбор стори открывает раннер, кнопка вставляет контекст в чат', async () => {
    const { api, emit, onInsertToChat } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'src/components/Button.stories.jsx', content: "export default { title: 'Button' }\nexport const Primary = {}\nexport const Small = {}" })
    emit({ conversationId: CONV, rev: next.rev, paths: ['src/components/Button.stories.jsx'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    await userEvent.click(await screen.findByRole('button', { name: 'Small' }))
    const frame = await screen.findByTitle('Стори Small') as HTMLIFrameElement
    expect(frame.src).toContain('__stories__?file=src%2Fcomponents%2FButton.stories.jsx&story=Small')
    await userEvent.click(screen.getByRole('button', { name: 'Работать над компонентом' }))
    expect(onInsertToChat).toHaveBeenCalledWith(expect.stringContaining('компонентом Button'))
  })

  it('controls: args из раннера превращаются в поля, изменение уходит в iframe, «Сбросить» очищает', async () => {
    const { api, emit, onInsertToChat } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'src/B.stories.jsx', content: "export default { title: 'B' }\nexport const A = {}" })
    emit({ conversationId: CONV, rev: next.rev, paths: ['src/B.stories.jsx'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    const frame = await screen.findByTitle('Стори A') as HTMLIFrameElement
    const post = vi.spyOn(frame.contentWindow!, 'postMessage')
    fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.story', story: 'A', args: { children: 'Кнопка', disabled: false, size: 2, onClick: '[function]' } }, source: frame.contentWindow }))
    const controls = await screen.findByTestId('make-controls')
    await userEvent.click(within(controls).getByLabelText('disabled'))
    expect(post).toHaveBeenLastCalledWith({ type: 'vc-make.args', args: { disabled: true } }, '*')
    await userEvent.clear(within(controls).getByLabelText('children'))
    await userEvent.type(within(controls).getByLabelText('children'), 'Ок')
    expect(post).toHaveBeenLastCalledWith({ type: 'vc-make.args', args: { disabled: true, children: 'Ок' } }, '*')
    expect(within(controls).getByText('[function]')).toBeInTheDocument()
    await userEvent.click(within(controls).getByRole('button', { name: 'Сохранить через ассистента' }))
    expect(onInsertToChat).toHaveBeenCalledWith(expect.stringContaining('"disabled":true'))
    await userEvent.click(within(controls).getByRole('button', { name: 'Сбросить' }))
    expect(post).toHaveBeenLastCalledWith({ type: 'vc-make.args', args: {} }, '*')
    expect((within(controls).getByLabelText('disabled') as HTMLInputElement).checked).toBe(false)
  })

  it('enum-подобный arg рисуется селектом с вариантами из других стори', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'src/C.stories.jsx', content: "export default { title: 'C' }\nexport const A = {}" })
    emit({ conversationId: CONV, rev: next.rev, paths: ['src/C.stories.jsx'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    const frame = await screen.findByTitle('Стори A') as HTMLIFrameElement
    const post = vi.spyOn(frame.contentWindow!, 'postMessage')
    fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.story', story: 'A', args: { variant: 'primary' }, options: { variant: ['primary', 'secondary', 'danger'] } }, source: frame.contentWindow }))
    const select = await screen.findByLabelText('variant') as HTMLSelectElement
    expect(select.tagName).toBe('SELECT')
    expect([...select.options].map((o) => o.value)).toEqual(['primary', 'secondary', 'danger'])
    await userEvent.selectOptions(select, 'danger')
    expect(post).toHaveBeenLastCalledWith({ type: 'vc-make.args', args: { variant: 'danger' } }, '*')
  })

  it('свежий проект показывает стартовые идеи; клик вставляет промпт в чат; диалог «Идеи» группирует все', async () => {
    const { onInsertToChat } = renderPane()
    await screen.findByTitle('Превью проекта')
    const starters = await screen.findByTestId('make-starters')
    await userEvent.click(within(starters).getByRole('button', { name: /Лендинг SaaS/ }))
    expect(onInsertToChat).toHaveBeenCalledWith(expect.stringContaining('лендинг для SaaS'))
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Идеи для старта' }))
    const dialog = await screen.findByTestId('make-ideas')
    expect(within(dialog).getByRole('heading', { name: 'React и компоненты' })).toBeInTheDocument()
    await userEvent.click(within(dialog).getByRole('button', { name: /Игра 2048/ }))
    expect(onInsertToChat).toHaveBeenLastCalledWith(expect.stringContaining('2048'))
    await waitFor(() => expect(screen.queryByTestId('make-ideas')).not.toBeInTheDocument())
  })

  it('вкладки открытых файлов: открытие добавляет, закрытие активной переключает на соседнюю', async () => {
    renderPane()
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const tree = screen.getByRole('navigation', { name: 'Файлы проекта' })
    await userEvent.click(within(tree).getByRole('button', { name: /^index\.html/ }))
    await userEvent.click(within(tree).getByRole('button', { name: /^styles\.css/ }))
    const bar = await screen.findByRole('tablist', { name: 'Открытые файлы' })
    expect(within(bar).getAllByRole('tab').map((t) => t.textContent)).toEqual(['index.html', 'styles.css'])
    expect(within(bar).getByRole('tab', { name: 'styles.css' })).toHaveAttribute('aria-selected', 'true')
    await userEvent.click(within(bar).getByRole('button', { name: 'Закрыть styles.css' }))
    expect(await screen.findByLabelText('Содержимое index.html')).toBeInTheDocument()
    expect(within(bar).getAllByRole('tab')).toHaveLength(1)
  })

  it('автосохранение пишет файл после паузы, а ошибка компиляции tsx попадает в маркеры/баннер', async () => {
    const { api, emit } = renderPane({ autosaveDelayMs: 30 })
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'src/A.tsx', content: 'export const A = 1' })
    emit({ conversationId: CONV, rev: next.rev, paths: ['src/A.tsx'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await userEvent.click((await screen.findAllByRole('button', { name: /A\.tsx/ }))[0]!)
    const editor = await screen.findByLabelText('Содержимое src/A.tsx')
    await userEvent.type(editor, ' // SYNTAX_ERROR')
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'src/A.tsx' })).content).toContain('SYNTAX_ERROR'))
    expect(await screen.findByTestId('make-issues')).toHaveTextContent('Ошибка компиляции (строка 1)')
    expect(screen.getByText('сохранено')).toBeInTheDocument()
  })

  it('консоль превью: сообщения из iframe копятся, ошибки считаются и уходят в чат', async () => {
    const { onInsertToChat } = renderPane()
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    const post = (level: string, text: string) => fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.console', level, text, at: 1 }, source: frame.contentWindow }))
    post('log', 'hello')
    post('error', 'Uncaught TypeError: x is not a function')
    expect(await screen.findByTestId('make-console-errors')).toHaveTextContent('1 ошибок')
    await userEvent.click(screen.getByRole('button', { name: /Консоль/ }))
    expect(screen.getByText('hello')).toBeInTheDocument()
    await userEvent.click(within(screen.getByTestId('make-console')).getByRole('button', { name: 'В чат' }))
    expect(onInsertToChat).toHaveBeenCalledWith(expect.stringContaining('TypeError'))
    await userEvent.click(screen.getByRole('button', { name: 'Очистить' }))
    expect(screen.queryByTestId('make-console-errors')).not.toBeInTheDocument()
  })

  it('ассеты: список бинарников с копированием пути; экспорт — два варианта; импорт по URL', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:upload']({ conversationId: CONV, path: 'img/a.png', dataBase64: 'AAAA' })
    emit({ conversationId: CONV, rev: next.rev, paths: ['img/a.png'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await openMore()
    await userEvent.click(await screen.findByRole('button', { name: 'Ассеты (1)' }))
    const assets = await screen.findByTestId('make-assets')
    expect(within(assets).getByText('img/a.png')).toBeInTheDocument()
    await userEvent.keyboard('{Escape}')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Скачать проект (ZIP)' }))
    const exp = await screen.findByTestId('make-export')
    expect(within(exp).getByRole('button', { name: /Vite-проект/ })).toBeInTheDocument()
    await userEvent.keyboard('{Escape}')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Импорт проекта' }))
    const imp = await screen.findByTestId('make-import')
    await userEvent.type(within(imp).getByLabelText('Адрес страницы'), 'https://example.com/{Enter}')
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'index.html' })).content).toContain('imported from https://example.com/'))
    await waitFor(() => expect(screen.queryByTestId('make-import')).not.toBeInTheDocument())
  })

  it('история: «Сравнить» показывает отличия от снимка, «Вернуть файл» возвращает один файл', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    await api['make:snapshot']({ conversationId: CONV, label: 'до' })
    const next = await api['make:write']({ conversationId: CONV, path: 'index.html', content: '<h1>changed</h1>' })
    emit({ conversationId: CONV, rev: next.rev, paths: ['index.html'] })
    await userEvent.click(screen.getByRole('tab', { name: 'История' }))
    await userEvent.click(await screen.findByRole('button', { name: 'Сравнить' }))
    const diff = await screen.findByTestId('make-diff')
    expect(within(diff).getByText('index.html')).toBeInTheDocument()
    expect(within(diff).getByText('изменён')).toBeInTheDocument()
    await userEvent.click(within(diff).getByRole('button', { name: 'index.html' }))
    const view = await screen.findByTestId('make-file-diff')
    expect(within(view).getByLabelText('Снимок')).toHaveTextContent('Новый проект')
    expect(within(view).getByLabelText('Сейчас')).toHaveTextContent('changed')
    await userEvent.keyboard('{Escape}')
    await waitFor(() => expect(screen.queryByTestId('make-file-diff')).not.toBeInTheDocument())
    await userEvent.click(within(diff).getByRole('button', { name: 'Вернуть файл' }))
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'index.html' })).content).toBe(MAKE_SCAFFOLD['index.html']))
  })

  it('ошибка в консоли сразу после правки → баннер «Исправить» отправляет текст ассистенту', async () => {
    const onAskAssistant = vi.fn()
    const { emit } = renderPane({ onAskAssistant })
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    emit({ conversationId: CONV, rev: 5, paths: ['app.js'] })
    // The preview is recreated with key=rev; wait for the new iframe so the message source matches
    // frameRef.
    await waitFor(() => expect(screen.getByTitle('Превью проекта')).not.toBe(frame))
    const frame2 = screen.getByTitle('Превью проекта') as HTMLIFrameElement
    fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.console', level: 'error', text: 'ReferenceError: foo is not defined', at: Date.now() }, source: frame2.contentWindow }))
    const banner = await screen.findByTestId('make-autofix')
    expect(banner).toHaveTextContent('ReferenceError')
    await userEvent.click(within(banner).getByRole('button', { name: 'Исправить' }))
    expect(onAskAssistant).toHaveBeenCalledWith(expect.stringContaining('foo is not defined'))
    await waitFor(() => expect(screen.queryByTestId('make-autofix')).not.toBeInTheDocument())
  })

  it('панель стилей: правка уходит в превью postMessage, «Записать в CSS» дописывает правило в styles.css', async () => {
    const { api } = renderPane()
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    const post = vi.spyOn(frame.contentWindow!, 'postMessage')
    fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.selected', selector: 'main > h1', tag: 'h1', text: 'Заголовок', html: '<h1>Заголовок</h1>', id: '', className: 'hero__title', styles: { color: 'rgb(0, 0, 0)', 'font-size': '32px' } }, source: frame.contentWindow }))
    await userEvent.click(await screen.findByRole('button', { name: 'Стили' }))
    const panel = await screen.findByTestId('make-style')
    expect((within(panel).getByLabelText('Селектор правила') as HTMLInputElement).value).toBe('.hero__title')
    await userEvent.clear(within(panel).getByLabelText('Размер шрифта'))
    await userEvent.type(within(panel).getByLabelText('Размер шрифта'), '40px')
    expect(post).toHaveBeenLastCalledWith({ type: 'vc-make.style', values: { 'font-size': '40px' } }, '*')
    await userEvent.click(within(panel).getByRole('button', { name: 'Записать в CSS' }))
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'styles.css' })).content).toContain('.hero__title {\n  font-size: 40px;\n}'))
  })

  it('📷 делает скриншот превью и отдаёт файл во вложения чата', async () => {
    const onAttachImage = vi.fn()
    renderPane({ onAttachImage })
    await screen.findByTitle('Превью проекта')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Скриншот превью в чат' }))
    await waitFor(() => expect(onAttachImage).toHaveBeenCalled())
    const file = onAttachImage.mock.calls[0]![0] as File
    expect(file.name).toBe('preview.png')
    expect(file.type).toBe('image/png')
  })

  it('публикация версии: «Опубликовать версию» в истории закрепляет снимок, диалог показывает его', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:snapshot']({ conversationId: CONV, label: 'релиз 1' })
    emit({ conversationId: CONV, rev: next.rev, paths: [] })
    await userEvent.click(screen.getByRole('tab', { name: 'История' }))
    await userEvent.click(await screen.findByRole('button', { name: 'Опубликовать версию' }))
    expect(await screen.findByRole('button', { name: 'Опубликована' })).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: 'Опубликован' }))
    const dialog = await screen.findByTestId('make-publish')
    expect(dialog).toHaveTextContent('Закреплена версия «релиз 1»')
    expect((within(dialog).getByLabelText('Что публиковать') as HTMLSelectElement).value).not.toBe('')
  })

  // @testCase T2
  it('requires a reviewed dry run before confirming project replacement', async () => {
    const { api } = renderPane()
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await userEvent.type(screen.getByRole('searchbox', { name: 'Поиск по файлам проекта' }), 'Новый проект')
    await userEvent.click(screen.getByRole('button', { name: 'Заменить по проекту' }))
    await userEvent.type(screen.getByLabelText('Заменить на'), 'Мой сайт')
    expect(screen.getByRole('button', { name: 'Заменить все' })).toBeDisabled()
    await userEvent.click(screen.getByRole('button', { name: 'Предпросмотр' }))
    await screen.findByTestId('make-replace-preview')
    expect((await api['make:read']({ conversationId: CONV, path: 'index.html' })).content).not.toContain('Мой сайт')
    await userEvent.click(screen.getByRole('button', { name: 'Заменить все' }))
    await userEvent.click(await screen.findByRole('button', { name: 'Заменить' }))
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'index.html' })).content).toContain('Мой сайт'))
  })

  it('«Форматировать» прогоняет файл через Prettier', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'ugly.css', content: 'body{margin:0;padding:0}' })
    emit({ conversationId: CONV, rev: next.rev, paths: ['ugly.css'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await userEvent.click((await screen.findAllByRole('button', { name: /ugly\.css/ }))[0]!)
    await screen.findByLabelText('Содержимое ugly.css')
    await userEvent.click(screen.getByRole('button', { name: 'Форматировать' }))
    await waitFor(() => expect((screen.getByLabelText('Содержимое ugly.css') as HTMLTextAreaElement).value).toBe('body {\n  margin: 0;\n  padding: 0;\n}\n'))
  }, 30_000)

  it('правка ИИ: Cmd+K с выделением отправляет ассистенту файл, строки и фрагмент', async () => {
    const onAskAssistant = vi.fn()
    renderPane({ onAskAssistant })
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await userEvent.click(within(screen.getByRole('navigation', { name: 'Файлы проекта' })).getByRole('button', { name: /^styles\.css/ }))
    const editor = await screen.findByLabelText('Содержимое styles.css') as HTMLTextAreaElement
    editor.focus(); editor.setSelectionRange(0, 5); fireEvent.select(editor)
    await userEvent.keyboard('{Meta>}i{/Meta}')
    const box = await screen.findByTestId('make-inline')
    expect(box).toHaveTextContent('Строки 1–1')
    await userEvent.type(within(box).getByLabelText('Что сделать с фрагментом'), 'сделай переменной{Enter}')
    expect(onAskAssistant).toHaveBeenCalledWith(expect.stringContaining('Файл styles.css, строки 1–1'))
    expect(onAskAssistant.mock.calls[0]![0]).toContain('сделай переменной')
  })

  it('локальные версии: после сохранения предыдущий текст доступен в «Версии» и подставляется в редактор', async () => {
    renderPane()
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await userEvent.click(within(screen.getByRole('navigation', { name: 'Файлы проекта' })).getByRole('button', { name: /^styles\.css/ }))
    const editor = await screen.findByLabelText('Содержимое styles.css') as HTMLTextAreaElement
    const original = editor.value
    await userEvent.type(editor, '/* v2 */')
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }))
    await waitFor(() => expect(screen.getByText('сохранено')).toBeInTheDocument())
    await userEvent.click(screen.getByRole('button', { name: 'Версии' }))
    const panel = await screen.findByTestId('make-local-history')
    await userEvent.click(within(panel).getAllByRole('button')[0]!)
    expect((screen.getByLabelText('Содержимое styles.css') as HTMLTextAreaElement).value).toBe(original)
  })

  it('вкладка «Сеть»: запросы из превью, счётчик незагруженных, «В чат»', async () => {
    const { onInsertToChat } = renderPane()
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    const post = (entry: object) => fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.network', ...entry }, source: frame.contentWindow }))
    post({ kind: 'fetch', method: 'GET', url: 'styles.css', status: 200, ok: true, ms: 12, at: 1 })
    post({ kind: 'fetch', method: 'GET', url: 'img/missing.png', status: 404, ok: false, ms: 7, at: 2 })
    expect(await screen.findByTestId('make-network-failed')).toHaveTextContent('1 не загрузилось')
    await userEvent.click(screen.getByTestId('make-network-toggle'))
    const list = await screen.findByTestId('make-network')
    expect(within(list).getByText('img/missing.png')).toBeInTheDocument()
    await userEvent.click(within(screen.getByTestId('make-console')).getByRole('button', { name: 'В чат' }))
    expect(onInsertToChat).toHaveBeenCalledWith(expect.stringContaining('img/missing.png → 404'))
  })

  it('скролл и hash превью восстанавливаются после перезагрузки iframe', async () => {
    const { emit } = renderPane()
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.state', x: 0, y: 640, hash: '#menu' }, source: frame.contentWindow }))
    emit({ conversationId: CONV, rev: 9, paths: ['index.html'] })
    await waitFor(() => expect(screen.getByTitle('Превью проекта')).not.toBe(frame))
    const next = screen.getByTitle('Превью проекта') as HTMLIFrameElement
    const post = vi.spyOn(next.contentWindow!, 'postMessage')
    fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.ready' }, source: next.contentWindow }))
    expect(post).toHaveBeenCalledWith({ type: 'vc-make.restore', x: 0, y: 640, hash: '#menu' }, '*')
  })

  it('тема и язык превью уходят в iframe и повторяются после перезагрузки', async () => {
    renderPane()
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    const post = vi.spyOn(frame.contentWindow!, 'postMessage')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Тема превью' }))
    expect(post).toHaveBeenLastCalledWith(expect.objectContaining({ type: 'vc-make.env', scheme: 'dark', lang: '' }), '*')
    expect(frame.src).toContain('makeScheme=dark')
    const currentPost = vi.spyOn(frame.contentWindow!, 'postMessage')
    await openMore()
    await userEvent.selectOptions(screen.getByLabelText('Язык превью'), 'en')
    expect(currentPost).toHaveBeenLastCalledWith(expect.objectContaining({ type: 'vc-make.env', scheme: 'dark', lang: 'en' }), '*')
    fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.ready' }, source: frame.contentWindow }))
    expect(currentPost).toHaveBeenLastCalledWith(expect.objectContaining({ type: 'vc-make.env', scheme: 'dark', lang: 'en' }), '*')
  })

  it('♿ запускает axe в превью, показывает нарушения и отдаёт их ассистенту', async () => {
    const onAskAssistant = vi.fn()
    renderPane({ onAskAssistant })
    await screen.findByTitle('Превью проекта')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Проверить доступность' }))
    const panel = await screen.findByTestId('make-a11y')
    expect(panel).toHaveTextContent('1 нарушений')
    expect(within(panel).getByText('Изображения должны иметь альтернативный текст')).toBeInTheDocument()
    await userEvent.click(within(panel).getByRole('button', { name: 'Исправить' }))
    expect(onAskAssistant).toHaveBeenCalledWith(expect.stringContaining('image-alt'))
  })

  it('«Поделиться» стори без публикации открывает диалог публикации; с публикацией копирует ссылку', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'src/S.stories.jsx', content: "export default { title: 'S' }\nexport const A = {}" })
    emit({ conversationId: CONV, rev: next.rev, paths: ['src/S.stories.jsx'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    await screen.findByTitle('Стори A')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Поделиться' }))
    expect(await screen.findByTestId('make-publish')).toBeInTheDocument()
    await userEvent.click(within(screen.getByTestId('make-publish')).getByRole('button', { name: 'Опубликовать' }))
    await screen.findByTestId('make-public-url')
    await userEvent.keyboard('{Escape}')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Поделиться' }))
    expect(await screen.findByText('Ссылка на стори скопирована')).toBeInTheDocument()
  })

  it('📸 сохраняет снимок стори; два снимка можно сравнить «до/после»', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'src/V.stories.jsx', content: "export default { title: 'V' }\nexport const A = {}" })
    emit({ conversationId: CONV, rev: next.rev, paths: ['src/V.stories.jsx'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    await screen.findByTitle('Стори A')
    await userEvent.click(screen.getByRole('button', { name: '📸 Снимок' }))
    await userEvent.click(await screen.findByRole('button', { name: '📸 Снимок' }))
    const strip = await screen.findByTestId('make-shots')
    await waitFor(() => expect(within(strip).getAllByRole('img')).toHaveLength(2))
    const [a, b] = within(strip).getAllByRole('button')
    await userEvent.click(a!); await userEvent.click(b!)
    expect(await screen.findByTestId('make-shots-compare')).toBeInTheDocument()
  })

  it('play-функции: маркер ▷ у стори с play, результат из раннера → ✓/✗ и баннер с «Исправить»', async () => {
    const onAskAssistant = vi.fn()
    const { api, emit } = renderPane({ onAskAssistant })
    await screen.findByTitle('Превью проекта')
    const next = await api['make:write']({ conversationId: CONV, path: 'src/P.stories.jsx', content: "export default { title: 'P' }\nexport const Ok = { play: async () => {} }\nexport const Plain = {}" })
    emit({ conversationId: CONV, rev: next.rev, paths: ['src/P.stories.jsx'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    const ok = await screen.findByRole('button', { name: /^Ok/ })
    expect(ok).toHaveTextContent('▷')
    const frame = await screen.findByTitle('Стори Ok') as HTMLIFrameElement
    fireEvent(window, new MessageEvent('message', { data: { type: 'vc-make.play', file: 'src/P.stories.jsx', story: 'Ok', status: 'failed', ms: 12, error: 'expected 2 to be 1' }, source: frame.contentWindow }))
    expect(await screen.findByTestId('make-play-failed')).toHaveTextContent('expected 2 to be 1')
    expect(screen.getByRole('button', { name: /^Ok/ })).toHaveTextContent('✗')
    await userEvent.click(within(screen.getByTestId('make-play-failed')).getByRole('button', { name: 'Исправить' }))
    expect(onAskAssistant).toHaveBeenCalledWith(expect.stringContaining('упала play-функция'))
  })

  it('библиотека: «В библиотеку» сохраняет компонент со сториз, диалог показывает его и вставляет в проект', async () => {
    const { api, emit } = renderPane()
    await screen.findByTitle('Превью проекта')
    await api['make:write']({ conversationId: CONV, path: 'src/components/Chip.jsx', content: 'export const Chip = () => null' })
    const next = await api['make:write']({ conversationId: CONV, path: 'src/components/Chip.stories.jsx', content: "export default { title: 'Chip' }\nexport const A = {}" })
    emit({ conversationId: CONV, rev: next.rev, paths: [] })
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    await screen.findByTitle('Стори A')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'В библиотеку' }))
    expect(await screen.findByText(/«Chip» сохранён в библиотеку \(2 файл\.\)/)).toBeInTheDocument()
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Библиотека' }))
    const dialog = await screen.findByTestId('make-library')
    expect(within(dialog).getByText('Chip')).toBeInTheDocument()
    await userEvent.click(within(dialog).getByRole('button', { name: 'Вставить' }))
    await waitFor(() => expect(screen.getAllByRole('button', { name: 'Вставить' }).length).toBeGreaterThan(1))
    await userEvent.click(screen.getAllByRole('button', { name: 'Вставить' }).at(-1)!)
    await waitFor(() => expect(screen.queryByTestId('make-library')).not.toBeInTheDocument())
  })
})

describe('MakePane: inline-diff правок ассистента (roadmap-4 п.9)', () => {
  it('после make.changed по открытому файлу во время хода показывает плашку с числом изменённых строк', async () => {
    const { api, emit } = renderPane({ turnActive: true })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const editor = await screen.findByLabelText('Содержимое index.html') as HTMLTextAreaElement
    await waitFor(() => expect(editor.value).toBe(MAKE_SCAFFOLD['index.html']))
    await api['make:write']({ conversationId: CONV, path: 'index.html', content: MAKE_SCAFFOLD['index.html'] + '\n<!-- one -->\n<!-- two -->' })
    emit({ conversationId: CONV, rev: 2, paths: ['index.html'] })
    await waitFor(() => expect(screen.getByText(/Подсвечены строки, изменённые ассистентом \(2\)/)).toBeInTheDocument())
    await userEvent.click(screen.getByRole('button', { name: 'скрыть' }))
    expect(screen.queryByText(/Подсвечены строки/)).toBeNull()
  })
})

describe('MakePane: мультивыбор файлов в дереве (roadmap-4 п.10)', () => {
  it('Ctrl-клик выбирает файлы, панель показывает счётчик, «Удалить» убирает все выбранные после подтверждения', async () => {
    const { api } = renderPane()
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const tree = screen.getByRole('navigation', { name: 'Файлы проекта' })
    const files = within(tree).getAllByRole('button', { name: /^[^ ]+\.(html|css|tsx|js|json|md)$/ })
    expect(files.length).toBeGreaterThan(2)
    fireEvent.click(files[0]!, { ctrlKey: true })
    fireEvent.click(files[1]!, { ctrlKey: true })
    const bulk = await screen.findByTestId('make-bulk')
    expect(bulk.textContent).toContain('Выбрано: 2')
    // Shift-click extends the selection from the anchor at files[1] through files[2].
    fireEvent.click(files[2]!, { shiftKey: true })
    expect(screen.getByTestId('make-bulk').textContent).toContain('Выбрано: 3')
    const before = (await api['make:state']({ conversationId: CONV })).files.length
    await userEvent.click(within(bulk).getByRole('button', { name: 'Удалить' }))
    const dlg = await screen.findByRole('alertdialog').catch(() => screen.findByRole('dialog'))
    await userEvent.click(within(dlg).getByRole('button', { name: 'Удалить' }))
    await waitFor(async () => expect((await api['make:state']({ conversationId: CONV })).files.length).toBe(before - 3))
    expect(screen.queryByTestId('make-bulk')).toBeNull()
  })
})

describe('MakePane: regex-поиск и предпросмотр замены (roadmap-4 п.11)', () => {
  it('«.*» включает regex, «Предпросмотр» показывает строки до/после без записи, «Заменить все» применяет $1', async () => {
    const { api } = renderPane()
    await api['make:write']({ conversationId: CONV, path: 'tokens.css', content: ':root { --bg: #fff; --card: #fff; }' })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await userEvent.click(screen.getByRole('button', { name: 'Регулярное выражение' }))
    await userEvent.type(screen.getByLabelText('Поиск по файлам проекта'), '--(\\w+): #fff')
    await userEvent.click(screen.getByRole('button', { name: 'Заменить по проекту' }))
    await userEvent.type(screen.getByLabelText('Заменить на'), '--$1: white')
    await userEvent.click(screen.getByRole('button', { name: 'Предпросмотр' }))
    const preview = await screen.findByTestId('make-replace-preview')
    expect(preview.textContent).toContain('Изменится строк: 1')
    expect(preview.textContent).toContain('--bg: white; --card: white;')
    expect((await api['make:read']({ conversationId: CONV, path: 'tokens.css' })).content).toContain('#fff')
    await userEvent.click(screen.getByRole('button', { name: 'Заменить все' }))
    const dlg = await screen.findByRole('alertdialog').catch(() => screen.findByRole('dialog'))
    await userEvent.click(within(dlg).getByRole('button', { name: 'Заменить' }))
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'tokens.css' })).content).toBe(':root { --bg: white; --card: white; }'))
  })
})

describe('MakePane: замечания линтера (roadmap-4 п.12)', () => {
  it('предупреждения показываются с ⚠, правилом и строкой, без пометки «ошибка»', async () => {
    const { api } = renderPane()
    await api['make:write']({ conversationId: CONV, path: 'src/lint.tsx', content: "console.log('x')\nexport const a = 1\n" })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await userEvent.click(screen.getByRole('button', { name: 'Проверить' }))
    const box = await screen.findByTestId('make-issues')
    expect(box).toHaveTextContent('Ошибок нет; замечания линтера (1)')
    expect(box).toHaveTextContent('⚠ src/lint.tsx:1 — Отладочный console.log')
    expect(box).toHaveTextContent('no-console')
    expect(box.className).toContain('make-issues--warn')
    expect(box.className).not.toContain('make-issues--bad')
  })
})

describe('MakePane: сплит «код | превью» и zen (roadmap-4 п.16)', () => {
  it('◫ показывает превью рядом с редактором и запоминает выбор; ⛶ скрывает шапку и дерево, Esc возвращает', async () => {
    renderPane()
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    expect(screen.queryByTestId('make-split-preview')).toBeNull()
    await userEvent.click(screen.getByRole('button', { name: 'Превью рядом' }))
    const side = await screen.findByTestId('make-split-preview')
    expect(within(side).getByTitle('Превью рядом').getAttribute('src')).toContain('index.html?rev=')
    expect(screen.getByRole('separator', { name: 'Граница код/превью' })).toBeInTheDocument()
    expect(localStorage.getItem('vc.make.split')).toBe('on')
    await userEvent.click(screen.getByRole('button', { name: 'Zen-режим' }))
    expect(screen.getByTestId('make-pane').className).toContain('make-pane--zen')
    expect(screen.getByTestId('make-code').className).toContain('make-code--zen')
    await userEvent.keyboard('{Escape}')
    await waitFor(() => expect(screen.getByTestId('make-pane').className).not.toContain('make-pane--zen'))
    await userEvent.click(screen.getByRole('button', { name: 'Превью рядом' }))
    expect(screen.queryByTestId('make-split-preview')).toBeNull()
    localStorage.removeItem('vc.make.split')
  })
})

describe('MakePane: правка текста в превью (roadmap-4 п.17)', () => {
  it('vc-make.text из iframe записывает новый текст в файл с единственным вхождением; неоднозначность — тост без записи', async () => {
    const { api } = renderPane()
    await api['make:write']({ conversationId: CONV, path: 'index.html', content: '<h1>Заголовок</h1>\n<p>Абзац\n  текста</p>' })
    await api['make:write']({ conversationId: CONV, path: 'about.html', content: '<h2>Дубль</h2>' })
    await api['make:write']({ conversationId: CONV, path: 'contacts.html', content: '<h2>Дубль</h2>' })
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    const send = (data: object) => window.dispatchEvent(new MessageEvent('message', { data, source: frame.contentWindow }))
    send({ type: 'vc-make.text', selector: 'p', before: 'Абзац текста', after: 'Новый <b>текст</b>' })
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'index.html' })).content).toBe('<h1>Заголовок</h1>\n<p>Новый &lt;b&gt;текст&lt;/b&gt;</p>'))
    send({ type: 'vc-make.text', selector: 'h2', before: 'Дубль', after: 'Другой' })
    await screen.findByText(/встречается в нескольких файлах/)
    expect((await api['make:read']({ conversationId: CONV, path: 'about.html' })).content).toBe('<h2>Дубль</h2>')
  })
})

describe('MakePane: перетаскивание секций в превью (roadmap-4 п.18)', () => {
  it('vc-make.reorder переносит фрагмент в файле; при неоднозначности файл не трогается', async () => {
    const { api } = renderPane()
    await api['make:write']({ conversationId: CONV, path: 'index.html', content: '<main>\n  <section id="a">A</section>\n  <section id="b">B</section>\n</main>' })
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    const send = (data: object) => window.dispatchEvent(new MessageEvent('message', { data, source: frame.contentWindow }))
    send({ type: 'vc-make.reorder', moved: '<section id="a">A</section>', target: '<section id="b">B</section>', position: 'after' })
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'index.html' })).content).toBe('<main>\n  <section id="b">B</section>\n  <section id="a">A</section>\n</main>'))
    send({ type: 'vc-make.reorder', moved: '<div>nope</div>', target: '<section id="b">B</section>', position: 'after' })
    await screen.findByText(/порядок в файле не изменён/)
  })
})

describe('MakePane: эмуляция состояний превью (roadmap-4 п.20)', () => {
  it('меню ⋯ переключает reduced motion и медленную сеть — в iframe уходит vc-make.env с флагами; состояние элемента доступно после выбора', async () => {
    renderPane()
    const frame = await screen.findByTitle('Превью проекта') as HTMLIFrameElement
    const post = vi.fn()
    Object.defineProperty(frame, 'contentWindow', { value: { postMessage: post }, configurable: true })
    await openMore()
    expect(screen.getByRole('button', { name: 'Состояние элемента' })).toBeDisabled()
    await userEvent.click(screen.getByRole('button', { name: 'Reduced motion' }))
    expect(post).toHaveBeenLastCalledWith(expect.objectContaining({ type: 'vc-make.env', reducedMotion: true, slowMs: 0 }), '*')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Медленная сеть' }))
    expect(post).toHaveBeenLastCalledWith(expect.objectContaining({ type: 'vc-make.env', reducedMotion: true, slowMs: 1500 }), '*')
    window.dispatchEvent(new MessageEvent('message', { data: { type: 'vc-make.selected', selector: 'h1', tag: 'h1', text: 'Привет', html: '<h1>Привет</h1>' }, source: frame.contentWindow }))
    await openMore()
    await waitFor(() => expect(screen.getByRole('button', { name: 'Состояние элемента' })).toBeEnabled())
    await userEvent.click(screen.getByRole('button', { name: 'Состояние элемента' }))
    expect(post).toHaveBeenLastCalledWith(expect.objectContaining({ type: 'vc-make.env', state: 'hover' }), '*')
  })
})

describe('MakePane: три ширины рядом (roadmap-4 п.21)', () => {
  it('режим ⫼ рисует три кадра; скролл одного уходит остальным как vc-make.restore, эхо не зацикливается', async () => {
    renderPane()
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('button', { name: 'Три ширины рядом' }))
    const main = screen.getByTitle('Превью проекта') as HTMLIFrameElement
    const tablet = screen.getByTitle('Превью 768px') as HTMLIFrameElement
    const phone = screen.getByTitle('Превью 390px') as HTMLIFrameElement
    expect(main.style.width).toBe('1200px')
    // MessageEvent.source must be a real Window; use jsdom iframe windows and replace their
    // postMessage methods.
    const posts = { main: vi.fn(), tablet: vi.fn(), phone: vi.fn() }
    Object.defineProperty(main.contentWindow!, 'postMessage', { value: posts.main, configurable: true })
    Object.defineProperty(tablet.contentWindow!, 'postMessage', { value: posts.tablet, configurable: true })
    Object.defineProperty(phone.contentWindow!, 'postMessage', { value: posts.phone, configurable: true })
    window.dispatchEvent(new MessageEvent('message', { data: { type: 'vc-make.state', x: 0, y: 240, hash: '' }, source: tablet.contentWindow }))
    expect(posts.main).toHaveBeenCalledWith({ type: 'vc-make.restore', x: 0, y: 240 }, '*')
    expect(posts.phone).toHaveBeenCalledWith({ type: 'vc-make.restore', x: 0, y: 240 }, '*')
    expect(posts.tablet).not.toHaveBeenCalledWith(expect.objectContaining({ type: 'vc-make.restore' }), '*')
    // A state response from the phone within 300 ms is an echo and must not be forwarded.
    window.dispatchEvent(new MessageEvent('message', { data: { type: 'vc-make.state', x: 0, y: 240, hash: '' }, source: phone.contentWindow }))
    expect(posts.tablet).not.toHaveBeenCalledWith(expect.objectContaining({ type: 'vc-make.restore' }), '*')
  })
})

describe('MakePane: автогенерация сториз (roadmap-4 п.23)', () => {
  it('компонент без сториз показан в группе «Без сториз»; клик создаёт stories-файл и открывает Default', async () => {
    const { api, emit } = renderPane()
    await api['make:write']({ conversationId: CONV, path: 'src/components/Badge.tsx', content: "export interface BadgeProps {\n  text: string\n  tone?: 'ok' | 'warn'\n}\nexport function Badge({ text }: BadgeProps) { return <span>{text}</span> }\n" })
    emit({ conversationId: CONV, rev: 1, paths: ['src/components/Badge.tsx'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Компоненты' }))
    const orphans = await screen.findByTestId('make-orphans')
    await userEvent.click(within(orphans).getByRole('button', { name: /сториз для Badge\.tsx/ }))
    await waitFor(async () => expect((await api['make:read']({ conversationId: CONV, path: 'src/components/Badge.stories.tsx' })).content).toContain('export const Warn = () => <Badge tone="warn" text="Пример" />'))
    await waitFor(() => expect(screen.queryByTestId('make-orphans')).toBeNull())
    expect(await screen.findByText('Default')).toBeInTheDocument()
  })
})

describe('MakePane: таблица коллекции моков (roadmap-4 п.29)', () => {
  it('mock/*.json с $body открывается таблицей, правка ячейки делает файл грязным и сохраняется JSON-ом; переключатель JSON показывает редактор', async () => {
    const { api, emit } = renderPane()
    await api['make:write']({ conversationId: CONV, path: 'mock/api/users.json', content: JSON.stringify({ $collection: true, $body: [{ id: 1, name: 'Анна' }] }, null, 2) })
    emit({ conversationId: CONV, rev: 1, paths: ['mock/api/users.json'] })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    const tree = screen.getByRole('navigation', { name: 'Файлы проекта' })
    await userEvent.click(await within(tree).findByRole('button', { name: /^users\.json/ }))
    const table = await screen.findByTestId('make-mock-table')
    await userEvent.type(within(table).getByLabelText('name строки 1'), '!')
    expect(screen.getByText('не сохранено')).toBeInTheDocument()
    await userEvent.click(screen.getByRole('button', { name: 'Сохранить' }))
    await waitFor(async () => expect(JSON.parse((await api['make:read']({ conversationId: CONV, path: 'mock/api/users.json' })).content).$body[0].name).toBe('Анна!'))
    await userEvent.click(screen.getByRole('button', { name: 'JSON' }))
    expect(screen.queryByTestId('make-mock-table')).toBeNull()
    expect(screen.getByLabelText('Содержимое mock/api/users.json')).toBeInTheDocument()
  })
})

describe('MakePane: мок из описания (roadmap-4 п.30)', () => {
  it('пункт меню ⋯ в режиме «Код» спрашивает описание и отправляет ассистенту запрос с форматом коллекции', async () => {
    const onAskAssistant = vi.fn()
    renderPane({ onAskAssistant })
    await userEvent.click(screen.getByRole('tab', { name: 'Код' }))
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Мок из описания' }))
    const dlg = await screen.findByRole('dialog', { name: 'Мок-данные из описания' })
    await userEvent.type(within(dlg).getByRole('textbox'), 'товары: название, цена, 7 штук')
    await userEvent.click(within(dlg).getByRole('button', { name: 'Сгенерировать' }))
    expect(onAskAssistant).toHaveBeenCalledTimes(1)
    const text = onAskAssistant.mock.calls[0]![0] as string
    expect(text).toContain('mock/api/tovary.json')
    expect(text).toContain('7 правдоподобных записей')
  })
})

describe('MakePane: комментарии зрителей и модерация (roadmap-4 пп.34–35)', () => {
  it('pending-комментарий показан отдельно, «Одобрить» переводит его в общий список; новый pending по make.changed даёт тост; флажок публикации шлёт allowComments', async () => {
    const { api, emit } = renderPane()
    await api['make:commentAdd']({ conversationId: CONV, selector: 'body', elementLabel: 'страница', text: 'Кнопка мелкая' })
    const list = (await api['make:comments']({ conversationId: CONV })).comments
    await api['make:commentUpdate']({ conversationId: CONV, commentId: list[0]!.id, status: 'pending' })
    await screen.findByTitle('Превью проекта')
    emit({ conversationId: CONV, rev: 0, paths: ['.comments.json'] })
    await userEvent.click(screen.getByRole('button', { name: /💬/ }))
    const panel = await screen.findByTestId('make-comments')
    await waitFor(() => expect(within(panel).getByTestId('make-comments-pending')).toHaveTextContent('1 на модерации'))
    expect(within(panel).queryByRole('button', { name: 'Исправить все' })).toBeNull()
    await userEvent.click(within(panel).getByRole('button', { name: 'Одобрить' }))
    await waitFor(() => expect(within(panel).queryByTestId('make-comments-pending')).toBeNull())
    // A new viewer comment arrives through make.changed and triggers an owner toast (item 35).
    await api['make:commentAdd']({ conversationId: CONV, selector: 'body', elementLabel: 'страница', text: 'Ещё одно замечание' })
    const fresh = (await api['make:comments']({ conversationId: CONV })).comments[0]!
    await api['make:commentUpdate']({ conversationId: CONV, commentId: fresh.id, status: 'pending' })
    emit({ conversationId: CONV, rev: 0, paths: ['.comments.json'] })
    await waitFor(() => expect(screen.getAllByText(/Новый комментарий зрителя/).length).toBeGreaterThan(0))
    expect(screen.getAllByText(/Ещё одно замечание/).length).toBeGreaterThan(0)
    // Publication checkbox.
    await userEvent.click(screen.getByRole('button', { name: 'Опубликовать' }))
    const dlg = await screen.findByTestId('make-publish')
    await userEvent.click(within(dlg).getByRole('button', { name: 'Опубликовать' }))
    const box = await within(dlg).findByLabelText('Комментарии зрителей')
    expect(box).not.toBeChecked()
    await userEvent.click(box)
    await waitFor(() => expect(within(dlg).getByLabelText('Комментарии зрителей')).toBeChecked())
  })
})

describe('MakePane: экспорт под хостинг и сравнение версий (roadmap-4 пп.36–37)', () => {
  it('селект «Хостинг» добавляет deploy= в ссылку экспорта', async () => {
    renderPane()
    const open = vi.spyOn(window, 'open').mockImplementation(() => null)
    await screen.findByTitle('Превью проекта')
    await openMore()
    await userEvent.click(screen.getByRole('button', { name: 'Скачать проект (ZIP)' }))
    const dlg = await screen.findByTestId('make-export')
    await userEvent.selectOptions(within(dlg).getByLabelText('Хостинг для экспорта'), 'netlify')
    await userEvent.click(within(dlg).getByRole('button', { name: /Статика как есть/ }))
    expect(open).toHaveBeenCalledWith(expect.stringContaining('deploy=netlify'), '_blank', 'noopener')
    open.mockRestore()
  })
  it('«Сравнить» в истории публикаций открывает снимок и текущее состояние рядом', async () => {
    const { api, emit } = renderPane()
    await api['make:snapshot']({ conversationId: CONV, label: 'v1' })
    const snap = (await api['make:state']({ conversationId: CONV })).snapshots[0]!
    await api['make:publish']({ conversationId: CONV, snapshotId: snap.id })
    await api['make:publish']({ conversationId: CONV, snapshotId: null })
    await screen.findByTitle('Превью проекта')
    emit({ conversationId: CONV, rev: 1, paths: ['index.html'] })
    await userEvent.click(await screen.findByRole('button', { name: 'Опубликован' }))
    const dlg = await screen.findByTestId('make-publish')
    await userEvent.click(within(dlg).getByText(/История публикаций/))
    await userEvent.click(within(dlg).getByRole('button', { name: 'Сравнить' }))
    const cmp = await screen.findByTestId('make-version-compare')
    expect((within(cmp).getByTitle('Версия из истории') as HTMLIFrameElement).getAttribute('src')).toContain(`/__snapshot__/${snap.id}/index.html`)
    expect((within(cmp).getByTitle('Текущая версия') as HTMLIFrameElement).getAttribute('src')).toContain('index.html?rev=')
  })
  it('вкладка «Репозиторий» появляется только у Make-чата, привязанного к проекту', async () => {
    renderPane()
    await screen.findByTitle('Превью проекта')
    expect(screen.queryByRole('tab', { name: 'Репозиторий' })).toBeNull()

    cleanup()
    renderPane({ projectId: 'p1' })
    await screen.findByTitle('Превью проекта')
    await userEvent.click(screen.getByRole('tab', { name: 'Репозиторий' }))
    // The component panel loads its own working copies; identify it by its selector.
    expect(await screen.findByLabelText('Рабочая копия проекта')).toBeTruthy()
  })
})
