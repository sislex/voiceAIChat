import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import Fastify, { type FastifyInstance } from 'fastify'
import type { ServerMessage } from '@voicechat/shared'
import { MakeHub } from './hub'
import { MakeWorkspaces } from './workspace'
import { signTaskScope } from './taskScope'
import type { MakeMcpDeps } from './mcp'
import { registerMakeMcp } from './mcp'

const SECRET = 's'
const CONV = 'conv-mcp'
const MCP_HEADERS = { 'content-type': 'application/json', accept: 'application/json, text/event-stream' }
const INIT = { jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-06-18', capabilities: {}, clientInfo: { name: 't', version: '1' } } }
const call = (name: string, args: Record<string, unknown> = {}): unknown => ({ jsonrpc: '2.0', id: 2, method: 'tools/call', params: { name, arguments: args } })

function resultText(json: unknown): { text: string; isError: boolean } {
  const r = (json as { result?: { content?: { text?: string }[]; isError?: boolean } }).result
  return { text: r?.content?.map((c) => c.text ?? '').join('') ?? '', isError: Boolean(r?.isError) }
}

let app: FastifyInstance
let workspaces: MakeWorkspaces
let hub: MakeHub
let events: ServerMessage[]

/** Run token for this conversation's design, signed with the MCP secret. */
const scopeToken = (mode: 'whole_project' | 'files' = 'whole_project', paths: string[] = [], opts: { ttlMs?: number; now?: number } = {}): string =>
  signTaskScope(SECRET, { userId: 'ann', projectId: 'p1', taskId: 't1', sources: [{ conversationId: CONV, title: mode === 'files' ? 'Макет оплаты' : 'Макет', mode, paths }] }, opts)

/**
 * Core as seen by MCP: conversation ownership and scope validation data. allowed means the task has
 * a design for exactly this conversation with matching mode/paths; otherwise the design has been
 * removed.
 */
function fakeCore(owner: string | null, allowed: { mode: 'whole_project' | 'files'; paths: string[] } | null): MakeMcpDeps['core'] {
  return {
    conversationOwner: async () => owner,
    conversationProject: async () => 'p1',
    isProjectViewer: async () => true,
    taskDesigns: async () => allowed ? [{ id: 'd1', conversationId: CONV, title: 'Макет', mode: allowed.mode, paths: allowed.paths } as never] : []
  }
}

async function setup(owner: string | null = 'ann', allowed: { mode: 'whole_project' | 'files'; paths: string[] } | null = null): Promise<void> {
  workspaces = new MakeWorkspaces(await mkdtemp(join(tmpdir(), 'vc-make-mcp-')))
  hub = new MakeHub()
  events = []
  hub.subscribe('ann', (m) => events.push(m))
  app = Fastify({ logger: false })
  registerMakeMcp(app, { workspaces, hub, core: fakeCore(owner, allowed) }, SECRET)
  await app.ready()
}

afterEach(async () => { await app?.close() })

async function rpc(body: unknown, query = `?k=${SECRET}&conv=${CONV}&turn=t1`): Promise<{ statusCode: number; json: () => unknown }> {
  const res = await app.inject({ method: 'POST', url: `/mcp/make${query}`, headers: MCP_HEADERS, payload: body as object })
  return { statusCode: res.statusCode, json: () => res.json() }
}

describe('makeMcp', () => {
  it('без секрета — 403, без владельца — 404', async () => {
    await setup()
    expect((await rpc(INIT, `?k=wrong&conv=${CONV}`)).statusCode).toBe(403)
    await app.close()
    await setup(null)
    expect((await rpc(INIT)).statusCode).toBe(404)
  })

  it('list создаёт заготовку; write делает снимок «до правок» один раз за ход и шлёт make.changed', async () => {
    await setup()
    expect((await rpc(INIT)).statusCode).toBe(200)
    const list = resultText((await rpc(call('make_list_files'))).json())
    expect(list.text).toContain('index.html')

    const w1 = resultText((await rpc(call('make_write_file', { path: 'index.html', content: '<h1>a</h1>' }))).json())
    expect(w1.isError).toBe(false)
    expect(w1.text).toContain('Записано: index.html')
    await rpc(call('make_write_file', { path: 'app.js', content: 'x' }))
    const state = await workspaces.state(CONV)
    expect(state.snapshots.map((s) => s.label)).toEqual(['До правок ассистента'])
    // Turn-to-snapshot mapping (roadmap-2, item 2): turns.ts stores this ID in response metadata.
    expect(hub.turnSnapshot('t1')).toBe(state.snapshots[0]!.id)
    expect(hub.turnSnapshot('nope')).toBeUndefined()
    expect(events.filter((e) => e.t === 'make.changed')).toHaveLength(2)
    expect(events[0]).toMatchObject({ t: 'make.changed', conversationId: CONV, paths: ['index.html'] })

    // A new turn gets a new snapshot; with note, the label includes the user's request.
    await rpc(call('make_write_file', { path: 'index.html', content: '<h1>b</h1>' }), `?k=${SECRET}&conv=${CONV}&turn=t2&note=${encodeURIComponent('сделай тёмную тему')}`)
    const snaps = await workspaces.snapshots(CONV)
    expect(snaps).toHaveLength(2)
    expect(snaps[0]!.label).toBe('До правок: «сделай тёмную тему»')
  })

  it('read/rename/delete и ошибки путей возвращаются моделью текстом, ro=1 блокирует мутации', async () => {
    await setup()
    await rpc(INIT)
    await rpc(call('make_write_file', { path: 'a.css', content: 'body{}' }))
    expect(resultText((await rpc(call('make_read_file', { path: 'a.css' }))).json()).text).toBe('body{}')
    expect(resultText((await rpc(call('make_rename_file', { from: 'a.css', to: 'css/a.css' }))).json()).text).toContain('→ css/a.css')
    expect(resultText((await rpc(call('make_delete_file', { path: 'css/a.css' }))).json()).text).toContain('Удалено')
    const bad = resultText((await rpc(call('make_read_file', { path: '../x' }))).json())
    expect(bad.isError).toBe(true)
    expect(bad.text).toMatch(/Недопустимый путь/)
    const ro = resultText((await rpc(call('make_write_file', { path: 'z.js', content: '1' }), `?k=${SECRET}&conv=${CONV}&turn=t1&ro=1`)).json())
    expect(ro.isError).toBe(true)
    expect(ro.text).toMatch(/План/)
  })

  it('task scope публикует только list/read и отклоняет истёкший, поддельный или неавторизованный scope', async () => {
    await setup('ann', { mode: 'whole_project', paths: [] })
    const token = scopeToken('whole_project', [], { ttlMs: 10_000, now: Date.now() })
    const query = `?k=${SECRET}&conv=${CONV}&scope=${encodeURIComponent(token)}`
    expect((await rpc(INIT, query)).statusCode).toBe(200)
    const listed = (await rpc({ jsonrpc: '2.0', id: 3, method: 'tools/list', params: {} }, query)).json() as { result?: { tools?: Array<{ name: string }> } }
    expect(listed.result?.tools?.map((tool) => tool.name)).toEqual(['make_list_files', 'make_read_file'])
    const mutation = (await rpc(call('make_write_file', { path: 'x', content: 'x' }), query)).json()
    expect(JSON.stringify(mutation)).toMatch(/not found/i)

    // Expired: the same document, issued 101 ms in the past.
    const expired = scopeToken('whole_project', [], { ttlMs: 100, now: Date.now() - 101 })
    expect((await rpc(INIT, `?k=${SECRET}&conv=${CONV}&scope=${encodeURIComponent(expired)}`)).statusCode).toBe(403)
    // Tampering: a different secret or a modified payload.
    const forged = signTaskScope('other', { userId: 'ann', projectId: 'p1', taskId: 't1', sources: [{ conversationId: CONV, title: 'Макет', mode: 'whole_project', paths: [] }] })
    expect((await rpc(INIT, `?k=${SECRET}&conv=${CONV}&scope=${encodeURIComponent(forged)}`)).statusCode).toBe(403)
    const tampered = `${Buffer.from(JSON.stringify({ userId: 'eve', projectId: 'p1', taskId: 't1', sources: [], expiresAt: Date.now() + 1e6 })).toString('base64url')}.${token.split('.')[1]}`
    expect((await rpc(INIT, `?k=${SECRET}&conv=${CONV}&scope=${encodeURIComponent(tampered)}`)).statusCode).toBe(403)
    await app.close()
    // The task's design was removed: the token is still valid, but core no longer authorizes it.
    await setup('ann', null)
    expect((await rpc(INIT, query)).statusCode).toBe(403)
  })

  it('файловый task scope разрешает только выбранные пути и сохраняет частичный доступ', async () => {
    await setup('ann', { mode: 'files', paths: ['allowed.css', 'missing.tsx'] })
    await workspaces.write(CONV, 'allowed.css', 'body{}')
    await workspaces.write(CONV, 'secret.txt', 'secret')
    const token = scopeToken('files', ['allowed.css', 'missing.tsx'])
    const query = `?k=${SECRET}&conv=${CONV}&scope=${encodeURIComponent(token)}`
    expect(resultText((await rpc(call('make_read_file', { path: 'allowed.css' }), query)).json()).text).toBe('body{}')
    const denied = resultText((await rpc(call('make_read_file', { path: 'secret.txt' }), query)).json())
    expect(denied.isError).toBe(true)
    expect(denied.text).toContain('Макет оплаты')
    expect(denied.text).toContain('secret.txt')
    const missing = resultText((await rpc(call('make_read_file', { path: 'missing.tsx' }), query)).json())
    expect(missing.isError).toBe(true)
    expect(missing.text).toContain('Макет оплаты')
    expect(missing.text).toContain('missing.tsx')
    expect(resultText((await rpc(call('make_read_file', { path: 'allowed.css' }), query)).json()).isError).toBe(false)
  })

  it('make_check сообщает о проблемах и об их отсутствии', async () => {
    await setup()
    await rpc(INIT)
    await rpc(call('make_write_file', { path: 'index.html', content: '<script src="missing.js"></script>' }))
    const bad = resultText((await rpc(call('make_check'))).json())
    expect(bad.isError).toBe(true)
    expect(bad.text).toContain('missing.js')
    await rpc(call('make_write_file', { path: 'missing.js', content: '1' }))
    const ok = resultText((await rpc(call('make_check'))).json())
    expect(ok.isError).toBe(false)
  })

  it('make_write_file возвращает замечания по записанному файлу: битая ссылка и ошибка компиляции', async () => {
    await app.close()
    await setup()
    const w = resultText((await rpc(call('make_write_file', { path: 'index.html', content: '<link rel="stylesheet" href="nope.css"><h1>a</h1>' }))).json())
    expect(w.text).toContain('Замечания по файлу')
    expect(w.text).toContain('nope.css')
    const ok = resultText((await rpc(call('make_write_file', { path: 'index.html', content: '<h1>a</h1>' }))).json())
    expect(ok.text).not.toContain('Замечания')
    const bad = resultText((await rpc(call('make_write_file', { path: 'src/App.tsx', content: 'export const A = () => <div>' }))).json())
    expect(bad.text).toContain('Ошибка компиляции')
  })

  it('make_apply_changes откатывает транзакцию при ошибке компиляции; make_edit_file правит фрагмент', async () => {
    await app.close()
    await setup()
    await rpc(INIT)
    const bad = resultText((await rpc(call('make_apply_changes', { files: [{ path: 'index.html', content: '<h1>tx</h1>' }, { path: 'src/App.tsx', content: 'export const A = () => <div>' }] }))).json())
    expect(bad.text).toContain('откачены')
    expect((await workspaces.read(CONV, 'index.html')).content).not.toBe('<h1>tx</h1>')
    const ok = resultText((await rpc(call('make_apply_changes', { files: [{ path: 'index.html', content: '<h1>tx</h1>' }] }))).json())
    expect(ok.text).toContain('Записано файлов: 1')
    const edited = resultText((await rpc(call('make_edit_file', { path: 'index.html', find: 'tx', replace: 'edited' }))).json())
    expect(edited.text).toContain('Заменено вхождений: 1')
    expect((await workspaces.read(CONV, 'index.html')).content).toBe('<h1>edited</h1>')
  })
})
