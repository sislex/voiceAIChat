import { dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
export const sharedSource = () => dirname(fileURLToPath(import.meta.resolve('@voicechat/shared'))) + '/'
