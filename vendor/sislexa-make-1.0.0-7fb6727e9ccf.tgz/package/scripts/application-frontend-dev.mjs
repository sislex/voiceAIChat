import {watch} from 'node:fs'
import {buildApplicationFrontend} from './application-frontend.mjs'
const id=process.argv[2]
let timer, running=false, pending=false
async function build(){ if(running){pending=true;return} running=true;try{await buildApplicationFrontend(id)}catch(error){console.error(error)}finally{running=false;if(pending){pending=false;void build()}} }
await build()
watch(new URL('../packages/',import.meta.url),{recursive:true},(_event,file)=>{if(!file||/(dist|node_modules)|\.tsbuildinfo$/.test(file))return;clearTimeout(timer);timer=setTimeout(()=>void build(),200)})
