import ts from 'typescript'
import { resolve } from 'node:path'
import { sharedSource } from './shared-path.mjs'
const file = resolve(process.cwd(), 'tsconfig.json')
const input = ts.readConfigFile(file, ts.sys.readFile)
const parsed = input.error ? {errors:[input.error]} : ts.parseJsonConfigFileContent(input.config, ts.sys, process.cwd(), {
  noEmit: true, incremental: false,
  paths: {...input.config.compilerOptions?.paths, '@shared/*':[sharedSource()+'*']}
}, file)
const diagnostics = [...parsed.errors]
if (!diagnostics.length) diagnostics.push(...ts.getPreEmitDiagnostics(ts.createProgram(parsed.fileNames, parsed.options)))
if (diagnostics.length) {
  console.error(ts.formatDiagnosticsWithColorAndContext(diagnostics, {
    getCanonicalFileName: name => name, getCurrentDirectory: () => process.cwd(), getNewLine: () => '\n'
  }))
  process.exitCode = 1
}
