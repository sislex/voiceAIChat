import { test } from 'node:test'
import assert from 'node:assert/strict'
import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
const root = new URL('../', import.meta.url)
test('source archive excludes build output and nested installed dependencies', () => {
  const manifest = JSON.parse(readFileSync(new URL('package.json', root), 'utf8'))
  for (const path of manifest.files) {
    assert.ok(!['apps', 'packages', ...manifest.workspaces].includes(path), 'Use explicit source/config paths: ' + path)
  }
  const [pack] = JSON.parse(execFileSync('npm', ['pack', '--ignore-scripts', '--dry-run', '--json'], { cwd: root, encoding: 'utf8' }))
  assert.ok(pack.files.some(file => /\/src\/.*\.tsx?$/.test(file.path)))
  for (const { path } of pack.files) assert.doesNotMatch(path, /(^|\/)(node_modules|dist|coverage|\.git|\.env)(\/|$)/)
})
