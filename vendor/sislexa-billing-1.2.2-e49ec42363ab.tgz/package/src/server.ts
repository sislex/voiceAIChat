import Fastify, { type FastifyRequest } from 'fastify'
import { BillingError, BillingStore } from './store.js'
import type { BillingPolicy, BillingReservationInput, BillingUsageEvidence } from '@sislexa/sdk'
import { BILLING_PRODUCT_CAPABILITIES, reservationPrincipal, type BillingOriginModuleId } from './contracts.js'

export interface VerifiedUser { userId: string; tenantId: string; role: string; capabilities: readonly string[] }
export interface BillingAuthority {
  environmentId: string
  /** Resolve the live Identity account; service tokens cannot authenticate here. */
  verifyUser(authorization: string, tenantId?: string): Promise<VerifiedUser>
  /** Verify provider-local grants; return the actual token consumer, never a body field. */
  verifyComponent(authorization: string | undefined, scope: string): Promise<{ consumerId: string }>
}
function bearer(value: unknown): string {
  if (typeof value !== 'string' || !/^Bearer \S+$/.test(value) || value.length > 8192) throw new BillingError(401, 'user_session_required')
  return value
}
const idSchema = { type: 'string', minLength: 1, maxLength: 256, pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]*$', not: { pattern: '[\\r\\n]' } }
const amountSchema = { type: 'integer', minimum: 0, maximum: 1_000_000_000_000 }
const empty = { type: 'object', additionalProperties: false, properties: {} }
const tokenFields = ['inputTokens', 'outputTokens', 'cacheReadTokens', 'cacheWriteTokens']
const tokensSchema = { type: 'object', additionalProperties: false, required: tokenFields,
  properties: Object.fromEntries(tokenFields.map(key => [key, { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER }])) }
const usageSchema = { type: 'object', additionalProperties: false, required: ['model', 'tokens', 'costSource'], properties: {
  model: { type: 'string', minLength: 1, maxLength: 256 }, tokens: tokensSchema,
  costSource: { type: 'string', enum: ['provider', 'estimate'] }, prices: tokensSchema
} }

export function buildBillingServer(store: BillingStore, authority: BillingAuthority) {
  const app = Fastify({ logger: false, bodyLimit: 16384, ajv: { customOptions: { removeAdditional: false, coerceTypes: false, useDefaults: false } } })
  app.addHook('onSend', async (_req, reply) => { reply.header('cache-control', 'no-store') })
  app.setErrorHandler((error, _req, reply) => {
    const code = error instanceof BillingError ? error.statusCode : error && typeof error === 'object' && 'validation' in error ? 400 : 503
    return reply.code(code).send({ error: error instanceof BillingError ? error.message : code === 400 ? 'invalid_request' : 'billing_unavailable' })
  })
  const user = async (req: FastifyRequest, delegated = false): Promise<VerifiedUser> => {
    const hint = req.headers['x-sislexa-tenant-id']
    if (hint !== undefined && typeof hint !== 'string') throw new BillingError(400, 'invalid_tenant')
    const result = await authority.verifyUser(bearer(delegated ? req.headers['x-sislexa-user-authorization'] : req.headers.authorization), hint)
    if (!result.userId || !result.tenantId) throw new BillingError(503, 'stable_identity_required')
    if (hint !== undefined && hint !== result.tenantId) throw new BillingError(403, 'tenant_access_denied')
    return result
  }
  const executor = async (req: FastifyRequest<{ Params: { id: string } }>) => {
    const actor = await authority.verifyComponent(req.headers.authorization, 'billing.execute')
    return store.executorPrincipal(authority.environmentId, actor.consumerId, req.params.id)
  }
  app.get('/api/health', async () => ({ ok: true, applicationId: 'billing' }))
  app.get('/api/billing/account', async req => {
    const account = await user(req)
    return { tenantId: account.tenantId, ...store.balance(authority.environmentId, account.tenantId) }
  })
  const report = (account: VerifiedUser, from: number, to: number) => store.usageReport({
    userId: account.userId, tenantId: account.tenantId, environmentId: authority.environmentId,
  }, from, to)
  app.get<{ Querystring: { from: string; to: string } }>('/api/billing/usage', {
    schema: { querystring: { type: 'object', additionalProperties: false, required: ['from', 'to'], properties: {
      from: { type: 'string', pattern: '^[0-9]{1,16}$' }, to: { type: 'string', pattern: '^[0-9]{1,16}$' }
    } } }
  }, async req => report(await user(req), Number(req.query.from), Number(req.query.to)))
  app.post<{ Body: { from: number; to: number } }>('/v1/billing/usage-report', {
    schema: { body: { type: 'object', additionalProperties: false, required: ['from', 'to'], properties: {
      from: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
      to: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER }
    } } }
  }, async req => {
    await authority.verifyComponent(req.headers.authorization, 'billing.report')
    return report(await user(req, true), req.body.from, req.body.to)
  })
  app.put<{ Body: { policy: BillingPolicy; expectedRevision: number } }>('/api/billing/policy', {
    schema: { body: { type: 'object', required: ['policy', 'expectedRevision'], additionalProperties: false, properties: {
      policy: { type: 'object', required: ['monthlyMicroUsd', 'monthlyRequests', 'maxConcurrent'], additionalProperties: false,
        properties: Object.fromEntries(['monthlyMicroUsd', 'monthlyRequests', 'maxConcurrent'].map(key => [key, { anyOf: [amountSchema, { type: 'null' }] }])) },
      expectedRevision: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER - 1 }
    } } }
  }, async req => {
    const account = await user(req)
    if (account.role !== 'admin') throw new BillingError(403, 'administrator_required')
    return { revision: store.setPolicy(authority.environmentId, account.tenantId, req.body.policy, req.body.expectedRevision) }
  })
  app.post<{ Body: BillingReservationInput & { originModuleId: string } }>('/v1/billing/reservations', {
    schema: { body: { type: 'object', additionalProperties: false, required: ['operationId', 'maxMicroUsd', 'expiresAt', 'originModuleId'], properties: {
      operationId: idSchema, maxMicroUsd: amountSchema, expiresAt: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
      executionBound: { type: 'string', const: 'unbounded' },
      originModuleId: { type: 'string', enum: Object.keys(BILLING_PRODUCT_CAPABILITIES) }
    } } }
  }, async (req, reply) => {
    const actor = await authority.verifyComponent(req.headers.authorization, 'billing.reserve')
    const account = await user(req, true), origin = req.body.originModuleId
    const principal = reservationPrincipal({ identity: account, environmentId: authority.environmentId,
      actorClientId: actor.consumerId, originModuleId: origin as BillingOriginModuleId })
    return reply.code(201).send(store.reserve(principal, req.body))
  })
  app.get<{ Params: { id: string } }>('/v1/billing/reservations/:id', async req => {
    const principal = await executor(req)
    return store.reservation(principal, req.params.id)
  })
  for (const action of ['start', 'uncertain', 'release'] as const) {
    app.post<{ Params: { id: string }; Body: Record<string, never> }>('/v1/billing/reservations/:id/'+action, { schema: { body: empty } }, async req => {
      const principal = await executor(req)
      if (action === 'start') {
        const account = await user(req, true)
        if (account.userId !== principal.userId || account.tenantId !== principal.tenantId) throw new BillingError(404, 'reservation_not_found')
        const required = BILLING_PRODUCT_CAPABILITIES[principal.originModuleId as BillingOriginModuleId]
        if (!required || !account.capabilities.includes(required)) throw new BillingError(403, 'product_access_denied')
      }
      return store.transition(principal, req.params.id, action)
    })
  }
  app.post<{ Params: { id: string }; Body: { eventId: string; actualMicroUsd: number; usage?: BillingUsageEvidence } }>('/v1/billing/reservations/:id/settle', {
    schema: { body: { type: 'object', additionalProperties: false, required: ['eventId', 'actualMicroUsd'], properties: { eventId: idSchema, actualMicroUsd: amountSchema, usage: usageSchema } } }
  }, async req => {
    const principal = await executor(req)
    return store.settle(principal, req.params.id, req.body.eventId, req.body.actualMicroUsd, req.body.usage)
  })
  return app
}
