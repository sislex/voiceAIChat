import { parseBillingPrincipal, parseBillingReservationInput, parseBillingUsageEvidence,
  type BillingPrincipal, type BillingReservationInput, type BillingUsageEvidence } from '@sislexa/sdk'
import { BillingError } from './store.js'

export const BILLING_PRODUCT_CAPABILITIES = Object.freeze({
  chat: 'chat.use', make: 'make.use', 'image-studio': 'image-studio.use',
  'web-reader': 'web-reader.use', 'playwright-reader': 'playwright-reader.use',
  projects: 'projects.use', machines: 'machines.use', stt: 'voice.stt', tts: 'voice.tts'
} as const)

export type BillingOriginModuleId = keyof typeof BILLING_PRODUCT_CAPABILITIES

export interface TrustedReservationAttribution {
  /** Stable fields returned by a live Identity verification. */
  identity: { userId: string; tenantId: string; capabilities: readonly string[] }
  /** Environment selected by Billing's local component configuration. */
  environmentId: string
  /** Consumer from the verified provider-issued component grant. */
  actorClientId: string
  /** The only attribution field selected by the request body. */
  originModuleId: BillingOriginModuleId
}

/** Convert authenticated boundary results into immutable ledger attribution. */
export function reservationPrincipal(source: TrustedReservationAttribution): BillingPrincipal {
  const required = BILLING_PRODUCT_CAPABILITIES[source.originModuleId]
  if (!required) throw new BillingError(400, 'invalid_origin_module')
  if (source.actorClientId !== 'core' && source.actorClientId !== source.originModuleId) {
    throw new BillingError(403, 'origin_not_allowed')
  }
  if (!source.identity.capabilities.includes(required)) throw new BillingError(403, 'product_access_denied')
  return parseBillingPrincipal({ userId: source.identity.userId, tenantId: source.identity.tenantId,
    environmentId: source.environmentId, actorClientId: source.actorClientId, originModuleId: source.originModuleId })
}

export interface BillingReservationRequest extends BillingReservationInput { originModuleId: BillingOriginModuleId }
export interface BillingSettlementRequest { eventId: string; actualMicroUsd: number; usage?: BillingUsageEvidence }
export interface BillingReportRequest { from: number; to: number }

export const BILLING_HISTORICAL_RECORD_POLICY = Object.freeze({
  version: 1,
  attribution: 'recorded-at-admission',
  correction: 'append-only-reconciliation',
  reservationTtl: 'unstarted-only',
  legacySettlementWithoutUsage: 'valid-cost-without-token-evidence',
  immutableFields: Object.freeze(['userId', 'tenantId', 'environmentId', 'actorClientId', 'originModuleId',
    'period', 'operationId', 'eventId', 'actualMicroUsd', 'usage'] as const)
} as const)

const fixtureTime = Date.UTC(2026, 0, 15, 12)
const fixtureUsage = parseBillingUsageEvidence({ model: 'fixture-model', costSource: 'provider',
  tokens: { inputTokens: 100, outputTokens: 25, cacheReadTokens: 10, cacheWriteTokens: 0 } })

/** Stable examples for consumer contract and replay tests; never use them as authentication data. */
export const BILLING_CONTRACT_FIXTURES = Object.freeze({
  reservation: Object.freeze({ ...parseBillingReservationInput({ operationId: 'fixture-operation-01', maxMicroUsd: 250,
    expiresAt: fixtureTime + 60_000 }), originModuleId: 'chat' as const }),
  settlement: Object.freeze({ eventId: 'fixture-settlement-01', actualMicroUsd: 125,
    usage: fixtureUsage }) as Readonly<BillingSettlementRequest>,
  report: Object.freeze({ from: fixtureTime, to: fixtureTime + 86_400_000 }) as Readonly<BillingReportRequest>,
  idempotency: Object.freeze({
    reservationKey: 'fixture-operation-01', settlementKey: 'fixture-settlement-01',
    exactReservationReplay: Object.freeze({ operationId: 'fixture-operation-01', maxMicroUsd: 250,
      expiresAt: fixtureTime + 60_000, originModuleId: 'chat' as const }),
    conflictingReservationReplay: Object.freeze({ operationId: 'fixture-operation-01', maxMicroUsd: 251,
      expiresAt: fixtureTime + 60_000, originModuleId: 'chat' as const }),
    exactSettlementReplay: Object.freeze({ eventId: 'fixture-settlement-01', actualMicroUsd: 125, usage: fixtureUsage }),
    conflictingSettlementReplay: Object.freeze({ eventId: 'fixture-settlement-01', actualMicroUsd: 126, usage: fixtureUsage })
  })
})

export const billingContractFixtures = BILLING_CONTRACT_FIXTURES
