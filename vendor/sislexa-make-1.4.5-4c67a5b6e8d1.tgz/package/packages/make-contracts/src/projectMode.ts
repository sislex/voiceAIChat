import { z } from 'zod'

const id = z.string().trim().min(1).max(256)
/** POSIX paths relative to the working copy; '.' identifies its root. */
export const projectPathSchema = z.string().min(1).max(4096).refine(value =>
  value === '.' || (!value.startsWith('/') && !value.includes('\\') && !/[:\x00-\x1f]/.test(value)
    && value.split('/').every(part => part !== '' && part !== '.' && part !== '..')), 'Expected a relative project path')
export const projectMachineSchema = z.object({
  agentId: id, name: z.string().optional(), online: z.boolean().optional(), canUse: z.boolean().optional(), path: z.string(),
})
export const makeProjectSchema = z.object({
  id, name: z.string(), type: id, gitUrl: z.string().nullable(), hasGit: z.boolean(),
  machines: z.array(projectMachineSchema), defaultAgentId: id.nullable(), role: z.enum(['owner', 'member']),
})
export const projectSubprojectSchema = z.object({
  path: projectPathSchema, name: z.string(), kind: z.enum(['app', 'library', 'storybook', 'other']),
  packageName: z.string().optional(), stories: z.number().int().nonnegative(), styleFiles: z.array(projectPathSchema),
})
export const projectDesignSchema = z.object({
  tokens: z.array(z.object({
    name: z.string().min(1), value: z.string(), file: projectPathSchema, line: z.number().int().positive(),
    theme: z.string().optional(), source: z.enum(['css', 'scss', 'typescript', 'json']),
  })),
  themes: z.array(z.string()),
  components: z.array(z.object({ name: z.string(), kind: z.enum(['story', 'component']), file: projectPathSchema })),
})
export const PROJECT_NOTES_SECTIONS = ['Решения', 'Стили и токены', 'Компоненты', 'Открытые вопросы'] as const
export const PROJECT_NOTES_MAX_BYTES = 32 * 1024
export const projectNotesSectionSchema = z.enum(PROJECT_NOTES_SECTIONS)
const boundedProjectNotes = z.string().refine(value => new TextEncoder().encode(value).byteLength <= PROJECT_NOTES_MAX_BYTES, 'Project notes exceed 32 KB')
export const projectNotesSchema = z.object({ content: boundedProjectNotes }).strict()
export function replaceProjectNotesSection(source: string, section: ProjectNotesSection, body: string): string {
  const bodies = new Map<ProjectNotesSection, string>()
  const heading = /^## (Решения|Стили и токены|Компоненты|Открытые вопросы)\s*$/gm
  const matches = [...source.matchAll(heading)]
  for (let index = 0; index < matches.length; index += 1) {
    const match = matches[index]!
    bodies.set(match[1] as ProjectNotesSection, source.slice((match.index ?? 0) + match[0].length, matches[index + 1]?.index ?? source.length).trim())
  }
  bodies.set(section, body.trim())
  return PROJECT_NOTES_SECTIONS.map(name => `## ${name}\n\n${bodies.get(name) ?? ''}`.trimEnd()).join('\n\n') + '\n'
}
const branch = z.string().min(1).max(256).refine(value =>
  !value.startsWith('-') && !value.startsWith('/') && !value.endsWith('/') && !value.endsWith('.')
  && !/[\s~^:?*\[\\\x00-\x1f\x7f]/.test(value) && !value.includes('..') && !value.includes('@{')
  && value !== '@' && value.split('/').every(part => part && !part.startsWith('.') && !part.endsWith('.lock')), 'Invalid branch name')
export const projectGitOperationSchema = z.discriminatedUnion('op', [
  z.object({ op: z.literal('status') }).strict(),
  z.object({ op: z.literal('branches') }).strict(),
  z.object({ op: z.literal('pull') }).strict(),
  z.object({ op: z.literal('commit'), message: z.string().trim().min(1).max(10000), files: z.array(projectPathSchema).min(1) }).strict(),
  z.object({ op: z.literal('push') }).strict(),
  z.object({ op: z.literal('branch'), name: branch }).strict(),
])
export const projectGitResultSchema = z.discriminatedUnion('op', [
  z.object({ op: z.literal('status'), branch: z.string().nullable(), files: z.array(z.object({ path: projectPathSchema, index: z.string(), workingTree: z.string() })), ahead: z.number().int().nonnegative(), behind: z.number().int().nonnegative() }),
  z.object({ op: z.literal('branches'), branches: z.array(z.object({ name: z.string(), current: z.boolean(), remote: z.boolean() })) }),
  z.object({ op: z.literal('commit'), commit: z.string().min(1) }),
  z.object({ op: z.literal('pull'), output: z.string() }),
  z.object({ op: z.literal('push'), output: z.string() }),
  z.object({ op: z.literal('branch'), name: branch }),
])
export const standPreviewOperationSchema = z.discriminatedUnion('op', [
  z.object({ op: z.literal('start'), subprojectPath: projectPathSchema, agentId: id.optional() }).strict(),
  z.object({ op: z.literal('status'), subprojectPath: projectPathSchema }).strict(),
  z.object({ op: z.literal('url'), subprojectPath: projectPathSchema }).strict(),
  z.object({ op: z.literal('live_on'), subprojectPath: projectPathSchema, standId: id, component: z.string().min(1) }).strict(),
  z.object({ op: z.literal('live_off'), subprojectPath: projectPathSchema, standId: id, component: z.string().min(1) }).strict(),
])
export const standPreviewResultSchema = z.object({
  standId: id.nullable(), status: z.enum(['stopped', 'starting', 'running', 'failed']),
  url: z.url().refine(value => ['http:', 'https:'].includes(new URL(value).protocol)).nullable(), error: z.string().optional(),
  live: z.boolean().optional(),
})
export const createTransferTaskSchema = z.object({
  targetProjectId: id, targetRepository: z.enum(['core-ui', 'ui-kit']),
  title: z.string().trim().min(1).max(1000), files: z.array(projectPathSchema).min(1), designConversationId: id,
}).strict()
const httpUrl = z.url().refine(value => ['http:', 'https:'].includes(new URL(value).protocol))
export const MAKE_STAND_ERROR_CODES = [
  'stand_not_found', 'machine_unavailable', 'base_environment_missing',
  'component_not_in_stand', 'branch_exists', 'branch_not_found',
  'path_outside_working_copy', 'stand_proxy_unavailable', 'operation_conflict',
] as const
export const MAKE_STAND_MAX_FILE_BYTES = 2 * 1024 * 1024
const standHttpUrl = z.url({ protocol: /^https?$/ })
const standContent = z.string().refine(value => new TextEncoder().encode(value).byteLength <= MAKE_STAND_MAX_FILE_BYTES, 'Stand file exceeds 2 MiB')
export const makeStandFilesOperationSchema = z.discriminatedUnion('action', [
  z.object({ op: z.literal('files'), action: z.literal('list'), dir: projectPathSchema }).strict(),
  z.object({ op: z.literal('files'), action: z.literal('read'), path: projectPathSchema }).strict(),
  z.object({ op: z.literal('files'), action: z.literal('write'), path: projectPathSchema, content: standContent }).strict(),
  z.object({ op: z.literal('files'), action: z.literal('delete'), path: projectPathSchema }).strict(),
  z.object({ op: z.literal('files'), action: z.literal('rename'), from: projectPathSchema, to: projectPathSchema }).strict(),
])
export const makeStandOperationSchema = z.discriminatedUnion('op', [
  z.object({ op: z.literal('options') }).strict(),
  z.object({ op: z.literal('create'), agentId: id }).strict(),
  z.object({
    op: z.literal('attach'), standId: id, hostProjectId: id,
    branch: branch.optional(), newBranch: branch.optional(), baseBranch: branch.optional(),
  }).strict().refine(value => value.branch === undefined || value.newBranch === undefined, 'Choose branch or newBranch, not both'),
  z.object({ op: z.literal('status'), standId: id, hostProjectId: id }).strict(),
  z.object({ op: z.literal('detach'), standId: id, hostProjectId: id }).strict(),
  makeStandFilesOperationSchema,
  z.object({ op: z.literal('git'), operation: projectGitOperationSchema }).strict(),
])
// Component identifiers are owned by the host's DevComponent registry.
export const makeStandOptionsSchema = z.object({
  component: id.nullable(), repository: z.string().nullable(),
  stands: z.array(z.object({
    standId: id, hostProjectId: id, hostProjectName: z.string(), machineId: id, machineName: z.string(),
    online: z.boolean(), status: z.string(), componentSource: z.enum(['base', 'dev', 'live']),
    branch: branch.nullable(), sha: z.string().nullable(),
  })),
  machines: z.array(z.object({ agentId: id, name: z.string(), online: z.boolean(), canCreate: z.boolean(), reason: z.string().optional() })),
})
export const makeStandFilesResultSchema = z.discriminatedUnion('action', [
  z.object({ action: z.literal('list'), entries: z.array(z.object({ path: projectPathSchema, kind: z.enum(['file', 'directory']) })) }),
  z.object({ action: z.literal('read'), content: standContent }),
  z.object({ action: z.literal('write') }),
  z.object({ action: z.literal('delete') }),
  z.object({ action: z.literal('rename') }),
])
/** Null identity fields represent an unbound conversation, including options discovery. */
export const makeStandStateSchema = z.object({
  standId: id.nullable(), hostProjectId: id.nullable(), machineId: id.nullable(), component: id.nullable(),
  branch: branch.nullable(), workingCopyPath: z.string().min(1).nullable(),
  phase: z.enum(['idle', 'creating', 'preparing', 'installing', 'switching', 'ready', 'failed']),
  error: z.string().optional(), previewUrl: standHttpUrl.nullable(), directUrls: z.array(standHttpUrl),
})
export const makeStandResultSchema = makeStandStateSchema.extend({
  operationId: id.optional(), options: makeStandOptionsSchema.optional(),
  files: makeStandFilesResultSchema.optional(), git: projectGitResultSchema.optional(),
})

/** Validate payload presence and discriminators against the initiating request. */
export function validateMakeStandResult(operation: MakeStandOperation, result: MakeStandResult): void {
  if (result.phase === 'failed') return
  const valid = operation.op === 'options' ? result.options !== undefined
    : operation.op === 'create' ? result.operationId !== undefined && result.standId !== null && result.hostProjectId !== null
    : operation.op === 'files' ? result.files?.action === operation.action
    : operation.op === 'git' ? result.git?.op === operation.operation.op : true
  if (!valid) throw new Error('Mismatched Make stand result')
}

export type MakeStandErrorCode = typeof MAKE_STAND_ERROR_CODES[number]
export type MakeStandOperation = z.infer<typeof makeStandOperationSchema>
export type MakeStandFilesOperation = z.infer<typeof makeStandFilesOperationSchema>
export type MakeStandOptions = z.infer<typeof makeStandOptionsSchema>
export type MakeStandFilesResult = z.infer<typeof makeStandFilesResultSchema>
export type MakeStandState = z.infer<typeof makeStandStateSchema>
export type MakeStandResult = z.infer<typeof makeStandResultSchema>

export const transferTaskResultSchema = z.object({
  taskId: id, projectId: id, branch: branch, branchUrl: httpUrl,
  /** In-app link (for example '#/projects/<id>/task/<id>') or an absolute URL. */
  taskUrl: z.string().min(1), designUrl: z.string().min(1).optional(),
})

export type MakeProject = z.infer<typeof makeProjectSchema>
export type ProjectSubproject = z.infer<typeof projectSubprojectSchema>
export type ProjectDesign = z.infer<typeof projectDesignSchema>
export type ProjectGitOperation = z.infer<typeof projectGitOperationSchema>
export type ProjectGitResult = z.infer<typeof projectGitResultSchema>
export type StandPreviewOperation = z.infer<typeof standPreviewOperationSchema>
export type StandPreviewResult = z.infer<typeof standPreviewResultSchema>
export type CreateTransferTaskArgs = z.infer<typeof createTransferTaskSchema>
export type TransferTaskResult = z.infer<typeof transferTaskResultSchema>
export type ProjectNotesSection = z.infer<typeof projectNotesSectionSchema>

/** Core authorizes each call against current membership, machine access and command policy. */
export interface MakeProjectCore {
  listProjects(userId: string): Promise<MakeProject[]>
  projectStructure(userId: string, projectId: string): Promise<ProjectSubproject[]>
  projectDesign(userId: string, projectId: string, subprojectPath: string): Promise<ProjectDesign>
  /** Read make/notes.md in the authorized subproject, creating is left to an update. */
  projectNotesRead(userId: string, projectId: string, subprojectPath: string): Promise<{ content: string }>
  /** Replace one canonical section in make/notes.md; hosts enforce containment and the byte limit. */
  projectNotesUpdate(userId: string, projectId: string, subprojectPath: string, section: ProjectNotesSection, content: string): Promise<{ content: string }>
  projectGit(userId: string, projectId: string, operation: ProjectGitOperation): Promise<ProjectGitResult>
  /** Live operations enable/disable host-managed updates on an existing stand; unsupported hosts must reject them. */
  standPreview(userId: string, projectId: string, operation: StandPreviewOperation): Promise<StandPreviewResult>
  makeStand(userId: string, conversationId: string, operation: MakeStandOperation): Promise<MakeStandResult>
  createTransferTask(userId: string, args: CreateTransferTaskArgs): Promise<TransferTaskResult>
}

export const projectModeRpcSchemas = {
  listProjects: { args: z.tuple([id]), result: z.array(makeProjectSchema) },
  projectStructure: { args: z.tuple([id, id]), result: z.array(projectSubprojectSchema) },
  projectDesign: { args: z.tuple([id, id, projectPathSchema]), result: projectDesignSchema },
  projectNotesRead: { args: z.tuple([id, id, projectPathSchema]), result: projectNotesSchema },
  projectNotesUpdate: { args: z.tuple([id, id, projectPathSchema, projectNotesSectionSchema, boundedProjectNotes]), result: projectNotesSchema },
  projectGit: { args: z.tuple([id, id, projectGitOperationSchema]), result: projectGitResultSchema },
  standPreview: { args: z.tuple([id, id, standPreviewOperationSchema]), result: standPreviewResultSchema },
  makeStand: { args: z.tuple([id, id, makeStandOperationSchema]), result: makeStandResultSchema },
  createTransferTask: { args: z.tuple([id, createTransferTaskSchema]), result: transferTaskResultSchema },
} as const
export type ProjectModeRpcMethod = keyof typeof projectModeRpcSchemas
export function isProjectModeRpcMethod(method: string): method is ProjectModeRpcMethod {
  return Object.prototype.hasOwnProperty.call(projectModeRpcSchemas, method)
}
