import { RpcError } from '@voicechat/shared'
import { replaceProjectNotesSection, type MakeStandResult, type MakeStandOperation, type MakeProjectCore, type MakeProject, type ProjectDesign, type ProjectSubproject, type ProjectGitResult, type StandPreviewResult, type CreateTransferTaskArgs } from './projectMode.js'

export interface FakeProjectFixture {
  project: MakeProject
  viewers: string[]
  structure?: ProjectSubproject[]
  designs?: Record<string, ProjectDesign>
  git?: Partial<Record<ProjectGitResult['op'], ProjectGitResult>>
  preview?: StandPreviewResult
  notes?: Record<string, string>
}

export interface FakeMakeStandFixture {
  viewers: string[]
  results: Partial<Record<MakeStandOperation['op'], MakeStandResult>>
}

/** Deterministic test double. Production machine operations remain Core-owned. */
export class FakeProjectCore implements MakeProjectCore {
  readonly calls: Array<{ method: keyof MakeProjectCore; args: unknown[] }> = []
  readonly transfers: Array<CreateTransferTaskArgs & { taskId: string; userId: string }> = []
  constructor(readonly fixtures: FakeProjectFixture[] = [], readonly designOwners: Record<string, string[]> = {}, readonly stands: Record<string, FakeMakeStandFixture> = {}) {}

  private record(method: keyof MakeProjectCore, args: unknown[]) { this.calls.push({ method, args: structuredClone(args) }) }
  private visible(userId: string, projectId: string) {
    const fixture = this.fixtures.find(item => item.project.id === projectId && item.viewers.includes(userId))
    if (!fixture) throw new RpcError(404, 'Project not found')
    return fixture
  }
  async listProjects(userId: string) {
    this.record('listProjects', [userId])
    return structuredClone(this.fixtures.filter(item => item.viewers.includes(userId)).map(item => item.project))
  }
  async projectStructure(userId: string, projectId: string) {
    this.record('projectStructure', [userId, projectId])
    return structuredClone(this.visible(userId, projectId).structure ?? [])
  }
  async projectDesign(userId: string, projectId: string, path: string) {
    this.record('projectDesign', [userId, projectId, path])
    const design = this.visible(userId, projectId).designs?.[path]
    if (!design) throw new RpcError(404, 'Subproject not found')
    return structuredClone(design)
  }
  async projectNotesRead(userId: string, projectId: string, path: string) {
    this.record('projectNotesRead', [userId, projectId, path])
    return { content: this.visible(userId, projectId).notes?.[path] ?? '' }
  }
  async projectNotesUpdate(userId: string, projectId: string, path: string, section: import('./projectMode.js').ProjectNotesSection, content: string) {
    this.record('projectNotesUpdate', [userId, projectId, path, section, content])
    const fixture = this.visible(userId, projectId)
    fixture.notes ??= {}
    fixture.notes[path] = replaceProjectNotesSection(fixture.notes[path] ?? '', section, content)
    return { content: fixture.notes[path] }
  }
  async projectGit(...args: Parameters<MakeProjectCore['projectGit']>) {
    this.record('projectGit', args)
    const result = this.visible(args[0], args[1]).git?.[args[2].op]
    if (!result) throw new RpcError(409, 'No Git fixture for this operation')
    return structuredClone(result)
  }
  async makeStand(...args: Parameters<MakeProjectCore['makeStand']>) {
    this.record('makeStand', args)
    const fixture = this.stands[args[1]]
    if (!fixture?.viewers.includes(args[0])) throw new RpcError(404, 'Conversation not found')
    const result = fixture.results[args[2].op]
    if (!result) throw new RpcError(409, 'No Make stand fixture for this operation')
    return structuredClone(result)
  }
  async standPreview(...args: Parameters<MakeProjectCore['standPreview']>) {
    this.record('standPreview', args)
    const result = this.visible(args[0], args[1]).preview
    if (!result) throw new RpcError(409, 'No stand fixture')
    return structuredClone(result)
  }
  async createTransferTask(userId: string, args: CreateTransferTaskArgs) {
    this.record('createTransferTask', [userId, args])
    this.visible(userId, args.targetProjectId)
    if (!this.designOwners[args.designConversationId]?.includes(userId)) throw new RpcError(404, 'Design not found')
    const taskId = `transfer-${this.transfers.length + 1}`
    this.transfers.push({ ...structuredClone(args), taskId, userId })
    const branch = `make/${taskId}`
    return {
      taskId, projectId: args.targetProjectId, branch,
      taskUrl: `#/projects/${args.targetProjectId}/task/${taskId}`,
      branchUrl: `https://git.example.test/${args.targetRepository}/tree/${branch}`,
    }
  }
}

/** Spreadable methods for the existing Make route and MCP test fixtures. */
export function fakeProjectCoreMethods(fake = new FakeProjectCore()): MakeProjectCore {
  return {
    listProjects: fake.listProjects.bind(fake), projectStructure: fake.projectStructure.bind(fake),
    projectDesign: fake.projectDesign.bind(fake), projectGit: fake.projectGit.bind(fake),
    projectNotesRead: fake.projectNotesRead.bind(fake), projectNotesUpdate: fake.projectNotesUpdate.bind(fake),
    makeStand: fake.makeStand.bind(fake), standPreview: fake.standPreview.bind(fake), createTransferTask: fake.createTransferTask.bind(fake),
  }
}
