import { createProjectHttpClient, type ProjectInventory, type MakeProjectClient } from '@voicechat/make-contracts/projectClient'
import { projectPathSchema } from '@voicechat/make-contracts/projectMode'
import type { RendererApi, RendererFsBridge } from '@voicechat/shared/ipc'

type FileApi = Pick<RendererApi, 'projects:gitFile' | 'projects:gitSaveFile'>

/** Reuse host authorization and machine transport; never execute Git in the panel. */
export function createMakeProjectClient(api: FileApi, inventory: ProjectInventory = createProjectHttpClient(), fs?: RendererFsBridge): MakeProjectClient {
  async function location(id: string, path: string) {
    projectPathSchema.parse(path)
    const project = (await inventory.listProjects()).find(project => project.id === id)
    if (!project) throw new Error('Project not found')
    const machine = project.machines.find(machine => machine.agentId === project.defaultAgentId)
      ?? (project.machines.length === 1 ? project.machines[0] : undefined)
    if (!machine || machine.online === false || machine.canUse === false) throw new Error('Project working copy is unavailable')
    return { agent: machine.agentId, absolute: `${machine.path.replace(/\/$/, '')}/${path}`, workspace: `project:${machine.agentId}` }
  }
  return {
    ...inventory,
    async read(id, path) {
      const target = await location(id, path)
      if (fs) {
        const result = await fs.read(target.agent, target.absolute, id)
        if (result.truncated || typeof result.dataBase64 !== 'string') throw new Error('File content is unavailable')
        return new TextDecoder().decode(Uint8Array.from(atob(result.dataBase64), char => char.charCodeAt(0)))
      }
      const result = await api['projects:gitFile']({ id, workspace: target.workspace, path })
      if (result.binary || result.truncated) throw new Error('File cannot be edited as text')
      return result.content
    },
    async write(id, path, content) {
      const target = await location(id, path)
      if (fs) {
        if (/(^|\/)themes\/[^/]+\.css$/.test(path)) {
          const directory = target.absolute.slice(0, target.absolute.lastIndexOf('/'))
          const parent = await fs.list(target.agent, directory.slice(0, directory.lastIndexOf('/')), id)
          if (!parent.entries?.some(entry => entry.name === 'themes')) await fs.mkdir(target.agent, directory, id)
        }
        let bytes = ''
        for (const byte of new TextEncoder().encode(content)) bytes += String.fromCharCode(byte)
        await fs.write(target.agent, target.absolute, btoa(bytes), id)
      } else await api['projects:gitSaveFile']({ id, workspace: target.workspace, path, content })
    },
  }
}
