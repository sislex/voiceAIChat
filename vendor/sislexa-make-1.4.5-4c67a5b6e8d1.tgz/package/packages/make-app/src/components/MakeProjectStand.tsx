import { useEffect, useRef, useState, type ReactNode } from 'react'
import type { MakeStandClient } from '@voicechat/make-contracts/projectClient'
import { MAKE_STAND_ERROR_CODES, type MakeStandOperation, type MakeStandResult, type MakeStandOptions, type ProjectGitResult } from '@voicechat/make-contracts/projectMode'
import { mt, useMakeLocale } from '../i18n'

export function standError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error)
  const code = MAKE_STAND_ERROR_CODES.find(code => message.includes(code))
  return code ? `${mt(code)} (${code})` : message
}
export function defaultStandBranch(title: string, id: string): string {
  const slug = title.toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '').slice(0, 60) || 'conversation'
  return `make/${slug}-${id.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 8) || 'draft'}`
}
const phaseMessages = {
  idle: 'standIdle', creating: 'standCreating', preparing: 'standPreparing',
  installing: 'standInstalling', switching: 'standSwitching', ready: 'standReady', failed: 'standFailed',
} as const

export function MakeProjectStand({ client, conversationId, title = 'conversation', branches, children, navigationLocked = false }: {
  client: MakeStandClient; conversationId: string; title?: string
  branches: () => Promise<ProjectGitResult>; children: ReactNode; navigationLocked?: boolean
}) {
  useMakeLocale()
  const [options, setOptions] = useState<MakeStandOptions>()
  const [state, setState] = useState<MakeStandResult>()
  const [selection, setSelection] = useState('')
  const [target, setTarget] = useState<{ standId: string; hostProjectId: string }>()
  const [branchMode, setBranchMode] = useState<'new' | 'existing'>('new')
  const [branch, setBranch] = useState(() => defaultStandBranch(title, conversationId))
  const [availableBranches, setAvailableBranches] = useState<string[]>([])
  const [existingBranch, setExistingBranch] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(true)
  const [dirty, setDirty] = useState(false)
  const [mode, setMode] = useState<'preview' | 'code'>('preview')
  const alive = useRef(true)
  const pending = useRef(false)
  const bound = Boolean(state?.standId)
  const locked = busy || dirty || navigationLocked
  useEffect(() => {
    alive.current = true
    let cancelled = false
    void (async () => {
      try {
        const current = await client.state(conversationId)
        if (cancelled) return
        setState(current)
        if (current.error) setError(standError(current.error))
        const discovery = current.options ? current : await client.operation(conversationId, { op: 'options' })
        if (cancelled) return
        setState(current); setOptions(discovery.options)
        if (current.standId && current.hostProjectId) {
          setSelection(current.standId)
          if (!current.branch) setTarget({ standId: current.standId, hostProjectId: current.hostProjectId })
        }
      } catch (error) { if (!cancelled) setError(standError(error)) }
      finally { if (!cancelled) setBusy(false) }
    })()
    return () => { cancelled = true; alive.current = false }
  }, [client, conversationId])
  const run = async (operation: MakeStandOperation) => {
    if (pending.current) return
    pending.current = true; setBusy(true); setError('')
    try {
      const next = await client.operation(conversationId, operation)
      if (!alive.current) return
      if (next.phase === 'failed') { setState(next); throw new Error(next.error ?? 'operation_conflict') }
      if (next.error) setError(standError(next.error))
      setState(next)
      return next
    } catch (error) { if (alive.current) setError(standError(error)) }
    finally { pending.current = false; if (alive.current) setBusy(false) }
  }
  useEffect(() => {
    if (!state?.standId || state.phase === 'ready' || state.phase === 'failed' || state.phase === 'idle') return
    let cancelled = false
    const timer = setInterval(() => {
      if (pending.current) return
      pending.current = true; setBusy(true)
      void client.state(conversationId).then(next => {
        if (!cancelled) { setState(next); if (next.error) setError(standError(next.error)) }
      }).catch(error => { if (!cancelled) setError(standError(error)) }).finally(() => { pending.current = false; if (alive.current) setBusy(false) })
    }, 3000)
    return () => { cancelled = true; clearInterval(timer) }
  }, [client, conversationId, state?.standId, state?.phase])
  useEffect(() => {
    if (!target) return
    let cancelled = false
    void branches().then(result => {
      if (!cancelled && result.op === 'branches') {
        const names = result.branches.map(branch => branch.name)
        setAvailableBranches(names); setExistingBranch(names[0] ?? '')
      }
    }).catch(error => { if (!cancelled) setError(standError(error)) })
    return () => { cancelled = true }
  }, [target, branches])
  useEffect(() => {
    const guard = (event: BeforeUnloadEvent) => { if (dirty) { event.preventDefault(); event.returnValue = '' } }
    window.addEventListener('beforeunload', guard)
    return () => window.removeEventListener('beforeunload', guard)
  }, [dirty])
  const choose = async (value: string) => {
    if (locked || bound) return
    setSelection(value); setError(''); setTarget(undefined)
    if (value.startsWith('machine:')) {
      const next = await run({ op: 'create', agentId: value.slice(8) })
      if (next?.standId && next.hostProjectId) {
        setSelection(next.standId); setTarget({ standId: next.standId, hostProjectId: next.hostProjectId })
      }
    } else {
      const stand = options?.stands.find(stand => stand.standId === value)
      if (stand) setTarget({ standId: stand.standId, hostProjectId: stand.hostProjectId })
    }
  }
  const attach = async () => {
    if (!target) return
    setState(previous => previous ? { ...previous, phase: 'preparing' } : previous)
    const next = await run({ op: 'attach', ...target, ...(branchMode === 'new' ? { newBranch: branch } : { branch: existingBranch }) })
    if (next) setTarget(undefined)
  }
  const detach = async () => {
    if (!state?.standId || !state.hostProjectId) return
    const next = await run({ op: 'detach', standId: state.standId, hostProjectId: state.hostProjectId })
    if (next) { setState(undefined); setSelection(''); setTarget(undefined); setMode('preview') }
  }
  return <section className="make-conversation-stand">
    <header className="make-stand-header">
      <label>{mt('standSelector')} <select aria-label={mt('standSelector')} value={selection} disabled={locked || bound} onChange={event => void choose(event.target.value)}>
        <option value="">{mt('makePreview')}</option>
        {state?.standId && !options?.stands.some(stand => stand.standId === state.standId) && <option value={state.standId}>{state.standId} · {state.component} · {state.branch}</option>}
        {options?.stands.map(stand => <option key={stand.standId} value={stand.standId} disabled={!stand.online}>
          {stand.hostProjectName} · {stand.machineName} · {stand.status} · {stand.branch ?? stand.componentSource}
        </option>)}
        <optgroup label={mt('standNewMachine')}>
          {options?.machines.map(machine => <option key={machine.agentId} value={`machine:${machine.agentId}`} disabled={!machine.online || !machine.canCreate}>
            {machine.name}{!machine.online ? ` — ${mt('standOffline')}` : !machine.canCreate ? ` — ${machine.reason ? standError(machine.reason) : mt('standNoBase')}` : ''}
          </option>)}
        </optgroup>
      </select></label>
      {bound && <button disabled={locked} onClick={() => void detach()}>{mt('standDisconnect')}</button>}
      {bound && <button disabled={locked} onClick={() => { if (state?.standId && state.hostProjectId) void run({ op: 'status', standId: state.standId, hostProjectId: state.hostProjectId }) }}>{mt('standRefresh')}</button>}
      {state && (bound || busy) && <p role="status">{mt(phaseMessages[state.phase])} · {state.component} · {state.branch}</p>}
      {error && <p role="alert">{error}</p>}
      {target && <fieldset disabled={locked || state?.phase === 'creating'}>
        <label><input type="radio" checked={branchMode === 'new'} onChange={() => setBranchMode('new')} />{mt('standNewBranch')}</label>
        <label><input type="radio" checked={branchMode === 'existing'} onChange={() => setBranchMode('existing')} />{mt('standExistingBranch')}</label>
        {branchMode === 'new' ? <><input aria-label={mt('standNewBranch')} value={branch} onChange={event => setBranch(event.target.value)} /><small>{mt('standBaseBranch')}</small></>
          : <select aria-label={mt('standExistingBranch')} value={existingBranch} onChange={event => setExistingBranch(event.target.value)}>{availableBranches.map(name => <option key={name}>{name}</option>)}</select>}
        <button disabled={branchMode === 'new' ? !branch.trim() : !existingBranch} onClick={() => void attach()}>{mt('standConnect')}</button>
      </fieldset>}
    </header>
    {bound ? <>
      <nav><button disabled={dirty} aria-pressed={mode === 'preview'} onClick={() => setMode('preview')}>{mt('preview')}</button><button disabled={state?.phase !== 'ready' || Boolean(target)} aria-pressed={mode === 'code'} onClick={() => setMode('code')}>{mt('code')}</button></nav>
      {mode === 'preview' && state?.phase === 'ready' && !target && <div className="make-preview">
        {state.previewUrl ? <><a href={state.previewUrl} target="_blank" rel="noopener noreferrer">{mt('openInNewTab')}</a><iframe className="make-frame" title={mt('developmentStand')} src={state.previewUrl} sandbox="allow-scripts allow-forms allow-modals allow-popups allow-same-origin allow-downloads" /></>
          : state.directUrls.map(url => <a key={url} href={url} target="_blank" rel="noopener noreferrer">{mt('openInNewTab')}: {url}</a>)}
      </div>}
      {mode === 'code' && state?.phase === 'ready' && <StandEditor client={client} conversationId={conversationId} onDirty={setDirty} />}
    </> : null}
    <div hidden={bound}>{children}</div>
  </section>
}

function StandEditor({ client, conversationId, onDirty }: { client: MakeStandClient; conversationId: string; onDirty: (dirty: boolean) => void }) {
  useMakeLocale()
  const [entries, setEntries] = useState<Array<{ path: string; kind: 'file' | 'directory' }>>([])
  const [dir, setDir] = useState('.')
  const [path, setPath] = useState('')
  const [content, setContent] = useState('')
  const [saved, setSaved] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [status, setStatus] = useState<Extract<ProjectGitResult, { op: 'status' }>>()
  const [selected, setSelected] = useState<string[]>([])
  const [message, setMessage] = useState('')
  const dirty = content !== saved
  const alive = useRef(true)
  const pending = useRef(false)
  useEffect(() => { alive.current = true; return () => { alive.current = false; onDirty(false) } }, [onDirty])
  useEffect(() => onDirty(dirty || busy), [dirty, busy, onDirty])
  const request = async (operation: MakeStandOperation) => {
    const result = await client.operation(conversationId, operation)
    if (result.phase === 'failed') throw new Error(result.error ?? 'operation_conflict')
    return result
  }
  const refresh = async () => {
    const result = await request({ op: 'git', operation: { op: 'status' } })
    if (alive.current && result.git?.op === 'status') { setStatus(result.git); setSelected([]) }
  }
  useEffect(() => {
    let cancelled = false
    setBusy(true)
    void request({ op: 'files', action: 'list', dir }).then(result => {
      if (!cancelled && result.files?.action === 'list') setEntries(result.files.entries)
    }).catch(error => { if (!cancelled) setError(standError(error)) }).finally(() => { if (!cancelled) setBusy(false) })
    return () => { cancelled = true }
  }, [client, conversationId, dir])
  useEffect(() => { void refresh().catch(error => { if (alive.current) setError(standError(error)) }) }, [client, conversationId])
  const run = async (action: () => Promise<void>) => {
    if (pending.current) return
    pending.current = true; setBusy(true); setError('')
    try { await action() } catch (error) { if (alive.current) setError(standError(error)) }
    finally { pending.current = false; if (alive.current) setBusy(false) }
  }
  return <section className="make-stand-editor" aria-label={mt('standFiles')}>
    {error && <p role="alert">{error}</p>}
    <p>{dir}</p>
    <button disabled={busy || dirty || dir === '.'} onClick={() => setDir(dir.includes('/') ? dir.slice(0, dir.lastIndexOf('/')) : '.')}>..</button>
    <ul>{entries.map(entry => <li key={entry.path}><button disabled={busy || dirty} onClick={() => {
      if (entry.kind === 'directory') setDir(entry.path)
      else void run(async () => {
        const result = await request({ op: 'files', action: 'read', path: entry.path })
        if (alive.current && result.files?.action === 'read') { setPath(entry.path); setContent(result.files.content); setSaved(result.files.content) }
      })
    }}>{entry.path}{entry.kind === 'directory' ? '/' : ''}</button></li>)}</ul>
    {path && <><p>{path}</p><textarea aria-label={mt('standFileContent')} value={content} disabled={busy} onChange={event => setContent(event.target.value)} />
      <button disabled={busy || !dirty} onClick={() => void run(async () => {
        const written = content
        await request({ op: 'files', action: 'write', path, content: written })
        if (alive.current) setSaved(written)
        await refresh()
      })}>{mt('standSave')}</button></>}
    <p>{status?.branch} {status ? `↑${status.ahead} ↓${status.behind}` : ''}</p>
    {status?.files.map(file => <label key={file.path}><input type="checkbox" disabled={busy || dirty} checked={selected.includes(file.path)} onChange={event => setSelected(event.target.checked ? [...selected, file.path] : selected.filter(path => path !== file.path))} />{file.index}{file.workingTree} {file.path}</label>)}
    <input aria-label={mt('standCommitMessage')} value={message} onChange={event => setMessage(event.target.value)} />
    <button disabled={busy || dirty || !message.trim() || !selected.length} onClick={() => void run(async () => { await request({ op: 'git', operation: { op: 'commit', message, files: selected } }); await refresh() })}>{mt('standCommit')}</button>
    <button disabled={busy || dirty} onClick={() => void run(async () => { await request({ op: 'git', operation: { op: 'push' } }); await refresh() })}>{mt('standPush')}</button>
    <button disabled={busy || dirty} onClick={() => void run(refresh)}>{mt('standRefresh')}</button>
  </section>
}
