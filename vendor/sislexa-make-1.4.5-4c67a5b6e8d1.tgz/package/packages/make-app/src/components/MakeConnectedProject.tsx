import { useEffect, useState } from 'react'
import { projectThemeFile, type MakeProjectClient } from '@voicechat/make-contracts/projectClient'
import { type MakeProject, type ProjectSubproject, type ProjectDesign, type ProjectGitOperation, type ProjectGitResult, type TransferTaskResult } from '@voicechat/make-contracts/projectMode'
import { mt, useMakeLocale, describeMakeError } from '../i18n'

export function MakeConnectedProject({ client, conversationId, onLocked }: { client: MakeProjectClient; conversationId: string; onLocked?: (value: boolean) => void }) {
  useMakeLocale()
  const [projects, setProjects] = useState<MakeProject[]>([])
  const [selected, setSelected] = useState('')
  const [error, setError] = useState('')
  const [locked, setLocked] = useState(false)
  const lock = (value: boolean) => { setLocked(value); onLocked?.(value) }
  useEffect(() => {
    let live = true
    void client.listProjects().then(value => { if (live) setProjects(value) }).catch(error => { if (live) setError(describeMakeError(error)) })
    return () => { live = false }
  }, [client])
  const project = projects.find(project => project.id === selected)
  return <section className="make-connected-project">
    {error && <p role="alert">{error}</p>}
    <label>{mt('connectedProject')}<select disabled={locked} value={selected} onChange={event => setSelected(event.target.value)}>
      <option value="">{mt('chooseProject')}</option>
      {projects.map(project => <option key={project.id} value={project.id}>{project.name}</option>)}
    </select></label>
    {project && <ProjectContent key={project.id} client={client} project={project} conversationId={conversationId} locked={locked} onLocked={lock} />}
  </section>
}

function ProjectContent({ client, project, conversationId, locked, onLocked }: { client: MakeProjectClient; project: MakeProject; conversationId: string; locked: boolean; onLocked: (value: boolean) => void }) {
  const [designLocked, setDesignLocked] = useState(false)
  useEffect(() => { onLocked(designLocked) }, [designLocked])
  const [structure, setStructure] = useState<ProjectSubproject[]>([])
  const [selected, setSelected] = useState('')
  const [error, setError] = useState('')
  useEffect(() => {
    let live = true
    void client.projectStructure(project.id).then(value => {
      if (live) { setStructure(value); setSelected(value[0]?.path ?? '') }
    }).catch(error => { if (live) setError(describeMakeError(error)) })
    return () => { live = false }
  }, [client, project.id])
  const subproject = structure.find(item => item.path === selected)
  return <>
    {error && <p role="alert">{error}</p>}
    <label>{mt('subproject')}<select disabled={locked} value={selected} onChange={event => setSelected(event.target.value)}>
      {structure.map(item => <option key={item.path} value={item.path}>{item.name} · {item.path} · {item.kind}</option>)}
    </select></label>
    {subproject && <Design key={subproject.path} client={client} project={project} conversationId={conversationId} subproject={subproject} onLocked={setDesignLocked} />}
    {project.hasGit && <fieldset disabled={locked}><ProjectGit client={client} id={project.id} /></fieldset>}
  </>
}

function Design({ client, project, conversationId, subproject, onLocked }: { client: MakeProjectClient; project: MakeProject; conversationId: string; subproject: ProjectSubproject; onLocked: (value: boolean) => void }) {
  const [design, setDesign] = useState<ProjectDesign | null>(null)
  const [theme, setTheme] = useState('')
  const [values, setValues] = useState<Record<string, string>>({})
  const [name, setName] = useState('')
  const [file, setFile] = useState<{ path: string; content: string; saved: string } | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState('')
  const [variantPath, setVariantPath] = useState('')
  const [selectedFiles, setSelectedFiles] = useState<string[]>([])
  const [targetRepository, setTargetRepository] = useState<'core-ui' | 'ui-kit'>('core-ui')
  const [transferTitle, setTransferTitle] = useState('')
  const [transfer, setTransfer] = useState<TransferTaskResult | null>(null)
  const dirty = file !== null && file.content !== file.saved
  useEffect(() => { onLocked(dirty || busy) }, [dirty, busy])
  useEffect(() => {
    let live = true
    void client.projectDesign(project.id, subproject.path).then(value => { if (live) setDesign(value) }).catch(error => { if (live) setError(describeMakeError(error)) })
    return () => { live = false }
  }, [client, project.id, subproject.path])
  useEffect(() => {
    if (!dirty) return
    const warn = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = '' }
    window.addEventListener('beforeunload', warn)
    return () => window.removeEventListener('beforeunload', warn)
  }, [dirty])
  async function run(action: () => Promise<void>) {
    setBusy(true); setError(''); setSaved('')
    try { await action() } catch (error) { setError(describeMakeError(error)) } finally { setBusy(false) }
  }
  const open = (path: string) => void run(async () => {
    const content = await client.read(project.id, path)
    setFile({ path, content, saved: content })
  })
  const toggleTransferFile = (path: string, checked: boolean) => setSelectedFiles(current => checked
    ? [...new Set([...current, path])]
    : current.filter(item => item !== path))
  return <section aria-label={mt('projectDesign')}>
    <h3>{mt('projectDesign')}</h3>
    {error && <p role="alert">{error}</p>}{saved && <p role="status">{saved}</p>}
    {design && <>
      <label>{mt('projectTheme')}<select value={theme} onChange={event => { setTheme(event.target.value); setValues({}) }}>
        <option value="">:root</option>{design.themes.map(theme => <option key={theme}>{theme}</option>)}
      </select></label>
      <ul>{design.tokens.filter(token => (token.theme ?? '') === theme).map((token, index) => <li key={`${token.file}:${token.line}:${index}`}>
        <label>{token.name}<input value={values[token.name] ?? token.value} onChange={event => setValues({ ...values, [token.name]: event.target.value })} /></label>
        <span>{token.value} · {token.file}:{token.line}</span>
        <button disabled={busy || dirty} onClick={() => open(token.file)}>{mt('editProjectFile')}</button>
      </li>)}</ul>
      <label>{mt('variantName')}<input value={name} onChange={event => setName(event.target.value)} /></label>
      <button disabled={busy || !name || !Object.keys(values).length} onClick={() => void run(async () => {
        const variant = projectThemeFile(subproject.path, name, design, values, theme || undefined)
        await client.write(project.id, variant.path, variant.content)
        setSaved(variant.path)
        setVariantPath(variant.path)
        setSelectedFiles(current => [...new Set([...current, variant.path])])
        setDesign(await client.projectDesign(project.id, subproject.path))
      })}>{mt('saveProjectVariant')}</button>
      <h4>{mt('components')}</h4>
      <ul>{design.components.map(item => <li key={`${item.file}:${item.name}`}><label><input type="checkbox" aria-label={`${mt('transferSelection')}: ${item.name}`} checked={selectedFiles.includes(item.file)} onChange={event => toggleTransferFile(item.file, event.target.checked)} />{item.name}</label> <button disabled={busy || dirty} onClick={() => open(item.file)}>{item.name} · {item.file}</button></li>)}</ul>
      <h4>{mt('styles')}</h4>
      <ul>{subproject.styleFiles.map(path => <li key={path}><label><input type="checkbox" aria-label={`${mt('transferSelection')}: ${path}`} checked={selectedFiles.includes(path)} onChange={event => toggleTransferFile(path, event.target.checked)} />{path}</label> <button disabled={busy || dirty} onClick={() => open(path)}>{path}</button></li>)}</ul>
      {variantPath && <label><input type="checkbox" aria-label={`${mt('transferSelection')}: ${variantPath}`} checked={selectedFiles.includes(variantPath)} onChange={event => toggleTransferFile(variantPath, event.target.checked)} />{variantPath}</label>}
      <fieldset disabled={busy || dirty}>
        <legend>{mt('transferToSislexa')}</legend>
        <label>{mt('transferTarget')}<select value={targetRepository} onChange={event => setTargetRepository(event.target.value as 'core-ui' | 'ui-kit')}>
          <option value="core-ui">{mt('transferCoreUi')}</option><option value="ui-kit">{mt('transferUiKit')}</option>
        </select></label>
        <label>{mt('transferTitle')}<input value={transferTitle} onChange={event => setTransferTitle(event.target.value)} /></label>
        <button disabled={!selectedFiles.length || !transferTitle.trim()} onClick={() => void run(async () => {
          const result = await client.createTransferTask({ targetProjectId: project.id, targetRepository, title: transferTitle, files: selectedFiles, designConversationId: conversationId })
          setTransfer(result)
        })}>{mt('transferToSislexa')}</button>
      </fieldset>
      {transfer && <p role="status"><a href={transfer.taskUrl} target="_blank" rel="noreferrer">{mt('transferTaskLink')} {transfer.taskId}</a>{' · '}<a href={transfer.branchUrl} target="_blank" rel="noreferrer">{mt('transferBranchLink')} {transfer.branch}</a></p>}
    </>}
    {file && <div>
      <label>{file.path}<textarea value={file.content} disabled={busy} onChange={event => setFile({ ...file, content: event.target.value })} rows={18} /></label>
      <button disabled={busy || !dirty} onClick={() => void run(async () => {
        await client.write(project.id, file.path, file.content)
        setFile({ ...file, saved: file.content }); setSaved(file.path)
        setDesign(await client.projectDesign(project.id, subproject.path))
      })}>{mt('save')}</button>
      <button disabled={busy || !dirty} onClick={() => setFile({ ...file, content: file.saved })}>{mt('discardProjectEdit')}</button>
    </div>}
  </section>
}

function ProjectGit({ client, id }: { client: MakeProjectClient; id: string }) {
  const [status, setStatus] = useState<Extract<ProjectGitResult, { op: 'status' }> | null>(null)
  const [files, setFiles] = useState<string[]>([])
  const [message, setMessage] = useState('')
  const [branch, setBranch] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [result, setResult] = useState('')
  async function run(operation: ProjectGitOperation) {
    setBusy(true); setError(''); setResult('')
    try {
      const result = await client.projectGit(id, operation)
      setResult(result.op === 'commit' ? result.commit
        : result.op === 'branch' ? result.name
          : result.op === 'pull' || result.op === 'push' ? result.output : '')
      const next = operation.op === 'status' ? result : await client.projectGit(id, { op: 'status' })
      if (next.op === 'status') { setStatus(next); setFiles([]) }
    } catch (error) { setError(describeMakeError(error)) } finally { setBusy(false) }
  }
  return <section aria-label="Git">
    {error && <p role="alert">{error}</p>}
    {status && <p>{status.branch ?? 'HEAD'} · ↑{status.ahead} ↓{status.behind}</p>}
    <button disabled={busy} onClick={() => void run({ op: 'status' })}>{mt('gitStatus')}</button>
    <button disabled={busy} onClick={() => void run({ op: 'pull' })}>{mt('projectGitPull')}</button>
    <button disabled={busy} onClick={() => void run({ op: 'push' })}>{mt('projectGitPush')}</button>
    <ul>{status?.files.map(file => <li key={file.path}><label><input type="checkbox" checked={files.includes(file.path)} onChange={event => setFiles(event.target.checked ? [...files, file.path] : files.filter(path => path !== file.path))} />{file.index}{file.workingTree} {file.path}</label></li>)}</ul>
    <label>{mt('commitMessage')}<input value={message} onChange={event => setMessage(event.target.value)} /></label>
    <button disabled={busy || !message.trim() || !files.length} onClick={() => void run({ op: 'commit', message, files })}>{mt('projectGitCommit')}</button>
    <label>{mt('newProjectBranch')}<input value={branch} onChange={event => setBranch(event.target.value)} /></label>
    <button disabled={busy || !branch.trim()} onClick={() => void run({ op: 'branch', name: branch })}>{mt('createProjectBranch')}</button>
    {result && <pre role="status">{result}</pre>}
  </section>
}
