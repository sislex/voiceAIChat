import type { FastifyInstance } from 'fastify'
import { projectModeRpcSchemas, type MakeCore, RpcError } from '@voicechat/make-contracts'

/** The identity always comes from host authentication, never from the request body. */
export function registerProjectRoutes(app: FastifyInstance, core: MakeCore) {
  app.post<{ Body: { method?: string; args?: unknown[] } }>('/api/make/projects/operation', async (req, reply) => {
    const user = (req as unknown as { user?: { name: string } }).user?.name
    if (!user) return reply.code(401).send({ error: 'Authentication required' })
    const method = req.body?.method
    if (method !== 'listProjects' && method !== 'projectStructure' && method !== 'projectDesign' && method !== 'projectGit' && method !== 'createTransferTask' && method !== 'standPreview') return reply.code(400).send({ error: 'Invalid project operation' })
    const schema = projectModeRpcSchemas[method]
    const parsed = schema.args.safeParse([user, ...(Array.isArray(req.body.args) ? req.body.args : [])])
    if (!parsed.success) return reply.code(400).send({ error: 'Invalid project arguments' })
    try {
      const fn = core[method] as (...args: unknown[]) => Promise<unknown>
      if (typeof fn !== 'function') return reply.code(409).send({ error: 'Project mode is unavailable on this Core' })
      const result = schema.result.parse(await fn.apply(core, parsed.data))
      if (method === 'projectGit' && (result as { op: string }).op !== (req.body.args?.[1] as { op: string }).op) throw new Error('Mismatched project Git result')
      return result
    } catch (error) {
      if (error instanceof RpcError) return reply.code(error.status).send({ error: error.message })
      throw error
    }
  })
}
