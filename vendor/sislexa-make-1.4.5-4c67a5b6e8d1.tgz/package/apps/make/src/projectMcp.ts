import { z } from 'zod'
import type { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js'
import { RpcError } from '@voicechat/shared'
import {
  createTransferTaskSchema, projectPathSchema, projectGitOperationSchema,
  standPreviewOperationSchema, projectNotesSectionSchema, PROJECT_NOTES_MAX_BYTES, type MakeProjectCore,
} from '@voicechat/make-contracts'

/** Identity comes from the authenticated conversation endpoint, never tool arguments. */
export function registerProjectMcp(server: McpServer, core: MakeProjectCore, context: {
  userId: string; conversationId: string; readOnly: boolean
  standGit?: (operation: import("@voicechat/make-contracts").ProjectGitOperation) => Promise<import("@voicechat/make-contracts").ProjectGitResult>
}, smallNotes: {
  read(): Promise<{ content: string }>
  update(section: import('@voicechat/make-contracts').ProjectNotesSection, content: string): Promise<{ content: string }>
}) {
  const json = (value: unknown, isError = false) => ({
    content: [{ type: 'text' as const, text: JSON.stringify(value) }], ...(isError ? { isError: true } : {}),
  })
  const run = async (mutates: boolean, invoke: () => Promise<unknown>) => {
    try {
      if (mutates && context.readOnly) throw new RpcError(403, 'Project mutations are unavailable in Plan mode')
      return json(await invoke())
    } catch (error) {
      return json({ status: error instanceof RpcError ? error.status : 500,
        error: error instanceof Error ? error.message : String(error) }, true)
    }
  }
  const projectId = createTransferTaskSchema.shape.targetProjectId
  const subprojectPath = projectPathSchema
  server.registerTool('make_list_projects', {
    description: 'List projects visible to the conversation user.', inputSchema: z.object({}).strict(),
  }, () => run(false, () => core.listProjects(context.userId)))
  server.registerTool('make_project_structure', {
    description: 'Inventory subprojects in an authorized project working copy.', inputSchema: z.object({ projectId }).strict(),
  }, args => run(false, () => core.projectStructure(context.userId, args.projectId)))
  server.registerTool('make_project_design', {
    description: 'Inventory design tokens, themes and components without executing project code.',
    inputSchema: z.object({ projectId, subprojectPath }).strict(),
  }, args => run(false, () => core.projectDesign(context.userId, args.projectId, args.subprojectPath)))
  const target = z.union([
    z.object({}).strict(),
    z.object({ projectId, subprojectPath }).strict(),
  ])
  server.registerTool('make_notes_read', {
    description: 'Read durable project memory from make/notes.md. Omit the target for a small project.', inputSchema: target,
  }, args => run(false, () => 'projectId' in args
    ? core.projectNotesRead(context.userId, args.projectId, args.subprojectPath)
    : smallNotes.read()))
  server.registerTool('make_notes_update', {
    description: 'Replace one section of durable project memory. Record durable decisions after making them.',
    inputSchema: z.union([
      z.object({ section: projectNotesSectionSchema, content: z.string() }).strict(),
      z.object({ projectId, subprojectPath, section: projectNotesSectionSchema, content: z.string() }).strict(),
    ]),
  }, args => run(true, () => {
    if (new TextEncoder().encode(args.content).byteLength > PROJECT_NOTES_MAX_BYTES) throw new RpcError(413, 'Project notes exceed 32 KB')
    return 'projectId' in args
      ? core.projectNotesUpdate(context.userId, args.projectId, args.subprojectPath, args.section, args.content)
      : smallNotes.update(args.section, args.content)
  }))

  for (const operation of projectGitOperationSchema.options) {
    const op = operation.shape.op.value
    const { op: discriminator, ...shape } = operation.shape
    server.registerTool(`make_git_${op === 'branch' ? 'new_branch' : op}`, {
      description: `Project Git ${op}. Commit requires explicit files; pull is fast-forward only; push never forces.`,
      inputSchema: z.object({ ...shape, projectId: context.standGit ? projectId.optional() : projectId }).strict(),
    }, args => run(op !== 'status' && op !== 'branches', () => {
      const { projectId: target, ...input } = args
      const operation = projectGitOperationSchema.parse({ ...input, op })
      return context.standGit ? context.standGit(operation) : core.projectGit(context.userId, target!, operation)
    }))
  }
  for (const operation of standPreviewOperationSchema.options) {
    const op = operation.shape.op.value
    if (op === 'url') continue
    const { op: discriminator, ...shape } = operation.shape
    server.registerTool(`make_stand_${op}`, {
      description: op === 'start' ? 'Start or reuse a project stand. Readiness may require polling status.'
        : op === 'status' ? 'Read stand readiness and URL without starting it.'
          : `Turn live updates ${op === 'live_on' ? 'on' : 'off'} for an existing stand through Core. This does not stop the stand.`,
      inputSchema: z.object({ ...shape, projectId }).strict(),
    }, args => run(op !== 'status', () => {
      const { projectId: target, ...input } = args
      return core.standPreview(context.userId, target, standPreviewOperationSchema.parse({ ...input, op }))
    }))
  }
  server.registerTool('make_create_transfer_task', {
    description: 'Create a Sislexa task for core-ui or ui-kit with selected files from this design conversation. Does not copy files or push Git.',
    inputSchema: createTransferTaskSchema.omit({ designConversationId: true }),
  }, args => run(true, () => core.createTransferTask(context.userId, {
    ...args, designConversationId: context.conversationId,
  })))
}
