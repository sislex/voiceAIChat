import { RpcError, type MakeProjectCore } from '@voicechat/make-contracts'
import { makeStandOperationSchema, type MakeStandOperation } from '@voicechat/make-contracts/projectMode'
import type { MakeWorkspaces } from './workspace.js'
import { runStand } from './stand.js'

/** Stand batches are sequential: report completed paths on failure, never claim atomic rollback. */
export function standTools(core: MakeProjectCore, workspaces: MakeWorkspaces, user: string, conversation: string) {
  const run = async (operation: MakeStandOperation) => {
    const state = await runStand(core, workspaces, user, conversation)
    if (state.phase !== 'ready') throw new RpcError(409, state.error ?? 'operation_conflict')
    const result = await runStand(core, workspaces, user, conversation, operation)
    if (result.phase === 'failed') throw new RpcError(409, result.error ?? 'operation_conflict')
    return result
  }
  const read = async (path: string) => {
    const result = await run({ op: 'files', action: 'read', path })
    if (result.files?.action !== 'read') throw new Error('Missing stand file content')
    return result.files.content
  }
  return {
    run, read,
    async list(dir = '.'): Promise<Array<{ path: string; kind: 'file' | 'directory' }>> {
      const result = await run({ op: 'files', action: 'list', dir })
      if (result.files?.action !== 'list') throw new Error('Missing stand file list')
      return result.files.entries
    },
    async edit(path: string, find: string, replace: string, all: boolean) {
      if (!find) throw new Error('Find text must not be empty')
      const content = await read(path)
      const count = content.split(find).length - 1
      if (!count || !all && count !== 1) throw new Error('Find text must match exactly once, or use all=true')
      await run({ op: 'files', action: 'write', path, content: all ? content.split(find).join(replace) : content.replace(find, () => replace) })
      return { replaced: count }
    },
    async apply(files: Array<{ path: string; content: string }>, remove: string[]) {
      const operations = [...files.map(file => ({ op: 'files' as const, action: 'write' as const, ...file })),
        ...remove.map(path => ({ op: 'files' as const, action: 'delete' as const, path }))].map(operation => makeStandOperationSchema.parse(operation))
      const completed: string[] = []
      try {
        for (const operation of operations) {
          await run(operation)
          if ('path' in operation) completed.push(operation.path)
        }
      } catch (error) { throw new Error(`Stand batch failed; completed: ${JSON.stringify(completed)}. ${error instanceof Error ? error.message : String(error)}`) }
      return { completed }
    },
  }
}
