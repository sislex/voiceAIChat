// Short-lived read-only preview links for browser engines (Web Reader proxy, Playwright Chromium).
// The regular preview at /api/preview/make/:id/* needs the user's session or preview cookie and
// sits under /api/preview, which readers refuse to open for the current app. A preview link is an
// HMAC-signed { conversation, expiry } document served under the public publication family
// /p/<token>/, so a browser without cookies can open the working files of exactly one project.
// Stateless like task-scope tokens: no process memory, so it survives restarts until it expires.

import { createHmac, timingSafeEqual } from 'node:crypto'
import { MAKE_PUBLIC_PREFIX } from '@voicechat/make-contracts/make'

/** Preview-link lifetime: long enough for a check with screenshots, short enough to leak little. */
export const MAKE_PREVIEW_LINK_TTL_MS = 15 * 60_000
/** Publication tokens are UUID-like; this prefix cannot collide with them. */
export const MAKE_PREVIEW_LINK_PREFIX = 'pv.'
/**
 * Stable "current application" origin understood by mcp__browser__open in both engines: Web Reader
 * serves it through Core's project resource and Chromium through Core's /api/preview?url= proxy.
 */
export const MAKE_PREVIEW_LINK_ORIGIN = 'https://app.internal'

// Domain separation: the same MCP secret signs task-scope tokens, which must never verify here.
const sign = (secret: string, payload: string): string =>
  createHmac('sha256', secret).update(`make-preview-link\n${payload}`).digest('base64url')

export interface MakePreviewLink {
  conversationId: string
  expiresAt: number
}

export const isPreviewLinkToken = (token: string): boolean => token.startsWith(MAKE_PREVIEW_LINK_PREFIX)

export function signPreviewLink(secret: string, conversationId: string, opts: { ttlMs?: number; now?: number } = {}): { token: string; expiresAt: number } {
  const expiresAt = (opts.now ?? Date.now()) + (opts.ttlMs ?? MAKE_PREVIEW_LINK_TTL_MS)
  const payload = Buffer.from(JSON.stringify({ c: conversationId, e: expiresAt }), 'utf8').toString('base64url')
  return { token: `${MAKE_PREVIEW_LINK_PREFIX}${payload}.${sign(secret, payload)}`, expiresAt }
}

/** Return null for a foreign prefix, signature mismatch, corrupt document, or expired link. */
export function verifyPreviewLink(secret: string, token: string, now = Date.now()): MakePreviewLink | null {
  if (!secret || !isPreviewLinkToken(token)) return null
  const body = token.slice(MAKE_PREVIEW_LINK_PREFIX.length)
  const dot = body.lastIndexOf('.')
  if (dot <= 0) return null
  const payload = body.slice(0, dot)
  const expected = Buffer.from(sign(secret, payload))
  const actual = Buffer.from(body.slice(dot + 1))
  if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) return null
  let doc: { c?: unknown; e?: unknown }
  try { doc = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as { c?: unknown; e?: unknown } } catch { return null }
  if (typeof doc?.c !== 'string' || !doc.c || typeof doc.e !== 'number' || doc.e <= now) return null
  return { conversationId: doc.c, expiresAt: doc.e }
}

/** Absolute link to the project's entry page. */
export const previewLinkUrl = (token: string, origin = MAKE_PREVIEW_LINK_ORIGIN): string =>
  `${origin.replace(/\/+$/, '')}${MAKE_PUBLIC_PREFIX}${encodeURIComponent(token)}/index.html`
