import type { FastifyInstance } from 'fastify'
import { RpcError, type MakeCore } from '@voicechat/make-contracts'
import { makeStandOperationSchema, makeStandResultSchema, validateMakeStandResult, type MakeStandOperation, type MakeStandResult } from '@voicechat/make-contracts/projectMode'
import type { MakeWorkspaces } from './workspace.js'

const queues = new WeakMap<MakeWorkspaces, Map<string, Promise<unknown>>>()

/** Serialize binding transitions with file operations. Core owns cross-process conflicts. */
export async function runStand(core: Pick<MakeCore, 'makeStand'>, workspaces: MakeWorkspaces, user: string, conversation: string, input?: MakeStandOperation): Promise<MakeStandResult> {
  let queue = queues.get(workspaces)
  if (!queue) { queue = new Map(); queues.set(workspaces, queue) }
  const previous = queue.get(conversation) ?? Promise.resolve()
  const next = previous.catch(() => undefined).then(async () => {
    const binding = await workspaces.standBinding(conversation)
    const operation = makeStandOperationSchema.parse(input ?? (binding?.standId && binding.hostProjectId
      ? { op: 'status', standId: binding.standId, hostProjectId: binding.hostProjectId } : { op: 'options' }))
    if ((operation.op === 'files' || operation.op === 'git') && !binding) throw new RpcError(409, 'operation_conflict')
    if ((operation.op === 'files' || operation.op === 'git') && binding && binding.phase !== 'ready') throw new RpcError(409, binding.error ?? 'operation_conflict')
    if ((operation.op === 'status' || operation.op === 'detach') && (!binding || binding.standId !== operation.standId || binding.hostProjectId !== operation.hostProjectId)) throw new RpcError(409, 'operation_conflict')
    if ((operation.op === 'attach' || operation.op === 'create') && binding && (operation.op === 'create' || binding.standId !== operation.standId || binding.hostProjectId !== operation.hostProjectId)) throw new RpcError(409, 'operation_conflict')
    if (typeof core.makeStand !== 'function') throw new RpcError(409, 'Stand mode is unavailable on this Core')
    const result = makeStandResultSchema.parse(await core.makeStand(user, conversation, operation))
    validateMakeStandResult(operation, result)
    if ((operation.op === 'attach' || operation.op === 'status') && result.phase !== 'failed'
      && (result.standId !== operation.standId || result.hostProjectId !== operation.hostProjectId)) throw new Error('Mismatched Make stand identity')
    if ((operation.op === 'files' || operation.op === 'git') && result.phase !== 'failed'
      && (result.standId !== binding?.standId || result.hostProjectId !== binding?.hostProjectId)) throw new Error('Mismatched Make stand identity')
    if (operation.op === 'detach' && result.phase !== 'failed') await workspaces.setStandBinding(conversation, null)
    else if (['attach', 'create', 'status', 'git'].includes(operation.op) && result.standId && result.hostProjectId) await workspaces.setStandBinding(conversation, result)
    return result
  })
  queue.set(conversation, next)
  try { return await next } finally { if (queue.get(conversation) === next) queue.delete(conversation) }
}

export function registerStandRoutes(app: FastifyInstance, core: MakeCore, workspaces: MakeWorkspaces) {
  app.route<{ Params: { conversationId: string }; Body: unknown }>({
    // JSON escaping can expand a valid 2 MiB UTF-8 file up to sixfold.
    method: ['GET', 'POST'], url: '/api/make/:conversationId/stand', bodyLimit: 13 * 1024 * 1024,
    async handler(req, reply) {
      const user = (req as unknown as { user?: { name: string } }).user?.name
      if (!user) return reply.code(401).send({ error: 'Authentication required' })
      const id = req.params.conversationId
      const conversation = await core.conversation(user, id)
      if (!conversation || conversation.assistantKind !== 'make') return reply.code(404).send({ error: 'conversation not found' })
      if (!await core.conversationProject(id)) return reply.code(409).send({ error: 'component_not_in_stand' })
      const parsed = req.method === 'POST' ? makeStandOperationSchema.safeParse(req.body) : undefined
      if (parsed && !parsed.success) return reply.code(400).send({ error: 'Invalid stand operation' })
      try { return await runStand(core, workspaces, user, id, parsed?.data) }
      catch (error) {
        if (error instanceof RpcError) return reply.code(error.status).send({ error: error.message })
        throw error
      }
    },
  })
}
