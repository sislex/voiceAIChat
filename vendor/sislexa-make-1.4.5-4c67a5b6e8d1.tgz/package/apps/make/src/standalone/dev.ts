import { createServer } from 'vite'
import { fileURLToPath } from 'node:url'
import { dirname, resolve } from 'node:path'
import { mkdirSync } from 'node:fs'
import { buildMakeServer } from './server.js'
import { loadMakeStandaloneConfig } from './config.js'

// The runner supplies the port and the stand gateway. A stand data copy is optional: Make's data lives
// in the stand's Docker volume, which a host process cannot open, so without VC_MAKE_DATA_DIR the dev
// process uses an empty data directory inside its own worktree.
for (const name of ['PORT', 'SISLEXA_STAND_URL']) {
  if (!process.env[name]) throw new Error(`${name} is required for dev:component`)
}
if (!process.env.VC_MAKE_DATA_DIR) {
  process.env.VC_MAKE_DATA_DIR = resolve('.dev-data/make')
  mkdirSync(process.env.VC_MAKE_DATA_DIR, { recursive: true })
  console.warn(`[make] VC_MAKE_DATA_DIR is not set; using an empty ${process.env.VC_MAKE_DATA_DIR}`)
}
const stand = new URL(process.env.SISLEXA_STAND_URL!)
if (!['http:', 'https:'].includes(stand.protocol)) throw new Error('Invalid SISLEXA_STAND_URL')
const config = loadMakeStandaloneConfig({ ...process.env, VC_CORE_URL: stand.href })
if (!Number.isInteger(config.port) || config.port < 1 || config.port > 65535) throw new Error('Invalid PORT')
const { app } = await buildMakeServer({ config, coreUrlOverride: stand.href, logger: true })
const root = fileURLToPath(new URL('../../../../packages/make-app', import.meta.url))
const vite = await createServer({
  configFile: false, root, appType: 'custom',
  esbuild: { jsx: 'automatic' },
  resolve: { alias: [{ find: /^@shared\//, replacement: `${dirname(fileURLToPath(import.meta.resolve('@voicechat/shared')))}/` }] },
  define: { __APPLICATION_VERSION__: JSON.stringify('dev'), __APPLICATION_COMMIT__: 'null' },
  server: { middlewareMode: true, hmr: { server: app.server }, host: config.host },
})
app.addHook('onRequest', (request, reply, done) => {
  if (/^\/(?:api|internal|v1|mcp|p|s)(?:\/|$)/.test(request.url)) return done()
  vite.middlewares(request.raw, reply.raw, (error?: Error) => done(error))
})
app.get('/api/health', async () => ({ ok: true, service: 'make', mode: 'development' }))
// The dev stand runner probes SISLEXA_READINESS_PATH, which defaults to `/` when the stand does not
// pass the registry's readiness path; answer it like health so the override becomes ready.
app.get('/', async () => ({ ok: true, service: 'make', mode: 'development' }))
app.addHook('preClose', async () => { await vite.close() })
for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.once(signal, () => { void app.close().then(() => process.exit(0)) })
}
try { await app.listen({ host: config.host, port: config.port }) }
catch (error) { await app.close(); throw error }
