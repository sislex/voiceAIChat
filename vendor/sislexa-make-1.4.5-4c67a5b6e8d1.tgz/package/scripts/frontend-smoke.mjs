import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { readFileSync, mkdtempSync, rmSync, mkdirSync, cpSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { spawn } from 'node:child_process'
import { tmpdir } from 'node:os'
import { setTimeout as delay } from 'node:timers/promises'

test('owner build publishes integrity-addressed frontend files and versioned host requirements', () => {
  const dir = 'packages/make-app/dist'
  const manifest = JSON.parse(readFileSync(join(dir, 'manifest.json'), 'utf8'))
  const pkg = JSON.parse(readFileSync('packages/make-app/package.json', 'utf8'))
  assert.equal(manifest.applicationId, 'make-ui')
  assert.equal(manifest.version, pkg.version)
  assert.match(manifest.commit, /^[0-9a-f]{40}$/)
  const dockerfile = readFileSync('Dockerfile', 'utf8')
  const frontendStage = dockerfile.split(' AS frontend\n')[1]?.split(' AS api\n')[0]
  assert.ok(frontendStage?.includes(`VC_APPLICATION_API_VERSION=${manifest.apiVersion}`))
  const apiVersion = JSON.parse(readFileSync('apps/make/release.json', 'utf8')).apiVersion
  const apiStage = dockerfile.split(' AS api\n')[1]
  assert.ok(apiStage?.includes(`VC_APPLICATION_API_VERSION=${apiVersion}`))
  assert.ok(manifest.host)
  for (const asset of [manifest.entry, ...manifest.styles]) {
    assert.match(asset.path, /^[a-zA-Z0-9_.-]+$/)
    assert.equal(asset.integrity, 'sha384-' + createHash('sha384').update(readFileSync(join(dir, asset.path))).digest('base64'))
  }
})

test('the released Make frontend starts with external catalog paths', { timeout: 15000 }, async () => {
  const manifest = JSON.parse(readFileSync('packages/make-app/dist/manifest.json', 'utf8'))
  const port = process.env.DELIVERY_PORTS?.match(/\d+/g)?.[0]
  assert.ok(port, 'DELIVERY_PORTS must supply an allocated smoke-test port')
  const dataDir = mkdtempSync(join(process.env.DELIVERY_ATTEMPT_ROOT ? join(process.env.DELIVERY_ATTEMPT_ROOT, 'tmp') : tmpdir(), 'make-ui-release-'))
  mkdirSync(join(dataDir, 'scripts'))
  mkdirSync(join(dataDir, 'packages/make-app'), { recursive: true })
  cpSync('scripts/application-frontend-server.mjs', join(dataDir, 'scripts/application-frontend-server.mjs'))
  cpSync('packages/make-app/dist', join(dataDir, 'packages/make-app/dist'), { recursive: true })
  assert.equal(existsSync(join(dataDir, 'node_modules')), false)
  const child = spawn(process.execPath, ['scripts/application-frontend-server.mjs'], {
    cwd: dataDir,
    env: {
      ...process.env,
      HOST: '127.0.0.1',
      PORT: String(port),
      VC_DATA_DIR: join(dataDir, 'data'),
      VC_APPLICATION_ID: 'make-ui',
      VC_APPLICATION_VERSION: manifest.version,
      VC_APPLICATION_COMMIT: manifest.commit,
      VC_APPLICATION_API_VERSION: manifest.apiVersion,
      VC_APPLICATION_DATA_VERSION: '1.0.0'
    },
    stdio: ['ignore', 'ignore', 'pipe']
  })
  let stderr = ''
  child.stderr.setEncoding('utf8').on('data', (chunk) => { stderr += chunk })
  try {
    let response
    for (let attempt = 0; attempt < 60; attempt++) {
      if (child.exitCode !== null) throw new Error(stderr)
      try {
        response = await fetch(`http://127.0.0.1:${port}/v1/health`)
        break
      } catch {
        await delay(100)
      }
    }
    assert.ok(response, `Make UI did not start: ${stderr}`)
    assert.equal(response.status, 200)
    const health = await response.json()
    assert.equal(health.application.version, manifest.version)
    assert.equal(health.application.apiVersion, manifest.apiVersion)
    const asset = await fetch(`http://127.0.0.1:${port}/manifest.json`)
    assert.equal(asset.status, 200)
    assert.deepEqual(await asset.json(), manifest)
    assert.equal(asset.headers.get('cache-control'), 'no-store')
    const entry = await fetch(`http://127.0.0.1:${port}/${manifest.entry.path}`)
    assert.equal(entry.status, 200)
    assert.equal(entry.headers.get('cache-control'), 'public, max-age=31536000, immutable')
    assert.equal(entry.headers.get('access-control-allow-origin'), '*')
    assert.equal(entry.headers.get('x-content-type-options'), 'nosniff')
    assert.deepEqual(Buffer.from(await entry.arrayBuffer()), readFileSync(join(dataDir, 'packages/make-app/dist', manifest.entry.path)))
    assert.equal((await fetch(`http://127.0.0.1:${port}/${manifest.entry.path}`, { method: 'HEAD' })).status, 200)
    assert.equal((await fetch(`http://127.0.0.1:${port}/missing.js`)).status, 404)
    assert.equal((await fetch(`http://127.0.0.1:${port}/manifest.json`, { method: 'POST' })).status, 405)
  } finally {
    if (child.exitCode === null && child.signalCode === null) {
      const exited = new Promise((resolve) => child.once('exit', resolve))
      child.kill('SIGTERM')
      await exited
    }
    rmSync(dataDir, { recursive: true, force: true })
  }
})
