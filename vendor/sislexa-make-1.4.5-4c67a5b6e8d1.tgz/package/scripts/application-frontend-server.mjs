// Один контейнер раздаёт один неизменяемый frontend-артефакт.
import { createServer } from 'node:http'
import {
  createReadStream,
  readFileSync,
  statSync,
  mkdirSync,
  readdirSync,
  copyFileSync
} from 'node:fs'
import { join, resolve } from 'node:path'
// Mirror the pinned shared contract without runtime dependencies; guarded by parity tests.
export function applicationRuntimeMetadata(applicationId, env) {
    const version = env.VC_APPLICATION_VERSION, apiVersion = env.VC_APPLICATION_API_VERSION, dataVersion = env.VC_APPLICATION_DATA_VERSION;
    const commit = env.VC_APPLICATION_COMMIT ?? env.VC_RELEASE_COMMIT;
    return {
        applicationId,
        version: applicationVersion(version) ? version : null,
        apiVersion: applicationVersion(apiVersion) ? apiVersion : null,
        dataVersion: applicationVersion(dataVersion) ? dataVersion : null,
        commit: /^[a-f0-9]{40}$/.test(commit ?? '') ? commit : null
    };
}
export const APPLICATION_ID_RE = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
const VERSION = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/;
export function applicationVersion(value) {
    return (typeof value === 'string' &&
        value.length <= 64 &&
        VERSION.test(value) &&
        value.split('.').every((part) => Number.isSafeInteger(Number(part))));
}
export function compareApplicationVersions(left, right) {
    if (!applicationVersion(left) || !applicationVersion(right))
        throw new Error('Ожидалась версия x.y.z без ведущих нулей');
    const a = left.split('.').map(Number), b = right.split('.').map(Number);
    for (let index = 0; index < 3; index++)
        if (a[index] !== b[index])
            return a[index] < b[index] ? -1 : 1;
    return 0;
}
export function applicationVersionMatches(version, min, max) {
    return (applicationVersion(version) &&
        compareApplicationVersions(version, min) >= 0 &&
        compareApplicationVersions(version, max) < 0);
}
export const APPLICATION_HOST_API_VERSION = '1.1.0';
export function parseApplicationFrontendManifest(value, id, hostVersion = APPLICATION_HOST_API_VERSION) {
    if (!value || typeof value !== 'object')
        throw new Error('Не удалось прочитать манифест приложения');
    const m = value;
    const asset = (a) => Boolean(a &&
        typeof a.path === 'string' &&
        /^[a-zA-Z0-9_-][a-zA-Z0-9_./-]*$/.test(a.path) &&
        !a.path
            .split('/')
            .some((part) => part === '.' || part === '..' || !part) &&
        /^sha384-[A-Za-z0-9+/]{64}$/.test(a.integrity));
    if (m.schemaVersion !== 1 ||
        !APPLICATION_ID_RE.test(m.applicationId) ||
        m.applicationId !== id ||
        !applicationVersion(m.version) ||
        !applicationVersion(m.apiVersion) ||
        !((typeof m.commit === 'string' && /^[a-f0-9]{40}$/.test(m.commit)) ||
            (m.commit === null && m.development === true)) ||
        !m.host ||
        !applicationVersion(m.host.minVersion) ||
        !applicationVersion(m.host.maxVersionExclusive) ||
        !asset(m.entry) ||
        !m.entry.path.endsWith('.js') ||
        !Array.isArray(m.styles) ||
        m.styles.length > 20 ||
        m.styles.some((item) => !asset(item) || !item.path.endsWith('.css')) ||
        new Set([m.entry.path, ...m.styles.map((item) => item.path)]).size !==
            m.styles.length + 1)
        throw new Error('Неверный манифест приложения');
    if (!applicationVersionMatches(hostVersion, m.host.minVersion, m.host.maxVersionExclusive))
        throw new Error(`Для приложения нужна версия API оболочки ${m.host.minVersion}…<${m.host.maxVersionExclusive}; установлена ${hostVersion}`);
    return m;
}

const id = process.env.VC_APPLICATION_ID
if (id !== 'make-ui') throw new Error('Не задано frontend-приложение')
const directory = resolve(import.meta.dirname, '..', 'packages/make-app/dist')
const manifest = parseApplicationFrontendManifest(
  JSON.parse(readFileSync(join(directory, 'manifest.json'), 'utf8')),
  id
)
const runtime = applicationRuntimeMetadata(id, process.env)
if (
  runtime.version !== manifest.version ||
  runtime.commit !== manifest.commit ||
  runtime.apiVersion !== manifest.apiVersion
)
  throw new Error('Метаданные образа и интерфейса различаются')
// Старые hashed assets сохраняются на собственном томе: открытая вкладка может
// запросить worker или картинку после обновления контейнера. Текущий manifest
// всегда читается из образа, поэтому rollback не меняет его по содержимому тома.
const cache = process.env.VC_DATA_DIR
  ? join(process.env.VC_DATA_DIR, 'assets')
  : directory
function retain(from, to) {
  mkdirSync(to, { recursive: true })
  for (const item of readdirSync(from, { withFileTypes: true })) {
    if (item.name === 'manifest.json') continue
    const source = join(from, item.name),
      target = join(to, item.name)
    if (item.isDirectory()) retain(source, target)
    else if (item.isFile()) {
      try {
        if (!readFileSync(target).equals(readFileSync(source)))
          throw new Error('Коллизия имени immutable asset: ' + item.name)
      } catch (error) {
        if (error.code !== 'ENOENT') throw error
        copyFileSync(source, target)
      }
    }
  }
}
if (cache !== directory) retain(directory, cache)
const mime = {
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.woff2': 'font/woff2'
}
const server = createServer((req, res) => {
  res.setHeader('access-control-allow-origin', '*')
  res.setHeader('x-content-type-options', 'nosniff')
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    res.writeHead(405)
    res.end()
    return
  }
  const path = (req.url ?? '/').split('?')[0]
  if (path === '/v1/health') {
    res.setHeader('content-type', 'application/json')
    res.end(JSON.stringify({ ok: true, application: runtime }))
    return
  }
  const file = path.slice(1)
  if (
    !/^[a-zA-Z0-9_-][a-zA-Z0-9_./-]*$/.test(file) ||
    file.split('/').some((part) => part === '.' || part === '..' || !part)
  ) {
    res.writeHead(404)
    res.end()
    return
  }
  const location = join(file === 'manifest.json' ? directory : cache, file)
  try {
    const stat = statSync(location)
    if (!stat.isFile()) throw new Error()
    const extension = file.slice(file.lastIndexOf('.'))
    if (!mime[extension]) throw new Error()
    res.writeHead(200, {
      'content-type': mime[extension],
      'content-length': stat.size,
      'cache-control':
        file === 'manifest.json'
          ? 'no-store'
          : 'public, max-age=31536000, immutable'
    })
    if (req.method === 'HEAD') res.end()
    else
      createReadStream(location)
        .on('error', () => res.destroy())
        .pipe(res)
  } catch {
    res.writeHead(404)
    res.end()
  }
})
server.listen(Number(process.env.PORT ?? 8080), process.env.HOST ?? '0.0.0.0')
for (const signal of ['SIGINT', 'SIGTERM'])
  process.on(signal, () => server.close(() => process.exit(0)))
