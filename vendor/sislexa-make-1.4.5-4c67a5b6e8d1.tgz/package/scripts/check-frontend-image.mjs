import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'

const docker = (...args) => execFileSync('docker', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'inherit'] }).trim()
const commit = process.env.APPLICATION_COMMIT || execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
const version = JSON.parse(readFileSync('packages/make-app/package.json', 'utf8')).version
const tag = `make-frontend-budget:${process.pid}`
let built = false
try {
  docker('build', '--target', 'frontend', '--build-arg', `APPLICATION_VERSION=${version}`, '--build-arg', `APPLICATION_COMMIT=${commit}`, '-t', tag, '.')
  built = true
  const bytes = Number(docker('image', 'inspect', '--format', '{{.Size}}', tag))
  console.log(JSON.stringify({ target: 'frontend', bytes, budgetBytes: 200_000_000, commit }))
  if (!Number.isSafeInteger(bytes) || bytes <= 0 || bytes >= 200_000_000) throw new Error('Frontend image must be below 200 MB')
  docker('run', '--rm', '--network=none', '--entrypoint', 'sh', tag, '-c', 'test ! -e /app/node_modules && test -f /app/packages/make-app/dist/manifest.json && node --check /app/scripts/application-frontend-server.mjs')
} finally {
  if (built) docker('image', 'rm', '-f', tag)
}
