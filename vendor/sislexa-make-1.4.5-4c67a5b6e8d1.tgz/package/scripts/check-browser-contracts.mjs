import { readdirSync, readFileSync } from 'node:fs'
import { resolve, relative } from 'node:path'
import { pathToFileURL } from 'node:url'
import ts from 'typescript'

const packageName = '@voicechat/make-contracts'
// Reviewed browser entry points. Review new exports before adding them here.
const browserSubpaths = new Set([
  'projectMode', 'projectClient', 'localization', 'make', 'makeAutoImport',
  'makeDeploy', 'makeGit', 'makeLint', 'makeMockPrompt', 'makeNextSteps',
  'makePwa', 'makeReorder', 'makeSearch', 'makeSelection', 'makeStoriesGen',
  'makeTextEdit', 'makeTokens',
])

export function browserContractViolations(source, filename) {
  const file = ts.createSourceFile(filename, source, ts.ScriptTarget.Latest, true)
  const errors = []
  const check = node => {
    if (!node || !ts.isStringLiteralLike(node)) return
    const name = node.text
    if (name !== packageName && !name.startsWith(`${packageName}/`)) return
    if (browserSubpaths.has(name.slice(packageName.length + 1))) return
    const { line, character } = file.getLineAndCharacterOfPosition(node.getStart(file))
    errors.push(`${filename}:${line + 1}:${character + 1}: runtime import of ${name} is not browser-safe; use an approved subpath or import type`)
  }
  const visit = node => {
    if (ts.isImportDeclaration(node)) {
      const clause = node.importClause
      const bindings = clause?.namedBindings
      const typeOnly = clause?.isTypeOnly || (!clause?.name && bindings && ts.isNamedImports(bindings) && bindings.elements.length > 0 && bindings.elements.every(item => item.isTypeOnly))
      if (!typeOnly) check(node.moduleSpecifier)
    } else if (ts.isExportDeclaration(node)) {
      const clause = node.exportClause
      const typeOnly = node.isTypeOnly || (clause && ts.isNamedExports(clause) && clause.elements.length > 0 && clause.elements.every(item => item.isTypeOnly))
      if (!typeOnly) check(node.moduleSpecifier)
    } else if (ts.isCallExpression(node) && (node.expression.kind === ts.SyntaxKind.ImportKeyword || (ts.isIdentifier(node.expression) && node.expression.text === 'require'))) {
      check(node.arguments[0])
    } else if (ts.isImportEqualsDeclaration(node) && !node.isTypeOnly && ts.isExternalModuleReference(node.moduleReference)) {
      check(node.moduleReference.expression)
    }
    ts.forEachChild(node, visit)
  }
  visit(file)
  return errors
}

export function checkBrowserContracts(root = process.cwd()) {
  const errors = []
  const visit = directory => {
    for (const entry of readdirSync(directory, { withFileTypes: true })) {
      const path = resolve(directory, entry.name)
      if (entry.isDirectory()) {
        if (!['__tests__', 'node_modules'].includes(entry.name)) visit(path)
      } else if (/\.[cm]?[jt]sx?$/.test(entry.name) && !/\.(?:test|spec)\.[cm]?[jt]sx?$/.test(entry.name)) {
        errors.push(...browserContractViolations(readFileSync(path, 'utf8'), relative(root, path)))
      }
    }
  }
  visit(resolve(root, 'packages/make-app/src'))
  if (errors.length) throw new Error(errors.join('\n'))
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  try { checkBrowserContracts(); console.log('Browser contract imports: OK') }
  catch (error) { console.error(error.message); process.exitCode = 1 }
}
