import { readdirSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

// TypeScript remains executable runtime source for the API and pinned peers.
export function pruneRuntime(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isSymbolicLink()) continue
    if (entry.isDirectory()) {
      if (['test', 'tests', '__tests__', '__mocks__', 'coverage', 'storybook-static', '.storybook'].includes(entry.name)) rmSync(path, { recursive: true })
      else pruneRuntime(path)
    } else if (/\.(test|spec|stories)\.[cm]?[jt]sx?$|\.map$|\.tsbuildinfo$/.test(entry.name)) rmSync(path)
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) pruneRuntime(resolve(process.argv[2]))
