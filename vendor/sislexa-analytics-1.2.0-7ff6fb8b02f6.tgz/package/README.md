# Sislexa Analytics

Browser hosts can import `createAnalyticsBrowserClient` and
`BrowserActivityTracker`. The client owns the versioned Analytics route contract
while the host supplies its credential-aware `fetch` implementation and headers.

Analytics owns authenticated active-time intervals and account reporting
projections. Billing remains authoritative for spending, settlement and balances;
Analytics outages never permit or block paid execution.

## Activity contract

Clients emit visible, focused, active-module intervals of at most 35 seconds.
`interactionAt` must be no more than 60 seconds before the interval, and offline
replay is bounded to ten minutes. Payloads contain module, device/session IDs and
a monotonic sequence, never keystrokes, prompts or document content. Identity is
derived from the bearer token. Replays are idempotent; changed payloads using the
same sequence are rejected.

Reports deduplicate overlaps across tabs and devices. For each overlapping segment,
the most recent explicit interaction owns attention; receipt time and stable IDs
break ties. The primary total is therefore wall-clock active time rather than a
sum of every open tab. Raw intervals are retained for 90 days, and reports expose
when a requested period is partial.

`GET /api/analytics/account?from=<ms>&to=<ms>` combines the activity projection
with a delegated Billing 1.2 report. A Billing outage returns `usageStatus:
"unavailable"` and keeps activity available. `POST /api/analytics/activity`
accepts up to 120 intervals. Periods are half-open and capped at 366 days.

Run `npm ci`, then `npm run gate`. Managed startup requires
`SISLEXA_COMPONENT_CONFIG`; the sample config documents Identity and Billing
endpoints and secret-file references.

Portable browser and host types are exported from `@sislexa/analytics/contracts`;
that entry has no Fastify, SQLite or runtime imports.

`@sislexa/analytics/ui/AccountAnalytics` renders personal cost, raw-token and
estimated active-time totals with separate per-application shares. The browser
tracker is exported from `@sislexa/analytics/browser/activityTracker`; it emits
only bounded timing metadata and never input contents.
