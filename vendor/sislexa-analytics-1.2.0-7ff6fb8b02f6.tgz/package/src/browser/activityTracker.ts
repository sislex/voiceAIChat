import type { ActivityIngestionResult, ActivityIntervalInput } from '../contracts.js'

export interface ActivityClient { ingest(intervals: ActivityIntervalInput[]): Promise<ActivityIngestionResult> }

/** Browser attention tracker. It records timing metadata only; event contents,
 * pointer coordinates and key values never leave the browser. */
export class BrowserActivityTracker {
  private moduleId = 'shell'
  private lastInteraction = 0
  private intervalStart = 0
  private sequence = 0
  private timer: ReturnType<typeof setInterval> | undefined
  private readonly deviceId: string
  private readonly sessionId: string
  private listeners: Array<() => void> = []
  constructor(private client: ActivityClient, private now: () => number = Date.now) {
    this.deviceId = this.id('sislexa.analytics.device', localStorage)
    // A page lifetime is the replay boundary. Reusing a session after reload
    // would restart its sequence and turn new intervals into conflicts.
    this.sessionId = `web-${crypto.randomUUID()}`
  }
  private id(key: string, storage: Storage): string {
    const existing = storage.getItem(key)
    if (existing && /^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$/.test(existing)) return existing
    const value = `web-${crypto.randomUUID()}`; storage.setItem(key, value); return value
  }
  start(): void {
    if (this.timer) return
    const interact = () => this.interact()
    for (const [target, event] of [[window, 'focus'], [window, 'blur'], [document, 'visibilitychange'], [document, 'pointerdown'], [document, 'keydown'], [document, 'touchstart']] as const) {
      target.addEventListener(event, interact, { passive: true }); this.listeners.push(() => target.removeEventListener(event, interact))
    }
    this.interact(); this.timer = setInterval(() => this.flush(), 30_000)
  }
  stop(): void { this.flush(); if (this.timer) clearInterval(this.timer); this.timer = undefined; for (const off of this.listeners.splice(0)) off() }
  setModule(moduleId: string): void {
    if (!/^[A-Za-z0-9][A-Za-z0-9._:-]{0,255}$/.test(moduleId) || moduleId === this.moduleId) return
    this.flush(); this.moduleId = moduleId; this.interact()
  }
  private eligible(at: number): boolean { return document.visibilityState === 'visible' && document.hasFocus() && at - this.lastInteraction <= 60_000 }
  private interact(): void {
    const at = this.now()
    if (this.intervalStart && (!document.hasFocus() || document.visibilityState !== 'visible')) this.flush(at)
    this.lastInteraction = at
    if (document.hasFocus() && document.visibilityState === 'visible' && !this.intervalStart) this.intervalStart = at
  }
  flush(at = this.now()): void {
    const startedAt = this.intervalStart
    this.intervalStart = this.eligible(at) ? at : 0
    if (!startedAt || at <= startedAt) return
    const endedAt = Math.min(at, startedAt + 35_000, this.lastInteraction + 60_000)
    if (endedAt <= startedAt) return
    const interval: ActivityIntervalInput = { version: 1, deviceId: this.deviceId, sessionId: this.sessionId,
      sequence: ++this.sequence, moduleId: this.moduleId, startedAt, endedAt, interactionAt: this.lastInteraction }
    void this.client.ingest([interval]).catch(() => { /* Missing time stays a visible reporting gap; it never authorizes work. */ })
  }
}
