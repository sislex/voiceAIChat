import { ANALYTICS_ROUTES, type ActivityIngestionResult, type ActivityIntervalInput, type AnalyticsAccountReport } from '../contracts.js'

export interface AnalyticsBrowserClientOptions {
  baseUrl?: string
  fetchImpl?: typeof fetch
  headers?: () => HeadersInit
}

export interface AnalyticsBrowserClient {
  account(from: number, to: number): Promise<AnalyticsAccountReport>
  ingest(intervals: ActivityIntervalInput[]): Promise<ActivityIngestionResult>
}

/** Builds the browser transport while leaving session credentials under host control. */
export function createAnalyticsBrowserClient(options: AnalyticsBrowserClientOptions = {}): AnalyticsBrowserClient {
  const base = (options.baseUrl ?? '').replace(/\/$/, '')
  const request = options.fetchImpl ?? fetch
  async function json<T>(path: string, init?: RequestInit): Promise<T> {
    const response = await request(base + path, { ...init, headers: { ...options.headers?.(), ...init?.headers } })
    if (!response.ok) {
      const body = await response.json().catch(() => null) as { error?: unknown } | null
      throw Object.assign(new Error(typeof body?.error === 'string' ? body.error : `analytics_http_${response.status}`), { status: response.status })
    }
    return response.json() as Promise<T>
  }
  return {
    account: (from, to) => json(`${ANALYTICS_ROUTES.account}?${new URLSearchParams({ from: String(from), to: String(to) })}`),
    ingest: intervals => json(ANALYTICS_ROUTES.activity, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ intervals }) })
  }
}
