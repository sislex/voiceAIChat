import { createHash } from 'node:crypto'
import { createRequire } from 'node:module'
import { assertPlatformIdentifier } from '@sislexa/sdk'
import { ACTIVITY_IDLE_MS, ACTIVITY_RAW_RETENTION_MS, activityShareBasisPoints, validateActivityInterval,
  type ActivityIntervalInput, type ActivityPrincipal, type ActivityReport } from './activity.js'

const { DatabaseSync } = createRequire(import.meta.url)('node:sqlite') as typeof import('node:sqlite')
type Row = ActivityIntervalInput & { receivedAt: number }
const fingerprint = (value: unknown) => createHash('sha256').update(JSON.stringify(value)).digest('hex')

export class AnalyticsError extends Error { constructor(readonly statusCode: number, message: string) { super(message) } }

export class ActivityStore {
  private db: InstanceType<typeof DatabaseSync>
  constructor(filename: string, private now: () => number = Date.now) {
    this.db = new DatabaseSync(filename)
    this.db.exec(`PRAGMA busy_timeout = 10000; PRAGMA journal_mode = WAL;
      CREATE TABLE IF NOT EXISTS activity_intervals (
        environment TEXT NOT NULL, tenant TEXT NOT NULL, user_id TEXT NOT NULL,
        device TEXT NOT NULL, session TEXT NOT NULL, sequence INTEGER NOT NULL,
        module TEXT NOT NULL, started_at INTEGER NOT NULL, ended_at INTEGER NOT NULL,
        interaction_at INTEGER NOT NULL, received_at INTEGER NOT NULL, fingerprint TEXT NOT NULL,
        PRIMARY KEY(environment, user_id, device, session, sequence));
      CREATE INDEX IF NOT EXISTS activity_account_time ON activity_intervals(environment, tenant, user_id, started_at, ended_at);`)
  }
  close(): void { this.db.close() }
  private principal(value: ActivityPrincipal): ActivityPrincipal {
    for (const field of ['userId', 'tenantId', 'environmentId'] as const) assertPlatformIdentifier(value[field], field)
    return value
  }
  record(authority: ActivityPrincipal, input: ActivityIntervalInput): { accepted: boolean } {
    const principal = this.principal(authority), now = this.now(), interval = validateActivityInterval(input, now)
    const hash = fingerprint({ principal, interval })
    const existing = this.db.prepare(`SELECT fingerprint FROM activity_intervals
      WHERE environment = ? AND user_id = ? AND device = ? AND session = ? AND sequence = ?`)
      .get(principal.environmentId, principal.userId, interval.deviceId, interval.sessionId, interval.sequence) as { fingerprint: string } | undefined
    if (existing) {
      if (existing.fingerprint !== hash) throw new AnalyticsError(409, 'activity_replay_conflict')
      return { accepted: false }
    }
    this.db.prepare(`INSERT INTO activity_intervals VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(principal.environmentId, principal.tenantId, principal.userId, interval.deviceId, interval.sessionId, interval.sequence,
        interval.moduleId, interval.startedAt, interval.endedAt, interval.interactionAt, now, hash)
    this.db.prepare('DELETE FROM activity_intervals WHERE ended_at < ?').run(now - ACTIVITY_RAW_RETENTION_MS)
    return { accepted: true }
  }
  report(authority: ActivityPrincipal, from: number, to: number): ActivityReport {
    const principal = this.principal(authority)
    if (![from, to].every(value => Number.isSafeInteger(value) && value >= 0) || to <= from || to - from > 366 * 24 * 60 * 60_000) {
      throw new AnalyticsError(400, 'invalid_report_period')
    }
    const retentionFrom = Math.max(0, this.now() - ACTIVITY_RAW_RETENTION_MS)
    const rows = this.db.prepare(`SELECT device AS deviceId, session AS sessionId, sequence, module AS moduleId,
      started_at AS startedAt, ended_at AS endedAt, interaction_at AS interactionAt, received_at AS receivedAt
      FROM activity_intervals WHERE environment = ? AND tenant = ? AND user_id = ? AND ended_at > ? AND started_at < ?`)
      .all(principal.environmentId, principal.tenantId, principal.userId, from, to) as unknown as Row[]
    const intervals = rows.map(row => ({ ...row, startedAt: Math.max(from, row.startedAt),
      endedAt: Math.min(to, row.endedAt, row.interactionAt + ACTIVITY_IDLE_MS) })).filter(row => row.endedAt > row.startedAt)
    const boundaries = [...new Set(intervals.flatMap(row => [row.startedAt, row.endedAt]))].sort((a, b) => a - b)
    const modules = new Map<string, number>(), days = new Map<string, number>()
    let activeMs = 0
    for (let index = 0; index + 1 < boundaries.length; index++) {
      let cursor = boundaries[index]!, end = boundaries[index + 1]!
      const candidates = intervals.filter(row => row.startedAt <= cursor && row.endedAt >= end).sort((a, b) =>
        b.interactionAt - a.interactionAt || b.receivedAt - a.receivedAt ||
        `${a.deviceId}\0${a.sessionId}\0${a.sequence}`.localeCompare(`${b.deviceId}\0${b.sessionId}\0${b.sequence}`))
      const winner = candidates[0]
      if (!winner) continue
      while (cursor < end) {
        const nextDay = Date.parse(new Date(cursor).toISOString().slice(0, 10) + 'T00:00:00.000Z') + 24 * 60 * 60_000
        const segmentEnd = Math.min(end, nextDay), duration = segmentEnd - cursor
        activeMs += duration
        modules.set(winner.moduleId, (modules.get(winner.moduleId) ?? 0) + duration)
        const day = new Date(cursor).toISOString().slice(0, 10)
        days.set(day, (days.get(day) ?? 0) + duration)
        cursor = segmentEnd
      }
    }
    return { version: 1, from, to, activeMs, estimated: true, rawIntervals: rows.length, retentionFrom, partial: from < retentionFrom,
      modules: [...modules].map(([moduleId, value]) => ({ moduleId, activeMs: value, shareBasisPoints: activityShareBasisPoints(value, activeMs) }))
        .sort((a, b) => b.activeMs - a.activeMs || a.moduleId.localeCompare(b.moduleId)),
      days: [...days].map(([day, value]) => ({ day, activeMs: value })).sort((a, b) => a.day.localeCompare(b.day)) }
  }
}
