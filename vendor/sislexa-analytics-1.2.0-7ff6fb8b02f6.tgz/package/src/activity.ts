import { assertPlatformIdentifier } from '@sislexa/sdk'
import type { ActivityIntervalInput } from './contracts.js'
export type { ActivityIntervalInput, ActivityModule, ActivityDay, ActivityReport } from './contracts.js'

export const ACTIVITY_IDLE_MS = 60_000
export const ACTIVITY_MAX_INTERVAL_MS = 35_000
export const ACTIVITY_MAX_REPLAY_AGE_MS = 10 * 60_000
export const ACTIVITY_RAW_RETENTION_MS = 90 * 24 * 60 * 60_000

export interface ActivityPrincipal { userId: string; tenantId: string; environmentId: string }
export function validateActivityInterval(value: ActivityIntervalInput, now: number): ActivityIntervalInput {
  if (!value || value.version !== 1) throw Error('unsupported_activity_interval')
  for (const field of ['deviceId', 'sessionId', 'moduleId'] as const) assertPlatformIdentifier(value[field], field)
  for (const field of ['sequence', 'startedAt', 'endedAt', 'interactionAt'] as const) {
    if (!Number.isSafeInteger(value[field]) || value[field] < 0) throw Error('invalid_activity_interval')
  }
  if (value.endedAt <= value.startedAt || value.endedAt - value.startedAt > ACTIVITY_MAX_INTERVAL_MS ||
    value.interactionAt > value.endedAt || value.interactionAt < value.startedAt - ACTIVITY_IDLE_MS ||
    value.endedAt > now + 5_000 || value.startedAt < now - ACTIVITY_MAX_REPLAY_AGE_MS) throw Error('invalid_activity_interval')
  return Object.freeze({ ...value })
}

export function activityShareBasisPoints(value: number, total: number): number | null {
  return total === 0 ? null : Number((BigInt(value) * 10_000n + BigInt(total) / 2n) / BigInt(total))
}
