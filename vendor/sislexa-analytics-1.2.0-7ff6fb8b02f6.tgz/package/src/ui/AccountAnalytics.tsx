import { useEffect, useMemo, useState } from 'react'
import type { AnalyticsAccountReport } from '../contracts.js'

export interface AccountAnalyticsClient {
  account(from: number, to: number): Promise<AnalyticsAccountReport>
}

export interface AccountAnalyticsProps { client: AccountAnalyticsClient; now?: number }
type Period = 'month' | '7d' | '30d'
const moduleNames: Record<string, string> = { chat: 'Чат', make: 'Make', 'image-studio': 'Студия картинок',
  'web-reader': 'Web Reader', 'playwright-reader': 'Playwright Reader', projects: 'Проекты', machines: 'Машины' }
const periodStart = (period: Period, now: number) => period === 'month'
  ? new Date(new Date(now).getFullYear(), new Date(now).getMonth(), 1).getTime()
  : now - (period === '7d' ? 7 : 30) * 86_400_000
const percent = (basisPoints: number | null) => basisPoints === null ? '—' : `${(basisPoints / 100).toLocaleString('ru-RU', { maximumFractionDigits: 2 })}%`
const duration = (milliseconds: number) => milliseconds < 60_000 ? `${Math.round(milliseconds / 1000)} сек.`
  : milliseconds < 3_600_000 ? `${Math.round(milliseconds / 60_000)} мин.` : `${(milliseconds / 3_600_000).toLocaleString('ru-RU', { maximumFractionDigits: 1 })} ч.`

export function AccountAnalytics({ client, now = Date.now() }: AccountAnalyticsProps): JSX.Element {
  const [period, setPeriod] = useState<Period>('month'), [report, setReport] = useState<AnalyticsAccountReport | null>(null)
  const [error, setError] = useState<string | null>(null), [reload, setReload] = useState(0)
  const range = useMemo(() => ({ from: periodStart(period, now), to: now }), [period, now])
  useEffect(() => {
    let active = true; setError(null); setReport(null)
    void client.account(range.from, range.to).then(value => { if (active) setReport(value) })
      .catch(reason => { if (active) setError(reason instanceof Error ? reason.message : String(reason)) })
    return () => { active = false }
  }, [client, range.from, range.to, reload])
  return <section className="analytics-account" aria-labelledby="analytics-title" data-testid="account-analytics">
    <header className="analytics-account__head"><div><h2 id="analytics-title">Расходы и активность</h2><p>Доли по приложениям за выбранный период</p></div>
      <div className="analytics-account__period" aria-label="Период отчёта">{([['month', 'Месяц'], ['7d', '7 дней'], ['30d', '30 дней']] as const).map(([id, label]) =>
        <button key={id} type="button" aria-pressed={period === id} onClick={() => setPeriod(id)}>{label}</button>)}</div></header>
    {!report && !error && <p role="status">Загружаем аналитику…</p>}
    {error && <div role="alert"><p>Не удалось загрузить аналитику: {error}</p><button type="button" onClick={() => setReload(value => value + 1)}>Повторить</button></div>}
    {report && <>
      {report.usageStatus === 'unavailable' && <p className="analytics-account__notice" role="status">Данные о расходах временно недоступны. Активное время показано отдельно.</p>}
      {report.activity.partial && <p className="analytics-account__notice">Начало периода выходит за срок хранения подробной активности.</p>}
      <div className="analytics-account__totals">
        <article><span>Списано</span><strong>{report.usage ? `$${(report.usage.actualMicroUsd / 1_000_000).toFixed(2)}` : '—'}</strong></article>
        <article><span>Токены</span><strong>{report.usage ? report.usage.totalTokens.toLocaleString('ru-RU') : '—'}</strong></article>
        <article><span>Активное время</span><strong>{duration(report.activity.activeMs)}</strong></article>
      </div>
      <div className="analytics-account__columns">
        <div><h3>Расходы по приложениям</h3>{!report.usage?.modules.length ? <p>За период расходов нет.</p> : <ol>{report.usage.modules.map(item => <li key={item.moduleId}>
          <span>{moduleNames[item.moduleId] ?? item.moduleId}</span><strong>{percent(item.costShareBasisPoints)}</strong><small>${(item.actualMicroUsd / 1_000_000).toFixed(2)} · {item.totalTokens.toLocaleString('ru-RU')} токенов</small>
        </li>)}</ol>}</div>
        <div><h3>Активное время по приложениям</h3>{!report.activity.modules.length ? <p>За период активность не зафиксирована.</p> : <ol>{report.activity.modules.map(item => <li key={item.moduleId}>
          <span>{moduleNames[item.moduleId] ?? item.moduleId}</span><strong>{percent(item.shareBasisPoints)}</strong><small>{duration(item.activeMs)}</small>
        </li>)}</ol>}</div>
      </div>
      <p className="analytics-account__footnote">Активное время — оценка по видимой вкладке, фокусу и последнему взаимодействию. Фоновая работа моделей в него не входит.</p>
    </>}
  </section>
}
