import type { BillingUsageReport } from '@sislexa/sdk'

export const ANALYTICS_ROUTES = {
  account: '/api/analytics/account',
  activity: '/api/analytics/activity'
} as const

export interface ActivityIntervalInput {
  version: 1
  deviceId: string
  sessionId: string
  sequence: number
  moduleId: string
  startedAt: number
  endedAt: number
  interactionAt: number
}

export interface ActivityModule { moduleId: string; activeMs: number; shareBasisPoints: number | null }
export interface ActivityDay { day: string; activeMs: number }
export interface ActivityReport {
  version: 1
  from: number
  to: number
  activeMs: number
  estimated: true
  rawIntervals: number
  modules: ActivityModule[]
  days: ActivityDay[]
  retentionFrom: number
  partial: boolean
}

export interface AnalyticsAccountReport {
  version: 1
  generatedAt: number
  usageStatus: 'current' | 'unavailable'
  usage: BillingUsageReport | null
  activity: ActivityReport
}

export interface ActivityIngestionResult { accepted: number; duplicates: number }
