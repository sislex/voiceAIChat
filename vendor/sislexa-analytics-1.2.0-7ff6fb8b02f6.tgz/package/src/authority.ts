import type { ComponentRuntime } from '@sislexa/component-runtime'
import { AnalyticsError } from './store.js'
import type { ActivityPrincipal } from './activity.js'

export interface AnalyticsAuthority {
  environmentId: string
  verifyUser(authorization: string): Promise<ActivityPrincipal>
}

export function componentAuthority(runtime: ComponentRuntime): AnalyticsAuthority {
  const identity = runtime.dependency('identity', { timeoutMs: 10_000 })
  return { environmentId: runtime.config.environmentId, async verifyUser(authorization) {
    const response = await identity.fetchImpl(identity.url + '/v1/identity/verify', { method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ request: { method: 'GET', url: '/api/me', headers: { authorization } } }) })
    if (!response.ok) throw new AnalyticsError(503, 'identity_unavailable')
    const verdict = await response.json() as { ok?: boolean; status?: number; user?: { mustChangePassword?: boolean; account?: { userId?: string; tenantId?: string } } }
    const account = verdict.user?.account
    if (verdict.ok !== true) throw new AnalyticsError(verdict.status === 403 ? 403 : 401, 'user_access_denied')
    if (verdict.user?.mustChangePassword) throw new AnalyticsError(403, 'password_change_required')
    if (typeof account?.userId !== 'string' || !account.userId || typeof account.tenantId !== 'string' || !account.tenantId) throw new AnalyticsError(503, 'stable_identity_required')
    return { userId: account.userId, tenantId: account.tenantId, environmentId: runtime.config.environmentId }
  } }
}
