import Fastify, { type FastifyRequest } from 'fastify'
import type { BillingUsageReport } from '@sislexa/sdk'
import type { AnalyticsAuthority } from './authority.js'
import type { ActivityIntervalInput, ActivityPrincipal } from './activity.js'
import { ANALYTICS_ROUTES } from './contracts.js'
import { ActivityStore, AnalyticsError } from './store.js'

export interface BillingReports { report(authorization: string, principal: ActivityPrincipal, from: number, to: number): Promise<BillingUsageReport> }

const bearer = (request: FastifyRequest): string => {
  const value = request.headers.authorization
  if (!value || !/^Bearer \S+$/.test(value) || value.length > 8192) throw new AnalyticsError(401, 'user_session_required')
  return value
}
const queryTime = (value: string): number => {
  const result = Number(value)
  if (!Number.isSafeInteger(result)) throw new AnalyticsError(400, 'invalid_report_period')
  return result
}

export function buildAnalyticsServer(store: ActivityStore, authority: AnalyticsAuthority, billing: BillingReports) {
  const app = Fastify({ logger: false, bodyLimit: 65_536, ajv: { customOptions: { removeAdditional: false, coerceTypes: false, useDefaults: false } } })
  app.addHook('onSend', async (_request, reply) => { reply.header('cache-control', 'no-store') })
  app.setErrorHandler((error, _request, reply) => {
    const status = error instanceof AnalyticsError ? error.statusCode : error && typeof error === 'object' && 'validation' in error ? 400 : 503
    return reply.code(status).send({ error: error instanceof AnalyticsError ? error.message : status === 400 ? 'invalid_request' : 'analytics_unavailable' })
  })
  app.get('/api/health', async () => ({ ok: true, applicationId: 'analytics' }))
  app.post<{ Body: { intervals: ActivityIntervalInput[] } }>(ANALYTICS_ROUTES.activity, {
    schema: { body: { type: 'object', additionalProperties: false, required: ['intervals'], properties: {
      intervals: { type: 'array', minItems: 1, maxItems: 120, items: { type: 'object', additionalProperties: false,
        required: ['version', 'deviceId', 'sessionId', 'sequence', 'moduleId', 'startedAt', 'endedAt', 'interactionAt'], properties: {
          version: { type: 'integer', const: 1 }, deviceId: { type: 'string', minLength: 1, maxLength: 256 },
          sessionId: { type: 'string', minLength: 1, maxLength: 256 }, sequence: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
          moduleId: { type: 'string', minLength: 1, maxLength: 256 }, startedAt: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
          endedAt: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER }, interactionAt: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER }
        } }
      }
    } } }
  }, async request => {
    const principal = await authority.verifyUser(bearer(request))
    let accepted = 0, duplicates = 0
    for (const interval of request.body.intervals) store.record(principal, interval).accepted ? accepted++ : duplicates++
    return { accepted, duplicates }
  })
  app.get<{ Querystring: { from: string; to: string } }>(ANALYTICS_ROUTES.account, {
    schema: { querystring: { type: 'object', additionalProperties: false, required: ['from', 'to'], properties: {
      from: { type: 'string', pattern: '^[0-9]{1,16}$' }, to: { type: 'string', pattern: '^[0-9]{1,16}$' }
    } } }
  }, async request => {
    const authorization = bearer(request), principal = await authority.verifyUser(authorization)
    const from = queryTime(request.query.from), to = queryTime(request.query.to)
    const activity = store.report(principal, from, to)
    try {
      const usage = await billing.report(authorization, principal, from, to)
      return { version: 1, generatedAt: Date.now(), usageStatus: 'current', usage, activity }
    } catch {
      return { version: 1, generatedAt: Date.now(), usageStatus: 'unavailable', usage: null, activity }
    }
  })
  return app
}
