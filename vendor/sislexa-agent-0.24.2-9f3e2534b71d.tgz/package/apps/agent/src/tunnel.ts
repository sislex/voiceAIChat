import { execFileSync } from 'node:child_process'
import { networkInterfaces } from 'node:os'
import type { Socket } from 'node:net'
import type { AgentToServer } from '@sislexa/agent-contracts'

export const TUNNEL_HIGH_WATER_MARK = 4 * 1024 * 1024

export function tunnelBindHost(
  host: 'loopback' | 'docker-host' | 'vpn' = 'loopback',
  platform: string = process.platform,
  interfaces = networkInterfaces(),
  readBridge: () => string | null = dockerBridgeFromIp
): string {
  if (host === 'loopback') return '127.0.0.1'
  if (host === 'vpn') {
    // tailscale0 on Linux, utunN on macOS: select by the Tailscale CGNAT range 100.64.0.0/10.
    const address = Object.values(interfaces)
      .flatMap((addresses) => addresses ?? [])
      .find((candidate) => candidate.family === 'IPv4' && !candidate.internal && isTailscaleIPv4(candidate.address))
    if (!address) throw new Error('Tailscale IPv4 address is unavailable')
    return address.address
  }
  if (host !== 'docker-host') throw new Error('Invalid tunnel host')
  if (platform !== 'linux') return '127.0.0.1'
  // The host-side address of Docker's default bridge is its gateway.
  const gateway = interfaces.docker0?.find((address) => address.family === 'IPv4' && !address.internal)
  if (gateway) return gateway.address
  // Node omits interfaces that are not running: docker0 without attached containers
  // has no carrier and is missing above although its address is configured.
  const configured = readBridge()
  if (!configured) throw new Error('Docker bridge gateway is unavailable')
  return configured
}

export function dockerBridgeFromIp(): string | null {
  try {
    const output = execFileSync('ip', ['-4', '-o', 'addr', 'show', 'dev', 'docker0'], { encoding: 'utf8', timeout: 5_000, stdio: ['ignore', 'pipe', 'ignore'] })
    return parseBridgeAddress(output)
  } catch {
    return null
  }
}

export function parseBridgeAddress(output: string): string | null {
  const match = /\binet (\d{1,3}(?:\.\d{1,3}){3})\//.exec(output)
  return match ? match[1]! : null
}

export type TunnelSend = (message: AgentToServer, done?: () => void) => void

export function attachTunnelFlow(socket: Socket, tunnelId: string, connectionId: string, send: TunnelSend) {
  let remotePaused = false
  let pendingBytes = 0
  let writePaused = false
  const updateReads = () => {
    if (socket.destroyed) return
    if (remotePaused || pendingBytes >= TUNNEL_HIGH_WATER_MARK) socket.pause()
    else socket.resume()
  }
  socket.on('data', (data: Buffer) => {
    pendingBytes += data.length
    updateReads()
    send({ t: 'tunnel.data', tunnelId, connectionId, data: data.toString('base64') }, () => {
      pendingBytes -= data.length
      updateReads()
    })
  })
  socket.on('drain', () => {
    if (!writePaused) return
    writePaused = false
    send({ t: 'tunnel.resume', tunnelId, connectionId })
  })
  return {
    pause(paused: boolean) { remotePaused = paused; updateReads() },
    write(data: Buffer) {
      if (socket.destroyed) return
      socket.write(data)
      if (!writePaused && socket.writableLength >= TUNNEL_HIGH_WATER_MARK) {
        writePaused = true
        send({ t: 'tunnel.pause', tunnelId, connectionId })
      }
    }
  }
}

/** 100.64.0.0/10, the carrier-grade NAT range Tailscale assigns. */
export function isTailscaleIPv4(address: string): boolean {
  const [a, b] = address.split('.').map(Number)
  return a === 100 && b >= 64 && b <= 127
}
