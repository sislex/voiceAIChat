import { createServer } from 'node:net'

/** Reserved Delivery Control port when the sandbox provides one, else the local default. */
export function preferredTestPort(offset: number): number {
  return Number(process.env.DELIVERY_PORTS?.match(/\d+/)?.[0] ?? 23000) + offset
}

/**
 * The preferred port when it is free, otherwise an ephemeral one: a dev stand on the
 * same machine may occupy the reserved range (gateway and live dev servers from 23000).
 */
export async function freeTestPort(offset: number): Promise<number> {
  const preferred = preferredTestPort(offset)
  const probe = (port: number): Promise<number> => new Promise((resolve, reject) => {
    const server = createServer()
    server.once('error', reject)
    server.listen(port, '127.0.0.1', () => {
      const address = server.address()
      const bound = typeof address === 'object' && address ? address.port : port
      server.close(() => resolve(bound))
    })
  })
  try { return await probe(preferred) } catch { return probe(0) }
}
