import { createHash, randomUUID } from 'node:crypto'
import { spawn, type ChildProcess } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:net'
import { dirname, join, resolve } from 'node:path'
import { createInterface } from 'node:readline'
import { resolveShellInfo } from './platform.js'
import type {
  DevProcessRecoveryEvent, DevProcessErrorCode, DevProcessLogsRequest, DevProcessLogsResult, DevProcessMethod,
  DevProcessRequestMessage, DevProcessResponseMessage, DevProcessStartRequest,
  DevGatewayHealth, DevProcessStartResult, DevProcessStatus, DevProcessStopRequest, DevProcessStopResult
} from '@sislexa/agent-contracts'

const MAX_LOG_LINES = 1_000
const DEFAULT_LOG_LINES = 200
const DEFAULT_READINESS_TIMEOUT_MS = 120_000
const mirrorOperations = new Map<string, Promise<unknown>>()
const MIRROR_REFS = ['+refs/heads/*:refs/heads/*', '+refs/tags/*:refs/tags/*']

type LogLine = DevProcessLogsResult['lines'][number]
interface PersistedProcess {
  ready?: boolean
  marker?: string
  standId: string
  component: DevProcessStatus['component']
  command: [string, ...string[]]
  env: Record<string, string>
  ports?: number[]
  repository: string
  sha: string
  port: number
  pid: number
  worktree: string
  startedAt: number
  url: string
}
interface RuntimeProcess extends PersistedProcess {
  child?: ChildProcess
  state: DevProcessStatus['state']
  exitCode?: number | null
  lines: LogLine[]
  secrets: string[]
}
interface SavedGateway { standId: string; pid: number; marker: string; port: number }
interface Registry { version: 1; processes: PersistedProcess[]; gateways?: SavedGateway[] }
interface GatewayRuntime {
  sha?: string
  standId: string
  port: number
  url: string
  worktree: string
  child?: ChildProcess
  state: DevGatewayHealth['state']
  restartAttempts: number
  restartTimer?: ReturnType<typeof setTimeout>
  stopping: boolean
}

/** Read-only CLI view; never expose persisted command environments. */
export async function devProcessStatusText(dataDir: string, ready: (url: string) => Promise<boolean> = async url => {
  try { return (await fetch(url, { signal: AbortSignal.timeout(1_000) })).ok } catch { return false }
}): Promise<string> {
  let registry: Registry
  try { registry = JSON.parse(readFileSync(join(dataDir, 'dev-processes', 'registry.json'), 'utf8')) as Registry }
  catch { return 'No dev stands registered.' }
  const gatewayHealth = new Map<string, boolean>()
  for (const item of registry.processes ?? []) {
    if (gatewayHealth.has(item.standId)) continue
    const port = gatewayPortFor(item.standId, registry.processes)
    gatewayHealth.set(item.standId, port !== undefined && await ready(`http://127.0.0.1:${port}/__gateway/health`))
  }
  return (registry.processes ?? []).map(item => `${item.standId}\t${item.component}\t${item.port}\t${alive(item.pid) ? 'running' : 'offline'}\t${item.url}\tgateway:${gatewayHealth.get(item.standId) ? 'healthy' : 'unhealthy'}`).join('\n') || 'No dev stands registered.'
}

function gatewayPortFor(standId: string, processes: PersistedProcess[]): number | undefined {
  const stand = processes.filter(item => item.standId === standId)
  const used = new Set(stand.map(item => item.port))
  return stand.flatMap(item => item.ports ?? []).find(port => !used.has(port))
}

export class DevProcessError extends Error {
  constructor(readonly code: DevProcessErrorCode, message: string) { super(message) }
}

export interface DevProcessManagerOptions {
  dataDir: string
  readinessTimeoutMs?: number
  readinessPollMs?: number
  gatewayRestartBaseMs?: number
  now?: () => number
  onLog?: (line: string) => void
  onRecovery?: (event: DevProcessRecoveryEvent) => void
  ports?: number[]
  spawn?: typeof spawnTool
  isAlive?: (pid: number) => boolean
  processMarker?: (pid: number) => Promise<string | undefined>
  portAvailable?: (port: number) => Promise<void>
  ready?: (url: string) => Promise<boolean>
  terminate?: (pid: number) => Promise<void>
}

const keyOf = (target: { standId: string; component: string }): string => `${target.standId}\0${target.component}`
const digest = (value: string): string => createHash('sha256').update(value).digest('hex')
const alive = (pid: number): boolean => {
  try { process.kill(pid, 0); return true } catch { return false }
}
const safeMessage = (error: unknown): string => {
  const code = error instanceof DevProcessError ? undefined : (error as NodeJS.ErrnoException | undefined)?.code
  return `${code ? code + ': ' : ''}${error instanceof Error ? error.message : String(error)}`
}

/** Node emits the spawn outcome asynchronously, including errors without a PID. */
async function spawned(child: ChildProcess): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    child.once('error', reject)
    child.once('spawn', () => child.pid ? resolve() : reject(new Error('Process did not receive a PID')))
  })
}

function quoteShell(value: string): string {
  if (process.platform === 'win32') return `"${value.replace(/"/g, '""')}"`
  return `'${value.replace(/'/g, `'"'"'`)}'`
}

/** Spawn through the platform shell so command discovery matches exec and PTY. */
function spawnTool(command: string, args: string[], options: { cwd?: string; env?: NodeJS.ProcessEnv; detached?: boolean } = {}): ChildProcess {
  const shell = resolveShellInfo().shell
  const line = [command, ...args].map(quoteShell).join(' ')
  const shellArgs = process.platform === 'win32' && /cmd(?:\.exe)?$/i.test(shell) ? ['/d', '/s', '/c', line] : ['-c', line]
  return spawn(shell, shellArgs, {
    cwd: options.cwd,
    env: options.env,
    detached: options.detached,
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true
  })
}

async function runTool(command: string, args: string[], cwd?: string): Promise<string> {
  return await new Promise<string>((resolvePromise, reject) => {
    const child = spawnTool(command, args, { cwd })
    let stdout = ''
    let stderr = ''
    child.stdout?.on('data', chunk => { stdout += String(chunk) })
    child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-4_096) })
    child.on('error', reject)
    child.on('close', code => code === 0 ? resolvePromise(stdout) : reject(new Error(`${command} exited ${code}: ${stderr.trim()}`)))
  })
}

/** Fail closed when a process environment cannot be inspected. Never log it. */
export async function readProcessMarker(pid: number, platform = process.platform, deps = {
  read: (path: string) => readFileSync(path, 'utf8'),
  command: (command: string, args: string[]) => runTool(command, args)
}): Promise<string | undefined> {
  if (!Number.isSafeInteger(pid) || pid <= 1) return undefined
  try {
    if (platform === 'linux') return deps.read(`/proc/${pid}/environ`).split('\0')
      .find(value => value.startsWith('SISLEXA_DEV_PROCESS_MARKER='))?.slice('SISLEXA_DEV_PROCESS_MARKER='.length)
    if (platform === 'darwin') {
      const output = await deps.command('ps', ['-E', '-ww', '-o', 'command=', '-p', String(pid)])
      return /(?:^|\s)SISLEXA_DEV_PROCESS_MARKER=([^\s]+)(?=\s|$)/.exec(output)?.[1]
    }
  } catch { /* Unreadable and vanished processes are not owned. */ }
  return undefined
}

export class DevProcessManager {
  private readonly root: string
  private readonly mirrors: string
  private readonly worktrees: string
  private readonly caches: string
  private readonly registryPath: string
  private readonly processes = new Map<string, RuntimeProcess>()
  private readonly reservedPorts = new Set<number>()
  private readonly operations = new Map<string, Promise<unknown>>()
  private readonly gateways = new Map<string, GatewayRuntime>()
  private readonly savedGateways = new Map<string, SavedGateway>()
  private shuttingDown = false
  private readonly now: () => number
  private readonly readinessTimeoutMs: number
  private readonly readinessPollMs: number

  readonly recovery: Promise<void>
  private readonly options: DevProcessManagerOptions

  constructor(options: DevProcessManagerOptions) {
    this.options = options
    this.root = resolve(options.dataDir, 'dev-processes')
    this.mirrors = join(this.root, 'mirrors')
    this.worktrees = join(this.root, 'worktrees')
    this.caches = join(this.root, 'dependency-cache')
    this.registryPath = join(this.root, 'registry.json')
    this.now = options.now ?? Date.now
    this.readinessTimeoutMs = options.readinessTimeoutMs ?? DEFAULT_READINESS_TIMEOUT_MS
    this.readinessPollMs = options.readinessPollMs ?? 250
    mkdirSync(this.root, { recursive: true, mode: 0o700 })
    this.recovery = Promise.resolve().then(() => this.recover())
  }

  async handle(message: DevProcessRequestMessage): Promise<DevProcessResponseMessage> {
    await this.recovery
    const method = message.t as DevProcessMethod
    try {
      let result: DevProcessStartResult | DevProcessStopResult | DevProcessStatus | DevProcessLogsResult
      if (message.t === 'devProcess.start') result = await this.exclusive(message, () => this.start(message))
      else if (message.t === 'devProcess.stop') result = await this.exclusive(message, () => this.stop(message))
      else if (message.t === 'devProcess.status') result = await this.status(message)
      else result = this.logs(message)
      return { t: `${method}.result`, requestId: message.requestId, result } as DevProcessResponseMessage
    } catch (error) {
      if (message.t === 'devProcess.start' || message.t === 'devProcess.stop') {
        this.log('failure', message.t === 'devProcess.start' ? message : this.processes.get(keyOf(message)) ?? message, safeMessage(error))
      }
      const code = error instanceof DevProcessError ? error.code : 'internal_error'
      return { t: 'devProcess.error', requestId: message.requestId, method, code,
        message: error instanceof DevProcessError ? error.message
          : this.redact(safeMessage(error), message.t === 'devProcess.start' ? Object.values(message.env) : []) }
    }
  }

  /** Shutdown preserves children and their registry for the next agent. */
  leaveRunning(): void {
    this.shuttingDown = true
    for (const gateway of this.gateways.values()) {
      gateway.stopping = true
      if (gateway.restartTimer) clearTimeout(gateway.restartTimer)
    }
    this.options.onLog?.('devProcess shutdown: leaving children running; startup recovery will replace owned process groups')
  }

  async close(): Promise<void> {
    await this.recovery
    for (const gateway of this.gateways.values()) await this.stopGateway(gateway)
    await Promise.all([...this.processes.values()].map(processInfo => this.stop(processInfo)))
  }

  private async exclusive<T>(target: { standId: string; component: string }, operation: () => Promise<T>): Promise<T> {
    const key = keyOf(target)
    if (this.operations.has(key)) throw new DevProcessError('operation_conflict', 'Another operation is in progress')
    const running = operation()
    this.operations.set(key, running)
    try { return await running } finally { this.operations.delete(key) }
  }

  private validateStart(request: DevProcessStartRequest): void {
    if (!/^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/.test(request.standId) || !/^[a-f0-9]{40}$/.test(request.sha) || !request.repository || !Number.isInteger(request.port) || request.port < 1 || request.port > 65535) {
      throw new DevProcessError('invalid_request', 'Invalid repository, SHA, or port')
    }
    try {
      const url = new URL(request.repository)
      if (url.username || url.password) throw new DevProcessError('invalid_request', 'Repository URL must not contain credentials')
    } catch (error) {
      if (error instanceof DevProcessError) throw error
      // Local paths and Git scp-style URLs are valid and use the configured credential helper.
    }
    if (!Array.isArray(request.command) || !request.command.length || request.command.some(value => typeof value !== 'string' || !value || value.includes('\0'))) {
      throw new DevProcessError('invalid_request', 'Invalid command')
    }
    if (request.ports && (!Array.isArray(request.ports) || request.ports.some(port => !Number.isInteger(port) || port < 1 || port > 65535))) {
      throw new DevProcessError('invalid_request', 'Invalid stand port allocation')
    }
    for (const [name, value] of Object.entries(request.env)) {
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || value.includes('\0')) throw new DevProcessError('invalid_request', 'Invalid environment')
    }
  }

  private async start(request: DevProcessStartRequest): Promise<DevProcessStartResult> {
    if (this.reservedPorts.has(request.port)) throw new DevProcessError('port_unavailable', `Port ${request.port} has a pending start`)
    this.reservedPorts.add(request.port)
    try { return await this.startCandidate(request) }
    finally { this.reservedPorts.delete(request.port) }
  }

  private async startCandidate(request: DevProcessStartRequest): Promise<DevProcessStartResult> {
    this.log('start', request, 'requested')
    this.validateStart(request)
    const existing = this.processes.get(keyOf(request))
    if (existing?.state === 'ready' && existing.sha === request.sha && existing.repository === request.repository && existing.port === request.port && this.isAlive(existing.pid)) {
      return this.toStartResult(existing)
    }
    for (const runtime of [...this.processes.values()]) {
      if (runtime.port === request.port && runtime.standId !== request.standId && runtime.child) {
        if (this.operations.has(keyOf(runtime))) throw new DevProcessError('port_unavailable', `Port ${request.port} is in use by an active operation`)
        this.log('stop', runtime, 'stale port owner')
        await this.stop(runtime)
      }
    }
    for (const gateway of [...this.gateways.values()]) {
      if (gateway.port === request.port && gateway.standId !== request.standId) {
        const owners = [...this.processes.values()].filter(item => item.standId === gateway.standId)
        if (owners.some(item => this.operations.has(keyOf(item)))) throw new DevProcessError('port_unavailable', `Port ${request.port} has an active owner`)
        await this.stopGateway(gateway)
        for (const owner of owners) await this.stop(owner)
      }
    }
    await this.assertPortFree(request.port)

    const repoHash = digest(request.repository)
    const mirror = join(this.mirrors, `${repoHash}.git`)
    const worktree = join(this.worktrees, digest(`${request.standId}\0${request.component}\0${request.sha}\0${randomUUID()}`))
    mkdirSync(dirname(mirror), { recursive: true, mode: 0o700 })
    mkdirSync(dirname(worktree), { recursive: true, mode: 0o700 })
    await this.checkout(request, mirror, worktree)

    try { await this.installDependencies(worktree) }
    catch (error) { await this.removeWorktree(mirror, worktree); throw new DevProcessError('dependency_failed', this.redact(safeMessage(error), Object.values(request.env))) }

    try { return await this.launch(request, worktree, existing) }
    catch (error) { await this.removeWorktree(mirror, worktree); throw error }
  }

  private async checkout(request: DevProcessStartRequest, mirror: string, worktree: string): Promise<void> {
    await this.withMirror(mirror, async () => {
      try {
        const cloned = !existsSync(mirror)
        if (cloned) {
          // Avoid copying unrelated objects when the remote is a local path.
          await runTool('git', ['clone', '--bare', '--no-local', '--', request.repository, mirror])
        }
        // Migrate the wildcard refspec left by older --mirror clones.
        await runTool('git', ['-C', mirror, 'config', '--replace-all', 'remote.origin.fetch', MIRROR_REFS[0]])
        await runTool('git', ['-C', mirror, 'config', '--add', 'remote.origin.fetch', MIRROR_REFS[1]])
        await runTool('git', ['-C', mirror, 'config', 'remote.origin.mirror', 'false'])
        if (!cloned) await runTool('git', ['-C', mirror, 'fetch', '--prune', 'origin', ...MIRROR_REFS])
        const pullRefs = await runTool('git', ['-C', mirror, 'for-each-ref', '--format=%(refname)', 'refs/pull/'])
        for (const ref of pullRefs.trim().split('\n').filter(Boolean)) {
          await runTool('git', ['-C', mirror, 'update-ref', '-d', ref])
        }
      } catch (error) {
        throw new DevProcessError('repository_unavailable', `Repository checkout failed: ${this.redact(safeMessage(error), Object.values(request.env))}`)
      }
      try {
        try { await runTool('git', ['-C', mirror, 'cat-file', '-e', `${request.sha}^{commit}`]) }
        catch {
          await runTool('git', ['-C', mirror, 'fetch', '--no-tags', 'origin', request.sha])
          await runTool('git', ['-C', mirror, 'cat-file', '-e', `${request.sha}^{commit}`])
        }
      }
      catch { throw new DevProcessError('ref_not_found', 'Requested commit is unavailable') }
      rmSync(worktree, { recursive: true, force: true })
      try { await runTool('git', ['-C', mirror, 'worktree', 'prune']); await runTool('git', ['-C', mirror, 'worktree', 'add', '--detach', worktree, request.sha]) }
      catch (error) { throw new DevProcessError('ref_not_found', `Commit checkout failed: ${this.redact(safeMessage(error), Object.values(request.env))}`) }
    })
  }

  private async launch(request: DevProcessStartRequest, worktree: string, replaced?: RuntimeProcess): Promise<DevProcessStartResult> {
    const startedAt = this.now()
    const url = `http://127.0.0.1:${request.port}`
    const marker = randomUUID()
    const secrets = [...Object.values(request.env).filter(value => value.length > 0), marker]
    const env = { ...process.env, ...request.env, PORT: String(request.port), SISLEXA_DEV_PROCESS_MARKER: marker }
    let child: ChildProcess
    try { child = (this.options.spawn ?? spawnTool)(request.command[0], request.command.slice(1), { cwd: worktree, env, detached: process.platform !== 'win32' }) }
    catch (error) { throw new DevProcessError('process_start_failed', this.redact(safeMessage(error), secrets)) }
    try { await spawned(child) }
    catch (error) { throw new DevProcessError('process_start_failed', this.redact(safeMessage(error), secrets)) }
    const runtime: RuntimeProcess = { ...request, ports: request.ports ?? this.options.ports, marker, pid: child.pid!, worktree, startedAt, url, child, ready: false, state: 'starting', lines: [], secrets }
    if (!replaced) this.processes.set(keyOf(request), runtime)
    this.capture(runtime, 'stdout', child.stdout)
    this.capture(runtime, 'stderr', child.stderr)
    child.on('exit', code => {
      runtime.exitCode = code
      if (runtime.state !== 'stopping') {
        runtime.state = 'failed'
        this.log('failure', runtime, `Process exited: ${code}`)
      }
      this.persist()
    })
    child.on('error', error => {
      this.append(runtime, 'stderr', safeMessage(error))
      this.log('failure', runtime, safeMessage(error))
    })
    try {
      this.persist()
      await this.waitForReadiness(runtime, request.env.SISLEXA_READINESS_PATH ?? '/')
      runtime.state = 'ready'
      this.processes.set(keyOf(request), runtime)
      this.persist()
      try {
        await this.refreshGateway(request.standId)
      } catch (error) {
        if (replaced) {
          this.processes.set(keyOf(request), replaced)
          this.persist()
          this.writeManifest(request.standId)
        }
        throw error
      }
      runtime.ready = true
      this.persist()
      if (replaced) await this.retireReplaced(replaced)
      this.log('start', runtime, 'ready')
      return this.toStartResult(runtime)
    } catch (error) {
      if (this.processes.get(keyOf(request)) === runtime && replaced) {
        this.processes.set(keyOf(request), replaced)
        this.persist()
        this.writeManifest(request.standId)
      }
      runtime.state = 'stopping'
      if (this.processes.get(keyOf(request)) === runtime) this.processes.delete(keyOf(request))
      this.persist()
      this.writeManifest(request.standId)
      this.log('stop', runtime, 'failed start cleanup')
      await this.terminate(runtime.pid)
      runtime.state = 'failed'
      await this.removeWorktree(join(this.mirrors, `${digest(runtime.repository)}.git`), worktree)
      if (error instanceof DevProcessError) throw error
      throw new DevProcessError('readiness_timeout', safeMessage(error))
    }
  }

  private async retireReplaced(runtime: RuntimeProcess): Promise<void> {
    this.log('stop', runtime, 'requested or replaced')
    runtime.state = 'stopping'
    if (runtime.child) await this.terminate(runtime.pid)
    const mirror = join(this.mirrors, `${digest(runtime.repository)}.git`)
    await this.removeWorktree(mirror, runtime.worktree)
  }

  private async installDependencies(worktree: string): Promise<void> {
    const lock = ['package-lock.json', 'npm-shrinkwrap.json'].map(name => join(worktree, name)).find(existsSync)
    if (!lock) throw new Error('No supported npm lockfile found')
    const cache = join(this.caches, digest(readFileSync(lock).toString('base64')))
    mkdirSync(cache, { recursive: true, mode: 0o700 })
    await runTool('npm', ['ci', '--cache', cache, '--prefer-offline', '--no-audit', '--no-fund'], worktree)
  }

  private async waitForReadiness(runtime: RuntimeProcess, path: string): Promise<void> {
    if (!path.startsWith('/') || path.startsWith('//')) throw new DevProcessError('invalid_request', 'Readiness path must start with /')
    const deadline = this.now() + this.readinessTimeoutMs
    while (this.now() < deadline) {
      if (!this.isAlive(runtime.pid) || runtime.state === 'failed') throw new DevProcessError('process_start_failed', 'Process exited before readiness')
      try {
        if (this.options.ready) {
          if (await this.options.ready(`${runtime.url}${path}`)) return
        } else {
          const response = await fetch(`${runtime.url}${path}`, { signal: AbortSignal.timeout(Math.max(100, this.readinessPollMs)) })
          if (response.ok) return
        }
      } catch { /* server is not ready yet */ }
      await new Promise(resolvePromise => setTimeout(resolvePromise, this.readinessPollMs))
    }
    throw new DevProcessError('readiness_timeout', 'Readiness check timed out')
  }

  private async status(target: { standId: string; component: DevProcessStatus['component'] }): Promise<DevProcessStatus> {
    const processInfo = this.processes.get(keyOf(target))
    if (!processInfo) return { ...target, state: 'stopped', gateway: await this.gatewayHealth(target.standId) }
    if (!this.isAlive(processInfo.pid) && processInfo.state !== 'stopping') processInfo.state = 'failed'
    return { standId: processInfo.standId, component: processInfo.component, state: processInfo.state,
      repository: processInfo.repository, sha: processInfo.sha, url: processInfo.url,
      startedAt: processInfo.startedAt, exitCode: processInfo.exitCode, gateway: await this.gatewayHealth(target.standId) }
  }

  private logs(request: DevProcessLogsRequest): DevProcessLogsResult {
    const limit = request.limit ?? DEFAULT_LOG_LINES
    if (!Number.isInteger(limit) || limit < 1 || limit > MAX_LOG_LINES) throw new DevProcessError('invalid_request', 'Log limit must be 1..1000')
    const all = this.processes.get(keyOf(request))?.lines ?? []
    return { standId: request.standId, component: request.component, lines: all.slice(-limit), truncated: all.length > limit }
  }

  private async stop(target: DevProcessStopRequest | RuntimeProcess): Promise<DevProcessStopResult> {
    const runtime = this.processes.get(keyOf(target))
    if (!runtime) {
      this.log('stop', target, 'already stopped')
      return { standId: target.standId, component: target.component, state: 'stopped' }
    }
    this.log('stop', runtime, 'requested or replaced')
    runtime.state = 'stopping'
    if (runtime.child) await this.terminate(runtime.pid)
    const mirror = join(this.mirrors, `${digest(runtime.repository)}.git`)
    await this.removeWorktree(mirror, runtime.worktree)
    this.processes.delete(keyOf(runtime))
    this.persist()
    await this.refreshGateway(target.standId)
    return { standId: target.standId, component: target.component, state: 'stopped' }
  }

  private async terminate(pid: number): Promise<void> {
    if (this.options.terminate) return this.options.terminate(pid)
    const target = process.platform === 'win32' ? pid : -pid
    if (!alive(target)) return
    try { process.kill(process.platform === 'win32' ? pid : -pid, 'SIGTERM') } catch { try { process.kill(pid, 'SIGTERM') } catch { return } }
    const deadline = this.now() + 10_000
    while (alive(target) && this.now() < deadline) await new Promise(resolvePromise => setTimeout(resolvePromise, 50))
    if (alive(target)) {
      if (process.platform === 'win32') { try { await runTool('taskkill', ['/pid', String(pid), '/t', '/f']) } catch { /* gone */ } }
      else { try { process.kill(-pid, 'SIGKILL') } catch { try { process.kill(pid, 'SIGKILL') } catch { /* gone */ } } }
    }
  }

  private async withMirror<T>(mirror: string, operation: () => Promise<T>): Promise<T> {
    const previous = mirrorOperations.get(mirror) ?? Promise.resolve()
    const running = previous.catch(() => {}).then(operation)
    mirrorOperations.set(mirror, running)
    try { return await running }
    finally { if (mirrorOperations.get(mirror) === running) mirrorOperations.delete(mirror) }
  }

  private async removeWorktree(mirror: string, worktree: string): Promise<void> {
    await this.withMirror(mirror, async () => {
      if (existsSync(mirror)) {
        try { await runTool('git', ['-C', mirror, 'worktree', 'remove', '--force', worktree]) } catch { rmSync(worktree, { recursive: true, force: true }) }
        try { await runTool('git', ['-C', mirror, 'worktree', 'prune']) } catch { /* best effort */ }
      } else rmSync(worktree, { recursive: true, force: true })
    })
  }

  private async assertPortFree(port: number): Promise<void> {
    if (this.options.portAvailable) {
      try { return await this.options.portAvailable(port) }
      catch (error) {
        if ((error instanceof DevProcessError && error.code === 'port_unavailable') || (error as NodeJS.ErrnoException).code === 'EADDRINUSE') {
          throw new DevProcessError('port_unavailable', `Port ${port} is unavailable`)
        }
        throw error
      }
    }
    await new Promise<void>((resolvePromise, reject) => {
      const server = createServer()
      server.once('error', (error: NodeJS.ErrnoException) => reject(error.code === 'EADDRINUSE' ? new DevProcessError('port_unavailable', `Port ${port} is unavailable`) : error))
      server.listen(port, '127.0.0.1', () => server.close(() => resolvePromise()))
    })
  }

  private capture(runtime: RuntimeProcess, stream: LogLine['stream'], source: NodeJS.ReadableStream | null): void {
    if (!source) return
    createInterface({ input: source }).on('line', text => this.append(runtime, stream, text))
  }
  private append(runtime: RuntimeProcess, stream: LogLine['stream'], text: string): void {
    runtime.lines.push({ stream, text: this.redact(text, runtime.secrets), at: this.now() })
    if (runtime.lines.length > MAX_LOG_LINES) runtime.lines.splice(0, runtime.lines.length - MAX_LOG_LINES)
  }
  private redact(text: string, secrets: string[]): string {
    let filtered = text.replace(/(https?:\/\/)[^/@\s]+@/gi, '$1***@')
    for (const secret of secrets.filter(value => value.length > 0).sort((a, b) => b.length - a.length)) filtered = filtered.split(secret).join('[REDACTED]')
    return filtered
  }
  private toStartResult(runtime: RuntimeProcess): DevProcessStartResult {
    return { standId: runtime.standId, component: runtime.component, state: 'ready', repository: runtime.repository,
      sha: runtime.sha, url: runtime.url, startedAt: runtime.startedAt,
      gateway: this.gateways.has(runtime.standId) ? { state: this.gateways.get(runtime.standId)!.state, url: this.gateways.get(runtime.standId)!.url } : { state: 'stopped' } }
  }

  private isAlive(pid: number): boolean { return (this.options.isAlive ?? alive)(pid) }

  private async replaceOwned(saved: { pid: number; marker?: string; port: number }): Promise<boolean> {
    if (!Number.isSafeInteger(saved.pid) || saved.pid <= 1 || !saved.marker || !this.isAlive(saved.pid)) return false
    let marker: string | undefined
    try { marker = await (this.options.processMarker ?? readProcessMarker)(saved.pid) }
    catch { return false }
    if (marker !== saved.marker) return false
    await this.terminate(saved.pid)
    const deadline = this.now() + 10_000
    for (;;) {
      try { await this.assertPortFree(saved.port); return true }
      catch (error) {
        if (!(error instanceof DevProcessError) || error.code !== 'port_unavailable' || this.now() >= deadline) throw error
      }
      await new Promise(resolvePromise => setTimeout(resolvePromise, this.readinessPollMs))
    }
  }

  private async recover(): Promise<void> {
    let registry: Registry
    try { registry = JSON.parse(readFileSync(this.registryPath, 'utf8')) as Registry }
    catch { return }
    if (!registry || registry.version !== 1 || !Array.isArray(registry.processes)) return
    // Legacy entries have no proof of readiness and must not be recovered.
    registry.processes = registry.processes.filter(saved => saved.ready === true)
    // Load all desired entries before persisting any individual recovery.
    for (const saved of registry.processes ?? []) {
      this.processes.set(keyOf(saved), { ...saved, state: 'starting', lines: [], secrets: Object.values(saved.env ?? {}) })
    }
    for (const saved of registry.gateways ?? []) this.savedGateways.set(saved.standId, saved)
    this.persist()
    for (const saved of registry.processes ?? []) {
      let url = saved.url
      try {
        if (!existsSync(saved.worktree)) throw new DevProcessError('repository_unavailable', 'Recovery worktree is missing')
        if (!saved.command || !saved.env) throw new DevProcessError('invalid_request', 'Registry entry has no launch configuration')
        this.validateStart(saved)
        const replaced = await this.replaceOwned(saved)
        let port = saved.port
        try { await this.assertPortFree(port) }
        catch (error) {
          if (replaced || !(error instanceof DevProcessError) || error.code !== 'port_unavailable') throw error
          let available: number | undefined
          for (const candidate of saved.ports ?? this.options.ports ?? []) {
            if (candidate === port || !Number.isInteger(candidate) || candidate < 1 || candidate > 65535) continue
            try { await this.assertPortFree(candidate); available = candidate; break }
            catch (candidateError) {
              if (!(candidateError instanceof DevProcessError) || candidateError.code !== 'port_unavailable') throw candidateError
            }
          }
          if (available === undefined) throw error
          port = available
        }
        url = `http://127.0.0.1:${port}`
        await this.launch({ ...saved, port }, saved.worktree)
        this.options.onRecovery?.({ t: 'devProcess.recovered', standId: saved.standId, component: saved.component, url, recovery: replaced ? 'replaced' : 'relaunched',
          gateway: await this.gatewayHealth(saved.standId) })
      } catch (error) {
        const runtime = this.processes.get(keyOf(saved))
        if (runtime) this.processes.delete(keyOf(saved))
        await this.removeWorktree(join(this.mirrors, `${digest(saved.repository)}.git`), saved.worktree)
        this.log('failure', saved, safeMessage(error))
        this.persist()
        this.options.onRecovery?.({ t: 'devProcess.recoveryFailed', standId: saved.standId, component: saved.component, url,
          message: this.redact(safeMessage(error), Object.values(saved.env ?? {}).filter(value => value.length >= 4)) })
      }
    }
  }
  private persist(): void {
    const registry: Registry = { version: 1, processes: [...this.processes.values()].map(item => ({
      ready: item.ready === true, standId: item.standId, component: item.component, repository: item.repository, sha: item.sha,
      command: item.command, env: item.env, ports: item.ports ?? this.options.ports,
      port: item.port, pid: item.pid, marker: item.marker, worktree: item.worktree, startedAt: item.startedAt, url: item.url
    })), gateways: [...this.savedGateways.values()] }
    mkdirSync(dirname(this.registryPath), { recursive: true, mode: 0o700 })
    const temporary = `${this.registryPath}.${randomUUID()}.tmp`
    writeFileSync(temporary, JSON.stringify(registry), { mode: 0o600 })
    renameSync(temporary, this.registryPath)
  }

  private manifestPath(standId: string): string { return join(dirname(this.root), 'dev', 'stands', standId, 'manifest.json') }

  private writeManifest(standId: string): void {
    const components = [...this.processes.values()].filter(item => item.standId === standId && item.state !== 'stopping')
      .map(item => ({ id: item.component, url: item.url, sha: item.sha,
        devBuildId: `0.0.0-dev.${item.sha.slice(0, 12)}`, startedAt: item.startedAt }))
    const path = this.manifestPath(standId)
    mkdirSync(dirname(path), { recursive: true, mode: 0o700 })
    const temporary = `${path}.${randomUUID()}.tmp`
    writeFileSync(temporary, JSON.stringify({ version: 1, standId, components }), { mode: 0o600 })
    renameSync(temporary, path)
  }

  private async refreshGateway(standId: string): Promise<void> {
    this.writeManifest(standId)
    const core = this.processes.get(keyOf({ standId, component: 'core' }))
    const standProcesses = [...this.processes.values()].filter(item => item.standId === standId)
    const port = gatewayPortFor(standId, standProcesses)
    const current = this.gateways.get(standId)
    if (!core || core.env.SISLEXA_STAND_MANIFEST || core.state !== 'ready' || port === undefined) {
      if (current) await this.stopGateway(current)
      return
    }
    if (current && current.port === port && current.worktree === core.worktree && current.state !== 'stopped') return
    if (current) await this.stopGateway(current)
    const saved = this.savedGateways.get(standId)
    if (saved) await this.replaceOwned(saved)
    await this.assertPortFree(port)
    await this.launchGateway(standId, core.worktree, port)
  }

  private async launchGateway(standId: string, worktree: string, port: number, attempt = 0): Promise<void> {
    const url = `http://127.0.0.1:${port}`
    const runtime: GatewayRuntime = { sha: this.processes.get(keyOf({ standId, component: 'core' }))?.sha, standId, worktree, port, url, state: 'starting', restartAttempts: attempt, stopping: false }
    this.gateways.set(standId, runtime)
    this.log('start', { ...runtime, component: 'gateway' }, 'gateway requested')
    let child: ChildProcess
    const marker = randomUUID()
    try {
      child = (this.options.spawn ?? spawnTool)('node', ['scripts/dev-gateway.mjs', '--manifest', this.manifestPath(standId), '--port', String(port)], {
        cwd: worktree, env: { ...process.env, SISLEXA_DEV_PROCESS_MARKER: marker, PORT: String(port), SISLEXA_STAND_MANIFEST: this.manifestPath(standId) }, detached: process.platform !== 'win32'
      })
      await spawned(child)
    } catch (error) {
      runtime.state = 'unhealthy'
      this.gateways.delete(standId)
      const message = this.redact(safeMessage(error), Object.values(process.env).filter((value): value is string => !!value && value.length >= 4))
      this.log('failure', { ...runtime, component: 'gateway' }, message)
      throw new DevProcessError('process_start_failed', `Gateway did not start: ${message}`)
    }
    runtime.child = child
    if (!child.pid) { runtime.state = 'unhealthy'; throw new DevProcessError('process_start_failed', 'Gateway did not start') }
    this.savedGateways.set(standId, { standId, port, pid: child.pid, marker })
    this.persist()
    child.on('error', error => {
      runtime.state = 'unhealthy'
      this.log('failure', { ...runtime, component: 'gateway' }, safeMessage(error))
    })
    child.on('exit', () => {
      if (runtime.stopping || this.gateways.get(standId) !== runtime) return
      runtime.state = 'unhealthy'
      this.log('failure', { ...runtime, component: 'gateway' }, 'gateway exited')
      this.scheduleGatewayRestart(runtime)
    })
    try {
      await this.waitForGateway(runtime)
      runtime.state = 'healthy'
      this.log('start', { ...runtime, component: 'gateway', sha: this.processes.get(keyOf({ standId, component: 'core' }))?.sha }, 'gateway ready')
    } catch (error) {
      runtime.state = 'unhealthy'
      this.log('failure', { ...runtime, component: 'gateway' }, safeMessage(error))
      await this.stopGateway(runtime)
      throw error
    }
  }

  private scheduleGatewayRestart(runtime: GatewayRuntime): void {
    if (this.shuttingDown) return
    const delay = Math.min((this.options.gatewayRestartBaseMs ?? 1_000) * (2 ** runtime.restartAttempts), 30_000)
    runtime.restartTimer = setTimeout(() => {
      if (runtime.stopping || this.gateways.get(runtime.standId) !== runtime) return
      void this.launchGateway(runtime.standId, runtime.worktree, runtime.port, runtime.restartAttempts + 1).catch(() => {
        const retry: GatewayRuntime = { standId: runtime.standId, worktree: runtime.worktree, port: runtime.port,
          url: runtime.url, state: 'unhealthy', restartAttempts: runtime.restartAttempts + 1, stopping: false }
        this.gateways.set(runtime.standId, retry)
        this.scheduleGatewayRestart(retry)
      })
    }, delay)
  }

  private async waitForGateway(runtime: GatewayRuntime): Promise<void> {
    const deadline = this.now() + this.readinessTimeoutMs
    while (this.now() < deadline) {
      if (!runtime.child?.pid || !this.isAlive(runtime.child.pid)) throw new DevProcessError('process_start_failed', 'Gateway exited before readiness')
      try {
        const url = `${runtime.url}/__gateway/health`
        if (this.options.ready ? await this.options.ready(url) : (await fetch(url, { signal: AbortSignal.timeout(Math.max(100, this.readinessPollMs)) })).ok) return
      } catch { /* gateway is starting */ }
      await new Promise(resolvePromise => setTimeout(resolvePromise, this.readinessPollMs))
    }
    throw new DevProcessError('readiness_timeout', 'Gateway readiness check timed out')
  }

  private async gatewayHealth(standId: string): Promise<DevGatewayHealth> {
    const gateway = this.gateways.get(standId)
    if (!gateway) return { state: 'stopped' }
    const url = `${gateway.url}/__gateway/health`
    try {
      const healthy = this.options.ready ? await this.options.ready(url) : (await fetch(url, { signal: AbortSignal.timeout(1_000) })).ok
      gateway.state = healthy ? 'healthy' : 'unhealthy'
    } catch { gateway.state = 'unhealthy' }
    return { state: gateway.state, url: gateway.url }
  }

  private log(event: string, target: { standId: string; component: string; sha?: string; port?: number; env?: Record<string, string> }, reason: string): void {
    this.options.onLog?.(`devProcess ${event} ${JSON.stringify({
      stand: target.standId, component: target.component, sha: target.sha ?? '-', port: target.port ?? null,
      reason: this.redact(reason, Object.values(target.env ?? {}))
    })}`)
  }

  private async stopGateway(runtime: GatewayRuntime): Promise<void> {
    this.log('stop', { ...runtime, component: 'gateway', sha: runtime.sha }, 'gateway stopped')
    runtime.stopping = true
    if (runtime.restartTimer) clearTimeout(runtime.restartTimer)
    if (runtime.child?.pid) await this.terminate(runtime.child.pid)
    runtime.state = 'stopped'
    this.savedGateways.delete(runtime.standId)
    this.persist()
    if (this.gateways.get(runtime.standId) === runtime) this.gateways.delete(runtime.standId)
  }
}
