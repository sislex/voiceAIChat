# Sislexa Analytics

Browser hosts can import `createAnalyticsBrowserClient` and
`BrowserActivityTracker`. The client owns the versioned Analytics route contract
while the host supplies its credential-aware `fetch` implementation and headers.

Analytics owns authenticated active-time intervals and account reporting
projections. Billing remains authoritative for spending, settlement and balances;
Analytics outages never permit or block paid execution.

## Activity contract

Clients emit visible, focused, active-module intervals of at most 35 seconds.
`interactionAt` must be no more than 60 seconds before the interval, and offline
replay is bounded to ten minutes. Payloads contain module, device/session IDs and
a monotonic sequence, never keystrokes, prompts or document content. Identity is
derived from the bearer token. Replays are idempotent; changed payloads using the
same sequence are rejected.

Reports deduplicate overlaps across tabs and devices. For each overlapping segment,
the most recent explicit interaction owns attention; receipt time and stable IDs
break ties. The primary total is therefore wall-clock active time rather than a
sum of every open tab. Raw intervals are retained for 90 days, and reports expose
when a requested period is partial.

`GET /api/analytics/account?from=<ms>&to=<ms>` combines the activity projection
with Billing API 1.2 application buckets. They carry authoritative request count,
cost and input/output/cache tokens, including a separate unattributed bucket and
the count of operations without token evidence. Application names, including
revoked names, come from the user's current Identity application directory. An
old or inconsistent Billing response returns `usageStatus: "unavailable"` rather
than a fabricated application report. Directory failure independently returns
`labelsStatus: "unavailable"` and leaves usage visible. `POST /api/analytics/activity`
accepts up to 120 intervals. Periods are half-open and capped at 366 days.

`GET /api/analytics/application?applicationId=<id>&from=<ms>&to=<ms>` projects
one application from Billing's authoritative application-attribution buckets.
It does not sum operation trees, so child operations cannot duplicate account totals.
Activity intervals identify modules, not registered applications; the application
route therefore returns `activity: null` even when `includeActivity=true`.

Run `npm ci`, then `npm run gate`. Managed startup requires
`SISLEXA_COMPONENT_CONFIG`; the sample config documents Identity and Billing
endpoints and secret-file references.

Portable browser and host types are exported from `@sislexa/analytics/contracts`;
that entry has no Fastify, SQLite or runtime imports.

`@sislexa/analytics/ui/AccountAnalytics` renders personal cost, raw-token and
estimated active-time totals. Cost is grouped by registered application, while
active time remains grouped by module. The browser
tracker is exported from `@sislexa/analytics/browser/activityTracker`; it emits
only bounded timing metadata and never input contents.

The account report captures one time boundary per mounted view, so rendering a
response cannot restart the request loop. Selecting another period issues one
new report request with the same upper boundary.
