import type { ComponentRuntime } from '@sislexa/component-runtime'
import type { BillingReports } from './server.js'
import type { BillingApplicationUsageReport } from './contracts.js'

export function componentBillingReports(runtime: ComponentRuntime): BillingReports {
  const billing = runtime.dependency('billing', { timeoutMs: 10_000 })
  return { async report(authorization, principal, from, to) {
    const response = await billing.fetchImpl(billing.url + '/v1/billing/usage-report', { method: 'POST', redirect: 'error',
      headers: { 'content-type': 'application/json', 'x-sislexa-user-authorization': authorization,
        'x-sislexa-tenant-id': principal.tenantId }, body: JSON.stringify({ from, to }) })
    if (!response.ok) throw Error('billing_report_unavailable')
    return await response.json() as BillingApplicationUsageReport
  } }
}
