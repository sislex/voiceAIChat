import type { BillingUsageReport } from '@sislexa/sdk'

export interface ApplicationUsageBucket {
  applicationId: string | null
  events: number
  actualMicroUsd: number
  inputTokens: number
  outputTokens: number
  cacheReadTokens: number
  cacheWriteTokens: number
  totalTokens: number
  missingUsageEvents: number
}
export type BillingApplicationUsageReport = BillingUsageReport & { applications: readonly ApplicationUsageBucket[] }
export interface ApplicationLabel { id: string; name: string; revokedAt: number | null }

export const ANALYTICS_ROUTES = {
  account: '/api/analytics/account',
  application: '/api/analytics/application',
  activity: '/api/analytics/activity'
} as const

export interface ActivityIntervalInput {
  version: 1
  deviceId: string
  sessionId: string
  sequence: number
  moduleId: string
  startedAt: number
  endedAt: number
  interactionAt: number
}

export interface ActivityModule { moduleId: string; activeMs: number; shareBasisPoints: number | null }
export interface ActivityDay { day: string; activeMs: number }
export interface ActivityReport {
  version: 1
  from: number
  to: number
  activeMs: number
  estimated: true
  rawIntervals: number
  modules: ActivityModule[]
  days: ActivityDay[]
  retentionFrom: number
  partial: boolean
}

export interface AnalyticsAccountReport {
  version: 2
  generatedAt: number
  usageStatus: 'current' | 'unavailable'
  usage: BillingApplicationUsageReport | null
  labelsStatus: 'current' | 'unavailable'
  applicationLabels: readonly ApplicationLabel[]
  activity: ActivityReport
}

export interface AnalyticsApplicationReport {
  version: 2
  generatedAt: number
  applicationId: string
  usageStatus: 'current' | 'unavailable'
  /** The authoritative Billing bucket for this application, or null when absent/unavailable. */
  usage: ApplicationUsageBucket | null
  labelsStatus: 'current' | 'unavailable'
  label: ApplicationLabel | null
  /** Activity has no verified application ID and must not be attributed by module name. */
  activity: null
}

export interface ActivityIngestionResult { accepted: number; duplicates: number }
