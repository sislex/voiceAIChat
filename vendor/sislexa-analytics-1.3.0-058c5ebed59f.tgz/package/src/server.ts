import Fastify, { type FastifyRequest } from 'fastify'
import { assertPlatformIdentifier } from '@sislexa/sdk'
import type { AnalyticsAuthority } from './authority.js'
import type { ActivityIntervalInput, ActivityPrincipal } from './activity.js'
import { ANALYTICS_ROUTES, type ApplicationLabel, type BillingApplicationUsageReport } from './contracts.js'
import { ActivityStore, AnalyticsError } from './store.js'

export interface BillingReports { report(authorization: string, principal: ActivityPrincipal, from: number, to: number): Promise<BillingApplicationUsageReport> }
export interface ApplicationDirectory { list(authorization: string, principal: ActivityPrincipal): Promise<readonly ApplicationLabel[]> }

/** An old Billing provider must not silently turn an application report into module attribution. */
function checkedReport(report: BillingApplicationUsageReport): BillingApplicationUsageReport {
  if (!Array.isArray(report.applications)) throw new Error('application_report_unavailable')
  const seen = new Set<string | null>()
  for (const row of report.applications) {
    if ((row.applicationId !== null && typeof row.applicationId !== 'string') || seen.has(row.applicationId) ||
      !(['events', 'actualMicroUsd', 'inputTokens', 'outputTokens', 'cacheReadTokens', 'cacheWriteTokens', 'totalTokens', 'missingUsageEvents'] as const)
        .every(key => Number.isSafeInteger(row[key]) && row[key] >= 0)) throw new Error('invalid_application_report')
    seen.add(row.applicationId)
  }
  for (const key of ['events', 'actualMicroUsd', 'inputTokens', 'outputTokens', 'cacheReadTokens', 'cacheWriteTokens', 'totalTokens'] as const) {
    if (report.applications.reduce((sum, row) => sum + row[key], 0) !== report[key]) throw new Error('application_report_mismatch')
  }
  return report
}

const bearer = (request: FastifyRequest): string => {
  const value = request.headers.authorization
  if (!value || !/^Bearer \S+$/.test(value) || value.length > 8192) throw new AnalyticsError(401, 'user_session_required')
  return value
}
const tenantHint = (request: FastifyRequest): string | undefined => {
  const value = request.headers['x-sislexa-tenant-id']
  if (value === undefined) return undefined
  if (typeof value !== 'string') throw new AnalyticsError(400, 'invalid_tenant_id')
  try { assertPlatformIdentifier(value, 'tenantId') }
  catch { throw new AnalyticsError(400, 'invalid_tenant_id') }
  return value
}
const queryTime = (value: string): number => {
  const result = Number(value)
  if (!Number.isSafeInteger(result)) throw new AnalyticsError(400, 'invalid_report_period')
  return result
}
const includeActivity = (value: string | undefined): boolean => {
  if (value === undefined || value === 'true') return true
  if (value === 'false') return false
  throw new AnalyticsError(400, 'invalid_activity_option')
}
const applicationQuery = (applicationId: string, from: number, to: number): void => {
  try { assertPlatformIdentifier(applicationId, 'applicationId') }
  catch { throw new AnalyticsError(400, 'invalid_application_id') }
  if (to <= from || to - from > 366 * 24 * 60 * 60_000) throw new AnalyticsError(400, 'invalid_report_period')
}

export function buildAnalyticsServer(store: ActivityStore, authority: AnalyticsAuthority, billing: BillingReports,
  directory?: ApplicationDirectory) {
  const app = Fastify({ logger: false, bodyLimit: 65_536, ajv: { customOptions: { removeAdditional: false, coerceTypes: false, useDefaults: false } } })
  app.addHook('onSend', async (_request, reply) => { reply.header('cache-control', 'no-store') })
  app.setErrorHandler((error, _request, reply) => {
    const status = error instanceof AnalyticsError ? error.statusCode : error && typeof error === 'object' && 'validation' in error ? 400 : 503
    return reply.code(status).send({ error: error instanceof AnalyticsError ? error.message : status === 400 ? 'invalid_request' : 'analytics_unavailable' })
  })
  app.get('/api/health', async () => ({ ok: true, applicationId: 'analytics' }))
  app.post<{ Body: { intervals: ActivityIntervalInput[] } }>(ANALYTICS_ROUTES.activity, {
    schema: { body: { type: 'object', additionalProperties: false, required: ['intervals'], properties: {
      intervals: { type: 'array', minItems: 1, maxItems: 120, items: { type: 'object', additionalProperties: false,
        required: ['version', 'deviceId', 'sessionId', 'sequence', 'moduleId', 'startedAt', 'endedAt', 'interactionAt'], properties: {
          version: { type: 'integer', const: 1 }, deviceId: { type: 'string', minLength: 1, maxLength: 256 },
          sessionId: { type: 'string', minLength: 1, maxLength: 256 }, sequence: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
          moduleId: { type: 'string', minLength: 1, maxLength: 256 }, startedAt: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
          endedAt: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER }, interactionAt: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER }
        } }
      }
    } } }
  }, async request => {
    const principal = await authority.verifyUser(bearer(request), tenantHint(request))
    let accepted = 0, duplicates = 0
    for (const interval of request.body.intervals) store.record(principal, interval).accepted ? accepted++ : duplicates++
    return { accepted, duplicates }
  })
  app.get<{ Querystring: { from: string; to: string } }>(ANALYTICS_ROUTES.account, {
    schema: { querystring: { type: 'object', additionalProperties: false, required: ['from', 'to'], properties: {
      from: { type: 'string', pattern: '^[0-9]{1,16}$' }, to: { type: 'string', pattern: '^[0-9]{1,16}$' }
    } } }
  }, async request => {
    const authorization = bearer(request), principal = await authority.verifyUser(authorization, tenantHint(request))
    const from = queryTime(request.query.from), to = queryTime(request.query.to)
    const activity = store.report(principal, from, to)
    const [usageResult, labelsResult] = await Promise.allSettled([billing.report(authorization, principal, from, to),
      directory ? directory.list(authorization, principal) : Promise.reject(new Error('application_directory_unavailable'))])
    let usage: BillingApplicationUsageReport | null = null
    if (usageResult.status === 'fulfilled') try { usage = checkedReport(usageResult.value) } catch { /* Old or inconsistent Billing. */ }
    return { version: 2, generatedAt: Date.now(), usageStatus: usage ? 'current' : 'unavailable', usage,
      labelsStatus: labelsResult.status === 'fulfilled' ? 'current' : 'unavailable',
      applicationLabels: labelsResult.status === 'fulfilled' ? labelsResult.value : [], activity }
  })
  app.get<{ Querystring: { applicationId: string; from: string; to: string; includeActivity?: string } }>(ANALYTICS_ROUTES.application, {
    schema: { querystring: { type: 'object', additionalProperties: false, required: ['applicationId', 'from', 'to'], properties: {
      applicationId: { type: 'string', minLength: 1, maxLength: 256 },
      from: { type: 'string', pattern: '^[0-9]{1,16}$' }, to: { type: 'string', pattern: '^[0-9]{1,16}$' },
      includeActivity: { type: 'string', enum: ['true', 'false'] }
    } } }
  }, async request => {
    const authorization = bearer(request), principal = await authority.verifyUser(authorization, tenantHint(request))
    const from = queryTime(request.query.from), to = queryTime(request.query.to)
    applicationQuery(request.query.applicationId, from, to)
    includeActivity(request.query.includeActivity)
    const [usageResult, labelsResult] = await Promise.allSettled([billing.report(authorization, principal, from, to),
      directory ? directory.list(authorization, principal) : Promise.reject(new Error('application_directory_unavailable'))])
    let report: BillingApplicationUsageReport | null = null
    if (usageResult.status === 'fulfilled') try { report = checkedReport(usageResult.value) } catch { /* No false zero bucket. */ }
    return { version: 2, generatedAt: Date.now(), applicationId: request.query.applicationId,
      usageStatus: report ? 'current' : 'unavailable',
      usage: report?.applications.find(row => row.applicationId === request.query.applicationId) ?? null,
      labelsStatus: labelsResult.status === 'fulfilled' ? 'current' : 'unavailable',
      label: labelsResult.status === 'fulfilled' ? labelsResult.value.find(row => row.id === request.query.applicationId) ?? null : null,
      activity: null }
  })
  return app
}
