import type { ComponentRuntime } from '@sislexa/component-runtime'
import type { ApplicationLabel } from './contracts.js'
import type { ApplicationDirectory } from './server.js'

/** Names remain available after revocation; Identity remains their source of truth. */
export function componentApplicationDirectory(runtime: ComponentRuntime): ApplicationDirectory {
  const identity = runtime.dependency('identity', { timeoutMs: 10_000 })
  return { async list(authorization, principal) {
    const response = await identity.publicFetchImpl(identity.url + '/api/session/applications', {
      method: 'GET', redirect: 'error', headers: { authorization, 'x-sislexa-tenant-id': principal.tenantId }
    })
    if (!response.ok) throw Error('application_directory_unavailable')
    const rows: unknown = await response.json()
    if (!Array.isArray(rows) || !rows.every(row => row && typeof row === 'object' &&
      typeof row.id === 'string' && typeof row.name === 'string' &&
      (row.revokedAt === null || Number.isSafeInteger(row.revokedAt) && row.revokedAt >= 0))) {
      throw Error('invalid_application_directory')
    }
    return rows.map((row: ApplicationLabel) => ({ id: row.id, name: row.name, revokedAt: row.revokedAt }))
  } }
}
