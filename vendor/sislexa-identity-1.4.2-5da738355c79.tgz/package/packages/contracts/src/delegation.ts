/** Delegation v1 timestamps are integer Unix milliseconds. No wildcard authority. */
export const DELEGATION_VERSION = 1 as const
export const DELEGATION_SCOPES = ['read', 'write', 'execute'] as const
export type DelegationScope = typeof DELEGATION_SCOPES[number]
export const DELEGATION_RESOURCE_TYPES = ['project', 'conversation', 'task', 'machine'] as const
export interface DelegationResource {
  tenantId: string
  type: typeof DELEGATION_RESOURCE_TYPES[number]
  id: string
}
/** Scope and resource stay paired; never form a Cartesian product of permissions. */
export interface DelegationPermission { resource: DelegationResource; scopes: DelegationScope[] }
export interface DelegatedPrincipal {
  kind: 'delegated'
  userId: string
  tenantId: string
  applicationId: string
  grantId: string
  audience: string
  permissions: DelegationPermission[]
  issuedAt: number
  expiresAt: number
}
export type DelegationIntrospection =
  | { version: 1; active: false }
  | { version: 1; active: true; principal: DelegatedPrincipal }
export interface DelegationIntrospectionRequest { token: string; audience: string }
export interface DelegationIntrospectionClient {
  introspect(input: DelegationIntrospectionRequest): Promise<DelegationIntrospection>
}
/** Billing may use this only after authenticating the Core component. */
export interface DelegatedBillingAdmissionRequest {
  token: string
  applicationId: string
  grantId: string
}
export type DelegatedBillingAdmission =
  | { version: 1; active: false }
  | { version: 1; active: true; user: { userId: string; tenantId: string; role: string; capabilities: string[] } }
export interface ManagedApplication {
  id: string
  ownerUserId: string
  tenantId: string
  name: string
  createdAt: number
  revokedAt: number | null
}
export interface ApplicationGrant {
  id: string
  applicationId: string
  userId: string
  tenantId: string
  audience: string
  permissions: DelegationPermission[]
  issuedAt: number
  expiresAt: number
  revokedAt: number | null
}
export interface CreateApplicationInput { name: string }
export interface CreateApplicationGrantInput {
  audience: string
  permissions: DelegationPermission[]
  expiresAt: number
}
/** The opaque bearer is returned once at issuance; list/get never return it. */
export interface IssuedApplicationGrant { grant: ApplicationGrant; token: string }
export interface ApplicationManagementClient {
  list(): Promise<ManagedApplication[]>
  create(input: CreateApplicationInput): Promise<ManagedApplication>
  rename(applicationId: string, input: CreateApplicationInput): Promise<ManagedApplication>
  revoke(applicationId: string): Promise<void>
  grants(applicationId: string): Promise<ApplicationGrant[]>
  issueGrant(applicationId: string, input: CreateApplicationGrantInput): Promise<IssuedApplicationGrant>
  rotateGrant(applicationId: string, grantId: string): Promise<IssuedApplicationGrant>
  revokeGrant(applicationId: string, grantId: string): Promise<void>
}
export const IDENTITY_DELEGATION_PATHS = {
  introspect: '/v1/identity/delegation/introspect',
  billingAdmission: '/v1/identity/delegation/billing-admission',
  applications: '/api/session/applications',
  application: (id: string) => `/api/session/applications/${encodeURIComponent(id)}`,
  grants: (id: string) => `/api/session/applications/${encodeURIComponent(id)}/grants`,
  grant: (id: string, grantId: string) => `/api/session/applications/${encodeURIComponent(id)}/grants/${encodeURIComponent(grantId)}`,
  rotateGrant: (id: string, grantId: string) => `/api/session/applications/${encodeURIComponent(id)}/grants/${encodeURIComponent(grantId)}/rotate`
} as const

type RecordValue = Record<string, unknown>
function record(v: unknown): v is RecordValue { return !!v && typeof v === 'object' && !Array.isArray(v) }
function exact(v: RecordValue, keys: string[]): boolean { return Object.keys(v).length === keys.length && keys.every(k => Object.hasOwn(v, k)) }
export function isDelegationIdentifier(v: unknown): v is string { return typeof v === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}$/.test(v) }
function timestamp(v: unknown): v is number { return Number.isSafeInteger(v) && Number(v) >= 0 }
function revokedAt(v: unknown): boolean { return v === null || timestamp(v) }
export function isDelegationResource(v: unknown): v is DelegationResource {
  return record(v) && exact(v, ['tenantId', 'type', 'id']) && isDelegationIdentifier(v.tenantId) && isDelegationIdentifier(v.id) && DELEGATION_RESOURCE_TYPES.includes(v.type as DelegationResource['type'])
}
export function isDelegationPermissions(v: unknown): v is DelegationPermission[] {
  if (!Array.isArray(v) || v.length === 0 || v.length > 100) return false
  const seen = new Set<string>()
  return v.every(p => {
    if (!record(p) || !exact(p, ['resource', 'scopes']) || !isDelegationResource(p.resource) || !Array.isArray(p.scopes) || p.scopes.length === 0 || !p.scopes.every(s => DELEGATION_SCOPES.includes(s)) || new Set(p.scopes).size !== p.scopes.length) return false
    const key = JSON.stringify([p.resource.tenantId, p.resource.type, p.resource.id])
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}
function authority(v: RecordValue): boolean {
  return ['userId', 'tenantId', 'applicationId', 'audience'].every(k => isDelegationIdentifier(v[k])) &&
    timestamp(v.issuedAt) && timestamp(v.expiresAt) && v.expiresAt > v.issuedAt &&
    isDelegationPermissions(v.permissions) && v.permissions.every(p => p.resource.tenantId === v.tenantId)
}
export function isDelegatedPrincipal(v: unknown): v is DelegatedPrincipal {
  return record(v) && exact(v, ['kind', 'userId', 'tenantId', 'applicationId', 'grantId', 'audience', 'permissions', 'issuedAt', 'expiresAt']) && v.kind === 'delegated' && isDelegationIdentifier(v.grantId) && authority(v)
}
export function isDelegationIntrospection(v: unknown): v is DelegationIntrospection {
  return record(v) && v.version === 1 && (v.active === false ? exact(v, ['version', 'active']) : v.active === true && exact(v, ['version', 'active', 'principal']) && isDelegatedPrincipal(v.principal))
}
export function isCreateApplicationInput(v: unknown): v is CreateApplicationInput {
  return record(v) && exact(v, ['name']) && typeof v.name === 'string' && v.name.trim().length > 0 && v.name.length <= 80
}
export function isCreateApplicationGrantInput(v: unknown, now: number): v is CreateApplicationGrantInput {
  if (!timestamp(now) || !record(v) || !exact(v, ['audience', 'permissions', 'expiresAt']) || !isDelegationIdentifier(v.audience) || !isDelegationPermissions(v.permissions) || !timestamp(v.expiresAt) || v.expiresAt <= now) return false
  const tenantId = v.permissions[0]!.resource.tenantId
  return v.permissions.every(p => p.resource.tenantId === tenantId)
}
export function isManagedApplication(v: unknown): v is ManagedApplication {
  return record(v) && exact(v, ['id', 'ownerUserId', 'tenantId', 'name', 'createdAt', 'revokedAt']) && ['id', 'ownerUserId', 'tenantId'].every(k => isDelegationIdentifier(v[k])) && isCreateApplicationInput({ name: v.name }) && timestamp(v.createdAt) && revokedAt(v.revokedAt) && (v.revokedAt === null || Number(v.revokedAt) >= v.createdAt)
}
export function isApplicationGrant(v: unknown): v is ApplicationGrant {
  return record(v) && exact(v, ['id', 'applicationId', 'userId', 'tenantId', 'audience', 'permissions', 'issuedAt', 'expiresAt', 'revokedAt']) && isDelegationIdentifier(v.id) && authority(v) && revokedAt(v.revokedAt) && (v.revokedAt === null || Number(v.revokedAt) >= Number(v.issuedAt))
}
/** Only narrows a fresh trusted introspection verdict; it is not user authentication. */
export function permitsDelegatedAction(verdict: unknown, audience: string, resource: DelegationResource, scope: DelegationScope, now: number): boolean {
  if (!timestamp(now) || !isDelegationResource(resource) || !isDelegationIntrospection(verdict) || !verdict.active) return false
  const p = verdict.principal
  return p.audience === audience && p.issuedAt <= now && now < p.expiresAt && p.tenantId === resource.tenantId && p.permissions.some(permission => permission.resource.type === resource.type && permission.resource.id === resource.id && permission.resource.tenantId === resource.tenantId && permission.scopes.includes(scope))
}
