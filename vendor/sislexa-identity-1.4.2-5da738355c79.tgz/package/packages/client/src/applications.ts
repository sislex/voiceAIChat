import {
  IDENTITY_DELEGATION_PATHS as paths, isManagedApplication, isApplicationGrant,
  isCreateApplicationInput, isCreateApplicationGrantInput, isDelegationIdentifier,
  type ApplicationManagementClient, type IssuedApplicationGrant
} from '../../contracts/src/delegation.js'
import { authHeaders, credentialedFetch } from './browser.js'

function identifier(value: string): string {
  if (!isDelegationIdentifier(value)) throw new TypeError('Invalid application or grant ID')
  return value
}
function arrayOf<T>(guard: (value: unknown) => value is T) {
  return (value: unknown): value is T[] => Array.isArray(value) && value.every(guard)
}
function issued(value: unknown): value is IssuedApplicationGrant {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const v = value as Record<string, unknown>
  return Object.keys(v).length === 2 && isApplicationGrant(v.grant) && v.grant.revokedAt === null && typeof v.token === 'string' && v.token.trim().length > 0 && v.token.length <= 16384
}

/** Uses existing browser session, tenant selection, and CSRF handling. */
export function makeApplicationManagementClient(httpBase = '', now: () => number = Date.now): ApplicationManagementClient {
  async function request<T>(path: string, method: string, guard: (value: unknown) => value is T, body?: unknown): Promise<T> {
    const response = await credentialedFetch(httpBase + path, {
      method, headers: { ...authHeaders(), ...(body === undefined ? {} : { 'content-type': 'application/json' }) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(15000)
    })
    if (!response.ok) throw Object.assign(new Error(`Application HTTP ${response.status}`), { status: response.status })
    const value: unknown = response.status === 204 ? undefined : await response.json()
    if (!guard(value)) throw new Error('Invalid application response')
    return value
  }
  const empty = (v: unknown): v is undefined => v === undefined
  return {
    list: () => request(paths.applications, 'GET', arrayOf(isManagedApplication)),
    create(input) {
      if (!isCreateApplicationInput(input)) throw new TypeError('Invalid application input')
      return request(paths.applications, 'POST', isManagedApplication, input)
    },
    rename(id, input) {
      if (!isCreateApplicationInput(input)) throw new TypeError('Invalid application input')
      return request(paths.application(identifier(id)), 'PATCH', isManagedApplication, input)
    },
    revoke: id => request(paths.application(identifier(id)), 'DELETE', empty),
    grants: id => request(paths.grants(identifier(id)), 'GET', arrayOf(isApplicationGrant)),
    issueGrant(id, input) {
      if (!isCreateApplicationGrantInput(input, now())) throw new TypeError('Invalid application grant input')
      return request(paths.grants(identifier(id)), 'POST', issued, input)
    },
    rotateGrant: (id, grantId) => request(paths.rotateGrant(identifier(id), identifier(grantId)), 'POST', issued),
    revokeGrant: (id, grantId) => request(paths.grant(identifier(id), identifier(grantId)), 'DELETE', empty)
  }
}
