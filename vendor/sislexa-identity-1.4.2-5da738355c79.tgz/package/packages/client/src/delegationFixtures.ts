import type { ApplicationGrant, DelegationIntrospection, IssuedApplicationGrant, ManagedApplication } from '../../contracts/src/delegation.js'

/** Wire fixtures with deterministic metadata and fresh synthetic tokens; never an authorization store. */
export function createDelegationFixtures() {
  const now = 1800000000000
  const application: ManagedApplication = { id: 'app-example', ownerUserId: 'user-example', tenantId: 'tenant-example', name: 'Example application', createdAt: now - 1000, revokedAt: null }
  const grant: ApplicationGrant = {
    id: 'grant-example', applicationId: application.id, userId: application.ownerUserId,
    tenantId: application.tenantId, audience: 'core',
    permissions: [{ resource: { tenantId: application.tenantId, type: 'project', id: 'project-example' }, scopes: ['read'] }],
    issuedAt: now, expiresAt: now + 60000, revokedAt: null
  }
  const { id, revokedAt: _revokedAt, ...authority } = grant
  const active: DelegationIntrospection = { version: 1, active: true, principal: { kind: 'delegated', grantId: id, ...structuredClone(authority) } }
  const inactive: DelegationIntrospection = { version: 1, active: false }
  const issued: IssuedApplicationGrant = { grant: structuredClone(grant), token: crypto.randomUUID() }
  return { now, application, grant, issued, active, inactive,
    expiredGrant: { ...structuredClone(grant), issuedAt: now - 60000, expiresAt: now },
    revokedGrant: { ...structuredClone(grant), revokedAt: now },
    revokedApplication: { ...application, revokedAt: now }
  }
}
