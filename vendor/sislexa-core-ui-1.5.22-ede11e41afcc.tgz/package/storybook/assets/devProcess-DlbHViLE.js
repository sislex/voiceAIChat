const e={"devProcess.start":!0,"devProcess.stop":!0,"devProcess.status":!0,"devProcess.logs":!0,"devProcess.stopStand":!0},t=Object.keys(e);[...t.map(s=>`${s}.result`)];
