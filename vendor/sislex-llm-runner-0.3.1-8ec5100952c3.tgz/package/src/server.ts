import { applicationRuntimeMetadata, RUNNER_LIFECYCLE_PATH, RUNNER_MCP_SERVERS_PATH } from '@sislex/runner-contracts'
import { randomUUID } from 'node:crypto'
import { mkdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import type { ServerResponse } from 'node:http'
import Fastify, { type FastifyInstance, type FastifyReply, type FastifyRequest } from 'fastify'
import {
  LLM_RUNNER,
  LLM_RUN_ID_HEADER,
  type LlmRunBody,
  type LlmRunnerHealth
} from '@sislex/runner-contracts'
import { registerRunnerAuth, bearerToken } from './auth.js'
import { ServiceTokenStore } from './serviceTokens.js'
import { PreviewCliGrants } from './previewGrants.js'
import { PREVIEW_CLI_GRANTS_PATH, type PreviewCliGrantScope } from '@sislex/runner-contracts'
import { listProfileMcpServers } from './cli/mcp.js'
import { ensureCliProfile } from './cli/cliProfiles.js'
import type { RunnerConfig } from './config.js'
import { RunManager, type RunSink } from './run/rawRun.js'
import { RunReceipts, numericUsage, type RunObservation } from './run/receipts.js'
import { LLM_RECEIPTS_PATH, parseLlmAccountingContext, type TurnUsage } from '@sislex/runner-contracts'
import { runnerHealth } from './health.js'
import { getLoginStatus } from './auth/loginStatus.js'
import { readUserFile } from './fs/userFiles.js'
import { listProjects, listSessions, readTranscript, readUsage, watchTranscriptFromOffset } from './fs/ccSessions.js'
import {
  listCxProjects,
  listCxSessions,
  readCxTranscript,
  readCxUsage,
  resolveCxSessionPath,
  watchCxTranscriptFromOffset
} from './fs/codexSessions.js'

const RUNNER_AUTH_STATUS_PATH = '/v1/auth/status'
const RUNNER_FILE_READ_PATH = '/v1/files/read'
const RUNNER_CC_PROJECTS_PATH = '/v1/fs/cc/projects'
const RUNNER_CC_WATCH_PATH = '/v1/fs/cc/watch'
const RUNNER_CX_PROJECTS_PATH = '/v1/fs/cx/projects'
const RUNNER_CX_SESSIONS_PATH = '/v1/fs/cx/sessions'
const RUNNER_CX_TRANSCRIPT_PATH = '/v1/fs/cx/transcript'
const RUNNER_CX_WATCH_PATH = '/v1/fs/cx/watch'
const packageVersion = (JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')) as { version: string }).version

export interface BuildRunnerOptions {
  config: RunnerConfig
  runs?: RunManager
  receipts?: RunReceipts
  health?: () => Promise<LlmRunnerHealth>
  authStatus?: (userId: string) => Promise<import('@sislex/runner-contracts').LoginStatusMap>
}

function responseSink(res: ServerResponse): RunSink {
  return {
    write: (chunk) => res.write(chunk),
    onDrain: (cb) => void res.on('drain', cb),
    onClose: (cb) => void res.on('close', cb),
    end: () => {
      if (!res.writableEnded) res.end()
    }
  }
}

function badRequest(body: LlmRunBody | undefined): string | null {
  if (!body || typeof body !== 'object') return 'тело запроса обязательно'
  if (typeof body.prompt !== 'string' || !body.prompt) return 'prompt обязателен'
  if (body.kind !== 'claude' && body.kind !== 'codex') return 'kind: claude | codex'
  // У codex пустая модель — норма: `settings.codexModel` по умолчанию '', тогда
  // `codexInvocation` не добавляет `-m` и модель берётся из config.toml самого CLI.
  // Требование непустой строки роняло КАЖДЫЙ ход codex через удалённого исполнителя.
  if (typeof body.model !== 'string') return 'model обязательна'
  if (!body.model && body.kind === 'claude') return 'model обязательна'
  return null
}

function requireUserId(
  req: FastifyRequest<{ Querystring: { userId?: string } }>,
  reply: FastifyReply
): string | null {
  const userId = req.query.userId?.trim()
  if (userId) return userId
  void reply.code(400).send({ error: 'bad_request', message: 'userId обязателен' })
  return null
}

function sseHeaders(reply: FastifyReply): ServerResponse {
  const res = reply.raw
  res.socket?.setNoDelay(true)
  reply.hijack()
  res.writeHead(200, {
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-store',
    connection: 'keep-alive',
    'x-accel-buffering': 'no'
  })
  res.flushHeaders()
  return res
}

function sendSse(res: ServerResponse, id: number, payload: unknown): void {
  res.write(`id: ${id}\n`)
  res.write(`data: ${JSON.stringify(payload)}\n\n`)
}

function lastEventId(req: FastifyRequest): number | undefined {
  const raw = req.headers['last-event-id']
  if (typeof raw !== 'string' || !raw.trim()) return undefined
  const parsed = Number(raw)
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : undefined
}

export async function buildRunner(opts: BuildRunnerOptions): Promise<FastifyInstance> {
  const { config } = opts
  if (!config.token) throw new Error('исполнитель без VC_RUNNER_TOKEN не поднимается')

  const app = Fastify({ logger: false, bodyLimit: 32 * 1024 * 1024 })
  if (!opts.receipts) mkdirSync(config.dataDir, { recursive: true })
  const receipts = opts.receipts ?? new RunReceipts(join(config.dataDir, 'execution-receipts.sqlite'))
  const serviceTokens = config.tokenStoreDir ? new ServiceTokenStore(config.tokenStoreDir) : undefined
  const previewGrants = new PreviewCliGrants((id) => runs.cancel(id))
  registerRunnerAuth(app, config.token, (token) => previewGrants.accepts(token), serviceTokens)
  const grantGc = setInterval(() => previewGrants.sweep(), 1000)
  grantGc.unref()
  app.addHook('onClose', async () => { clearInterval(grantGc); previewGrants.close(); serviceTokens?.close(); receipts.close() })
  app.post<{ Body: PreviewCliGrantScope }>(PREVIEW_CLI_GRANTS_PATH, async (req, reply) => {
    try { return previewGrants.issue(req.body) }
    catch { return reply.code(400).send({ error: 'invalid_preview_scope' }) }
  })
  app.delete<{ Params: { id: string } }>(PREVIEW_CLI_GRANTS_PATH + '/:id', async (req) => {
    previewGrants.revoke(req.params.id)
    return { revoked: true }
  })

  const runs =
    opts.runs ??
    new RunManager({
      claudeBin: config.claudeBin,
      codexBin: config.codexBin,
      orphanMs: config.orphanMs,
      profileHome: (userId) =>
        ensureCliProfile(config.dataDir, userId, config.home, { sharedCodexAuth: config.sharedCodexAuth === true, sharedCodexAuthUser: config.sharedCodexAuthUser }).home
    })
  const health =
    opts.health ??
    (() =>
      runnerHealth({
        home: config.home,
        claudeBin: config.claudeBin,
        codexBin: config.codexBin,
        runs: () => runs.size
      }))

  const profile = (userId: string) =>
    ensureCliProfile(config.dataDir, userId, config.home, { sharedCodexAuth: config.sharedCodexAuth === true, sharedCodexAuthUser: config.sharedCodexAuthUser })

  // Admission changes and run registration execute without an await between them.
  // Draining never closes streams or stops children that were already admitted.
  let draining = false
  const lifecycle = () => ({ draining, activeRuns: runs.size })
  const masterOnly = async (req: FastifyRequest, reply: FastifyReply) => {
    if (req.runnerIdentity?.kind !== 'master') return reply.code(403).send({ error: 'admin_token_required' })
  }
  app.get(RUNNER_LIFECYCLE_PATH, { preHandler: masterOnly }, async () => lifecycle())
  app.put<{ Body: { draining: boolean } }>(RUNNER_LIFECYCLE_PATH, {
    preHandler: masterOnly,
    schema: { body: { type: 'object', required: ['draining'], additionalProperties: false,
      properties: { draining: { type: 'boolean' } } } }
  }, async (req) => {
    draining = req.body.draining
    return lifecycle()
  })

  const receiptOwner = (req: FastifyRequest): string | undefined => {
    const identity = req.runnerIdentity
    return identity?.kind === 'master' ? 'master' : identity?.kind === 'service' ? 'service:' + identity.application : undefined
  }
  app.get<{ Params: { id: string } }>(LLM_RECEIPTS_PATH + '/:id', async (req, reply) => {
    const owner = receiptOwner(req)
    const receipt = owner ? receipts.get(owner, req.params.id) : undefined
    if (!receipt) return reply.code(404).send({ error: 'execution_not_found' })
    return reply.header('cache-control', 'no-store').send(receipt)
  })
  app.post<{ Params: { id: string }; Body: { context: unknown; kind: 'claude' | 'codex' } }>(LLM_RECEIPTS_PATH + '/:id/fence', async (req, reply) => {
    const owner = receiptOwner(req)
    if (!owner) return reply.code(403).send({ error: 'execution_authority_required' })
    let context
    try {
      context = parseLlmAccountingContext(req.body?.context)
      if (context.operationId !== req.params.id || !['claude', 'codex'].includes(req.body.kind)) throw Error('invalid_fence')
    } catch { return reply.code(400).send({ error: 'invalid_execution_fence' }) }
    try {
      return reply.header('cache-control', 'no-store').send(receipts.fence(owner, context, req.body.kind))
    } catch { return reply.code(409).send({ error: 'execution_fence_conflict' }) }
  })

  app.post<{ Body: LlmRunBody }>(LLM_RUNNER.run, async (req, reply) => {
    if (draining) {
      return reply.code(503).header('retry-after', '5').send({ error: 'runner_draining' })
    }
    const scoped = req.runnerIdentity?.kind === 'preview'
    if (scoped) {
      const body = previewGrants.prepare(bearerToken(req), req.body)
      if (!body) return reply.code(403).send({ error: 'preview_scope_denied' })
      req.body = body
      const id = body.runId!
      reply.raw.once('close', () => previewGrants.finish(bearerToken(req), id))
    }
    const problem = badRequest(req.body)
    if (problem) return reply.code(400).send({ error: 'bad_request', message: problem })
    if (req.body.accounting !== undefined) {
      try {
        if (!receiptOwner(req)) throw Error('accounting_authority_required')
        const context = parseLlmAccountingContext(req.body.accounting)
        if (context.operationId !== req.body.runId) throw Error('accounting_run_id_mismatch')
      } catch { return reply.code(400).send({ error: 'invalid_accounting_context' }) }
    }

    if (req.body.runId && runs.has(req.body.runId)) {
      return reply.code(409).send({ error: 'run_exists' })
    }

    const body: LlmRunBody = { ...req.body, sessionId: req.body.sessionId ?? null }
    const id = body.runId || randomUUID()
    const runBody = { ...body, runId: id }
    if (receipts.has(id)) return reply.code(409).send({ error: 'execution_already_claimed' })
    if (!runs.reserveCodexThread(runBody)) {
      return reply.code(409).send({
        error: 'codex_thread_in_use',
        message: 'Codex thread уже выполняется'
      })
    }
    let observation: RunObservation | undefined
    if (body.accounting) {
      try {
        let baseline: TurnUsage | undefined
        if (body.kind === 'codex') {
          if (!body.sessionId) baseline = { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 }
          else if (body.userId) {
            const filename = resolveCxSessionPath(body.sessionId, profile(body.userId).codexSessions)
            if (filename) {
              for (const line of readFileSync(filename, 'utf8').split(/\r?\n/)) {
                try {
                  const event = JSON.parse(line)
                  if (event?.payload?.type === 'token_count') baseline = numericUsage(event.payload.info?.total_token_usage, 'codex')
                } catch { /* A partial append is not a complete usage snapshot. */ }
              }
            }
          }
        }
        const owner = receiptOwner(req)!
        const result = receipts.claim(owner, runBody, baseline)
        if (!result.fresh) throw Error('execution_already_claimed')
        observation = receipts.observe(owner, id)
      } catch {
        runs.releaseCodexThread(runBody, id)
        return reply.code(503).send({ error: 'execution_receipt_unavailable' })
      }
    }
    const res = reply.raw
    res.socket?.setNoDelay(true)
    reply.hijack()
    res.writeHead(200, {
      'content-type': 'application/x-ndjson; charset=utf-8',
      'cache-control': 'no-store',
      'x-accel-buffering': 'no',
      [LLM_RUN_ID_HEADER]: id
    })
    res.flushHeaders()
    try { runs.start(runBody, responseSink(res), observation) }
    catch { res.destroy() }
  })

  app.delete<{ Params: { id: string } }>(`${LLM_RUNNER.run}/:id`, async (req, reply) => {
    if (receipts.has(req.params.id) && !receipts.get(receiptOwner(req) ?? '', req.params.id)) {
      return reply.code(404).send({ error: 'execution_not_found' })
    }
    return { stopped: runs.cancel(req.params.id) }
  })

  app.get(LLM_RUNNER.health, async () => ({ application: applicationRuntimeMetadata('llm-runner', {
    ...process.env, VC_APPLICATION_VERSION: process.env.VC_APPLICATION_VERSION?.trim() || packageVersion
  }), ...await health(), ...lifecycle(), accountingVersion: 1 }))

  app.get<{ Querystring: { userId?: string } }>(RUNNER_MCP_SERVERS_PATH, {
    schema: { querystring: { type: 'object', required: ['userId'],
      properties: { userId: { type: 'string', minLength: 1, maxLength: 256 } } } }
  }, async (req, reply) => {
    const userId = requireUserId(req, reply)
    if (!userId) return
    reply.header('cache-control', 'no-store')
    return listProfileMcpServers(profile(userId).home, config.claudeBin)
  })

  app.get<{ Querystring: { userId?: string } }>(RUNNER_AUTH_STATUS_PATH, async (req, reply) => {
    const userId = requireUserId(req, reply)
    if (!userId) return
    return opts.authStatus
      ? opts.authStatus(userId)
      : getLoginStatus({ home: profile(userId).home, claudeBin: config.claudeBin })
  })

  app.get<{ Querystring: { userId?: string; path?: string } }>(RUNNER_FILE_READ_PATH, async (req, reply) => {
    const userId = requireUserId(req as FastifyRequest<{ Querystring: { userId?: string } }>, reply)
    if (!userId) return
    const res = readUserFile(req.query.path ?? '', [profile(userId).home])
    if (!res.ok) {
      const code = res.reason === 'too-large' ? 413 : 404
      return reply.code(code).send({ error: res.reason })
    }
    return res.file
  })

  app.get<{ Querystring: { userId?: string } }>(RUNNER_CC_PROJECTS_PATH, async (req, reply) => {
    const userId = requireUserId(req, reply)
    if (!userId) return
    return listProjects(profile(userId).ccProjects)
  })

  app.get<{ Params: { slug: string }; Querystring: { userId?: string } }>(
    '/v1/fs/cc/projects/:slug/sessions',
    async (req, reply) => {
      const userId = requireUserId(req as FastifyRequest<{ Querystring: { userId?: string } }>, reply)
      if (!userId) return
      return listSessions(req.params.slug, profile(userId).ccProjects)
    }
  )

  app.get<{ Params: { slug: string; id: string }; Querystring: { userId?: string; limit?: string } }>(
    '/v1/fs/cc/projects/:slug/sessions/:id',
    async (req, reply) => {
      const userId = requireUserId(req as FastifyRequest<{ Querystring: { userId?: string } }>, reply)
      if (!userId) return
      const dir = profile(userId).ccProjects
      const items = readTranscript(
        req.params.slug,
        req.params.id,
        { limit: req.query.limit ? Number(req.query.limit) : undefined },
        dir
      )
      return { items, usage: readUsage(req.params.slug, req.params.id, dir) }
    }
  )

  app.get<{ Querystring: { userId?: string; slug?: string; id?: string } }>(RUNNER_CC_WATCH_PATH, async (req, reply) => {
    const userId = requireUserId(req, reply)
    if (!userId) return
    const slug = req.query.slug ?? ''
    const id = req.query.id ?? ''
    if (!slug || !id) return reply.code(400).send({ error: 'bad_request', message: 'slug и id обязательны' })
    const res = sseHeaders(reply)
    const stop = watchTranscriptFromOffset(
      slug,
      id,
      lastEventId(req),
      (items, nextOffset) => sendSse(res, nextOffset, { items }),
      profile(userId).ccProjects
    )
    req.raw.on('close', stop)
  })

  app.get<{ Querystring: { userId?: string } }>(RUNNER_CX_PROJECTS_PATH, async (req, reply) => {
    const userId = requireUserId(req, reply)
    if (!userId) return
    return listCxProjects(profile(userId).codexSessions)
  })

  app.get<{ Querystring: { userId?: string; cwd?: string } }>(RUNNER_CX_SESSIONS_PATH, async (req, reply) => {
    const userId = requireUserId(req, reply)
    if (!userId) return
    return listCxSessions(req.query.cwd ?? '', profile(userId).codexSessions)
  })

  app.get<{ Querystring: { userId?: string; id?: string; limit?: string } }>(RUNNER_CX_TRANSCRIPT_PATH, async (req, reply) => {
    const userId = requireUserId(req, reply)
    if (!userId) return
    const dir = profile(userId).codexSessions
    const id = req.query.id ?? ''
    const items = readCxTranscript(id, { limit: req.query.limit ? Number(req.query.limit) : undefined }, dir)
    return { items, usage: readCxUsage(id, dir) }
  })

  app.get<{ Querystring: { userId?: string; id?: string } }>(RUNNER_CX_WATCH_PATH, async (req, reply) => {
    const userId = requireUserId(req, reply)
    if (!userId) return
    const id = req.query.id ?? ''
    if (!id) return reply.code(400).send({ error: 'bad_request', message: 'id обязателен' })
    const res = sseHeaders(reply)
    const stop = watchCxTranscriptFromOffset(
      id,
      lastEventId(req),
      (items, nextOffset) => sendSse(res, nextOffset, { items }),
      profile(userId).codexSessions
    )
    req.raw.on('close', stop)
  })

  app.addHook('onClose', async () => runs.cancelAll())

  return app
}
