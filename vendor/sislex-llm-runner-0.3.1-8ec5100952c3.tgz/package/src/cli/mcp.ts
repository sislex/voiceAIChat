// Получение списка MCP-серверов через `claude mcp list`. Ошибки/недоступность CLI
// деградируют к пустому списку (фича необязательная, не должна ронять UI).

import { execFile } from 'node:child_process'
import { cliProfileEnv } from './cliProfiles.js'
import { parseMcpList, type McpServer } from '@sislex/runner-contracts'

export type ExecFileFn = (
  cmd: string,
  args: string[],
  cb: (err: unknown, stdout: string) => void
) => void

const defaultExec: ExecFileFn = (cmd, args, cb) =>
  execFile(cmd, args, { timeout: 8000 }, (err, stdout) => cb(err, stdout ?? ''))

/** Запускает `claude mcp list` и парсит вывод; при ошибке — []. */
export function listMcpServers(exec: ExecFileFn = defaultExec, bin = 'claude'): Promise<McpServer[]> {
  return new Promise((resolve) => {
    try {
      exec(bin, ['mcp', 'list'], (err, stdout) => {
        // Даже при ненулевом коде пытаемся распарсить stdout — там бывает список.
        void err
        resolve(parseMcpList(stdout || ''))
      })
    } catch {
      resolve([])
    }
  })
}

/** Inspect only the caller-selected user's runner profile, never the Core host. */
export function listProfileMcpServers(home: string, bin: string): Promise<McpServer[]> {
  return listMcpServers((command, args, callback) => {
    execFile(command, args, {
      timeout: 8000,
      maxBuffer: 1024 * 1024,
      cwd: home,
      env: cliProfileEnv(home)
    }, (error, stdout) => callback(error, stdout ?? ''))
  }, bin)
}
