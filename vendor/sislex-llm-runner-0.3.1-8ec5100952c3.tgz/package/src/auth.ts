// Chat applications authenticate with service credentials; end-user authorization
// remains upstream. The legacy master credential is retained for safe migration.

import { timingSafeEqual } from 'node:crypto'
import type { FastifyInstance, FastifyRequest } from 'fastify'
import type { ServiceTokenStore } from './serviceTokens.js'

type RunnerIdentity = { kind: 'master' | 'preview' } | { kind: 'service'; tokenId: string; application: string }

declare module 'fastify' {
  interface FastifyRequest { runnerIdentity: RunnerIdentity | null }
}

/** Токен из заголовка `Authorization: Bearer <token>`. */
export function bearerToken(req: FastifyRequest): string | undefined {
  const header = req.headers['authorization']
  if (typeof header !== 'string') return undefined
  const match = /^Bearer\s+(.+)$/i.exec(header)
  return match ? match[1] : undefined
}

/** Сравнение за постоянное время: токен долгоживущий, побайтовый подбор ему не нужен. */
export function tokenMatches(expected: string, given: string | undefined): boolean {
  if (!expected || !given) return false
  const a = Buffer.from(expected, 'utf8')
  const b = Buffer.from(given, 'utf8')
  if (a.length !== b.length) return false
  return timingSafeEqual(a, b)
}

/** All v1 requests need a master, managed service, or narrowly scoped preview credential. */
export function registerRunnerAuth(app: FastifyInstance, token: string, previewAccepts?: (token: string | undefined) => boolean,
  serviceTokens?: ServiceTokenStore): void {
  app.decorateRequest('runnerIdentity', null)
  app.addHook('onRequest', async (req, reply) => {
    if (!req.url.startsWith('/v1/')) return
    const bearer = bearerToken(req)
    if (tokenMatches(token, bearer)) { req.runnerIdentity = { kind: 'master' }; return }
    const service = serviceTokens?.authenticate(bearer, req.ip)
    if (service) {
      req.runnerIdentity = { kind: 'service', tokenId: service.id, application: service.application }
      return
    }
    if (req.method === 'POST' && req.url === '/v1/run' && previewAccepts?.(bearer)) {
      req.runnerIdentity = { kind: 'preview' }
      return
    }
    await reply.code(401).send({ error: 'unauthorized' })
    return reply
  })
}
