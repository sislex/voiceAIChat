import { createCipheriv, createDecipheriv, createHash, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto'
import { closeSync, existsSync, lstatSync, mkdirSync, openSync, readFileSync, writeFileSync } from 'node:fs'
import { isIP } from 'node:net'
import { join, resolve } from 'node:path'
import { DatabaseSync } from 'node:sqlite'

export class TokenCommandError extends Error {}

interface TokenRow {
  id: string
  application: string
  created_at: number
  expires_at: number | null
  revoked_at: number | null
  digest: string | null
  encrypted_secret: string | null
  last_used_at: number | null
  requests: number
}

export interface ServiceTokenInfo {
  id: string
  application: string
  createdAt: string
  expiresAt: string | null
  revokedAt: string | null
  status: 'active' | 'expired' | 'revoked'
  lastUsedAt: string | null
  requests: number
}

export interface TokenUsage {
  ip: string
  firstUsedAt: string
  lastUsedAt: string
  requests: number
}

const digest = (value: string | Buffer): string => createHash('sha256').update(value).digest('hex')
const iso = (value: number | null): string | null => value === null ? null : new Date(value).toISOString()
const tokenPattern = /^llmr_([a-f0-9]{32})_[A-Za-z0-9_-]{43}$/
const ADMIN_SESSION_MS = 30 * 60_000
const passwordHash = (password: string, salt: string): Buffer => scryptSync(password, salt, 32, { N: 65536, r: 8, p: 1, maxmem: 96 * 1024 * 1024 })
interface AdminRow { salt: string; password_hash: string; failures: number; locked_until: number }

function assertPrivate(path: string, directory = false): void {
  const stat = lstatSync(path)
  if ((directory ? !stat.isDirectory() : !stat.isFile()) || stat.isSymbolicLink() ||
      (stat.mode & 0o077) !== 0 || (!directory && stat.nlink !== 1) ||
      (process.getuid && stat.uid !== process.getuid())) {
    throw new TokenCommandError('Token storage must be owned by the current OS user, private (0700/0600), and not symlinked')
  }
}

/** Local SQLite transactions make CLI mutations visible to the live server without reloads. */
export class ServiceTokenStore {
  private readonly db: DatabaseSync
  private readonly key: Buffer

  constructor(directory: string, private readonly now: () => number = Date.now) {
    const dir = resolve(directory)
    mkdirSync(dir, { recursive: true, mode: 0o700 })
    assertPrivate(dir, true)
    const file = join(dir, 'tokens.sqlite')
    try { closeSync(openSync(file, 'wx', 0o600)) }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error }
    for (const path of [file, `${file}-wal`, `${file}-shm`, join(dir, 'encryption.key')]) {
      if (existsSync(path)) assertPrivate(path)
    }
    this.db = new DatabaseSync(file)
    try {
      this.db.exec('PRAGMA busy_timeout=5000; PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA foreign_keys=ON;')
      this.key = this.transaction(() => {
        const version = this.db.prepare('PRAGMA user_version').get()!.user_version
        if (version !== 0 && version !== 1 && version !== 2) throw new TokenCommandError('Unsupported token store version')
        this.db.exec(`
          CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL) STRICT;
          CREATE TABLE IF NOT EXISTS tokens (
            id TEXT PRIMARY KEY, application TEXT NOT NULL, created_at INTEGER NOT NULL,
            expires_at INTEGER, revoked_at INTEGER, digest TEXT, encrypted_secret TEXT,
            last_used_at INTEGER, requests INTEGER NOT NULL DEFAULT 0
          ) STRICT;
          CREATE TABLE IF NOT EXISTS token_usage (
            token_id TEXT NOT NULL REFERENCES tokens(id), ip TEXT NOT NULL,
            first_used_at INTEGER NOT NULL, last_used_at INTEGER NOT NULL, requests INTEGER NOT NULL,
            PRIMARY KEY (token_id, ip)
          ) STRICT;
          CREATE TABLE IF NOT EXISTS administrator (
            id INTEGER PRIMARY KEY CHECK(id=1), salt TEXT NOT NULL, password_hash TEXT NOT NULL,
            failures INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0
          ) STRICT;
          CREATE TABLE IF NOT EXISTS admin_sessions (digest TEXT PRIMARY KEY, expires_at INTEGER NOT NULL) STRICT;
          PRAGMA user_version=2;
        `)
        const stored = this.db.prepare("SELECT value FROM metadata WHERE key='encryption_key_digest'").get()
        const keyPath = join(dir, 'encryption.key')
        if (!existsSync(keyPath)) {
          if (stored) throw new TokenCommandError('Encryption key is missing; restore it from the private backup')
          writeFileSync(keyPath, randomBytes(32), { flag: 'wx', mode: 0o600 })
        }
        assertPrivate(keyPath)
        const key = readFileSync(keyPath)
        if (key.length !== 32 || (stored && stored.value !== digest(key))) {
          throw new TokenCommandError('Encryption key does not match this token store')
        }
        this.db.prepare("INSERT OR IGNORE INTO metadata(key,value) VALUES ('encryption_key_digest',?)").run(digest(key))
        return key
      })
    } catch (error) {
      this.db.close()
      throw error
    }
  }

  private transaction<T>(action: () => T): T {
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const result = action()
      this.db.exec('COMMIT')
      return result
    } catch (error) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  adminConfigured(): boolean { return !!this.db.prepare('SELECT id FROM administrator WHERE id=1').get() }

  private validatePassword(password: string): void {
    if (password.length < 12 || Buffer.byteLength(password) > 1024 || /[\r\n\0]/.test(password)) {
      throw new TokenCommandError('Use a password of at least 12 characters and at most 1024 bytes, without line breaks')
    }
  }

  initializeAdmin(password: string): void {
    this.validatePassword(password)
    const salt = randomBytes(32).toString('hex'), hash = passwordHash(password, salt).toString('hex')
    this.transaction(() => {
      if (this.adminConfigured()) throw new TokenCommandError('Administrator already initialized; use admin password')
      this.db.prepare('INSERT INTO administrator(id,salt,password_hash) VALUES (1,?,?)').run(salt, hash)
    })
  }

  private verifyAdminPassword(password: string): boolean {
    const row = this.db.prepare('SELECT * FROM administrator WHERE id=1').get() as unknown as AdminRow | undefined
    if (!row) throw new TokenCommandError('Administrator is not initialized; run admin init')
    if (row.locked_until > this.now()) throw new TokenCommandError('Administrator login is temporarily locked; try again later')
    const valid = Buffer.byteLength(password) <= 1024 && timingSafeEqual(passwordHash(password, row.salt), Buffer.from(row.password_hash, 'hex'))
    if (!valid) {
      const failures = row.failures + 1
      const lockedUntil = failures >= 5 ? this.now() + Math.min(300_000, 30_000 * 2 ** Math.min(failures - 5, 4)) : 0
      this.db.prepare('UPDATE administrator SET failures=?,locked_until=? WHERE id=1').run(failures, lockedUntil)
      return false
    }
    this.db.exec('UPDATE administrator SET failures=0,locked_until=0 WHERE id=1')
    return true
  }

  loginAdmin(password: string): string {
    const session = this.transaction(() => {
      if (!this.verifyAdminPassword(password)) return undefined
      const now = this.now()
      this.db.prepare('DELETE FROM admin_sessions WHERE expires_at<=?').run(now)
      if ((this.db.prepare('SELECT count(*) AS n FROM admin_sessions').get()!.n as number) >= 100) {
        throw new TokenCommandError('Too many administrator sessions; close a session or wait for expiry')
      }
      const credential = randomBytes(32).toString('hex')
      this.db.prepare('INSERT INTO admin_sessions(digest,expires_at) VALUES (?,?)').run(digest(credential), now + ADMIN_SESSION_MS)
      return credential
    })
    if (!session) throw new TokenCommandError('Invalid administrator password')
    return session
  }

  requireAdmin(session: string | undefined): void {
    if (!this.adminConfigured()) throw new TokenCommandError('Administrator is not initialized; run admin init')
    const row = session && /^[a-f0-9]{64}$/.test(session)
      ? this.db.prepare('SELECT expires_at FROM admin_sessions WHERE digest=?').get(digest(session)) : undefined
    if (!row || (row.expires_at as number) <= this.now()) throw new TokenCommandError('Administrator session expired or missing; run admin login')
  }

  logoutAdmin(session: string): void { this.db.prepare('DELETE FROM admin_sessions WHERE digest=?').run(digest(session)) }

  changeAdminPassword(current: string, replacement: string): void {
    this.validatePassword(replacement)
    const changed = this.transaction(() => {
      if (!this.verifyAdminPassword(current)) return false
      const salt = randomBytes(32).toString('hex')
      this.db.prepare('UPDATE administrator SET salt=?,password_hash=? WHERE id=1').run(salt, passwordHash(replacement, salt).toString('hex'))
      this.db.exec('DELETE FROM admin_sessions')
      return true
    })
    if (!changed) throw new TokenCommandError('Invalid administrator password')
  }

  private row(id: string): TokenRow {
    const row = this.db.prepare('SELECT * FROM tokens WHERE id=?').get(id) as unknown as TokenRow | undefined
    if (!row) throw new TokenCommandError('Token not found')
    return row
  }

  private info(row: TokenRow): ServiceTokenInfo {
    return {
      id: row.id, application: row.application, createdAt: iso(row.created_at)!,
      expiresAt: iso(row.expires_at), revokedAt: iso(row.revoked_at),
      status: row.revoked_at !== null ? 'revoked' : row.expires_at !== null && row.expires_at <= this.now() ? 'expired' : 'active',
      lastUsedAt: iso(row.last_used_at), requests: row.requests
    }
  }

  private aad(row: Pick<TokenRow, 'id' | 'application' | 'created_at' | 'expires_at'>): Buffer {
    return Buffer.from(JSON.stringify([row.id, row.application, row.created_at, row.expires_at]))
  }

  create(application: string, expiresAt: number | null): ServiceTokenInfo {
    if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,79}$/.test(application)) {
      throw new TokenCommandError('Application must be a 1-80 character name using letters, digits, dot, underscore or hyphen')
    }
    const now = this.now()
    if (expiresAt !== null && (!Number.isSafeInteger(expiresAt) || expiresAt <= now || expiresAt > 8.64e15)) {
      throw new TokenCommandError('Expiration must be a future timestamp, or explicitly never')
    }
    const id = randomBytes(16).toString('hex')
    const secret = `llmr_${id}_${randomBytes(32).toString('base64url')}`
    const row = { id, application, created_at: now, expires_at: expiresAt }
    const iv = randomBytes(12)
    const cipher = createCipheriv('aes-256-gcm', this.key, iv)
    cipher.setAAD(this.aad(row))
    const encrypted = Buffer.concat([cipher.update(secret, 'utf8'), cipher.final()])
    const stored = Buffer.concat([iv, cipher.getAuthTag(), encrypted]).toString('base64')
    this.db.prepare('INSERT INTO tokens(id,application,created_at,expires_at,digest,encrypted_secret) VALUES (?,?,?,?,?,?)')
      .run(id, application, now, expiresAt, digest(secret), stored)
    return this.show(id)
  }

  list(includeRevoked = false): ServiceTokenInfo[] {
    const rows = this.db.prepare(`SELECT * FROM tokens ${includeRevoked ? '' : 'WHERE revoked_at IS NULL'} ORDER BY created_at, id`).all()
    return rows.map(row => this.info(row as unknown as TokenRow))
  }

  show(id: string): ServiceTokenInfo { return this.info(this.row(id)) }

  /** Only the explicit local copy command decrypts credentials; metadata never includes them. */
  copy(id: string): string {
    const row = this.row(id)
    if (this.info(row).status !== 'active' || !row.encrypted_secret) throw new TokenCommandError('Only active tokens can be copied')
    const stored = Buffer.from(row.encrypted_secret, 'base64')
    const decipher = createDecipheriv('aes-256-gcm', this.key, stored.subarray(0, 12))
    decipher.setAuthTag(stored.subarray(12, 28))
    decipher.setAAD(this.aad(row))
    const secret = Buffer.concat([decipher.update(stored.subarray(28)), decipher.final()]).toString('utf8')
    if (digest(secret) !== row.digest) throw new TokenCommandError('Token integrity check failed')
    return secret
  }

  revoke(id: string): ServiceTokenInfo {
    this.row(id)
    // Retain attribution and IP history, but remove the usable credential from live rows.
    this.db.prepare('UPDATE tokens SET revoked_at=?, digest=NULL, encrypted_secret=NULL WHERE id=? AND revoked_at IS NULL')
      .run(this.now(), id)
    return this.show(id)
  }

  usage(id: string): TokenUsage[] {
    this.row(id)
    return this.db.prepare('SELECT ip, first_used_at, last_used_at, requests FROM token_usage WHERE token_id=? ORDER BY last_used_at DESC, ip')
      .all(id).map(row => ({ ip: row.ip as string, firstUsedAt: iso(row.first_used_at as number)!,
        lastUsedAt: iso(row.last_used_at as number)!, requests: row.requests as number }))
  }

  authenticate(secret: string | undefined, peerIp: string): ServiceTokenInfo | undefined {
    const match = secret && tokenPattern.exec(secret)
    if (!match) return undefined
    // Ignore forwarded headers: this is the actual peer, possibly a Docker gateway or proxy.
    const ip = peerIp.startsWith('::ffff:') && isIP(peerIp.slice(7)) === 4 ? peerIp.slice(7) : peerIp
    if (!isIP(ip)) throw new Error('Invalid socket peer address')
    return this.transaction(() => {
      const row = this.db.prepare('SELECT * FROM tokens WHERE id=?').get(match[1]) as unknown as TokenRow | undefined
      if (!row || this.info(row).status !== 'active' || !row.digest ||
          !timingSafeEqual(Buffer.from(row.digest, 'hex'), Buffer.from(digest(secret!), 'hex'))) return undefined
      const now = this.now()
      this.db.prepare('UPDATE tokens SET last_used_at=?, requests=requests+1 WHERE id=?').run(now, row.id)
      this.db.prepare(`INSERT INTO token_usage(token_id,ip,first_used_at,last_used_at,requests) VALUES (?,?,?,?,1)
        ON CONFLICT(token_id,ip) DO UPDATE SET last_used_at=excluded.last_used_at, requests=requests+1`)
        .run(row.id, ip, now, now)
      return this.info({ ...row, last_used_at: now, requests: row.requests + 1 })
    })
  }

  close(): void { this.db.close() }
}
