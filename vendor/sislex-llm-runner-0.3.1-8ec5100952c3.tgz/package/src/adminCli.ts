import { createInterface } from 'node:readline/promises'
import { fileURLToPath } from 'node:url'
import { loadRunnerConfig } from './config.js'
import { readPassword } from './consolePassword.js'
import { ServiceTokenStore, TokenCommandError } from './serviceTokens.js'
import { runTokenCli } from './tokenCli.js'

const HELP = `Local runner administrator console:
  admin init       Set and confirm the first administrator password
  admin login      Open a token-management console (30-minute session)
  admin password   Change the password; requires the current password
  admin status     Show whether the administrator has been initialized

Passwords are entered without echo. No password flags or environment variables
are accepted. In the console use: create, list, show, copy, usage, delete,
password, help, and logout. Tokens are for chat backends, not individual users.
`

export interface AdminTerminal {
  password(label: string): Promise<string>
  line(label: string): Promise<string | null>
  write(value: string): void
}

const terminal: AdminTerminal = {
  password: readPassword,
  async line(label) {
    if (!process.stdin.isTTY || !process.stderr.isTTY) throw new TokenCommandError('An interactive administrator terminal is required')
    const reader = createInterface({ input: process.stdin, output: process.stderr, terminal: true, historySize: 0 })
    try { return await reader.question(label) }
    catch { return null }
    finally { reader.close() }
  },
  write: value => { process.stdout.write(value) }
}

async function newPassword(io: AdminTerminal): Promise<string> {
  const password = await io.password('New administrator password: ')
  if (await io.password('Confirm password: ') !== password) throw new TokenCommandError('Passwords do not match')
  return password
}

async function changePassword(store: ServiceTokenStore, io: AdminTerminal): Promise<void> {
  const current = await io.password('Current administrator password: ')
  const replacement = await newPassword(io)
  store.changeAdminPassword(current, replacement)
  io.write('Administrator password changed; all administrator sessions have been revoked. Service tokens are unchanged.\n')
}

export async function runAdminCli(args: string[], directory: string, io: AdminTerminal = terminal): Promise<void> {
  if (!args.length || args[0] === '--help' || args[0] === 'help') { io.write(HELP); return }
  if (args.length !== 1 || !['init', 'login', 'password', 'status'].includes(args[0])) {
    throw new TokenCommandError('Usage: admin init|login|password|status (passwords must not be passed as arguments)')
  }
  const store = new ServiceTokenStore(directory)
  try {
    if (args[0] === 'status') { io.write(JSON.stringify({ initialized: store.adminConfigured() }) + '\n'); return }
    if (args[0] === 'init') {
      if (store.adminConfigured()) throw new TokenCommandError('Administrator already initialized; use admin password')
      store.initializeAdmin(await newPassword(io))
      io.write('Administrator initialized. Run admin login to manage tokens.\n')
      return
    }
    if (!store.adminConfigured()) throw new TokenCommandError('Administrator is not initialized; run admin init')
    if (args[0] === 'password') { await changePassword(store, io); return }
    const session = store.loginAdmin(await io.password('Administrator password: '))
    io.write('Administrator console open for up to 30 minutes. Type help or logout.\n')
    try {
      while (true) {
        store.requireAdmin(session)
        const line = await io.line('runner> ')
        if (line === null || line.trim() === 'logout' || line.trim() === 'exit') break
        store.requireAdmin(session)
        const command = line.trim().split(/\s+/).filter(Boolean)
        if (!command.length) continue
        try {
          if (command[0] === 'password' && command.length === 1) { await changePassword(store, io); break }
          runTokenCli(command[0] === 'tokens' ? command.slice(1) : command, directory, value => io.write(value), session)
        } catch (error) {
          io.write((error instanceof TokenCommandError ? error.message : 'Operation failed; check token storage integrity') + '\n')
        }
      }
    } finally { store.logoutAdmin(session); io.write('Administrator logged out.\n') }
  } finally { store.close() }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  try { await runAdminCli(process.argv.slice(2), loadRunnerConfig().tokenStoreDir!) }
  catch (error) {
    console.error(error instanceof TokenCommandError ? error.message : 'Administrator operation failed; check local store permissions and integrity')
    process.exitCode = 1
  }
}
