import { TokenCommandError } from './serviceTokens.js'

/** Passwords are read only from a terminal, never argv, environment, stdin pipes, or logs. */
export function readPassword(label: string): Promise<string> {
  const input = process.stdin
  if (!input.isTTY || !process.stderr.isTTY) throw new TokenCommandError('An interactive terminal is required for administrator passwords')
  return new Promise((resolve, reject) => {
    const wasRaw = input.isRaw
    let value = ''
    const finish = (error?: Error) => {
      input.removeListener('data', onData)
      input.removeListener('end', onEnd)
      input.removeListener('error', onError)
      process.removeListener('SIGTERM', onEnd)
      input.setRawMode(wasRaw)
      input.pause()
      process.stderr.write('\n')
      if (error) reject(error); else resolve(value)
    }
    const onEnd = () => finish(new TokenCommandError('Password entry cancelled'))
    const onError = () => finish(new TokenCommandError('Password terminal failed'))
    const onData = (data: string) => {
      for (const character of data) {
        if (character === '\u0003' || character === '\u0004') { onEnd(); return }
        if (character === '\r' || character === '\n') { finish(); return }
        if (character === '\u007f' || character === '\b') { value = Array.from(value).slice(0, -1).join(''); continue }
        if (character >= ' ' && character !== '\u007f') value += character
        if (Buffer.byteLength(value) > 1024) { finish(new TokenCommandError('Password is too long')); return }
      }
    }
    process.stderr.write(label)
    input.setEncoding('utf8')
    input.setRawMode(true)
    input.on('data', onData)
    input.once('end', onEnd)
    input.once('error', onError)
    process.once('SIGTERM', onEnd)
    input.resume()
  })
}
