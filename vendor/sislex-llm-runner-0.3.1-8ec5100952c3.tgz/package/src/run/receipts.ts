import { createRequire } from 'node:module'
import { createHash } from 'node:crypto'
import type { DatabaseSync as SqliteDatabase } from 'node:sqlite'
import { parseLlmAccountingContext, type LlmAccountingContext, type LlmExecutionReceipt, type LlmRunBody, type TurnUsage } from '@sislex/runner-contracts'

const { DatabaseSync } = createRequire(import.meta.url)('node:sqlite') as typeof import('node:sqlite')
type Row = { owner: string; fingerprint: string; receipt: string }
export interface RunObservation {
  starting(): void
  line(value: string): void
  finished(code: number | null): void
  notStarted(): void
}

function canonical(value: unknown): string {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']'
  if (value && typeof value === 'object') return '{' + Object.entries(value).filter(([, v]) => v !== undefined)
    .sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => JSON.stringify(k) + ':' + canonical(v)).join(',') + '}'
  return JSON.stringify(value)
}

/** A dedicated durable store; one runner process owns each file/profile set. */
export class RunReceipts {
  private db: SqliteDatabase
  constructor(filename: string, private now: () => number = Date.now) {
    this.db = new DatabaseSync(filename)
    this.db.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=10000;
      CREATE TABLE IF NOT EXISTS execution_receipts (
        id TEXT PRIMARY KEY, owner TEXT NOT NULL, fingerprint TEXT NOT NULL, receipt TEXT NOT NULL);`)
    // Restart cannot prove whether the old child exited or emitted a final usage event.
    for (const row of this.db.prepare('SELECT id, receipt FROM execution_receipts').all()) {
      const receipt = JSON.parse(String(row.receipt)) as LlmExecutionReceipt
      if (receipt.state === 'claimed' || receipt.state === 'running') {
        receipt.state = 'uncertain'; receipt.updatedAt = this.now()
        this.save(receipt)
      }
    }
  }
  close(): void { this.db.close() }
  has(id: string): boolean { return !!this.db.prepare('SELECT 1 FROM execution_receipts WHERE id=?').get(id) }
  get(owner: string, id: string): LlmExecutionReceipt | undefined {
    const row = this.db.prepare('SELECT receipt FROM execution_receipts WHERE id=? AND owner=?').get(id, owner)
    return row ? JSON.parse(String(row.receipt)) as LlmExecutionReceipt : undefined
  }
  private save(receipt: LlmExecutionReceipt): void {
    this.db.prepare('UPDATE execution_receipts SET receipt=? WHERE id=?').run(JSON.stringify(receipt), receipt.runId)
  }
  /** Fence delayed delivery before resolving a missing execution as no-spawn. */
  fence(owner: string, context: LlmAccountingContext, kind: 'claude' | 'codex'): LlmExecutionReceipt {
    const checked = parseLlmAccountingContext(context)
    this.db.exec('BEGIN IMMEDIATE')
    try {
      if (this.has(checked.operationId)) {
        const previous = this.get(owner, checked.operationId)
        if (!previous || canonical(previous.context) !== canonical(checked) || previous.kind !== kind) throw Error('execution_replay_conflict')
        this.db.exec('COMMIT'); return previous
      }
      const receipt: LlmExecutionReceipt = { version: 1, runId: checked.operationId, context: checked, kind,
        state: 'not_started', createdAt: this.now(), updatedAt: this.now(), finalUsage: false }
      this.db.prepare('INSERT INTO execution_receipts VALUES (?,?,?,?)').run(checked.operationId, owner, 'fenced', JSON.stringify(receipt))
      this.db.exec('COMMIT'); return receipt
    } catch (error) { this.db.exec('ROLLBACK'); throw error }
  }
  /** Store only a fingerprint of the complete request; it may contain credentials/prompts. */
  claim(owner: string, body: LlmRunBody, baseline?: TurnUsage): { receipt: LlmExecutionReceipt; fresh: boolean } {
    const context = parseLlmAccountingContext(body.accounting)
    if (!body.runId || body.runId !== context.operationId) throw Error('accounting_run_id_mismatch')
    const hash = createHash('sha256').update(canonical(body)).digest('hex')
    this.db.exec('BEGIN IMMEDIATE')
    try {
      const previous = this.db.prepare('SELECT * FROM execution_receipts WHERE id=?').get(body.runId) as Row | undefined
      if (previous) {
        if (previous.owner !== owner || previous.fingerprint !== hash) throw Error('execution_replay_conflict')
        this.db.exec('COMMIT')
        return { receipt: JSON.parse(previous.receipt), fresh: false }
      }
      const receipt: LlmExecutionReceipt = { version: 1, runId: body.runId, context, kind: body.kind,
        state: 'claimed', createdAt: this.now(), updatedAt: this.now(), finalUsage: false,
        ...(body.model ? { model: body.model } : {}), ...(baseline ? { baseline: { ...baseline } } : {}) }
      this.db.prepare('INSERT INTO execution_receipts VALUES (?,?,?,?)').run(body.runId, owner, hash, JSON.stringify(receipt))
      this.db.exec('COMMIT')
      return { receipt, fresh: true }
    } catch (error) { this.db.exec('ROLLBACK'); throw error }
  }
  observe(owner: string, id: string): RunObservation {
    const receipt = this.get(owner, id)
    if (!receipt || receipt.state !== 'claimed') throw Error('execution_not_claimed')
    const update = (state?: LlmExecutionReceipt['state']) => {
      if (state) receipt.state = state
      receipt.updatedAt = this.now(); this.save(receipt)
    }
    let terminal = false
    return {
      starting: () => update('running'),
      notStarted: () => { terminal = true; receipt.finalUsage = false; update('not_started') },
      line: value => {
        if (terminal) return
        let event: Record<string, unknown>
        try { event = JSON.parse(value) } catch { return }
        if (!event || typeof event !== 'object') return
        if (receipt.kind === 'claude' && event.type === 'system' && event.subtype === 'init' && typeof event.model === 'string') {
          receipt.model = event.model; update(); return
        }
        const final = receipt.kind === 'claude' ? event.type === 'result' : event.type === 'turn.completed'
        if (!final) return
        const usage = numericUsage(event.usage, receipt.kind)
        // Invalid/missing totals remain visible as uncertain; never infer a free execution.
        receipt.finalUsage = usage !== undefined
        receipt.usage = usage
        delete receipt.providerCostUsd
        if (typeof event.model === 'string' && event.model) receipt.model = event.model
        if (receipt.kind === 'claude' && typeof event.total_cost_usd === 'number' && Number.isFinite(event.total_cost_usd) && event.total_cost_usd >= 0) {
          receipt.providerCostUsd = String(event.total_cost_usd)
        }
        update()
      },
      finished: code => {
        if (terminal) return
        terminal = true; receipt.exitCode = code
        update('finished')
      }
    }
  }
}

/** Codex input includes cached reads; Claude categories are already disjoint. */
export function numericUsage(value: unknown, kind: 'claude' | 'codex'): TurnUsage | undefined {
  if (!value || typeof value !== 'object') return undefined
  const input = value as Record<string, unknown>
  const fields = kind === 'claude'
    ? ['input_tokens', 'output_tokens', 'cache_read_input_tokens', 'cache_creation_input_tokens']
    : ['input_tokens', 'output_tokens', 'cached_input_tokens', 'cache_write_input_tokens']
  const numbers = fields.map((key, index) => input[key] ?? (index >= 2 ? 0 : undefined))
  if (numbers.some(v => typeof v !== 'number' || !Number.isSafeInteger(v) || v < 0)) return undefined
  const [inputTokens, outputTokens, cacheReadTokens, cacheCreationTokens] = numbers as number[]
  if (kind === 'codex' && inputTokens < cacheReadTokens) return undefined
  return { inputTokens, outputTokens, cacheReadTokens, cacheCreationTokens }
}
