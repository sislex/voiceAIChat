import { fileURLToPath } from 'node:url'
import { loadRunnerConfig } from './config.js'
import { ServiceTokenStore, TokenCommandError } from './serviceTokens.js'
import { readPassword } from './consolePassword.js'

const HELP = `Local chat-application token administration (run as the runner OS user).
Initialize with admin init, then use admin login for an interactive console.
Standalone commands prompt for the administrator password on every invocation.

  tokens create --app chat-production --expires-in 90d
  tokens create --app chat-staging --expires-at 2027-01-01T00:00:00Z
  tokens create --app chat-production --expires-in never
  tokens list [--all]
  tokens show <id>
  tokens copy <id>
  tokens usage <id>
  tokens delete <id>

Metadata is JSON; only copy prints a secret to stdout. Pipe it to a secret
manager or clipboard and avoid terminal/session recording. create never prints
the secret. Durations: positive integer followed by m, h, or d. --all includes
revoked tokens. delete revokes new requests but does not interrupt active runs.
Storage: VC_RUNNER_TOKEN_DIR, default VC_DATA_DIR/service-auth. Never share this
directory over a network filesystem. Applications, not end users, own tokens.
`

export function expiration(options: Map<string, string>, now: number): number | null {
  const duration = options.get('--expires-in')
  const absolute = options.get('--expires-at')
  if ((duration === undefined) === (absolute === undefined)) {
    throw new TokenCommandError('Choose exactly one of --expires-in or --expires-at')
  }
  if (duration === 'never') return null
  let value: number
  if (duration !== undefined) {
    const match = /^([1-9][0-9]*)(m|h|d)$/.exec(duration)
    if (!match) throw new TokenCommandError('Use a positive duration such as 30m, 24h, 90d, or never')
    value = now + Number(match[1]) * ({ m: 60_000, h: 3_600_000, d: 86_400_000 }[match[2]]!)
  } else {
    if (!/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$/.test(absolute!)) {
      throw new TokenCommandError('Use an explicit UTC timestamp: YYYY-MM-DDTHH:mm:ssZ')
    }
    value = Date.parse(absolute!)
    if (Number.isFinite(value) && new Date(value).toISOString().replace('.000Z', 'Z') !== absolute) value = NaN
  }
  if (!Number.isSafeInteger(value) || value <= now || value > 8.64e15) throw new TokenCommandError('Expiration must be in the future')
  return value
}

export function runTokenCli(args: string[], directory: string, write: (value: string) => void = value => process.stdout.write(value), adminSession?: string): void {
  const [command, ...rest] = args
  if (!command || command === 'help' || command === '--help') { write(HELP); return }
  const options = new Map<string, string>()
  if (command === 'create') {
    for (let i = 0; i < rest.length; i += 2) {
      const name = rest[i]
      if (!['--app', '--expires-in', '--expires-at'].includes(name) || options.has(name) || !rest[i + 1]) {
        throw new TokenCommandError('Invalid or duplicate create option; run tokens --help')
      }
      options.set(name, rest[i + 1])
    }
    if (!options.has('--app')) throw new TokenCommandError('--app is required')
    expiration(options, Date.now())
  } else if (command === 'list') {
    if (rest.length && (rest.length !== 1 || rest[0] !== '--all')) throw new TokenCommandError('Usage: tokens list [--all]')
  } else if (['show', 'copy', 'usage', 'delete'].includes(command)) {
    if (rest.length !== 1 || !/^[a-f0-9]{32}$/.test(rest[0])) throw new TokenCommandError('Supply exactly one token ID from tokens list')
  } else throw new TokenCommandError('Unknown command; run tokens --help')

  const store = new ServiceTokenStore(directory)
  try {
    store.requireAdmin(adminSession)
    if (command === 'copy') { write(store.copy(rest[0]) + '\n'); return }
    const result = command === 'create' ? store.create(options.get('--app')!, expiration(options, Date.now()))
      : command === 'list' ? store.list(rest[0] === '--all')
      : command === 'show' ? store.show(rest[0])
      : command === 'usage' ? { token: store.show(rest[0]), addresses: store.usage(rest[0]) }
      : store.revoke(rest[0])
    write(JSON.stringify(result, null, 2) + '\n')
  } finally { store.close() }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  let admin: ServiceTokenStore | undefined
  let session: string | undefined
  try {
    const args = process.argv.slice(2), directory = loadRunnerConfig().tokenStoreDir!
    if (!args.length || args[0] === 'help' || args[0] === '--help') runTokenCli(args, directory)
    else {
      admin = new ServiceTokenStore(directory)
      if (!admin.adminConfigured()) throw new TokenCommandError('Administrator is not initialized; run admin init')
      session = admin.loginAdmin(await readPassword('Administrator password: '))
      runTokenCli(args, directory, undefined, session)
    }
  }
  catch (error) {
    console.error(error instanceof TokenCommandError ? error.message : 'Token operation failed; check local store permissions and integrity')
    process.exitCode = 1
  }
  finally { if (session) admin?.logoutAdmin(session); admin?.close() }
}
