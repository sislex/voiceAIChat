# llm-runner

Standalone authenticated HTTP executor for Claude Code and Codex CLI. It owns CLI
processes and profile storage, not conversations, billing, feature workflows, or
the application database. No voiceAIChat checkout is required.

## Development

Requires Node.js 22.13+ and npm (including built-in `node:sqlite`). Run `npm ci`, then `npm run gate` (typecheck and all
runner/compatibility tests). Set `VC_RUNNER_TOKEN` and run `npm start`. The default
port is 8790. Real provider calls are not made by the test suite.

## Compatibility boundary

The first extraction retains the v1 HTTP protocol and profile paths from
`sislex/voiceAIChat` commit `7ed88f46a79e7e1957a3461ad73e6c62f4ba9741`.
`src/` comes from `apps/llm-runner/src`; `packages/contracts/src` contains a frozen
dependency closure of `packages/shared/src` plus its adjacent tests. Original
comments and prompt text are retained to make provenance and behavior auditable.
This compatibility package intentionally still includes product hints and their
transitive types. It is not yet a clean, minimal, separately published SDK.

`test/fixtures/core` freezes the same upstream commit's actual `RemoteLlmClient`,
stream sinks, and four client-to-runner HTTP contract tests. Only import paths
are adapted. These fixtures are test-only and are excluded from the image.

Do not automatically synchronize it on every core release. Treat wire changes as
versioned contracts, test both consumers, and move product prompt construction
out of the executor in a subsequent migration. Core's legacy local CLI fallback
has not been removed by this repository.

- `POST /v1/run`: raw NDJSON stdout/stderr/exit frames, with `x-run-id`.
- `DELETE /v1/run/:id`: explicit cancellation.
- `GET /v1/health`: binaries, login status, active runs, release metadata.
- `GET /v1/mcp/servers?userId=...`: profile-scoped Claude MCP inventory. Requires
  a master or backend service token; preview grants cannot access it. Missing CLI
  or an empty inventory returns `[]` as before. Execution uses the user's profile
  directory/environment and an eight-second timeout; Core must not spawn a CLI.
- Existing `/v1/auth/status`, `/v1/files/read`, `/v1/fs/cc/*`, `/v1/fs/cx/*`, and
  scoped preview-grant routes remain compatible.
- `GET/PUT /v1/admin/lifecycle`: additive master-token-only drain control.
  PUT `{ "draining": true }` rejects new runs with 503 and leaves existing
  streams running; `{ "draining": false }` reopens admission.

All v1 routes require a bearer token. Preview grants permit only scoped run
creation, not lifecycle administration or profile access.

## Console token administration

Only chat application backends receive service tokens. Make and other product
applications call the chat backend; browsers and end users never receive these
credentials. Run these commands locally as the same OS user as the runner:

```bash
npm run --silent admin -- init
npm run --silent admin -- login
# Inside the authenticated console:
create --app chat-production --expires-in 90d
list
show <id>
usage <id>
copy <id>
delete <id>
logout
# Change the administrator password (prompts for current/new/confirmation):
npm run --silent admin -- password
```

For one-off commands, each invocation prompts for the administrator password:

```bash
npm run --silent tokens -- create --app chat-production --expires-in 90d
npm run --silent tokens -- list
npm run --silent tokens -- show <id>
npm run --silent tokens -- usage <id>
npm run --silent tokens -- copy <id>
npm run --silent tokens -- delete <id>
```

Creation returns metadata only. `copy` explicitly prints the secret for secure
transfer; avoid recorded terminals and logs. `list --all` includes revoked tokens.
Choose an explicit expiry (`--expires-in 90d`, `--expires-at 2027-01-01T00:00:00Z`,
or `--expires-in never`). Creation and revocation apply without restarting the
server. Revocation denies subsequent requests; it does not cancel admitted runs.

The administrator password is entered without echo. Login opens a 30-minute
console session; password changes invalidate all admin sessions, not service
tokens. OS/SSH access is still required, and there is no public HTTP management
endpoint. See
[operations](docs/operations.md#service-token-administration) for Docker commands,
storage, IP attribution, backups, and the legacy master-token migration boundary.

## Deployment

See [operations](docs/operations.md). `compose.yaml` owns a separate project and
fresh volumes by default. It publishes **only on loopback**. Remote deployments
must use a private network/VPN or authenticated TLS proxy, not plaintext public
8790. Never commit bearer tokens, provider credentials, or profile archives.

`compose.production.yaml` is the current-host migration layout: two independent
services, external legacy profile volumes, and private `runner-work` /
`runner-personal` aliases on the existing core network. It has no published ports.
`deploy/core-external.override.yaml` removes the legacy services and their
dependency edges from core Compose using `!reset`. Validate this boundary with
`npm run test:compose` (requires Docker Compose 2.24.4+). The single-service
`scripts/deploy.sh` is for `compose.yaml`, not the two-service production layout.

The image pins Claude `2.1.274` and Codex `0.154.0`, matching the inspected current
production runners. Fastify is patched to `5.12.5`; dependency resolution is
locked. CI gates the code, checks production dependency advisories, builds the
image, and runs authenticated container smoke checks without provider accounts.

## Important limits

**v1 still cancels a CLI when its core HTTP connection closes.** Independent
containers prevent unnecessary runner rebuilds, but do not by themselves make
active turns survive a core restart. Durable events, reconnect/ack, core run
rehydration, and MCP continuity need a separate protocol migration.

Drain is an administrative deployment gate, not a user-facing pause queue. An
uncoordinated caller gets a terminal 503; the current core does not automatically
pause/retry it. Do not drain the production traffic target until admission is
paused upstream or a replacement is routed for new turns.

The main application still contains legacy runner services in its Compose file.
Starting this independent stack does not remove them or route existing traffic.
Migration must explicitly remove those ownership links before reusing aliases.
