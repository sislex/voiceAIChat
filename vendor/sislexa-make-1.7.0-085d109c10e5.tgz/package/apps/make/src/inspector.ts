import { INSPECTOR_SOURCE_LOCATOR } from './inspectorSource.js'

/** Browser source shared by workshop previews and external stand frames. */
export const MAKE_INSPECTOR_SOURCE = `(function(){
  var locateElement = ${INSPECTOR_SOURCE_LOCATOR};
  if (window.parent === window && !new URLSearchParams(location.search).has('makeScheme')) return;
  // Консоль превью: console.* и ошибки страницы уходят родителю — панель показывает их под превью.
  (function(){
    var levels = ['log','info','warn','error'];
    function fmt(a){ try { return typeof a === 'string' ? a : (a instanceof Error ? (a.message + (a.stack ? ' | ' + a.stack.split(String.fromCharCode(10)).slice(1,3).join(' | ') : '')) : JSON.stringify(a)); } catch(e){ return String(a); } }
    function send(level, args){ try { window.parent.postMessage({ type: 'vc-make.console', level: level, text: Array.prototype.map.call(args, fmt).join(' ').slice(0, 2000), at: Date.now() }, '*'); } catch(e){} }
    levels.forEach(function(l){ var orig = console[l]; console[l] = function(){ send(l, arguments); if (orig) orig.apply(console, arguments); }; });
    window.addEventListener('error', function(e){ send('error', [e.message + (e.filename ? ' (' + e.filename.split('/').pop() + ':' + e.lineno + ')' : '')]); });
    window.addEventListener('unhandledrejection', function(e){ send('error', ['Unhandled rejection: ' + fmt(e.reason)]); });
    // Сеть превью: fetch и XHR → родителю (метод, адрес, статус, время) — панель «Сеть» под превью.
    function net(kind, method, url, status, ok, started){ try { window.parent.postMessage({ type: 'vc-make.network', kind: kind, method: String(method || 'GET').toUpperCase(), url: String(url).slice(0, 500), status: status, ok: ok, ms: Math.round(performance.now() - started), at: Date.now() }, '*'); } catch(e){} }
    var origFetch = window.fetch;
    if (origFetch) window.fetch = function(input, init){ var started = performance.now(); var url = typeof input === 'string' ? input : (input && input.url) || String(input); var method = (init && init.method) || (input && input.method) || 'GET'; var slow = window.__vcSlowMs || 0; var p = origFetch.apply(this, arguments); if (slow > 0) p = p.then(function(res){ return new Promise(function(done){ setTimeout(function(){ done(res); }, slow); }); }); return p.then(function(res){ net('fetch', method, url, res.status, res.ok, started); return res; }, function(err){ net('fetch', method, url, 0, false, started); throw err; }); };
    var XO = window.XMLHttpRequest && window.XMLHttpRequest.prototype.open, XS = window.XMLHttpRequest && window.XMLHttpRequest.prototype.send;
    if (XO && XS) { window.XMLHttpRequest.prototype.open = function(method, url){ this.__vc = { method: method, url: url }; return XO.apply(this, arguments); }; window.XMLHttpRequest.prototype.send = function(){ var x = this, started = performance.now(); x.addEventListener('loadend', function(){ var m = x.__vc || {}; net('xhr', m.method, m.url, x.status, x.status >= 200 && x.status < 400, started); }); return XS.apply(this, arguments); }; }
  })();
  var on = false, hovered = null, box = null;
  function ensureBox(){ if (box) return box; box = document.createElement('div'); box.setAttribute('data-vc-make-box',''); box.style.cssText='position:fixed;pointer-events:none;border:2px solid #4f7cff;background:rgba(79,124,255,.12);z-index:2147483647;border-radius:3px;transition:all .05s'; document.documentElement.appendChild(box); return box }
  // Линейки (roadmap-4 п.19): бейдж W×H у рамки и расстояния до краёв родителя — четыре направляющие с подписями.
  var sizeBadge = null, guides = null;
  function ensureRulers(){ if (sizeBadge) return; sizeBadge = document.createElement('div'); sizeBadge.setAttribute('data-vc-make-box',''); sizeBadge.style.cssText='position:fixed;pointer-events:none;z-index:2147483647;font:11px/1.4 ui-monospace,Menlo,monospace;background:#4f7cff;color:#fff;padding:1px 6px;border-radius:3px;white-space:nowrap'; document.documentElement.appendChild(sizeBadge); guides = []; for (var i = 0; i < 4; i++) { var g = document.createElement('div'); g.setAttribute('data-vc-make-box',''); g.style.cssText='position:fixed;pointer-events:none;z-index:2147483647;background:rgba(255,120,0,.9);display:none'; var lbl = document.createElement('span'); lbl.style.cssText='position:absolute;font:10px/1.2 ui-monospace,Menlo,monospace;background:#ff7800;color:#fff;padding:0 3px;border-radius:2px;white-space:nowrap'; g.appendChild(lbl); document.documentElement.appendChild(g); guides.push(g); } }
  function guide(i, x, y, vertical, len, text){ var g = guides[i]; if (Math.round(len) < 2) { g.style.display = 'none'; return; } g.style.display='block'; g.style.left=x+'px'; g.style.top=y+'px'; g.style.width=(vertical ? 1 : len)+'px'; g.style.height=(vertical ? len : 1)+'px'; var l = g.firstChild; l.textContent = text; if (!vertical) { l.style.left = (len/2 - 12) + 'px'; l.style.top = '-14px'; } else { l.style.left = '3px'; l.style.top = (len/2 - 7) + 'px'; } }
  function placeRulers(el, r){ ensureRulers(); sizeBadge.style.display='block'; sizeBadge.textContent = Math.round(r.width) + ' × ' + Math.round(r.height); var above = r.top > 18; sizeBadge.style.left = r.left + 'px'; sizeBadge.style.top = (above ? r.top - 18 : r.bottom + 2) + 'px'; var p = el.parentElement; if (!p || p === document.documentElement) { guides.forEach(function(g){ g.style.display='none'; }); return; } var pr = p.getBoundingClientRect(); var cx = r.left + r.width/2, cy = r.top + r.height/2; guide(0, cx, pr.top, true, r.top - pr.top, Math.round(r.top - pr.top) + 'px'); guide(1, cx, r.bottom, true, pr.bottom - r.bottom, Math.round(pr.bottom - r.bottom) + 'px'); guide(2, pr.left, cy, false, r.left - pr.left, Math.round(r.left - pr.left) + 'px'); guide(3, r.right, cy, false, pr.right - r.right, Math.round(pr.right - r.right) + 'px'); }
  function place(el){ var r = el.getBoundingClientRect(), b = ensureBox(); b.style.left=r.left+'px'; b.style.top=r.top+'px'; b.style.width=r.width+'px'; b.style.height=r.height+'px'; b.style.display='block'; placeRulers(el, r) }
  function hide(){ if (box) box.style.display='none'; if (sizeBadge) { sizeBadge.style.display='none'; guides.forEach(function(g){ g.style.display='none'; }); } }
  function selectorOf(el){ var parts=[]; while (el && el.nodeType===1 && el !== document.documentElement){ var s = el.tagName.toLowerCase(); if (el.id){ parts.unshift(s+'#'+el.id); break } var cls = (el.className && typeof el.className==='string') ? el.className.trim().split(/\\s+/).filter(Boolean).slice(0,2) : []; if (cls.length) s += '.'+cls.join('.'); var p = el.parentElement; if (p){ var same = Array.prototype.filter.call(p.children, function(c){ return c.tagName===el.tagName }); if (same.length>1) s += ':nth-of-type('+(Array.prototype.indexOf.call(same, el)+1)+')' } parts.unshift(s); el = p } return parts.join(' > ') }
  function onMove(e){ if (!on) return; var el = e.target; if (!el || el.hasAttribute && el.hasAttribute('data-vc-make-box')) return; hovered = el; place(el) }
  var STYLE_PROPS = ['color','background-color','font-size','font-weight','text-align','padding','margin','border-radius'];
  var selectedEl = null, savedInline = '';
  function computedOf(el){ var cs = getComputedStyle(el), out = {}; STYLE_PROPS.forEach(function(p){ out[p] = cs.getPropertyValue(p); }); return out; }
  function onClick(e){ if (!on) return; e.preventDefault(); e.stopPropagation(); var el = e.target; if (!el) return; if (selectedEl && selectedEl !== el) selectedEl.style.cssText = savedInline; selectedEl = el; savedInline = el.style.cssText; var html = el.outerHTML || ''; var located = locateElement(el, { href: location.href }); window.parent.postMessage(Object.assign({ type: 'vc-make.selected', selector: selectorOf(el), tag: el.tagName.toLowerCase(), text: (el.innerText||'').trim().slice(0,200), html: html.slice(0,1500), id: el.id || '', className: (typeof el.className === 'string' ? el.className : ''), styles: computedOf(el) }, located), '*'); }
  // Панель стилей родителя: применяем значения inline (мгновенно), сброс возвращает исходный style.
  window.addEventListener('message', function(e){ if (e.source !== window.parent) return; var d = e.data; if (!d || d.type !== 'vc-make.style' || !selectedEl) return; selectedEl.style.cssText = savedInline; var v = d.values || {}; Object.keys(v).forEach(function(k){ if (v[k]) selectedEl.style.setProperty(k, v[k]); }); });
  window.addEventListener('message', function(e){ if (e.source !== window.parent) return; var d = e.data; if (!d || d.type !== 'vc-make.inspect') return; on = !!d.enabled; document.documentElement.style.cursor = on ? 'crosshair' : ''; if (!on) hide() });
  // Правка текста прямо в превью (roadmap-4 п.17): двойной клик в режиме инспектора делает элемент редактируемым,
  // Enter/blur завершают; изменённый текст уходит панели как vc-make.text — она ищет его в исходнике и записывает файл.
  var editingEl = null, editingBefore = '';
  function finishEdit(){ if (!editingEl) return; var el = editingEl; editingEl = null; el.removeAttribute('contenteditable'); el.style.outline = ''; var after = (el.innerText || '').trim(); if (after && after !== editingBefore) { try { window.parent.postMessage({ type: 'vc-make.text', selector: selectorOf(el), before: editingBefore, after: after }, '*'); } catch (err) {} } }
  function onDbl(e){ if (!on) return; var el = e.target; if (!el || el === document.body || el === document.documentElement) return; if (el.children.length > 3) return; e.preventDefault(); e.stopPropagation(); editingEl = el; editingBefore = (el.innerText || '').trim(); el.setAttribute('contenteditable', 'plaintext-only'); if (el.contentEditable !== 'plaintext-only') el.setAttribute('contenteditable', 'true'); el.style.outline = '2px solid #4f7cff'; el.focus(); el.addEventListener('blur', finishEdit, { once: true }); el.addEventListener('keydown', function(ev){ if (ev.key === 'Enter' && !ev.shiftKey) { ev.preventDefault(); el.blur(); } if (ev.key === 'Escape') { el.innerText = editingBefore; el.blur(); } }); }
  document.addEventListener('dblclick', onDbl, true);
  // Перетаскивание секций (roadmap-4 п.18): Alt+зажатие в режиме инспектора ведёт элемент среди соседей,
  // отпускание над соседом переставляет узел в DOM и шлёт vc-make.reorder — панель переносит фрагмент в исходнике.
  // outerHTML снимаем до наших inline-правок (opacity/boxShadow): после них браузер пересериализует style и фрагмент не совпадёт с исходником.
  var dragEl = null, dragOver = null, dragPos = 'after', dragHtml = '', overHtml = '';
  function siblingUnder(x, y){ if (!dragEl || !dragEl.parentElement) return null; var kids = dragEl.parentElement.children; for (var i = 0; i < kids.length; i++) { var k = kids[i]; if (k === dragEl || (k.hasAttribute && k.hasAttribute('data-vc-make-box'))) continue; var r = k.getBoundingClientRect(); if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) { dragPos = (y - r.top) > r.height / 2 ? 'after' : 'before'; return k; } } return null; }
  function onDragDown(e){ if (!on || !e.altKey || e.button !== 0) return; var el = e.target; if (!el || el === document.body || el === document.documentElement || !el.parentElement) return; e.preventDefault(); e.stopPropagation(); dragEl = el; dragHtml = el.outerHTML; el.style.opacity = '0.5'; document.documentElement.style.cursor = 'grabbing'; }
  function onDragMove(e){ if (!dragEl) return; var over = siblingUnder(e.clientX, e.clientY); if (dragOver && dragOver !== over) dragOver.style.boxShadow = ''; if (over && over !== dragOver) overHtml = over.outerHTML; dragOver = over; if (over) over.style.boxShadow = dragPos === 'after' ? 'inset 0 -3px 0 #4f7cff' : 'inset 0 3px 0 #4f7cff'; }
  function onDragUp(){ if (!dragEl) return; var el = dragEl, over = dragOver, pos = dragPos; dragEl = null; dragOver = null; el.style.opacity = ''; document.documentElement.style.cursor = on ? 'crosshair' : ''; if (over) { over.style.boxShadow = ''; var moved = dragHtml, target = overHtml; if (pos === 'after') over.after(el); else over.before(el); try { window.parent.postMessage({ type: 'vc-make.reorder', moved: moved.slice(0, 20000), target: target.slice(0, 20000), position: pos }, '*'); } catch (err) {} } }
  document.addEventListener('mousedown', onDragDown, true); document.addEventListener('mousemove', onDragMove, true); document.addEventListener('mouseup', onDragUp, true);
  document.addEventListener('mousemove', onMove, true);
  document.addEventListener('click', onClick, true);
  // Телефон (roadmap-3 п.4): пальцем нет hover — подсвечиваем элемент под касанием, тап выбирает (через click).
  document.addEventListener('touchstart', function(e){ if (!on || !e.touches || !e.touches[0]) return; var t = e.touches[0]; var el = document.elementFromPoint(t.clientX, t.clientY); if (el) { hovered = el; place(el); } }, { capture: true, passive: true });
  window.addEventListener('scroll', function(){ if (on && hovered) place(hovered) }, true);
  // Состояние страницы (скролл, hash) — родитель восстановит его после перезагрузки превью по make.changed.
  var scrollTimer = null;
  function reportState(){ try { window.parent.postMessage({ type: 'vc-make.state', x: window.scrollX, y: window.scrollY, hash: location.hash }, '*'); } catch(e){} }
  window.addEventListener('scroll', function(){ clearTimeout(scrollTimer); scrollTimer = setTimeout(reportState, 120); }, true);
  window.addEventListener('hashchange', reportState);
  window.addEventListener('message', function(e){ if (e.source !== window.parent) return; var d = e.data; if (!d || d.type !== 'vc-make.restore') return; if (d.hash && d.hash !== location.hash) { try { location.hash = d.hash; } catch(err){} } if (typeof d.y === 'number') { window.scrollTo(d.x || 0, d.y); setTimeout(function(){ window.scrollTo(d.x || 0, d.y); }, 250); } });
  // Preserve compound media conditions while emulating both CSS and matchMedia consumers.
  var envScheme = new URLSearchParams(location.search).get('makeScheme') || 'auto';
  if (['auto', 'dark', 'light'].indexOf(envScheme) < 0) envScheme = 'auto';
  var nativeMatchMedia = window.matchMedia.bind(window), schemeQueries = [];
  function schemeQuery(query){ return envScheme === 'auto' ? query : query.replace(/[(]prefers-color-scheme[ ]*:[ ]*(dark|light)[)]/gi, function(_, value){ return value.toLowerCase() === envScheme ? '(min-width: 0px)' : '(max-width: 0px)'; }); }
  window.matchMedia = function(query){
    query = String(query);
    if (query.indexOf('prefers-color-scheme') < 0) return nativeMatchMedia(query);
    var source = nativeMatchMedia(query), target = new EventTarget(), previous = nativeMatchMedia(schemeQuery(query)).matches;
    Object.defineProperties(target, { media: { value: query }, matches: { get: function(){ return nativeMatchMedia(schemeQuery(query)).matches; } } });
    target.onchange = null;
    target.addListener = function(listener){ target.addEventListener('change', listener); };
    target.removeListener = function(listener){ target.removeEventListener('change', listener); };
    function refresh(){ var next = target.matches; if (next === previous) return; previous = next; var event = new Event('change'); Object.defineProperties(event, { matches: { value: next }, media: { value: query } }); target.dispatchEvent(event); if (typeof target.onchange === 'function') target.onchange.call(target, event); }
    source.addEventListener('change', refresh); window.addEventListener('resize', refresh); schemeQueries.push(refresh);
    return target;
  };
  function applyScheme(scheme){
    if (['auto', 'dark', 'light'].indexOf(scheme) < 0) return;
    envScheme = scheme; document.documentElement.style.colorScheme = scheme === 'auto' ? '' : scheme;
    function media(list){ var original = list.__vcSchemeOriginal || (list.__vcSchemeOriginal = list.mediaText); if (original.indexOf('prefers-color-scheme') >= 0) list.mediaText = schemeQuery(original); }
    function visit(rules){ for (var j = 0; j < rules.length; j++) { var rule = rules[j]; if (rule.media) media(rule.media); try { if (rule.cssRules) visit(rule.cssRules); } catch(error){} } }
    for (var i = 0; i < document.styleSheets.length; i++) { var sheet = document.styleSheets[i]; try { if (sheet.media) media(sheet.media); visit(sheet.cssRules); } catch(error){} }
    schemeQueries.forEach(function(refresh){ refresh(); });
  }
  applyScheme(envScheme);
  document.addEventListener('load', function(){ applyScheme(envScheme); }, true);
  new MutationObserver(function(){ applyScheme(envScheme); }).observe(document.documentElement, { childList: true, subtree: true, characterData: true });
  // Эмуляция состояний (roadmap-4 п.20): правила с :hover/:focus/:active клонируются под классы .vc-force-*, класс ставится выбранному элементу.
  var forcedRulesDone = false, forcedEl = null;
  function cloneStateRules(){ if (forcedRulesDone) return; forcedRulesDone = true; var sheets = document.styleSheets; var extra = []; for (var i = 0; i < sheets.length; i++) { var rules; try { rules = sheets[i].cssRules; } catch(e) { continue; } for (var j = 0; j < rules.length; j++) { var r = rules[j]; if (!r.selectorText || !/:(hover|focus|focus-visible|focus-within|active)(?![a-z-])/.test(r.selectorText)) continue; var sel = r.selectorText.replace(/:hover(?![a-z-])/g, '.vc-force-hover').replace(/:focus(-visible|-within)?(?![a-z-])/g, '.vc-force-focus').replace(/:active(?![a-z-])/g, '.vc-force-active'); extra.push(sel + '{' + r.style.cssText + '}'); } } if (extra.length) { var st = document.createElement('style'); st.setAttribute('data-vc-make-box',''); st.textContent = extra.join(String.fromCharCode(10)); document.head.appendChild(st); } }
  function applyForcedState(state){ if (forcedEl) { forcedEl.classList.remove('vc-force-hover','vc-force-focus','vc-force-active'); } forcedEl = selectedEl; if (!state || !forcedEl) return; cloneStateRules(); forcedEl.classList.add('vc-force-' + state); }
  var motionStyle = null;
  function applyReducedMotion(onOff){ if (!motionStyle) { motionStyle = document.createElement('style'); motionStyle.setAttribute('data-vc-make-box',''); motionStyle.textContent = '*,*::before,*::after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important;scroll-behavior:auto!important}'; } if (onOff) { if (!motionStyle.parentNode) document.head.appendChild(motionStyle); } else if (motionStyle.parentNode) motionStyle.parentNode.removeChild(motionStyle); var sheets = document.styleSheets; for (var i = 0; i < sheets.length; i++) { var rules; try { rules = sheets[i].cssRules; } catch(e) { continue; } for (var j = 0; j < rules.length; j++) { var r = rules[j]; if (!r.media) continue; var orig = r.__vcMedia || (r.__vcMedia = r.media.mediaText); if (orig.indexOf('prefers-reduced-motion') < 0) continue; if (!onOff) { r.media.mediaText = orig; continue; } r.media.mediaText = orig.indexOf('no-preference') >= 0 ? 'not all' : 'all'; } } }
  window.__vcSlowMs = 0;
  window.addEventListener('message', function(e){ if (e.source !== window.parent) return; var d = e.data; if (!d || d.type !== 'vc-make.env') return; if (d.scheme) applyScheme(d.scheme); if (typeof d.lang === 'string') { if (d.lang) document.documentElement.setAttribute('lang', d.lang); else document.documentElement.removeAttribute('lang'); } if ('state' in d) applyForcedState(d.state || null); if ('reducedMotion' in d) applyReducedMotion(!!d.reducedMotion); if ('slowMs' in d) window.__vcSlowMs = Number(d.slowMs) || 0; });
  // Комментарии (п.32): подсветка элемента по селектору и нумерованные метки, которые едут за элементами.
  var pins = [], pinLayer = null;
  function ensurePinLayer(){ if (pinLayer) return pinLayer; pinLayer = document.createElement('div'); pinLayer.setAttribute('data-vc-make-pins', ''); pinLayer.style.cssText = 'position:fixed;left:0;top:0;width:0;height:0;z-index:2147483646;pointer-events:none;'; document.documentElement.appendChild(pinLayer); return pinLayer; }
  function placePins(){ if (!pinLayer) return; pinLayer.innerHTML = ''; pins.forEach(function(p){ var el = null; try { el = document.querySelector(p.selector); } catch(e){} if (!el) return; var r = el.getBoundingClientRect(); var b = document.createElement('div'); b.textContent = String(p.n); b.title = p.text || ''; b.style.cssText = 'position:absolute;left:' + Math.max(0, r.right - 10) + 'px;top:' + Math.max(0, r.top - 10) + 'px;min-width:20px;height:20px;padding:0 6px;border-radius:10px;background:' + (p.resolved ? '#8a8f98' : '#e5484d') + ';color:#fff;font:600 12px/20px system-ui,sans-serif;text-align:center;box-shadow:0 1px 4px rgba(0,0,0,.3);pointer-events:none;'; pinLayer.appendChild(b); }); }
  window.addEventListener('message', function(e){ if (e.source !== window.parent) return; var d = e.data; if (!d || d.type !== 'vc-make.pins') return; pins = Array.isArray(d.items) ? d.items : []; ensurePinLayer(); placePins(); });
  window.addEventListener('scroll', function(){ if (pins.length) placePins(); }, true);
  window.addEventListener('resize', function(){ if (pins.length) placePins(); });
  window.addEventListener('message', function(e){ if (e.source !== window.parent) return; var d = e.data; if (!d || d.type !== 'vc-make.highlight' || !d.selector) return; var el = null; try { el = document.querySelector(d.selector); } catch(err){} if (!el) return; try { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } catch(err){ el.scrollIntoView(); } var prev = el.style.outline, prevOff = el.style.outlineOffset; el.style.outline = '3px solid #e5484d'; el.style.outlineOffset = '2px'; setTimeout(function(){ el.style.outline = prev; el.style.outlineOffset = prevOff; }, 1600); });
  window.parent.postMessage({ type: 'vc-make.ready' }, '*');
})();
`

export const MAKE_INSPECTOR_SCRIPT = `<script data-vc-make-inspector>\n${MAKE_INSPECTOR_SOURCE}\n</script>`

