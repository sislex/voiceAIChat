import { registerProjectRoutes } from './projectRoutes.js'
import { registerStandRoutes } from './stand.js'
import type { MakeLocale } from '@voicechat/make-contracts/localization'
import { publicText, publicLanguageSelect } from './publicLocale.js'
// Make REST API: conversation project state, file CRUD, snapshots, restore, and template reset for
// the code editor. Project files for iframe previews and ZIP exports are served under
// /api/preview/make/... with preview-cookie authentication, as with Web Reader, because iframes and
// download links cannot send Bearer headers. Routes check conversation access and notify the owner
// through make.changed.

import { createHash } from 'node:crypto'
import type { MakeComment, MakeProjectFileEntry, MakeProjectLinkInfo, MakeProjectLinkStatus, MakeProjectNotes, MakeProjectPullResult } from '@voicechat/make-contracts/make'
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import { SlidingWindowLimiter } from '@voicechat/shared'
import { MAKE_PROJECT_SYNC_MAX_FILES, MAKE_COMMENTS_SYNC_PATH as COMMENTS_SYNC_PATH, MAKE_GALLERY_PAGE, MAKE_PUBLIC_COMMENTS_PAGE, MAKE_SNAPSHOT_PREVIEW, MAKE_PUBLIC_PREFIX, MAKE_SLUG_PREFIX, MAKE_STORIES_PAGE, isMakeTranspiledPath, makeMimeType, normalizeMakePath, MAKE_TESTS_PAGE } from '@voicechat/make-contracts/make'
import { type MockResponse } from '@voicechat/make-contracts'
import { transpileForPreview } from './transpile.js'
import { renderGalleryPage, renderStoriesPage, renderTestsPage, storyUsageSnippets } from './stories.js'
import { readZip, ZipReadError } from './zipRead.js'
import { importFromUrl, ImportUrlError } from './importUrl.js'
import type { MakeCore } from './core.js'
import { MakeError, MakeWorkspaces } from './workspace.js'
import { registerMakeLocalization, requestMakeLocale } from './localization.js'
import type { MakeLibrary } from './library.js'
import type { MakeHub } from './hub.js'
import { isPreviewLinkToken, verifyPreviewLink } from './previewLink.js'
import { MAKE_INSPECTOR_SCRIPT, MAKE_INSPECTOR_SOURCE } from './inspector.js'

export interface MakeRoutesDeps {
  /** All chat, kanban, and machine knowledge comes through this port; see make/core.ts. */
  core: MakeCore
  workspaces: MakeWorkspaces
  hub: MakeHub
  library: MakeLibrary
  /** Import limits can be replaced in tests. */
  importLimiter?: SlidingWindowLimiter
  importUrlLimiter?: SlidingWindowLimiter
  passwordLimiter?: SlidingWindowLimiter
  /** Secret verifying read-only preview links (/p/pv.<token>/); without it such links are rejected. */
  previewLinkSecret?: string
}

/** Showcase usage code (item 28): read the project's story sources; omit the snippet on read errors. */
async function galleryUsage(workspaces: MakeWorkspaces, conversationId: string): Promise<Record<string, Record<string, string>>> {
  const out: Record<string, Record<string, string>> = {}
  for (const f of await workspaces.stories(conversationId).catch(() => [])) {
    // Use read(), since publicFile() returns transpiled JavaScript and snippets need the original
    // JSX.
    const src = await workspaces.read(conversationId, f.path).catch(() => null)
    if (src) out[f.path] = storyUsageSnippets(f.path, src.content)
  }
  return out
}

/** Floating comment button on published pages (item 34): submit name and text to __comments__ without window.prompt. */
function guestCommentsWidget(base: string, locale: MakeLocale): string {
  const t = (key: Parameters<typeof publicText>[1]): string => publicText(locale, key)
  return `<style>[data-vc-guest-comments] [hidden]{display:none!important}</style><div data-vc-guest-comments lang="${locale}" style="position:fixed;right:16px;bottom:16px;z-index:2147483000;font:14px/1.4 system-ui,sans-serif">
<button type="button" data-vc-gc-open style="border:0;border-radius:24px;padding:10px 16px;background:#4f7cff;color:#fff;box-shadow:0 4px 16px rgba(0,0,0,.2);cursor:pointer">${t('comment')}</button>
<form data-vc-gc-form hidden style="width:280px;background:#fff;color:#1a1d23;border-radius:12px;padding:12px;box-shadow:0 8px 30px rgba(0,0,0,.25);display:grid;gap:8px">
<strong>${t('commentTitle')}</strong>${publicLanguageSelect(locale)}
<input name="name" placeholder="${t('name')}" maxlength="60" style="padding:6px 8px;border:1px solid #d5d8e0;border-radius:6px;font:inherit">
<textarea name="text" required rows="3" maxlength="2000" placeholder="${t('feedback')}" style="padding:6px 8px;border:1px solid #d5d8e0;border-radius:6px;font:inherit"></textarea>
<div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" data-vc-gc-cancel style="border:1px solid #d5d8e0;background:#fff;border-radius:6px;padding:6px 10px;font:inherit;cursor:pointer">${t('cancel')}</button><button type="submit" style="border:0;background:#4f7cff;color:#fff;border-radius:6px;padding:6px 12px;font:inherit;cursor:pointer">${t('send')}</button></div>
<small data-vc-gc-status style="color:#666"></small>
</form></div>
<script>(function(){var root=document.querySelector('[data-vc-guest-comments]');if(!root)return;var open=root.querySelector('[data-vc-gc-open]'),form=root.querySelector('[data-vc-gc-form]'),status=root.querySelector('[data-vc-gc-status]');open.addEventListener('click',function(){form.hidden=false;open.hidden=true;form.querySelector('textarea').focus()});root.querySelector('[data-vc-gc-cancel]').addEventListener('click',function(){form.hidden=true;open.hidden=false});form.addEventListener('submit',function(e){e.preventDefault();var fd=new FormData(form);status.textContent=${JSON.stringify(t('sending'))};fetch(${JSON.stringify(base)}+'__comments__',{method:'POST',headers:{'content-type':'application/json'},credentials:'same-origin',body:JSON.stringify({name:fd.get('name'),text:fd.get('text'),elementLabel:document.title||${JSON.stringify(t('page'))}})}).then(function(r){if(!r.ok)throw new Error(r.status===429?${JSON.stringify(t('tooManyComments'))}:${JSON.stringify(t('sendFailed'))});status.textContent=${JSON.stringify(t('thanks'))};form.querySelector('textarea').value='';setTimeout(function(){form.hidden=true;open.hidden=false;status.textContent=''},2500)}).catch(function(err){status.textContent=err.message===${JSON.stringify(t('tooManyComments'))}?err.message:${JSON.stringify(t('sendFailed'))}})})})();</script>`
}


/**
 * The single Make-error-to-HTTP-status mapping used by roughly fifty routes. Exported for the table
 * in make.sendError.test.ts: a mapping error affects the entire Make API, while testing every code
 * through individual routes would duplicate checks. Non-MakeError failures deliberately propagate
 * to Fastify's 500 handler instead of silently becoming 400 responses.
 */
export function sendError(reply: FastifyReply, error: unknown): FastifyReply {
  if (error instanceof MakeError) {
    const status = error.code === 'not_found' ? 404 : error.code === 'too_large' || error.code === 'too_many_files' ? 413 : error.code === 'exists' ? 409 : error.code === 'quota' ? 413 : 400
    return reply.code(status).send({ error: error.message, code: error.code })
  }
  throw error
}

export function registerMakeRoutes(app: FastifyInstance, deps: MakeRoutesDeps): void {
  registerMakeLocalization(app)
  registerProjectRoutes(app, deps.core)
  registerStandRoutes(app, deps.core, deps.workspaces)
  const { core, workspaces, hub, library } = deps
  const inspectorEtag = `"${createHash('sha256').update(MAKE_INSPECTOR_SOURCE).digest('base64url')}"`
  app.get('/api/make/inspector.js', async (req, reply) => {
    reply.header('content-type', 'application/javascript; charset=utf-8')
      .header('cache-control', 'public, max-age=300')
      .header('etag', inspectorEtag)
    if (req.headers['if-none-match'] === inspectorEtag) return reply.code(304).send()
    return reply.send(MAKE_INSPECTOR_SOURCE)
  })
  // The host's authentication preHandler, in core or standalone Make, sets req.user. Read its type
  // structurally to avoid a second FastifyRequest augmentation conflicting with core's declaration.
  const uid = (req: unknown): string => (req as { user?: { name: string } | null }).user?.name ?? ''

  /** Return the user's Make conversation, or 404; inaccessible and missing conversations are indistinguishable. */
  const own = async (userId: string, id: string, reply: FastifyReply): Promise<boolean> => {
    const conversation = await core.conversation(userId, id)
    if (!conversation || conversation.assistantKind !== 'make') {
      void reply.code(404).send({ error: 'conversation not found' })
      return false
    }
    return true
  }  /**
      * Named grants (roadmap-3, item 6): owners have full access; editors can modify files,
      * snapshots, and comments; viewers can only read. Publishing, sharing, clearing, and deletion
      * remain owner-only (own).
      */
  const access = async (userId: string, id: string, reply: FastifyReply, level: 'editor' | 'viewer'): Promise<boolean> => {
    const mine = await core.conversation(userId, id)
    if (mine && mine.assistantKind === 'make') return true
    const owner = await core.conversationOwner(id)
    if (owner) {
      const role = await workspaces.shareRole(id, userId)
      if (role === 'editor' || (role === 'viewer' && level === 'viewer')) return true
      // Every project member can read its linked Make project: task cards refer to the design, so
      // it must open for the whole team.
      if (level === 'viewer' && await core.isProjectViewer(userId, id)) return true
    }
    void reply.code(404).send({ error: 'conversation not found' })
    return false
  }


  app.get<{ Params: { id: string } }>('/api/make/:id', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    try { await workspaces.ensure(req.params.id); return await workspaces.state(req.params.id) } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string }; Querystring: { path?: string } }>('/api/make/:id/file', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    try { return await workspaces.read(req.params.id, req.query.path ?? '') } catch (error) { return sendError(reply, error) }
  })

  app.put<{ Params: { id: string }; Body: { path?: string; content?: string; kind?: 'file' | 'directory'; createOnly?: boolean } }>('/api/make/:id/file', async (req, reply) => {
    const userId = uid(req)
    if (!(await access(userId, req.params.id, reply, 'editor'))) return reply
    const { path, content, kind, createOnly } = req.body ?? {}
    if ((kind !== undefined && kind !== 'file' && kind !== 'directory') || (createOnly !== undefined && typeof createOnly !== 'boolean')) return reply.code(400).send({ error: 'Invalid file operation' })
    if (typeof path !== 'string' || typeof content !== 'string') return reply.code(400).send({ error: 'path и content обязательны' })
    try {
      await workspaces.ensure(req.params.id)
      const state = await workspaces.write(req.params.id, path, content, { kind, createOnly })
      hub.changed(userId, req.params.id, state.rev, [normalizeMakePath(path) ?? path])
      return state
    } catch (error) { return sendError(reply, error) }
  })

  // Binary panel uploads, such as images and fonts, expand by one third in base64; allow extra body
  // size.
  app.post<{ Params: { id: string }; Body: { path?: string; dataBase64?: string } }>('/api/make/:id/upload', { bodyLimit: 4 * 1024 * 1024 }, async (req, reply) => {
    const userId = uid(req)
    if (!(await access(userId, req.params.id, reply, 'editor'))) return reply
    const { path, dataBase64 } = req.body ?? {}
    if (typeof path !== 'string' || typeof dataBase64 !== 'string') return reply.code(400).send({ error: 'path и dataBase64 обязательны' })
    try {
      await workspaces.ensure(req.params.id)
      const state = await workspaces.writeBuffer(req.params.id, path, Buffer.from(dataBase64, 'base64'))
      hub.changed(userId, req.params.id, state.rev, [normalizeMakePath(path) ?? path])
      return state
    } catch (error) { return sendError(reply, error) }
  })

  app.delete<{ Params: { id: string }; Querystring: { path?: string } }>('/api/make/:id/file', async (req, reply) => {
    const userId = uid(req)
    if (!(await access(userId, req.params.id, reply, 'editor'))) return reply
    try {
      const state = await workspaces.delete(req.params.id, req.query.path ?? '')
      hub.changed(userId, req.params.id, state.rev, [req.query.path ?? ''])
      return state
    } catch (error) { return sendError(reply, error) }
  })

  app.post<{ Params: { id: string }; Body: { from?: string; to?: string } }>('/api/make/:id/rename', async (req, reply) => {
    const userId = uid(req)
    if (!(await access(userId, req.params.id, reply, 'editor'))) return reply
    const { from, to } = req.body ?? {}
    if (typeof from !== 'string' || typeof to !== 'string') return reply.code(400).send({ error: 'from и to обязательны' })
    try {
      const state = await workspaces.rename(req.params.id, from, to)
      hub.changed(userId, req.params.id, state.rev, [from, to])
      return state
    } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/snapshots', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    return workspaces.snapshots(req.params.id)
  })

  app.post<{ Params: { id: string }; Body: { label?: string } }>('/api/make/:id/snapshots', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'editor'))) return reply
    try {
      await workspaces.ensure(req.params.id)
      return await workspaces.snapshot(req.params.id, typeof req.body?.label === 'string' ? req.body.label : 'Снимок пользователя')
    } catch (error) { return sendError(reply, error) }
  })

  app.post<{ Params: { id: string; snapshotId: string } }>('/api/make/:id/snapshots/:snapshotId/restore', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    try {
      const state = await workspaces.restore(req.params.id, req.params.snapshotId)
      hub.changed(userId, req.params.id, state.rev, state.files.map((f) => f.path))
      return state
    } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string; snapshotId: string }; Querystring: { compareSnapshotId?: string } }>('/api/make/:id/snapshots/:snapshotId/diff', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { return await workspaces.snapshotDiff(req.params.id, req.params.snapshotId, req.query.compareSnapshotId) } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string; snapshotId: string }; Querystring: { path?: string } }>('/api/make/:id/snapshots/:snapshotId/file', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { return await workspaces.snapshotFile(req.params.id, req.params.snapshotId, req.query.path ?? '') } catch (error) { return sendError(reply, error) }
  })

  app.post<{ Params: { id: string; snapshotId: string }; Body: { path?: string } }>('/api/make/:id/snapshots/:snapshotId/restore-file', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    if (typeof req.body?.path !== 'string') return reply.code(400).send({ error: 'path обязателен' })
    try {
      const state = await workspaces.restoreFile(req.params.id, req.params.snapshotId, req.body.path)
      hub.changed(userId, req.params.id, state.rev, [normalizeMakePath(req.body.path) ?? req.body.path])
      return state
    } catch (error) { return sendError(reply, error) }
  })

  // ZIP import: base64 in JSON supports archives up to about 8 MB, with encoding overhead included
  // in the body limit. Import rate limits (item 39): 10 ZIPs and 20 URLs per user per 10 minutes;
  // return 429 with Retry-After.
  const importLimiter = deps.importLimiter ?? new SlidingWindowLimiter(10, 10 * 60_000)
  const passwordLimiter = deps.passwordLimiter ?? new SlidingWindowLimiter(10, 10 * 60_000)
  // Viewer comments (roadmap-4, item 34): at most 10 per publication and IP address in 10 minutes.
  const guestCommentLimiter = new SlidingWindowLimiter(10, 10 * 60_000)
  const importUrlLimiter = deps.importUrlLimiter ?? new SlidingWindowLimiter(20, 10 * 60_000)
  const limited = (limiter: SlidingWindowLimiter, userId: string, reply: FastifyReply): boolean => {
    const v = limiter.hit(userId)
    if (v.ok) return false
    void reply.code(429).header('retry-after', String(v.retryAfterSec)).send({ error: `Слишком много импортов — повторите через ${v.retryAfterSec} с` })
    return true
  }
  app.post<{ Params: { id: string }; Body: { dataBase64?: string; mode?: string } }>('/api/make/:id/import', { bodyLimit: 12 * 1024 * 1024 }, async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    if (limited(importLimiter, userId, reply)) return reply
    if (typeof req.body?.dataBase64 !== 'string') return reply.code(400).send({ error: 'dataBase64 обязателен' })
    const mode = req.body.mode === 'merge' ? 'merge' : 'replace'
    try {
      const entries = readZip(Buffer.from(req.body.dataBase64, 'base64'))
      const state = await workspaces.importFiles(req.params.id, entries, mode)
      hub.changed(userId, req.params.id, state.rev, state.files.map((f) => f.path))
      return state
    } catch (error) {
      if (error instanceof ZipReadError) return reply.code(400).send({ error: error.message, code: 'bad_zip' })
      return sendError(reply, error)
    }
  })

  app.post<{ Params: { id: string }; Body: { url?: string; mode?: string } }>('/api/make/:id/import-url', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    if (limited(importUrlLimiter, userId, reply)) return reply
    if (typeof req.body?.url !== 'string') return reply.code(400).send({ error: 'url обязателен' })
    const mode = req.body.mode === 'merge' ? 'merge' : 'replace'
    try {
      const files = await importFromUrl(req.body.url)
      const state = await workspaces.importFiles(req.params.id, files, mode)
      hub.changed(userId, req.params.id, state.rev, state.files.map((f) => f.path))
      return state
    } catch (error) {
      if (error instanceof ImportUrlError) return reply.code(400).send({ error: error.message, code: 'bad_url' })
      if (error instanceof Error && !(error instanceof MakeError)) return reply.code(400).send({ error: `Не удалось загрузить страницу: ${error.message}`, code: 'bad_url' })
      return sendError(reply, error)
    }
  })

  app.post<{ Params: { id: string } }>('/api/make/:id/reset', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    try {
      await workspaces.ensure(req.params.id)
      const state = await workspaces.reset(req.params.id)
      hub.changed(userId, req.params.id, state.rev, state.files.map((f) => f.path))
      return state
    } catch (error) { return sendError(reply, error) }
  })

  app.post<{ Params: { id: string }; Body: { snapshotId?: string | null; slug?: string | null; password?: string | null; allowComments?: boolean } | undefined }>('/api/make/:id/publish', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { await workspaces.ensure(req.params.id); return await workspaces.publish(req.params.id, { snapshotId: req.body?.snapshotId ?? null, slug: req.body?.slug, password: req.body?.password, allowComments: typeof req.body?.allowComments === 'boolean' ? req.body.allowComments : undefined }) } catch (error) { return sendError(reply, error) }
  })

  // Project repository synchronization. Copy components and styles from the project machine's
  // working directory into the workshop (pull), edit them here, then send them back (push). Each
  // link retains the hash at copy time for status comparison. Unless force is set, reject pushes
  // when the repository file has changed to avoid overwriting someone else's work.
  const sha256 = (data: Buffer): string => createHash('sha256').update(data).digest('hex')

  /** Relative project path: nonempty, with no .. segments or leading slashes. */
  const safeRelPath = (raw: string): string | null => {
    const path = raw.trim().replace(/\\/g, '/').replace(/^\.\//, '')
    if (!path || path.startsWith('/') || path.includes('..') || path.includes('\0')) return null
    return path
  }

  /** Resolve the Make conversation's project machine: agent, root directory, and availability. Return readable errors. */
  const projectMachine = async (userId: string, conversationId: string): Promise<{ agentId: string; root: string } | { error: string }> => {
    const conversation = await core.conversation(userId, conversationId)
    if (!conversation?.projectId) return { error: 'Чат не привязан к проекту — копировать не из чего.' }
    const project = await core.project(userId, conversation.projectId)
    if (!project) return { error: 'Проект недоступен.' }
    const machines = project.machines.filter((machine) => machine.canUse !== false && machine.path.trim())
    const machine = machines.find((candidate) => candidate.agentId === project.defaultAgentId) ?? machines[0]
    if (!machine) return { error: 'У проекта нет машины с рабочей директорией.' }
    if (!core.machineFs) return { error: 'Файловый мост машин недоступен в этой конфигурации.' }
    if (!await core.machineFs.isOnline(machine.agentId)) return { error: `Машина «${machine.name ?? machine.agentId}» offline.` }
    return { agentId: machine.agentId, root: machine.path.replace(/\/+$/, '') }
  }

  /** Link statuses compare workshop and machine hashes with the hash recorded at copy time. */
  const linkInfos = async (conversationId: string, machine: { agentId: string; root: string }): Promise<MakeProjectLinkInfo[]> => {
    const links = await workspaces.projectLinks(conversationId)
    const out: MakeProjectLinkInfo[] = []
    for (const link of links) {
      const local = await workspaces.readBuffer(conversationId, link.path).catch(() => null)
      const localHash = local ? sha256(local.data) : null
      let remoteHash: string | null = null
      try {
        const result = await core.machineFs!.read(machine.agentId, `${machine.root}/${link.path}`)
        remoteHash = result.dataBase64 !== undefined ? sha256(Buffer.from(result.dataBase64, 'base64')) : null
      } catch { remoteHash = null }
      const status: MakeProjectLinkStatus = localHash === null
        ? 'missing_in_make'
        : remoteHash === null
          ? 'missing_in_project'
          : localHash === link.importedHash && remoteHash === link.importedHash
            ? 'same'
            : localHash !== link.importedHash && remoteHash !== link.importedHash
              ? 'both'
              : localHash !== link.importedHash
                ? 'edited_in_make'
                : 'changed_in_project'
      out.push({ ...link, status })
    }
    return out
  }

  app.get<{ Params: { id: string }; Querystring: { path?: string } }>('/api/make/:id/project-files', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    const machine = await projectMachine(userId, req.params.id)
    if ('error' in machine) return reply.code(409).send({ error: machine.error })
    const rel = typeof req.query.path === 'string' && req.query.path ? safeRelPath(req.query.path) : ''
    if (rel === null) return reply.code(400).send({ error: 'Некорректный путь' })
    try {
      const result = await core.machineFs!.list(machine.agentId, rel ? `${machine.root}/${rel}` : machine.root)
      const entries: MakeProjectFileEntry[] = (result.entries ?? [])
        // Exclude repository infrastructure from Make: hidden entries and node_modules are not
        // components and would clutter the listing.
        .filter((entry) => !entry.name.startsWith('.') && entry.name !== 'node_modules')
        .filter((entry) => entry.kind === 'dir' || entry.kind === 'file')
        .map((entry) => ({ name: entry.name, path: rel ? `${rel}/${entry.name}` : entry.name, kind: entry.kind as 'dir' | 'file', size: entry.size }))
      return entries
    } catch (error) {
      return reply.code(502).send({ error: `Машина не ответила: ${error instanceof Error ? error.message : String(error)}` })
    }
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/project-links', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    const machine = await projectMachine(userId, req.params.id)
    if ('error' in machine) return reply.code(409).send({ error: machine.error })
    return linkInfos(req.params.id, machine)
  })

  app.post<{ Params: { id: string }; Body: { paths?: string[] } }>('/api/make/:id/project-pull', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    const machine = await projectMachine(userId, req.params.id)
    if ('error' in machine) return reply.code(409).send({ error: machine.error })
    const rawPaths = Array.isArray(req.body?.paths) ? req.body.paths : []
    if (!rawPaths.length) return reply.code(400).send({ error: 'Выберите файлы' })
    if (rawPaths.length > MAKE_PROJECT_SYNC_MAX_FILES) return reply.code(400).send({ error: `Не больше ${MAKE_PROJECT_SYNC_MAX_FILES} файлов за раз` })
    const paths: string[] = []
    for (const raw of rawPaths) {
      const path = safeRelPath(String(raw))
      if (!path) return reply.code(400).send({ error: `Некорректный путь: ${String(raw)}` })
      paths.push(path)
    }
    try {
      await workspaces.ensure(req.params.id)
      const files: Array<{ path: string; data: Buffer }> = []
      for (const path of paths) {
        const result = await core.machineFs!.read(machine.agentId, `${machine.root}/${path}`)
        if (result.dataBase64 === undefined) return reply.code(404).send({ error: `«${path}» — не файл или не читается` })
        files.push({ path, data: Buffer.from(result.dataBase64, 'base64') })
      }
      // Merge imports add or update files while preserving the rest of the project.
      const state = await workspaces.importFiles(req.params.id, files, 'merge')
      const now = Date.now()
      const links = await workspaces.projectLinks(req.params.id)
      const byPath = new Map(links.map((link) => [link.path, link]))
      for (const file of files) byPath.set(file.path, { path: file.path, importedHash: sha256(file.data), importedAt: now })
      await workspaces.saveProjectLinks(req.params.id, [...byPath.values()].sort((a, b) => a.path.localeCompare(b.path, 'ru')))
      hub.changed(userId, req.params.id, state.rev, files.map((file) => file.path))
      return { links: await linkInfos(req.params.id, machine), state } satisfies MakeProjectPullResult
    } catch (error) {
      if (error instanceof MakeError) return sendError(reply, error)
      return reply.code(502).send({ error: `Копирование не удалось: ${error instanceof Error ? error.message : String(error)}` })
    }
  })

  // Project task links (design to card). The reverse of /api/projects/:id/tasks/:taskId/designs:
  // the Make panel shows cards linked to the open page and can attach a new one.
  app.get<{ Params: { id: string }; Querystring: { path?: string } }>('/api/make/:id/task-links', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    const path = typeof req.query.path === 'string' ? req.query.path : undefined
    return await core.taskLinks(req.params.id, path)
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/task-links/tasks', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    return await core.linkableTasks(uid(req), req.params.id)
  })

  app.post<{ Params: { id: string }; Body: { taskId?: string; path?: string; label?: string } }>('/api/make/:id/task-links', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    const projectId = await core.conversationProject(req.params.id)
    const taskId = req.body?.taskId
    if (!taskId || !projectId) return reply.code(400).send({ error: 'Make-проект не привязан к проекту' })
    try {
      await core.linkTaskDesign(uid(req), projectId, taskId, { conversationId: req.params.id, path: req.body?.path, label: req.body?.label })
      core.boardChanged(projectId)
      return await core.taskLinks(req.params.id, typeof req.body?.path === 'string' ? req.body.path : undefined)
    } catch (error) { return reply.code(400).send({ error: error instanceof Error ? error.message : String(error) }) }
  })

  app.delete<{ Params: { id: string; linkId: string } }>('/api/make/:id/task-links/:linkId', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    const projectId = await core.conversationProject(req.params.id)
    const link = (await core.taskLinks(req.params.id)).find((l) => l.id === req.params.linkId)
    if (!projectId || !link) return reply.code(404).send({ error: 'Связь не найдена' })
    await core.unlinkTaskDesign(uid(req), projectId, link.taskId, link.id)
    core.boardChanged(projectId)
    return await core.taskLinks(req.params.id)
  })

  // Read-only links inside ChatAI (item 33): owners create or revoke them; any signed-in user can
  // read using the token.
  app.post<{ Params: { id: string } }>('/api/make/:id/share', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { await workspaces.ensure(req.params.id); return await workspaces.createShare(req.params.id) } catch (error) { return sendError(reply, error) }
  })
  app.post<{ Params: { id: string }; Body: { user?: string; role?: 'editor' | 'viewer' | null } | undefined }>('/api/make/:id/share/grants', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    const user = String(req.body?.user ?? '').trim()
    if (user && !await core.userExists(user)) return reply.code(404).send({ error: `Пользователь «${user}» не найден` })
    const role = req.body?.role === 'editor' || req.body?.role === 'viewer' ? req.body.role : null
    try { await workspaces.ensure(req.params.id); return await workspaces.setShareGrant(req.params.id, user, role) } catch (error) { return sendError(reply, error) }
  })
  app.delete<{ Params: { id: string } }>('/api/make/:id/share', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { return await workspaces.revokeShare(req.params.id) } catch (error) { return sendError(reply, error) }
  })
  const sharedConv = async (token: string, reply: FastifyReply): Promise<string | null> => {
    const conversationId = await workspaces.sharedTarget(token)
    if (!conversationId) { void reply.code(404).send({ error: 'Ссылка недействительна или отозвана' }); return null }
    return conversationId
  }
  app.get<{ Params: { token: string } }>('/api/make/shared/:token', async (req, reply) => {
    const conversationId = await sharedConv(req.params.token, reply)
    if (!conversationId) return reply
    try {
      const owner = await core.conversationOwner(conversationId) ?? ''
      const conv = owner ? await core.conversation(owner, conversationId) : null
      const state = await workspaces.state(conversationId)
      const settings = await workspaces.notes(conversationId)
      return { token: req.params.token, stack: settings.stack, uiKit: settings.uiKit, owner, title: conv?.title ?? 'Проект', role: await workspaces.shareRole(conversationId, uid(req)), conversationId, files: state.files, snapshots: state.snapshots, rev: state.rev }
    } catch (error) { return sendError(reply, error) }
  })
  app.get<{ Params: { token: string }; Querystring: { path?: string } }>('/api/make/shared/:token/file', async (req, reply) => {
    const conversationId = await sharedConv(req.params.token, reply)
    if (!conversationId) return reply
    try { return await workspaces.read(conversationId, req.query.path ?? '') } catch (error) { return sendError(reply, error) }
  })
  app.get<{ Params: { token: string } }>('/api/make/shared/:token/stories', async (req, reply) => {
    const conversationId = await sharedConv(req.params.token, reply)
    if (!conversationId) return reply
    try { return { files: await workspaces.stories(conversationId) } } catch (error) { return sendError(reply, error) }
  })
  app.get<{ Params: { token: string; '*': string } }>('/api/preview/make-shared/:token/*', async (req, reply) => {
    const conversationId = await sharedConv(req.params.token, reply)
    if (!conversationId) return reply
    const raw = req.params['*'] || 'index.html'
    const base = `/api/preview/make-shared/${encodeURIComponent(req.params.token)}/`
    const csp = "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:; frame-ancestors 'self'"
    if (raw === MAKE_GALLERY_PAGE) return reply.header('content-type', 'text/html; charset=utf-8').header('cache-control', 'no-store').header('content-security-policy', csp).send(renderGalleryPage(await workspaces.stories(conversationId), base, 'Компоненты', await galleryUsage(workspaces, conversationId), requestMakeLocale(req)))
    if (raw === MAKE_STORIES_PAGE) {
      const q = req.query as { file?: string; story?: string }
      const index = await workspaces.readBuffer(conversationId, 'index.html').catch(() => null)
      return reply.header('content-type', 'text/html; charset=utf-8').header('cache-control', 'no-store').header('content-security-policy', csp).send(renderStoriesPage(q.file ?? '', q.story ?? '', index ? index.data.toString('utf8') : null, requestMakeLocale(req)))
    }
    const path = raw.endsWith('/') ? `${raw}index.html` : raw
    let file
    try { file = await workspaces.readBuffer(conversationId, path) } catch (error) { return sendError(reply, error) }
    if (!file) {
      const mock = await workspaces.resolveMock(conversationId, path, 'GET', false, undefined, req.headers.cookie)
      if (mock) return sendMock(reply, mock)
      return reply.code(404).type('text/plain; charset=utf-8').send(`Файл не найден: ${path}`)
    }
    return reply.header('content-type', makeMimeType(file.path)).header('cache-control', 'no-store').header('x-content-type-options', 'nosniff').header('content-security-policy', csp)
      .send(await previewBody(conversationId, file))
  })

  // Tab presence (roadmap-2, item 14): each tab sends heartbeats; responses and WS events reach all
  // of the owner's sockets.
  app.post<{ Params: { id: string }; Body: { clientId?: string; path?: string | null; editing?: boolean; leave?: boolean } | undefined }>('/api/make/:id/presence', async (req, reply) => {
    const userId = uid(req)
    if (!(await access(userId, req.params.id, reply, 'viewer'))) return reply
    const clientId = String(req.body?.clientId ?? '').slice(0, 64)
    if (!clientId) return reply.code(400).send({ error: 'clientId обязателен' })
    const clients = hub.heartbeat(req.params.id, { clientId, user: userId, path: typeof req.body?.path === 'string' ? req.body.path.slice(0, 300) : null, editing: Boolean(req.body?.editing), at: Date.now() }, Boolean(req.body?.leave))
    hub.broadcastPresence(userId, req.params.id, clients)
    return { clients }
  })

  // Private replies are hydrated only here, after checking ownership separately from access.
  const commentView = async (userId: string, id: string, comments: MakeComment[]) => {
    if (await core.conversationOwner(id) !== userId) return comments
    const replies = await workspaces.ownerReplies(id)
    return comments.map((comment) => ({ ...comment, canReply: true as const, ...(replies[comment.id] !== undefined ? { ownerReply: replies[comment.id] } : {}) }))
  }
  // Comments attached to preview elements (item 32).
  app.get<{ Params: { id: string } }>('/api/make/:id/comments', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    try { await workspaces.ensure(req.params.id); return { comments: await commentView(uid(req), req.params.id, await workspaces.comments(req.params.id)) } } catch (error) { return sendError(reply, error) }
  })
  app.post<{ Params: { id: string }; Body: { selector?: string; elementLabel?: string; text?: string } | undefined }>('/api/make/:id/comments', async (req, reply) => {
    const userId = uid(req)
    if (!(await access(userId, req.params.id, reply, 'editor'))) return reply
    try {
      await workspaces.ensure(req.params.id)
      const comments = await workspaces.addComment(req.params.id, { selector: req.body?.selector ?? '', elementLabel: req.body?.elementLabel ?? '', text: req.body?.text ?? '', author: userId })
      hub.changed(userId, req.params.id, workspaces.rev(req.params.id), [COMMENTS_SYNC_PATH])
      return { comments: await commentView(userId, req.params.id, comments) }
    } catch (error) { return sendError(reply, error) }
  })
  app.patch<{ Params: { id: string; commentId: string }; Body: { resolved?: boolean; text?: string; status?: 'pending' | 'approved'; ownerReply?: string } | undefined }>('/api/make/:id/comments/:commentId', async (req, reply) => {
    const userId = uid(req)
    if (!(await access(userId, req.params.id, reply, 'editor'))) return reply
    try {
      if (req.body?.ownerReply !== undefined) {
        if (await core.conversationOwner(req.params.id) !== userId) return reply.code(404).send({ error: 'conversation not found' })
        if (typeof req.body.ownerReply !== 'string') return reply.code(400).send({ error: 'Invalid owner reply' })
        await workspaces.replyToComment(req.params.id, req.params.commentId, req.body.ownerReply)
      }
      const comments = await workspaces.updateComment(req.params.id, req.params.commentId, { resolved: req.body?.resolved, text: req.body?.text, status: req.body?.status === 'approved' || req.body?.status === 'pending' ? req.body.status : undefined })
      hub.changed(userId, req.params.id, workspaces.rev(req.params.id), [COMMENTS_SYNC_PATH])
      return { comments: await commentView(userId, req.params.id, comments) }
    } catch (error) { return sendError(reply, error) }
  })
  app.delete<{ Params: { id: string; commentId: string } }>('/api/make/:id/comments/:commentId', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    try {
      const comments = await workspaces.removeComment(req.params.id, req.params.commentId)
      hub.changed(userId, req.params.id, workspaces.rev(req.params.id), [COMMENTS_SYNC_PATH])
      return { comments: await commentView(userId, req.params.id, comments) }
    } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/usage', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { await workspaces.ensure(req.params.id); return await workspaces.usage(req.params.id) } catch (error) { return sendError(reply, error) }
  })
  app.post<{ Params: { id: string }; Body: { keepSnapshots?: number; shots?: boolean; unusedAssets?: boolean } | undefined }>('/api/make/:id/cleanup', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    try {
      await workspaces.ensure(req.params.id)
      const result = await workspaces.cleanup(req.params.id, { keepSnapshots: req.body?.keepSnapshots, shots: req.body?.shots, unusedAssets: req.body?.unusedAssets })
      hub.changed(userId, req.params.id, result.state.rev, [])
      return result
    } catch (error) { return sendError(reply, error) }
  })
  app.delete<{ Params: { id: string } }>('/api/make/:id/publish', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { return await workspaces.unpublish(req.params.id) } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/check', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { await workspaces.ensure(req.params.id); return { issues: await workspaces.check(req.params.id) } } catch (error) { return sendError(reply, error) }
  })

  app.post<{ Params: { id: string }; Body: { templateId?: string } }>('/api/make/:id/template', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    if (typeof req.body?.templateId !== 'string') return reply.code(400).send({ error: 'templateId обязателен' })
    try {
      const state = await workspaces.applyTemplate(req.params.id, req.body.templateId)
      hub.changed(userId, req.params.id, state.rev, state.files.map((f) => f.path))
      return state
    } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string }; Querystring: { q?: string; regex?: string; matchCase?: string } }>('/api/make/:id/search', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { await workspaces.ensure(req.params.id); return { matches: await workspaces.search(req.params.id, req.query.q ?? '', 200, { regex: req.query.regex === '1', matchCase: req.query.matchCase === '1' }) } } catch (error) { return sendError(reply, error) }
  })

  app.post<{ Params: { id: string }; Body: { query?: string; replacement?: string; matchCase?: boolean; regex?: boolean; dryRun?: boolean; previewToken?: string; path?: string; matchIndex?: number } }>('/api/make/:id/replace', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    const { query, replacement, matchCase, regex, dryRun, previewToken, path, matchIndex } = req.body ?? {}
    if (typeof query !== 'string' || typeof replacement !== 'string') return reply.code(400).send({ error: 'query и replacement обязательны' })
    if (!dryRun && (typeof previewToken !== 'string' || !previewToken)) return reply.code(400).send({ error: 'Preview changes before applying replacement' })
    if (path !== undefined && (typeof path !== 'string' || normalizeMakePath(path) !== path)) return reply.code(400).send({ error: 'Invalid match path' })
    try {
      const result = await workspaces.replaceAll(req.params.id, query, replacement, { matchCase: Boolean(matchCase), regex: Boolean(regex), dryRun: Boolean(dryRun), previewToken, path, matchIndex })
      if (!dryRun && result.files > 0) hub.changed(userId, req.params.id, result.state.rev, result.state.files.map((f) => f.path))
      return result
    } catch (error) { return sendError(reply, error) }
  })

  // Personal component library (item 17).
  app.get('/api/make/library', async (req) => ({ items: await library.list(uid(req)) }))

  app.delete<{ Params: { slug: string } }>('/api/make/library/:slug', async (req) => {
    await library.remove(uid(req), req.params.slug)
    return { items: await library.list(uid(req)) }
  })

  app.post<{ Params: { id: string }; Body: { name?: string; paths?: string[] } }>('/api/make/:id/library', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    const { name, paths } = req.body ?? {}
    if (typeof name !== 'string' || !Array.isArray(paths) || paths.length === 0) return reply.code(400).send({ error: 'name и paths обязательны' })
    try {
      const files: Array<{ path: string; data: Buffer }> = []
      for (const raw of paths.slice(0, 30)) {
        const file = await workspaces.readBuffer(req.params.id, String(raw))
        if (file) files.push({ path: file.path, data: file.data })
      }
      return { item: await library.save(userId, name, files, req.params.id) }
    } catch (error) { return sendError(reply, error) }
  })

  app.post<{ Params: { id: string; slug: string } }>('/api/make/:id/library/:slug/insert', async (req, reply) => {
    const userId = uid(req)
    if (!await own(userId, req.params.id, reply)) return reply
    try {
      const files = await library.files(userId, req.params.slug)
      const { state, mergedTokens, autoImported } = await workspaces.insertLibraryFiles(req.params.id, files)
      hub.changed(userId, req.params.id, state.rev, files.map((f) => f.path))
      return { state, mergedTokens, autoImported }
    } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/notes', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    try { await workspaces.ensure(req.params.id); return await workspaces.notes(req.params.id) } catch (error) { return sendError(reply, error) }
  })
  app.put<{ Params: { id: string }; Body: { notes?: string; mode?: string; stack?: string; uiKit?: string } | undefined }>('/api/make/:id/notes', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'editor'))) return reply
    const mode = req.body?.mode === 'designer' || req.body?.mode === 'developer' || req.body?.mode === 'balanced' ? req.body.mode : undefined
    try {
      await workspaces.ensure(req.params.id)
      return await workspaces.setNotes(req.params.id, {
        ...(typeof req.body?.notes === 'string' ? { notes: req.body.notes } : {}),
        ...(mode ? { mode } : {}),
        ...(typeof req.body?.stack === 'string' ? { stack: req.body.stack as MakeProjectNotes['stack'] } : {}),
        ...(typeof req.body?.uiKit === 'string' ? { uiKit: req.body.uiKit as MakeProjectNotes['uiKit'] } : {})
      })
    } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/tests', async (req, reply) => {
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    try { return { files: await workspaces.tests(req.params.id) } } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/shots', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { return { shots: await workspaces.shots(req.params.id) } } catch (error) { return sendError(reply, error) }
  })

  app.post<{ Params: { id: string }; Body: { file?: string; story?: string; dataBase64?: string } }>('/api/make/:id/shots', { bodyLimit: 8 * 1024 * 1024 }, async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    const { file, story, dataBase64 } = req.body ?? {}
    if (typeof file !== 'string' || typeof story !== 'string' || typeof dataBase64 !== 'string') return reply.code(400).send({ error: 'file, story и dataBase64 обязательны' })
    try { return { shots: await workspaces.addShot(req.params.id, file, story, Buffer.from(dataBase64, 'base64')) } } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string } }>('/api/make/:id/stories', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try { await workspaces.ensure(req.params.id); return { files: await workspaces.stories(req.params.id) } } catch (error) { return sendError(reply, error) }
  })

  /** Response file content: transpile JSX/TS with esbuild and serve other files unchanged. */
  const previewBody = async (conversationId: string, file: { path: string; data: Buffer }): Promise<Buffer | string> => {
    if (!isMakeTranspiledPath(file.path)) return file.data
    const paths = new Set((await workspaces.list(conversationId)).map((f) => f.path))
    return transpileForPreview(conversationId, file.path, file.data.toString('utf8'), workspaces.rev(conversationId), (p) => paths.has(p))
  }

  // Publications at /p/<token>/... are outside /api and require no account authentication; the link
  // grants access. The publication password form posts URL-encoded data to __auth__ and issues a
  // 30-day cookie.
  if (!app.hasContentTypeParser('application/x-www-form-urlencoded')) {
    app.addContentTypeParser('application/x-www-form-urlencoded', { parseAs: 'string' }, (_req, body, done) => {
      try { done(null, Object.fromEntries(new URLSearchParams(String(body)))) } catch (e) { done(e as Error, undefined) }
    })
  }
  const gateCookieName = (token: string): string => `vc_pub_${token}`
  const cookieValue = (req: FastifyRequest, name: string): string | null => {
    const m = (req.headers.cookie ?? '').split(/;\s*/).find((c) => c.startsWith(`${name}=`))
    return m ? decodeURIComponent(m.slice(name.length + 1)) : null
  }
  const passwordPage = (action: string, wrong: boolean, limited = 0, locale: MakeLocale = 'ru'): string => `<!doctype html><html lang="${locale}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex"><title>${publicText(locale, 'passwordAccess')}</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;font:15px/1.5 system-ui,sans-serif;background:#f6f7fb;color:#1a1d23}form{background:#fff;padding:28px 32px;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.08);display:grid;gap:12px;min-width:280px}h1{margin:0;font-size:18px}input{font:inherit;padding:10px 12px;border:1px solid #d9dbe3;border-radius:8px}button{font:inherit;padding:10px 12px;border:0;border-radius:8px;background:#4f7cff;color:#fff;cursor:pointer}.err{color:#c0392b;margin:0;font-size:13px}</style></head>
<body><form method="post" action="${action}&amp;makeLocale=${locale}">${publicLanguageSelect(locale)}<h1>${publicText(locale, 'passwordProtected')}</h1>${limited ? `<p class="err">${publicText(locale, 'tooManyAttempts', { p0: limited })}</p>` : wrong ? `<p class="err">${publicText(locale, 'wrongPassword')}</p>` : ''}<input type="password" name="password" aria-label="${publicText(locale, 'projectPassword')}" placeholder="${publicText(locale, 'password')}" autofocus required autocomplete="current-password"><button type="submit">${publicText(locale, 'open')}</button></form></body></html>`

  /** Mock API response (item 29): JSON, status, and headers come from the envelope; an artificial delay simulates a backend. */
  const sendMock = async (reply: FastifyReply, mock: MockResponse): Promise<unknown> => {
    if (mock.delayMs > 0) await new Promise((r) => setTimeout(r, mock.delayMs))
    reply.code(mock.status).header('content-type', 'application/json; charset=utf-8').header('cache-control', 'no-store').header('x-vc-mock', '1')
    for (const [k, v] of Object.entries(mock.headers)) reply.header(k, v)
    return reply.send(mock.body === null ? '' : JSON.stringify(mock.body))
  }
  // Non-GET preview requests are only for mocks; they never serve files.
  app.route<{ Params: { id: string; '*': string } }>({
    method: ['POST', 'PUT', 'PATCH', 'DELETE'], url: '/api/preview/make/:id/*',
    handler: async (req, reply) => {
      if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
      const mock = await workspaces.resolveMock(req.params.id, req.params['*'] || '', req.method, false, req.body, req.headers.cookie)
      if (!mock) return reply.code(404).type('text/plain; charset=utf-8').send(`Мок не найден: mock/${req.params['*']}.${req.method}.json`)
      return sendMock(reply, mock)
    }
  })

  /** Serve a publication file by token: shared implementation for /p/<token>/ and /s/<slug>/. */
  const servePublic = async (token: string, rawPath: string, base: string, req: FastifyRequest, reply: FastifyReply): Promise<unknown> => {
    const conversationId = await workspaces.publishedTarget(token)
    if (!conversationId) return reply.code(404).type('text/plain; charset=utf-8').send('Публикация не найдена или снята')
    const raw = rawPath || 'index.html'
    // Password protection (item 25): without a valid cookie, show a form for HTML requests and
    // return 401 for other requests.
    const gate = await workspaces.publicGate(conversationId)
    if (gate && cookieValue(req, gateCookieName(token)) !== gate) {
      const wantsHtml = raw === 'index.html' || raw.endsWith('/') || raw.endsWith('.html') || raw === MAKE_STORIES_PAGE || raw === MAKE_GALLERY_PAGE
      if (!wantsHtml) return reply.code(401).type('text/plain; charset=utf-8').send('Публикация защищена паролем')
      const q = req.query as { wrong?: string }
      return reply.code(401).header('content-type', 'text/html; charset=utf-8').header('cache-control', 'no-store').header('x-robots-tag', 'noindex')
        .send(passwordPage(`${base}__auth__?next=${encodeURIComponent(raw)}`, q.wrong === '1', 0, requestMakeLocale(req)))
    }
    // Viewer comments (roadmap-4, item 34): GET returns approved comments and POST submits for
    // moderation, only when enabled by the owner.
    if (raw === MAKE_PUBLIC_COMMENTS_PAGE) {
      const pub = await workspaces.publication(conversationId)
      if (!pub?.allowComments) return reply.code(404).send({ error: 'Комментарии зрителей выключены' })
      if (req.method === 'GET') return reply.header('cache-control', 'no-store').send({ comments: await workspaces.publicComments(conversationId) })
      if (req.method !== 'POST') return reply.code(405).send({ error: 'method not allowed' })
      if (!guestCommentLimiter.hit(`${req.ip}:${token}`).ok) return reply.code(429).send({ error: 'Слишком много комментариев — попробуйте позже' })
      const b = (req.body ?? {}) as { text?: string; name?: string; selector?: string; elementLabel?: string }
      if (typeof b.text !== 'string' || !b.text.trim()) return reply.code(400).send({ error: 'Нужен текст комментария' })
      try {
        const item = await workspaces.addGuestComment(conversationId, { selector: String(b.selector ?? 'body').slice(0, 500), elementLabel: String(b.elementLabel ?? '').slice(0, 160), text: b.text, guestName: String(b.name ?? '').slice(0, 60) })
        const owner = await core.conversationOwner(conversationId)
        if (owner) hub.changed(owner, conversationId, 0, [COMMENTS_SYNC_PATH])
        return reply.code(201).send({ ok: true, id: item.id, pending: true })
      } catch (error) { return sendError(reply, error) }
    }
    // Public stories and gallery (item 15): the preview pages without sign-in, using published
    // files.
    if (raw === MAKE_STORIES_PAGE || raw === MAKE_GALLERY_PAGE) {
      const headers = (r: FastifyReply): FastifyReply => r.header('content-type', 'text/html; charset=utf-8').header('cache-control', 'no-store').header('x-robots-tag', 'noindex')
        .header('content-security-policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:")
      if (raw === MAKE_GALLERY_PAGE) return headers(reply).send(renderGalleryPage(await workspaces.stories(conversationId), base, 'Компоненты', await galleryUsage(workspaces, conversationId), requestMakeLocale(req)))
      const q = req.query as { file?: string; story?: string }
      const index = await workspaces.publicFile(conversationId, 'index.html').catch(() => null)
      return headers(reply).send(renderStoriesPage(q.file ?? '', q.story ?? '', index ? index.data.toString('utf8') : null, requestMakeLocale(req)))
    }
    const path = raw.endsWith('/') ? `${raw}index.html` : raw
    let file
    try { file = await workspaces.publicFile(conversationId, path) } catch { file = null }
    if (!file) {
      const mock = await workspaces.resolveMock(conversationId, path, req.method, true, (req as FastifyRequest & { body?: unknown }).body, req.headers.cookie)
      if (mock) return sendMock(reply, mock)
      return reply.code(404).type('text/plain; charset=utf-8').send(`Файл не найден: ${path}`)
    }
    if (path === 'index.html') { const ref = typeof req.headers.referer === 'string' ? req.headers.referer : null; const own = ref && req.hostname && ref.includes(`//${req.hostname}`); void workspaces.countView(conversationId, own ? null : ref) }
    let body: Buffer | string = isMakeTranspiledPath(file.path)
      ? await transpileForPreview(file.cacheKey, file.path, file.data.toString('utf8'), file.rev, () => true)
      : file.data
    // Viewer comment widget (roadmap-4, item 34): inject only into published HTML with comments
    // enabled.
    if (path === 'index.html' && (await workspaces.publication(conversationId))?.allowComments) {
      const html = body.toString('utf8')
      body = /<\/body>/i.test(html) ? html.replace(/<\/body>/i, `${guestCommentsWidget(base, requestMakeLocale(req))}</body>`) : html + guestCommentsWidget(base, requestMakeLocale(req))
    }
    return reply
      .header('content-type', makeMimeType(file.path))
      .header('cache-control', 'no-store')
      .header('x-content-type-options', 'nosniff')
      .header('content-security-policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:")
      .header('x-robots-tag', 'noindex')
      .send(body)
  }
  const authPublic = async (token: string, base: string, req: FastifyRequest, reply: FastifyReply): Promise<unknown> => {
    const conversationId = await workspaces.publishedTarget(token)
    if (!conversationId) return reply.code(404).type('text/plain; charset=utf-8').send('Публикация не найдена или снята')
    const body = (req.body ?? {}) as { password?: string }
    const q = req.query as { next?: string; makeLocale?: string }
    const localeQuery = q.makeLocale === 'en' || q.makeLocale === 'ru' ? `makeLocale=${q.makeLocale}` : ''
    const next = (q.next ?? 'index.html').replace(/^\/+/, '')
    // Password guessing protection (roadmap-2, item 3): 10 attempts per 10 minutes per IP and
    // token; return 429 with the same form and a countdown after the limit.
    const verdict = passwordLimiter.hit(`${req.ip}:${token}`)
    if (!verdict.ok) return reply.code(429).header('retry-after', String(verdict.retryAfterSec)).header('content-type', 'text/html; charset=utf-8').header('cache-control', 'no-store').send(passwordPage(`${base}__auth__?next=${encodeURIComponent(next)}`, false, verdict.retryAfterSec, requestMakeLocale(req)))
    if (!(await workspaces.verifyPublicPassword(conversationId, body.password ?? ''))) return reply.redirect(`${base}${next}?wrong=1${localeQuery ? '&' + localeQuery : ''}`)
    const gate = await workspaces.publicGate(conversationId)
    return reply
      .header('set-cookie', `${gateCookieName(token)}=${gate ?? ''}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${30 * 86400}`)
      .redirect(`${base}${next}${localeQuery ? '?' + localeQuery : ''}`)
  }

  /**
   * Read-only preview link (/p/pv.<token>/, see previewLink.ts): the project's current working files
   * for browser engines without the user's cookies. No inspector script, no mutations, and GET-only
   * mocks; the conversation must still exist.
   */
  const servePreviewLink = async (token: string, rawPath: string, req: FastifyRequest, reply: FastifyReply): Promise<unknown> => {
    const link = verifyPreviewLink(deps.previewLinkSecret ?? '', token)
    if (!link || !await core.conversationOwner(link.conversationId)) return reply.code(404).type('text/plain; charset=utf-8').send('Ссылка превью недействительна или истекла')
    const conversationId = link.conversationId
    const headers = (r: FastifyReply, type: string): FastifyReply => r.header('content-type', type).header('cache-control', 'no-store').header('x-content-type-options', 'nosniff')
      .header('x-robots-tag', 'noindex').header('content-security-policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:")
    if (req.method !== 'GET' && req.method !== 'HEAD') return headers(reply.code(405), 'application/json; charset=utf-8').send({ error: 'Ссылка превью только для чтения' })
    const raw = rawPath || 'index.html'
    const base = `${MAKE_PUBLIC_PREFIX}${encodeURIComponent(token)}/`
    if (raw === MAKE_GALLERY_PAGE) return headers(reply, 'text/html; charset=utf-8').send(renderGalleryPage(await workspaces.stories(conversationId), base, 'Компоненты', await galleryUsage(workspaces, conversationId), requestMakeLocale(req)))
    if (raw === MAKE_STORIES_PAGE) {
      const q = req.query as { file?: string; story?: string }
      const index = await workspaces.readBuffer(conversationId, 'index.html').catch(() => null)
      return headers(reply, 'text/html; charset=utf-8').send(renderStoriesPage(q.file ?? '', q.story ?? '', index ? index.data.toString('utf8') : null, requestMakeLocale(req)))
    }
    const path = raw.endsWith('/') ? `${raw}index.html` : raw
    let file
    try { file = await workspaces.readBuffer(conversationId, path) } catch (error) { return sendError(reply, error) }
    if (!file) {
      const mock = await workspaces.resolveMock(conversationId, path, 'GET', false, undefined, req.headers.cookie)
      if (mock) return sendMock(reply, mock)
      return reply.code(404).type('text/plain; charset=utf-8').send(`Файл не найден: ${path}`)
    }
    return headers(reply, makeMimeType(file.path)).send(await previewBody(conversationId, file))
  }

  app.get<{ Params: { token: string; '*': string } }>(`${MAKE_PUBLIC_PREFIX}:token/*`, async (req, reply) => isPreviewLinkToken(req.params.token)
    ? servePreviewLink(req.params.token, req.params['*'], req, reply)
    : servePublic(req.params.token, req.params['*'], `${MAKE_PUBLIC_PREFIX}${encodeURIComponent(req.params.token)}/`, req, reply))
  /** Non-GET publication requests: __auth__ handles the password form; other paths are mocks after access validation. */
  const publicMutation = async (token: string, rawPath: string, base: string, req: FastifyRequest, reply: FastifyReply): Promise<unknown> => {
    if (isPreviewLinkToken(token)) return servePreviewLink(token, rawPath, req, reply)
    if (rawPath === '__auth__') return authPublic(token, base, req, reply)
    // Viewer comment POST (item 34) uses the same handler as the comment-list GET.
    if (rawPath === MAKE_PUBLIC_COMMENTS_PAGE) return servePublic(token, rawPath, base, req, reply)
    const conversationId = await workspaces.publishedTarget(token)
    if (!conversationId) return reply.code(404).type('text/plain; charset=utf-8').send('Публикация не найдена или снята')
    const gate = await workspaces.publicGate(conversationId)
    if (gate && cookieValue(req, gateCookieName(token)) !== gate) return reply.code(401).type('text/plain; charset=utf-8').send('Публикация защищена паролем')
    const mock = await workspaces.resolveMock(conversationId, rawPath, req.method, true, (req as FastifyRequest & { body?: unknown }).body, req.headers.cookie)
    if (!mock) return reply.code(404).type('text/plain; charset=utf-8').send('Мок не найден')
    return sendMock(reply, mock)
  }
  app.route<{ Params: { token: string; '*': string } }>({
    method: ['POST', 'PUT', 'PATCH', 'DELETE'], url: `${MAKE_PUBLIC_PREFIX}:token/*`,
    handler: async (req, reply) => publicMutation(req.params.token, req.params['*'] || '', `${MAKE_PUBLIC_PREFIX}${encodeURIComponent(req.params.token)}/`, req, reply)
  })
  app.get<{ Params: { token: string } }>(`${MAKE_PUBLIC_PREFIX}:token`, async (req, reply) => reply.redirect(`${MAKE_PUBLIC_PREFIX}${encodeURIComponent(req.params.token)}/index.html`))
  app.get<{ Params: { token: string } }>(`${MAKE_PUBLIC_PREFIX}:token/`, async (req, reply) => reply.redirect(`${MAKE_PUBLIC_PREFIX}${encodeURIComponent(req.params.token)}/index.html`))

  // Slug URLs (item 25): /s/<slug>/... serves the same content without exposing the token.
  const slugBase = (slug: string): string => `${MAKE_SLUG_PREFIX}${encodeURIComponent(slug)}/`
  app.get<{ Params: { slug: string; '*': string } }>(`${MAKE_SLUG_PREFIX}:slug/*`, async (req, reply) => {
    const token = await workspaces.slugToken(req.params.slug)
    if (!token) return reply.code(404).type('text/plain; charset=utf-8').send('Публикация не найдена или снята')
    return servePublic(token, req.params['*'], slugBase(req.params.slug), req, reply)
  })
  app.route<{ Params: { slug: string; '*': string } }>({
    method: ['POST', 'PUT', 'PATCH', 'DELETE'], url: `${MAKE_SLUG_PREFIX}:slug/*`,
    handler: async (req, reply) => {
      const token = await workspaces.slugToken(req.params.slug)
      if (!token) return reply.code(404).type('text/plain; charset=utf-8').send('Публикация не найдена или снята')
      return publicMutation(token, req.params['*'] || '', slugBase(req.params.slug), req, reply)
    }
  })
  app.get<{ Params: { slug: string } }>(`${MAKE_SLUG_PREFIX}:slug`, async (req, reply) => reply.redirect(`${slugBase(req.params.slug)}index.html`))
  app.get<{ Params: { slug: string } }>(`${MAKE_SLUG_PREFIX}:slug/`, async (req, reply) => reply.redirect(`${slugBase(req.params.slug)}index.html`))

  // Preview and export use cookie authentication; see users/auth.ts.

  app.get<{ Params: { id: string }; Querystring: { vite?: string; pwa?: string; deploy?: string } }>('/api/preview/make/:id/export.zip', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    try {
      await workspaces.ensure(req.params.id)
      const deploy = req.query.deploy === 'netlify' || req.query.deploy === 'vercel' ? req.query.deploy : null
      const zip = await workspaces.exportZip(req.params.id, { vite: req.query.vite === '1', pwa: req.query.pwa === '1', deploy })
      return reply
        .header('content-type', 'application/zip')
        .header('content-disposition', `attachment; filename="make-${req.params.id.slice(0, 8)}.zip"`)
        .header('cache-control', 'no-store')
        .send(zip)
    } catch (error) { return sendError(reply, error) }
  })

  app.get<{ Params: { id: string; '*': string } }>('/api/preview/make/:id/*', async (req, reply) => {
    // Read access also grants preview access so the whole team can view a design linked to a task.
    if (!(await access(uid(req), req.params.id, reply, 'viewer'))) return reply
    await workspaces.ensure(req.params.id)
    const raw = req.params['*'] || 'index.html'
    // Snapshot preview (roadmap-4, item 37): __snapshot__/<id>/<file> serves versioned files with a
    // separate transpilation cache key.
    if (raw.startsWith(`${MAKE_SNAPSHOT_PREVIEW}/`)) {
      const [snapshotId, ...rest] = raw.slice(MAKE_SNAPSHOT_PREVIEW.length + 1).split('/')
      const snapPath = rest.join('/') || 'index.html'
      const file = snapshotId ? await workspaces.snapshotBuffer(req.params.id, snapshotId, snapPath.endsWith('/') ? `${snapPath}index.html` : snapPath) : null
      if (!file) return reply.code(404).type('text/plain; charset=utf-8').send(`В снимке нет файла: ${snapPath}`)
      const snapBase = `/api/preview/make/${encodeURIComponent(req.params.id)}/${MAKE_SNAPSHOT_PREVIEW}/${encodeURIComponent(snapshotId!)}/`
      const body = isMakeTranspiledPath(file.path)
        ? await transpileForPreview(`${req.params.id}:snap:${snapshotId}`, file.path, file.data.toString('utf8'), 0, () => true)
        : file.path === 'index.html' ? file.data.toString('utf8').replace(/<head([^>]*)>/i, `<head$1><base href="${snapBase}">`) : file.data
      return reply.header('content-type', makeMimeType(file.path)).header('cache-control', 'no-store').header('x-content-type-options', 'nosniff')
        .header('content-security-policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:; frame-ancestors 'self'").send(body)
    }
    if (raw.startsWith('__shots__/') && raw.endsWith('.png')) {
      const img = await workspaces.shotImage(req.params.id, raw.slice('__shots__/'.length, -4))
      if (!img) return reply.code(404).type('text/plain; charset=utf-8').send('Снимок не найден')
      return reply.header('content-type', 'image/png').header('cache-control', 'private, max-age=3600').send(img)
    }
    if (raw === MAKE_GALLERY_PAGE) {
      const files = await workspaces.stories(req.params.id)
      return reply.header('content-type', 'text/html; charset=utf-8').header('cache-control', 'no-store')
        .header('content-security-policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:; frame-ancestors 'self'")
        .send(renderGalleryPage(files, `/api/preview/make/${encodeURIComponent(req.params.id)}/`, 'Компоненты', await galleryUsage(workspaces, req.params.id), requestMakeLocale(req)))
    }
    if (raw === MAKE_TESTS_PAGE) {
      const q = req.query as { file?: string }
      const index = await workspaces.readBuffer(req.params.id, 'index.html').catch(() => null)
      return reply.header('content-type', 'text/html; charset=utf-8').header('cache-control', 'no-store')
        .header('content-security-policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:; frame-ancestors 'self'")
        .send(renderTestsPage(q.file ?? '', index ? index.data.toString('utf8') : null, requestMakeLocale(req)))
    }
    if (raw === MAKE_STORIES_PAGE) {
      const q = req.query as { file?: string; story?: string }
      const index = await workspaces.readBuffer(req.params.id, 'index.html').catch(() => null)
      return reply
        .header('content-type', 'text/html; charset=utf-8')
        .header('cache-control', 'no-store')
        .header('content-security-policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:; frame-ancestors 'self'")
        .send(renderStoriesPage(q.file ?? '', q.story ?? '', index ? index.data.toString('utf8') : null, requestMakeLocale(req)))
    }
    const path = raw.endsWith('/') ? `${raw}index.html` : raw
    let file
    try { file = await workspaces.readBuffer(req.params.id, path) } catch (error) { return sendError(reply, error) }
    if (!file) {
      const mock = await workspaces.resolveMock(req.params.id, path, 'GET', false, undefined, req.headers.cookie)
      if (mock) return sendMock(reply, mock)
      return reply.code(404).type('text/plain; charset=utf-8').send(`Файл не найден: ${path}`)
    }
    const mime = makeMimeType(file.path)
    reply
      .header('content-type', mime)
      .header('cache-control', 'no-store')
      .header('x-content-type-options', 'nosniff')
      // Isolate the preview: allow its own resources and inline code, but prevent parent
      // navigation.
      .header('content-security-policy', "default-src 'self' 'unsafe-inline' 'unsafe-eval' data: blob: https:; frame-ancestors 'self'")
    if (mime.startsWith('text/html')) {
      const html = file.data.toString('utf8')
      const injected = /<\/body>/i.test(html) ? html.replace(/<\/body>/i, `${MAKE_INSPECTOR_SCRIPT}</body>`) : `${html}${MAKE_INSPECTOR_SCRIPT}`
      return reply.send(injected)
    }
    return reply.send(await previewBody(req.params.id, file))
  })

  app.get<{ Params: { id: string } }>('/api/preview/make/:id/', async (req, reply) => {
    if (!await own(uid(req), req.params.id, reply)) return reply
    return reply.redirect(`/api/preview/make/${encodeURIComponent(req.params.id)}/index.html`)
  })
}
