import type { MakeStandClient, MakeProjectClient } from '@voicechat/make-contracts/projectClient'
import type { MakeStandResult, ProjectGitResult } from '@voicechat/make-contracts/projectMode'
import { Dialog } from '../i18n/ui'
import { mt, useMakeLocale } from '../i18n'
import { MakeConnectedProject } from './MakeConnectedProject'
import { MakeProjectStand } from './MakeProjectStand'
import type { MakeProjectStoriesApi } from './MakeProjectComponents'

export interface MakeStandSettingsDialogProps {
  client: MakeStandClient
  conversationId: string
  projectId: string
  api: MakeProjectStoriesApi
  localAgentId?: string | null
  onClose: () => void
  onState: (state: MakeStandResult | undefined) => void
  projectClient?: MakeProjectClient
  branches?: () => Promise<ProjectGitResult>
  title?: string
}

/** Conversation-level stand and repository settings, shared by the toolbar and chat settings. */
export function MakeStandSettingsDialog({ client, conversationId, projectId, api, localAgentId, onClose, onState, projectClient, branches, title }: MakeStandSettingsDialogProps): JSX.Element {
  useMakeLocale()
  const loadBranches = branches ?? (projectClient
    ? () => projectClient.projectGit(projectId, { op: 'branches' })
    : async () => ({ op: 'branches' as const, branches: [] }))
  return <Dialog className="make-dialog make-stand-settings" padded title={mt('standSettings')} ariaLabel={mt('standSettings')} size="lg" onClose={onClose} testId="make-stand-settings">
    <MakeProjectStand client={client} conversationId={conversationId} projectId={projectId} api={api} localAgentId={localAgentId}
      title={title} branches={loadBranches} settingsOnly onState={onState}>{null}</MakeProjectStand>
    {projectClient && <MakeConnectedProject client={projectClient} conversationId={conversationId} />}
  </Dialog>
}
