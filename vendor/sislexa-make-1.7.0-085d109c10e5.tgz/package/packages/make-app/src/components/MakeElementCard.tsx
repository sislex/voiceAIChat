import { Button } from '@voicechat/ui-kit'
import { mt, useMakeLocale } from '../i18n'
import type { SelectedElement } from './MakePreviewHost'

export interface MakeElementCardProps {
  selected: SelectedElement
  projectName: string
  actions: {
    openInCode?(file: string, line: number): void
    addToPrompt?(text: string): void
    comment?(selector: string): void
    styles(): void
  }
}

export function MakeElementCard({ selected, projectName, actions }: MakeElementCardProps) {
  useMakeLocale()
  const { source, story } = selected
  // Only explicit workspace or scoped package prefixes identify a package.
  const packageName = source?.package
    || /^(?:packages|apps)\/[^/]+(?=\/|$)|^@[^/]+\/[^/]+(?=\/|$)/.exec(source?.file ?? story?.title ?? '')?.[0]
  const prompt = mt('changeElementValueValue', {
    p0: selected.selector,
    p1: (selected.text ? ` («${selected.text.slice(0, 80)}»)` : '')
      + (source ? ` (${[source.component, `${source.file}:${source.line}`].filter(Boolean).join(', ')})` : '')
  })
  const location = source ? `${source.file}:${source.line}` : mt('elementSourceUnavailable')
  const description = [projectName, packageName, source?.component, location, story?.title ?? story?.id,
    `<${selected.tag}> ${selected.selector} «${selected.text}»`].filter(Boolean).join(' → ')
  return <div className="make-element-card" data-testid="make-element-card">
    <div>{description}</div>
    <span className="make-selected-actions">
      {source && actions.openInCode && <Button size="sm" onClick={() => actions.openInCode!(source.file, source.line)}>{mt('elementOpenInCode')}</Button>}
      {actions.addToPrompt && <Button size="sm" onClick={() => actions.addToPrompt!(prompt)}>{mt('elementAddToPrompt')}</Button>}
      {actions.comment && <Button size="sm" onClick={() => actions.comment!(selected.selector)}>{mt('elementComment')}</Button>}
      <Button size="sm" onClick={actions.styles}>{mt('styles')}</Button>
    </span>
  </div>
}
