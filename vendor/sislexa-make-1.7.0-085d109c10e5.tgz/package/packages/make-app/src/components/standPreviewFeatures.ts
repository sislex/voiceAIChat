import type { PreviewFeatures } from './MakePreviewHost'

export const standPreviewFeatures: PreviewFeatures = {
  publish: false, upload: false, storage: false, templates: false,
  inlineEdit: false, reorder: false,
}
