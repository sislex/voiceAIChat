import { useEffect, useRef, useState, useImperativeHandle, forwardRef, type ReactNode } from 'react'
import { Button, IconButton } from '@voicechat/ui-kit'
import { Dialog, useToast } from '../i18n/ui'
import { mt, useMakeLocale, describeMakeError, localizeMakeText } from '../i18n'
import { useMediaQuery } from '@voicechat/ui-foundation/lib/mediaQuery'
import type { MakeComment, MakeConsoleLine, MakeNetworkEntry } from '@voicechat/make-contracts/make'
import type { z } from 'zod'
import type { ELEMENT_SOURCE_SCHEMA } from '@voicechat/make-contracts'
import { MakeStylePanel, type StyleValues } from './MakeStylePanel'
import { MakeElementCard } from './MakeElementCard'
import { MakeCommentsPanel, type MakeCommentsPanelProps } from './MakeCommentsPanel'
import { captureIframeScreenshot } from '../lib/makeScreenshot'
import { a11yPrompt, a11yHelp, a11yImpact, runAxeInFrame, type A11yViolation } from '../lib/makeA11y'

export interface SelectedElement extends z.infer<typeof ELEMENT_SOURCE_SCHEMA> {
  selector: string
  tag: string
  text: string
  html: string
  id?: string
  className?: string
  styles?: StyleValues
}

export type PreviewSource = { kind: 'make'; src: string } | { kind: 'frame'; src: string; origin: string }
export interface PreviewFeatures {
  publish?: boolean
  upload?: boolean
  storage?: boolean
  templates?: boolean
  inlineEdit?: boolean
  reorder?: boolean
}
type MenuItem = (label: string, onClick: () => void, options?: { ariaLabel?: string; disabled?: boolean; title?: string }) => JSX.Element
export interface PreviewLayout {
  controls: ReactNode
  actions: ReactNode
  fullscreen: boolean
  zen: boolean
  setZen(value: boolean): void
  previewSrc: string
  a11y: A11yViolation[] | null
  renderPreview: (beforeSelection?: ReactNode, afterSelection?: ReactNode) => ReactNode
}
export interface MakePreviewHostHandle {
  getFrame(): HTMLIFrameElement | null
  addConsole(line: MakeConsoleLine): void
}
export interface MakePreviewHostProps {
  source: PreviewSource
  conversationId: string
  features: PreviewFeatures
  onSelected?(selected: SelectedElement): void
  projectName?: string
  frameTitle?: string
  inspectTitle?: string
  onOpenInCode?(file: string, line: number): void
  ready?: boolean
  revision?: number
  onRefresh?(): void
  onTextEdit?(before: string, after: string): Promise<void>
  onReorder?(moved: string, target: string, position: 'before' | 'after'): Promise<void>
  onWriteStyles?(selector: string, values: StyleValues): Promise<void>
  comments?: MakeComment[] | null
  commentActions?: Omit<MakeCommentsPanelProps, 'comments' | 'selected' | 'onAdd' | 'onHighlight' | 'onClose' | 'onAskAssistant'> & {
    onAdd(selected: SelectedElement, text: string): Promise<void>
  }
  onInsertToChat?(text: string): void
  onAskAssistant?(text: string): void
  onAttachImage?(file: File): void
  askOnly?: boolean
  onAskOnlyChange?(value: boolean): void
  /** Project adapters provide persistence without coupling frame sources to Make storage. */
  projectActions?: Partial<Record<'publish' | 'upload' | 'storage' | 'templates', () => void>>
  published?: boolean
  moreActions?(item: MenuItem): ReactNode
  showPreviewControls?: boolean
  /** Insert host-owned controls and preview into the workshop's existing layout without wrappers. */
  children?(layout: PreviewLayout): ReactNode
}

type Device = 'desktop' | 'tablet' | 'mobile' | 'all'
const DEVICE_WIDTH: Record<Device, number | null> = { desktop: null, tablet: 768, mobile: 390, all: null }
const DEVICE_LABEL: Record<Device, string> = { get desktop() { return mt("desktop") }, get tablet() { return mt("tablet") }, get mobile() { return mt("phone") }, get all() { return mt("threeWidthsSideBySide") } }
/** Three side-by-side widths (roadmap-4, item 21): extra frames synchronize scrolling through vc-make.state and vc-make.restore. */
const SYNC_WIDTHS = [768, 390]

export const MakePreviewHost = forwardRef<MakePreviewHostHandle, MakePreviewHostProps>(function MakePreviewHost({
  source, conversationId, features, onSelected, projectName, frameTitle, inspectTitle, onOpenInCode, ready: previewReady = true, revision = 0, onRefresh,
  onTextEdit, onReorder, onWriteStyles, comments = null, commentActions,
  onInsertToChat, onAskAssistant, onAttachImage, askOnly = false, onAskOnlyChange,
  projectActions, published = false, moreActions, showPreviewControls = true, children
}, ref) {
  const locale = useMakeLocale()
  const toast = useToast()
  const describeError = describeMakeError
  const isPhone = useMediaQuery('(max-width: 720px)')
  const frameRef = useRef<HTMLIFrameElement | null>(null)
  const [localRevision, setLocalRevision] = useState(0)
  const previewRev = revision + localRevision
  const refresh = (): void => { if (onRefresh) onRefresh(); else setLocalRevision(value => value + 1) }
  const [ask, setAsk] = useState<{ title: string; label: string; initial: string; submit: string; onSubmit: (value: string) => void } | null>(null)
  const [askValue, setAskValue] = useState('')
  const openAsk = (title: string, label: string, initial: string, submit: string, onSubmit: (value: string) => void): void => { setAskValue(initial); setAsk({ title, label, initial, submit, onSubmit }) }
  const [device, setDevice] = useState<Device>('desktop')
  const [customSize, setCustomSize] = useState<[number, number] | null>(null)
  const [rotated, setRotated] = useState(false)
  const [fullscreen, setFullscreen] = useState(false)
  const [zen, setZen] = useState(false)
  useEffect(() => {
    if (!zen) return
    const onKey = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') setZen(false)
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [zen])
  const [inspect, setInspect] = useState(false)
  const [selected, setSelected] = useState<SelectedElement | null>(null)
  // Restore the preview's last known scroll position and hash after reload (item 11).
  const pageStateRef = useRef<{ x: number; y: number; hash: string } | null>(null)
  const syncFramesRef = useRef<Array<HTMLIFrameElement | null>>([])
  const syncMuteUntil = useRef(0)
  // Preview theme and language (item 12): send them to the iframe again after every reload.
  const [previewScheme, setPreviewScheme] = useState<'auto' | 'light' | 'dark'>('auto')
  const [previewLang, setPreviewLang] = useState('')
  const envRef = useRef<{ scheme: 'auto' | 'light' | 'dark'; lang: string; state: 'hover' | 'focus' | 'active' | null; reducedMotion: boolean; slowMs: number }>({ scheme: 'auto', lang: '', state: null, reducedMotion: false, slowMs: 0 })
  /** Preview environment emulation (roadmap-4, item 20): forced element state, reduced motion, and mock delay. */
  const [forcedState, setForcedState] = useState<'hover' | 'focus' | 'active' | null>(null)
  const [reducedMotion, setReducedMotion] = useState(false)
  const [slowMs, setSlowMs] = useState(0)
  envRef.current = { scheme: previewScheme, lang: previewLang, state: forcedState, reducedMotion, slowMs }
  const sendEnv = (scheme = previewScheme, lang = previewLang, extra: { state?: 'hover' | 'focus' | 'active' | null; reducedMotion?: boolean; slowMs?: number } = {}): void => { frameRef.current?.contentWindow?.postMessage({ type: 'vc-make.env', scheme, lang, state: forcedState, reducedMotion, slowMs, ...extra }, '*') }
  const cycleForcedState = (): void => { const order: Array<'hover' | 'focus' | 'active' | null> = [null, 'hover', 'focus', 'active']; const next = order[(order.indexOf(forcedState) + 1) % order.length] ?? null; setForcedState(next); sendEnv(previewScheme, previewLang, { state: next }) }
  const toggleReducedMotion = (): void => { const next = !reducedMotion; setReducedMotion(next); sendEnv(previewScheme, previewLang, { reducedMotion: next }) }
  const cycleSlowMs = (): void => { const next = slowMs === 0 ? 1500 : slowMs === 1500 ? 4000 : 0; setSlowMs(next); sendEnv(previewScheme, previewLang, { slowMs: next }) }
  const cycleScheme = (): void => { const next = previewScheme === 'auto' ? 'dark' : previewScheme === 'dark' ? 'light' : 'auto'; setPreviewScheme(next); sendEnv(next, previewLang) }
  // Poll the same-origin iframe directly because parent-side scroll events are unreliable.
  useEffect(() => {
    if (source.kind !== 'make') return
    const timer = setInterval(() => {
      const w = frameRef.current?.contentWindow
      try { if (w && w.document?.readyState === 'complete') pageStateRef.current = { x: w.scrollX, y: w.scrollY, hash: w.location.hash } } catch { /* Cross-origin frames report state through the inspector. */ }
    }, 500)
    return () => clearInterval(timer)
  }, [source.kind])
  const restorePageState = (): void => {
    const w = frameRef.current?.contentWindow
    const s = pageStateRef.current
    if (!w || !s) return
    const apply = (): void => { try { if (s.hash && w.location.hash !== s.hash) w.location.hash = s.hash; w.scrollTo(s.x, s.y) } catch { /* ignore */ } }
    if (source.kind === 'make') { apply(); setTimeout(apply, 250); setTimeout(apply, 800) }
    w.postMessage({ type: 'vc-make.restore', ...s }, '*')
  }
  const [styleOpen, setStyleOpen] = useState(false)
  const previewStyles = (values: StyleValues): void => { frameRef.current?.contentWindow?.postMessage({ type: 'vc-make.style', values }, '*') }
  const [consoleLines, setConsoleLines] = useState<MakeConsoleLine[]>([])
  const [consoleOpen, setConsoleOpen] = useState(false)
  const [network, setNetwork] = useState<MakeNetworkEntry[]>([])
  const [bottomTab, setBottomTab] = useState<'console' | 'network'>('console')

  useImperativeHandle(ref, () => ({
    getFrame: () => frameRef.current,
    addConsole: line => setConsoleLines(previous => [...previous.slice(-199), line])
  }), [])
  const [commentsOpen, setCommentsOpen] = useState(false)
  const commentsRef = useRef<MakeComment[]>([])
  commentsRef.current = comments ?? []
  const sendPins = (list: MakeComment[] = commentsRef.current): void => {
    const open = list.filter((c) => !c.resolved)
    frameRef.current?.contentWindow?.postMessage({ type: 'vc-make.pins', items: list.map((c) => ({ selector: c.selector, n: open.indexOf(c) + 1, text: c.text, resolved: c.resolved })) }, '*')
  }

  useEffect(() => { sendPins() }, [comments])
  const highlightInPreview = (selector: string): void => { frameRef.current?.contentWindow?.postMessage({ type: 'vc-make.highlight', selector }, '*') }
  useEffect(() => {
    setSelected(null); pageStateRef.current = null
  }, [conversationId, source.kind, source.kind === 'frame' ? source.src : null])
  // Preview messages include the element selected in picker mode.
  useEffect(() => {
    const onMessage = (event: MessageEvent): void => {
      const fromSync = syncFramesRef.current.some((f) => f?.contentWindow === event.source)
      if (!event.source || (event.source !== frameRef.current?.contentWindow && !fromSync)) return
      const data = event.data as { type?: string; before?: string; after?: string; moved?: string; target?: string; position?: string; selector?: string; tag?: string; text?: string; html?: string; id?: string; className?: string; styles?: StyleValues; source?: SelectedElement['source']; story?: SelectedElement['story'] } | null
      if (!data || typeof data !== 'object') return
      // Three side-by-side widths (item 21): mirror scrolling between frames and suppress echoes
      // for 300 ms.
      if (data.type === 'vc-make.state' && typeof (data as { y?: unknown }).y === 'number') {
        const all = [frameRef.current?.contentWindow, ...syncFramesRef.current.map((f) => f?.contentWindow)].filter(Boolean) as Window[]
        const from = all.find((w) => w === event.source)
        if (from && all.length > 1 && Date.now() > syncMuteUntil.current) {
          syncMuteUntil.current = Date.now() + 300
          for (const w of all) if (w !== from) w.postMessage({ type: 'vc-make.restore', x: 0, y: (data as { y: number }).y }, '*')
        }
      }
      // Extra frames only contribute scroll state; selection, text edits, and other actions come
      // from the main frame.
      if (fromSync) { if (data.type === 'vc-make.ready' && event.source) (event.source as Window).postMessage({ type: 'vc-make.env', ...envRef.current, state: null }, '*'); return }
      if (data.type === 'vc-make.state' && event.source === frameRef.current?.contentWindow) {
        const s = data as unknown as { x: number; y: number; hash: string }
        pageStateRef.current = { x: s.x, y: s.y, hash: s.hash }
      }
      if (data.type === 'vc-make.network') {
        const entry = event.data as MakeNetworkEntry
        setNetwork(previous => [...previous.slice(-199), entry])
      }
      if (data.type === 'vc-make.console') {
        const line = event.data as MakeConsoleLine
        setConsoleLines(previous => [...previous.slice(-199), { level: line.level, text: line.text, at: line.at }])
      }
      if (data.type === 'vc-make.ready') {
        frameRef.current?.contentWindow?.postMessage({ type: 'vc-make.inspect', enabled: inspect }, '*')
        if (commentsRef.current.length) sendPins()
        // Restore scroll position and hash after any preview reload to avoid jumping to the top.
        if (pageStateRef.current) frameRef.current?.contentWindow?.postMessage({ type: 'vc-make.restore', ...pageStateRef.current }, '*')
        if (envRef.current.scheme !== 'auto' || envRef.current.lang || envRef.current.reducedMotion || envRef.current.slowMs) frameRef.current?.contentWindow?.postMessage({ type: 'vc-make.env', ...envRef.current, state: null }, '*')
      } else if (data.type === 'vc-make.selected' && data.selector) {
        const next: SelectedElement = { selector: data.selector, tag: data.tag ?? '', text: data.text ?? '', html: data.html ?? '', id: data.id, className: data.className, styles: data.styles, source: data.source, story: data.story }
        setSelected(next); onSelected?.(next)
        setStyleOpen(false)
      } else if (data.type === 'vc-make.text' && features.inlineEdit && typeof data.before === 'string' && typeof data.after === 'string' && event.source === frameRef.current?.contentWindow) {
        void onTextEdit?.(data.before, data.after)
      } else if (data.type === 'vc-make.reorder' && features.reorder && typeof data.moved === 'string' && typeof data.target === 'string' && event.source === frameRef.current?.contentWindow) {
        void onReorder?.(data.moved, data.target, data.position === 'before' ? 'before' : 'after')
      }
    }
    window.addEventListener('message', onMessage)
    return () => window.removeEventListener('message', onMessage)
  }, [inspect, features.inlineEdit, features.reorder, onTextEdit, onReorder, onSelected])

  useEffect(() => {
    frameRef.current?.contentWindow?.postMessage({ type: 'vc-make.inspect', enabled: inspect }, '*')
  }, [inspect, previewRev])
  const sendSelectedToChat = (): void => {
    if (!selected || !onInsertToChat) return
    const text = mt("changeElementValueValue", { p0: selected.selector, p1: selected.text ? ` («${selected.text.slice(0, 80)}»)` : '' })
    onInsertToChat(text)
    setInspect(false)
  }
  // Attach a preview or selected-element screenshot to chat so visual bugs can be shown directly.
  const [shooting, setShooting] = useState(false)
  // Preview accessibility (item 13): run axe inside the iframe and display results below it.
  const [a11y, setA11y] = useState<A11yViolation[] | null>(null)
  const [a11yBusy, setA11yBusy] = useState(false)
  const runA11y = async (): Promise<void> => {
    const doc = frameRef.current?.contentDocument
    if (!doc) return
    setA11yBusy(true)
    try { setA11y(await runAxeInFrame(doc)) } catch (e) { toast.error(describeError(e)) } finally { setA11yBusy(false) }
  }
  useEffect(() => { setA11y(null) }, [previewRev, source.src])
  const showA11yTarget = (target: string): void => {
    const doc = frameRef.current?.contentDocument
    const el = target ? doc?.querySelector(target) : null
    if (!el) return
    el.scrollIntoView({ block: 'center' })
    ;(el as HTMLElement).style.outline = '3px solid #f85149'
    setTimeout(() => { (el as HTMLElement).style.outline = '' }, 2000)
  }
  const screenshotToChat = async (): Promise<void> => {
    const doc = frameRef.current?.contentDocument
    if (!doc || !onAttachImage) return
    setShooting(true)
    try {
      const element = selected ? doc.querySelector(selected.selector) : null
      const file = await captureIframeScreenshot({ doc, element, width: frameRef.current?.clientWidth }, selected ? 'element.png' : 'preview.png')
      onAttachImage(file)
      if (onInsertToChat && !selected) onInsertToChat(mt("theScreenshotShowsThePreview"))
      toast.success(mt("screenshotAttached"))
    } catch (e) { toast.error(describeError(e)) } finally { setShooting(false) }
  }
  useEffect(() => { setConsoleLines([]); setNetwork([]) }, [previewRev, source.src])
  const networkFailed = network.filter((n) => !n.ok).length
  // Iterative fixes: listen to the preview console for eight seconds after a reload. If errors
  // appear, offer a fix action that sends them directly to the assistant.
  const [autofix, setAutofix] = useState<{ rev: number; dismissed: boolean }>({ rev: 0, dismissed: false })
  const watchUntil = useRef(0)
  useEffect(() => { watchUntil.current = Date.now() + 8_000; setAutofix({ rev: previewRev, dismissed: false }) }, [previewRev, source.src])
  const recentErrors = consoleLines.filter((l) => l.level === 'error' && l.at <= watchUntil.current)
  const showAutofix = !autofix.dismissed && recentErrors.length > 0
  const askFix = (): void => {
    const text = mt("errorsAppearedInThePreviewConsoleAfterTheLatest", { p0: recentErrors.slice(-5).map((l) => `- ${l.text.slice(0, 300)}`).join('\n') })
    if (onAskAssistant) onAskAssistant(text); else onInsertToChat?.(text)
    setAutofix((a) => ({ ...a, dismissed: true }))
  }
  const consoleErrors = consoleLines.filter((l) => l.level === 'error').length
  const sendConsoleToChat = (): void => {
    const errors = consoleLines.filter((l) => l.level === 'error' || l.level === 'warn').slice(-5)
    if (!onInsertToChat || errors.length === 0) return
    onInsertToChat(mt("errorsInThePreviewConsoleValueFixThem", { p0: errors.map((l) => `- [${l.level}] ${l.text.slice(0, 300)}`).join('\n') }))
  }
  const sendNetworkToChat = (): void => {
    const failed = network.filter((n) => !n.ok).slice(-8)
    if (!onInsertToChat || failed.length === 0) return
    onInsertToChat(mt("resourcesFailedToLoadInThePreviewValueFix", { p0: failed.map((n) => `- ${n.method} ${n.url} → ${n.status || mt("network")}`).join('\n') }))
  }
  const dimensions: [number | null, number | null] = customSize ?? [DEVICE_WIDTH[device], device === 'mobile' ? 844 : device === 'tablet' ? 1024 : null]
  const frameWidth = rotated ? dimensions[1] : dimensions[0]
  const frameHeight = rotated ? dimensions[0] : dimensions[1]
  const previewSrc = source.kind === 'make' ? `${source.src}${source.src.includes('?') ? '&' : '?'}makeScheme=${previewScheme}` : source.src
  // Overflow menu: move secondary actions out of the header to prevent wrapping onto several rows,
  // especially on phones. Close on outside click or Escape.
  const [moreOpen, setMoreOpen] = useState(false)
  const moreRef = useRef<HTMLDivElement | null>(null)
  useEffect(() => {
    if (!moreOpen) return
    const onDoc = (e: MouseEvent): void => { if (!moreRef.current?.contains(e.target as Node)) setMoreOpen(false) }
    const onKey = (e: KeyboardEvent): void => { if (e.key === 'Escape') setMoreOpen(false) }
    document.addEventListener('mousedown', onDoc); document.addEventListener('keydown', onKey)
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onKey) }
  }, [moreOpen])
  const item = (label: string, onClick: () => void, opts: { ariaLabel?: string; disabled?: boolean; title?: string } = {}): JSX.Element => (
    <button key={opts.ariaLabel ?? label} type="button" aria-label={opts.ariaLabel} title={opts.title} disabled={opts.disabled} onClick={() => { setMoreOpen(false); onClick() }}>{label}</button>
  )
  const controls = (
        <>
          <div className="make-devices" role="group" aria-label={mt("previewWidth")}>
            {(['desktop', 'tablet', 'mobile', ...(isPhone ? [] : ['all' as Device])] as Device[]).map((d) => (
              <button key={d} type="button" aria-pressed={device === d} className={device === d ? 'make-device on' : 'make-device'} title={DEVICE_LABEL[d]} aria-label={DEVICE_LABEL[d]} onClick={() => { setDevice(d); setCustomSize(null); setRotated(false) }}>
                {d === 'desktop' ? mt("pc") : d === 'tablet' ? mt("tablet") : d === 'mobile' ? mt("phone") : '⫼'}
              </button>
            ))}
          </div>
          <IconButton size="sm" aria-label={mt("selectElement")} title={inspectTitle ?? mt("selectAnElementOnThePageAndAskThe")} aria-pressed={inspect} className={inspect ? 'make-inspect on' : undefined} onClick={() => setInspect((v) => !v)}>⌖</IconButton>
          <IconButton size="sm" aria-label={mt("refreshPreview")} title={mt("refreshPreview")} onClick={() => refresh()}>⟳</IconButton>
          <Button size="sm" variant={commentsOpen ? 'secondary' : 'ghost'} aria-pressed={commentsOpen} onClick={() => setCommentsOpen((v) => !v)} title={mt("commentsOnPreviewElements")}>💬{comments && comments.some((c) => !c.resolved) ? ` ${comments.filter((c) => !c.resolved).length}` : ''}</Button>
        </>
  )
  const actions = <>
      {onAskOnlyChange && <IconButton size="sm" aria-label={mt("askOnly")} title={askOnly ? mt("questionModeTheNextResponseWillNotEditFiles") : mt("askOnlyTheNextTurnAnswersWithoutEditingFiles")} aria-pressed={askOnly} className={askOnly ? 'make-inspect on' : undefined} onClick={() => onAskOnlyChange(!askOnly)}>❓</IconButton>}
      {features.publish && projectActions?.publish && <Button size="sm" variant={published ? 'secondary' : 'ghost'} onClick={projectActions?.publish} >{published ? mt("published") : mt("publish")}</Button>}
      <div className="make-more" ref={moreRef}>
        <IconButton size="sm" aria-label={mt("more")} title={mt("moreActions")} aria-haspopup="true" aria-expanded={moreOpen} onClick={() => setMoreOpen((v) => !v)}>⋯</IconButton>
        {moreOpen && (
          <div className="jcard-menu make-more-menu" role="group" aria-label={mt("moreActions")} data-testid="make-more-menu">
            {showPreviewControls && <>
              {item(mt('customSize'), () => openAsk(mt('customSize'), mt('previewSizePrompt'), (customSize ?? [390, 844]).join(' × '), mt('apply'), (value) => {
                const match = /^([0-9]+)\s*[x×]\s*([0-9]+)$/.exec(value.trim())
                const width = Number(match?.[1]), height = Number(match?.[2])
                if (!match || width < 240 || width > 3840 || height < 240 || height > 3840) { toast.error(mt('previewSizePrompt')); return }
                setDevice('desktop'); setCustomSize([width, height]); setRotated(false)
              }))}
              {item(mt('rotatePreview'), () => setRotated((value) => !value), { disabled: dimensions[0] === null || dimensions[1] === null })}
              {item(mt("themeValue", { p0: previewScheme === 'auto' ? mt("system") : previewScheme === 'dark' ? mt("dark") : mt("light") }), () => cycleScheme(), { ariaLabel: mt("previewTheme"), title: mt("switchPreviewTheme") })}
              {item(mt("elementStateValue", { p0: forcedState ?? mt("normal") }), () => cycleForcedState(), { ariaLabel: mt("elementState"), title: mt("showTheSelectedElementInHoverFocusActiveBy"), disabled: !selected })}
              {item(`Reduced motion: ${reducedMotion ? mt("on") : mt("off")}`, () => toggleReducedMotion(), { ariaLabel: 'Reduced motion', title: mt("emulatePrefersReducedMotionWithZeroDurationAnimationsAnd") })}
              {item(mt("slowNetworkValue", { p0: slowMs === 0 ? mt("off") : mt("valueS", { p0: slowMs / 1000 }) }), () => cycleSlowMs(), { ariaLabel: mt("slowNetwork"), title: mt("delayFetchResponsesInThePreviewMocksAndData") })}
              <label className="make-more-row"><span>{mt("previewLanguage")}</span>
                <select className="make-lang" aria-label={mt("previewLanguage")} value={previewLang} onChange={(e) => { setPreviewLang(e.target.value); sendEnv(previewScheme, e.target.value) }} title={mt("thePreviewDocumentSLangAttribute")}>
                  <option value="">{mt("auto")}</option>
                  {['ru', 'en', 'de', 'fr', 'es', 'zh', 'ar'].map((l) => <option key={l} value={l}>{l}</option>)}
                </select>
              </label>
              {item(mt("checkAccessibility"), () => void runA11y(), { ariaLabel: mt("checkAccessibility_307c02"), disabled: a11yBusy, title: mt("axeCoreInThePreviewContrastAltTextLabels") })}
              {onAttachImage && item(selected ? mt("attachElementScreenshotToChat") : mt("attachPreviewScreenshotToChat"), () => void screenshotToChat(), { ariaLabel: mt("attachPreviewScreenshotToChat_ef08c9"), disabled: shooting })}
              {item(mt("openInNewTab"), () => window.open(previewSrc, '_blank', 'noopener'), { ariaLabel: mt("openInNewTab_97acdc") })}
              <hr />
            </>}
            {features.upload && projectActions?.upload && item(mt('uploadFiles'), projectActions.upload, { ariaLabel: mt('upload') })}
            {features.storage && projectActions?.storage && item(mt('storage'), projectActions.storage)}
            {features.templates && projectActions?.templates && item(mt('projectTemplates'), projectActions.templates, { ariaLabel: mt('projectTemplates_0a30aa') })}
            {moreActions?.(item)}
          </div>
        )}
      </div>
      <IconButton size="sm" aria-label={fullscreen ? mt("collapsePanel") : mt("fullScreen")} title={fullscreen ? mt("collapsePanel") : mt("fullScreen")} aria-pressed={fullscreen} onClick={() => setFullscreen((v) => !v)}>⛶</IconButton>
  </>
  const renderPreview = (beforeSelection?: ReactNode, afterSelection?: ReactNode): ReactNode => (
    <div className="make-preview" data-testid="make-preview">
      {beforeSelection}
          {selected && (
            <div className="make-selected" data-testid="make-selected">
              {selected.source || selected.story ? <MakeElementCard selected={selected} projectName={projectName ?? conversationId} actions={{
                openInCode: onOpenInCode, addToPrompt: onInsertToChat ? text => { onInsertToChat(text); setInspect(false) } : undefined,
                comment: commentActions ? () => setCommentsOpen(true) : undefined, styles: () => setStyleOpen(value => !value)
              }} /> : <>
              <code className="make-selected-sel" title={selected.selector}>&lt;{selected.tag}&gt; {selected.selector}</code>
              {selected.text && <span className="make-selected-text">«{selected.text.slice(0, 80)}»</span>}
              <span className="make-selected-actions">
                <Button size="sm" variant={styleOpen ? 'secondary' : 'ghost'} aria-expanded={styleOpen} onClick={() => setStyleOpen((v) => !v)}>{mt("styles")}</Button>
                {onInsertToChat && <Button size="sm" variant="primary" onClick={sendSelectedToChat}>{mt("toChat")}</Button>}
              </span></>}
              <span className="make-selected-actions">
                <IconButton size="sm" aria-label={mt("clearSelection")} title={mt("clearSelection")} onClick={() => { previewStyles({}); setSelected(null) }}>✕</IconButton>
              </span>
            </div>
          )}
          {selected && styleOpen && (
            <MakeStylePanel selector={selected.selector} id={selected.id} className={selected.className} computed={selected.styles ?? {}} onPreview={previewStyles} onWrite={onWriteStyles} onReset={() => previewStyles({})} />
          )}
          {afterSelection}
          <div className={commentsOpen ? 'make-preview-body make-preview-split' : 'make-preview-body'}>
          <div className={`make-frame-host make-frame-host--${device}`}>
            {previewReady && <iframe
              ref={frameRef}
              key={`${source.src}:${previewRev}`}
              className="make-frame"
              title={frameTitle ?? mt("projectPreview")}
              src={previewSrc}
              onLoad={restorePageState}
              sandbox="allow-scripts allow-forms allow-modals allow-popups allow-same-origin allow-downloads"
              style={frameWidth ? { width: `${frameWidth}px`, ...(frameHeight ? { height: `${frameHeight}px`, flex: '0 0 auto' } : {}) } : device === 'all' ? { width: '1200px' } : undefined}
            />}
            {device === 'all' && previewReady && SYNC_WIDTHS.map((w, i) => (
              <iframe key={`${source.src}:${previewRev}-${w}`} ref={(el) => { syncFramesRef.current[i] = el }} className="make-frame make-frame--sync" title={mt("previewAtValuePx", { p0: w })} src={previewSrc} sandbox="allow-scripts allow-forms allow-modals allow-popups allow-same-origin allow-downloads" style={{ width: `${w}px` }} />
            ))}
          </div>
          {commentsOpen && commentActions && (
            <MakeCommentsPanel {...commentActions} comments={comments ?? []}
              selected={selected} onAdd={text => selected ? commentActions.onAdd(selected, text) : Promise.resolve()}
              onHighlight={highlightInPreview} onAskAssistant={onAskAssistant ?? onInsertToChat}
              onClose={() => setCommentsOpen(false)} />
          )}
          </div>
          {a11y !== null && (
            <section className={a11y.length ? 'make-a11y make-a11y--bad' : 'make-a11y'} aria-label={mt("accessibilityCheck")} data-testid="make-a11y">
              <div className="make-a11y-head">
                <strong>{a11y.length === 0 ? mt("accessibilityNoViolationsFound") : mt("accessibilityValueViolations", { p0: a11y.length })}</strong>
                <span className="make-a11y-actions">
                  {a11y.length > 0 && (onAskAssistant || onInsertToChat) && <Button size="sm" variant="primary" onClick={() => { (onAskAssistant ?? onInsertToChat)!(a11yPrompt(a11y)) }}>{mt("fix")}</Button>}
                  <IconButton size="sm" aria-label={mt("hideAccessibilityResults")} title={mt("hide")} onClick={() => setA11y(null)}>✕</IconButton>
                </span>
              </div>
              {a11y.length > 0 && (
                <ul className="make-a11y-list">
                  {a11y.map((v) => (
                    <li key={v.id} className={`make-a11y-row make-a11y-row--${v.impact}`}>
                      <span className="make-a11y-impact">{a11yImpact(v.impact)}</span>
                      <button type="button" className="make-a11y-help" onClick={() => showA11yTarget(v.target)} title={v.target}>{a11yHelp(v)}</button>
                      <small>{v.nodes}{' '}{mt("elements")}</small>
                      <a href={v.helpUrl} target="_blank" rel="noreferrer">?</a>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          )}
          {showAutofix && (
            <div className="make-autofix" role="alert" data-testid="make-autofix">
              <span>{mt("afterTheChangeTheConsoleHas")}{' '}{recentErrors.length === 1 ? mt("anError") : mt("errorsValue", { p0: recentErrors.length })} — <code>{recentErrors[recentErrors.length - 1]!.text.slice(0, 120)}</code></span>
              <span className="make-autofix-actions">
                {(onAskAssistant || onInsertToChat) && <Button size="sm" variant="primary" onClick={askFix}>{mt("fix")}</Button>}
                <Button size="sm" variant="ghost" onClick={() => { setAutofix((a) => ({ ...a, dismissed: true })); setConsoleOpen(true) }}>{mt("showConsole")}</Button>
                <IconButton size="sm" aria-label={mt("hideFixSuggestion")} title={mt("hide")} onClick={() => setAutofix((a) => ({ ...a, dismissed: true }))}>✕</IconButton>
              </span>
            </div>
          )}
          <section className={consoleOpen ? 'make-console make-console--open' : 'make-console'} aria-label={mt("previewConsole")} data-testid="make-console">
            <div className="make-console-head">
              <span className="make-console-tabs">
                <button type="button" className={`make-console-toggle${bottomTab === 'console' ? ' on' : ''}`} aria-expanded={consoleOpen && bottomTab === 'console'} onClick={() => { if (bottomTab === 'console') setConsoleOpen((v) => !v); else { setBottomTab('console'); setConsoleOpen(true) } }}>
                  {consoleOpen && bottomTab === 'console' ? '▾' : '▸'}{' '}{mt("console")}{' '}<span className="make-console-count">{consoleLines.length}</span>
                  {consoleErrors > 0 && <span className="make-console-errors" data-testid="make-console-errors">{consoleErrors}{' '}{mt("errors")}</span>}
                </button>
                <button type="button" className={`make-console-toggle${bottomTab === 'network' ? ' on' : ''}`} aria-expanded={consoleOpen && bottomTab === 'network'} onClick={() => { if (bottomTab === 'network') setConsoleOpen((v) => !v); else { setBottomTab('network'); setConsoleOpen(true) } }} data-testid="make-network-toggle">
                  {consoleOpen && bottomTab === 'network' ? '▾' : '▸'}{' '}{mt("network_b3c4b1")}{' '}<span className="make-console-count">{network.length}</span>
                  {networkFailed > 0 && <span className="make-console-errors" data-testid="make-network-failed">{networkFailed}{' '}{mt("failedToLoad")}</span>}
                </button>
              </span>
              <span className="make-console-actions">
                {onInsertToChat && bottomTab === 'console' && consoleErrors > 0 && <Button size="sm" variant="secondary" onClick={sendConsoleToChat}>{mt("toChat")}</Button>}
                {onInsertToChat && bottomTab === 'network' && networkFailed > 0 && <Button size="sm" variant="secondary" onClick={sendNetworkToChat}>{mt("toChat")}</Button>}
                {bottomTab === 'console' && consoleLines.length > 0 && <Button size="sm" variant="ghost" onClick={() => setConsoleLines([])}>{mt("clear")}</Button>}
                {bottomTab === 'network' && network.length > 0 && <Button size="sm" variant="ghost" onClick={() => setNetwork([])}>{mt("clear")}</Button>}
              </span>
            </div>
            {consoleOpen && bottomTab === 'network' && (
              <ol className="make-console-lines make-network" data-testid="make-network">
                {network.length === 0 && <li className="make-console-empty">{mt("noRequestsYetPreviewFetchXhrRequestsWillAppear")}</li>}
                {network.map((n, i) => (
                  <li key={`${n.at}-${i}`} className={`make-network-row${n.ok ? '' : ' make-network-row--bad'}`}>
                    <span className="make-network-status">{n.status || '—'}</span>
                    <span className="make-network-method">{n.method}</span>
                    <code className="make-network-url" title={n.url}>{n.url}</code>
                    <small>{n.ms}{' '}{mt("ms")}{' '}{n.kind}</small>
                  </li>
                ))}
              </ol>
            )}
            {consoleOpen && bottomTab === 'console' && (
              <ol className="make-console-lines">
                {consoleLines.length === 0 && <li className="make-console-empty">{mt("noConsoleOutputYetPageLogsAndErrorsWill")}</li>}
                {consoleLines.map((l, i) => <li key={`${l.at}-${i}`} className={`make-console-line make-console-line--${l.level}`}><span className="make-console-level">{l.level}</span><code>{l.text}</code></li>)}
              </ol>
            )}
          </section>
    </div>
  )
  return <>
    {children ? children({ controls, actions, fullscreen, zen, setZen, previewSrc, a11y, renderPreview }) : (
      <section lang={locale} className={`make-pane${fullscreen || zen ? ' make-pane--fs' : ''}`} data-testid="make-preview-host">
        <div className="make-head" role="toolbar" aria-label={mt('projectPanel')}>{controls}<span className="make-head-spacer" />
          {!isPhone && <IconButton size="sm" aria-label={mt('zenMode')} title={mt('zenMode')} aria-pressed={zen} onClick={() => setZen(value => !value)}>⛶</IconButton>}
          {actions}
        </div>
        {renderPreview()}
      </section>
    )}
      {ask && (
        <Dialog className="make-dialog" padded title={ask.title} ariaLabel={ask.title} size="sm" onClose={() => setAsk(null)} testId="make-ask">
          <form className="make-ask" onSubmit={(e) => { e.preventDefault(); const value = askValue.trim(); setAsk(null); if (value) ask.onSubmit(value) }}>
            <label className="make-ask-field"><span>{localizeMakeText(ask.label)}</span><input className="tin" autoFocus value={askValue} aria-label={localizeMakeText(ask.label)} onChange={(e) => setAskValue(e.target.value)} /></label>
            <div className="make-ask-actions">
              <Button size="sm" variant="secondary" type="button" onClick={() => setAsk(null)}>{mt("cancel")}</Button>
              <Button size="sm" variant="primary" type="submit" disabled={!askValue.trim()}>{ask.submit}</Button>
            </div>
          </form>
        </Dialog>
      )}
  </>
})
