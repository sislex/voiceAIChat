import { randomBytes } from 'node:crypto'
import { IDENTITY_TENANT_PATHS } from '../../../../packages/contracts/src/accountAccess.js'
import type { TeamInvitationRole } from '../../../../packages/contracts/src/accountAccess.js'
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import type { AuthDatabase } from '../ports.js'
import type { AuthenticateFn } from './auth.js'

const INVITATION_TTL_MS = 7 * 24 * 60 * 60_000

export function registerTeamTenantRoutes(app: FastifyInstance, db: AuthDatabase, authenticate: AuthenticateFn): void {
  const guard = async (request: FastifyRequest, reply: FastifyReply) => {
    const verdict = await authenticate(request)
    if (!verdict.ok) return reply.code(verdict.status).send({ error: verdict.error })
    request.user = verdict.user
  }
  const bodyOf = (value: unknown): Record<string, unknown> | null => value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : null
  const roleOf = (value: unknown): TeamInvitationRole | null => value === 'admin' || value === 'member' ? value : null

  app.get(IDENTITY_TENANT_PATHS.tenants, { preHandler: guard }, async request => db.identity.listTenantMemberships(request.user!.name))
  app.post<{ Body: unknown }>(IDENTITY_TENANT_PATHS.tenants, { preHandler: guard }, async (request, reply) => {
    const body = bodyOf(request.body)
    if (!body || Object.keys(body).some(key => key !== 'name') || typeof body.name !== 'string') return reply.code(400).send({ error: 'invalid_tenant' })
    return reply.code(201).send(await db.identity.createTeamTenant(request.user!.name, body.name))
  })
  app.patch<{ Params: { tenantId: string }; Body: unknown }>('/api/session/tenants/:tenantId', { preHandler: guard }, async (request, reply) => {
    const body = bodyOf(request.body)
    if (!body || Object.keys(body).some(key => key !== 'name') || typeof body.name !== 'string') return reply.code(400).send({ error: 'invalid_tenant' })
    return db.identity.renameTeamTenant(request.user!.name, request.params.tenantId, body.name)
  })
  app.delete<{ Params: { tenantId: string } }>('/api/session/tenants/:tenantId', { preHandler: guard }, async (request, reply) => {
    await db.identity.deleteTeamTenant(request.user!.name, request.params.tenantId)
    return reply.code(204).send()
  })
  app.get<{ Params: { tenantId: string } }>('/api/session/tenants/:tenantId/members', { preHandler: guard }, async request =>
    db.identity.listTeamTenantMembers(request.user!.name, request.params.tenantId))
  app.put<{ Params: { tenantId: string; userName: string }; Body: unknown }>('/api/session/tenants/:tenantId/members/:userName', { preHandler: guard }, async (request, reply) => {
    const body = bodyOf(request.body), role = roleOf(body?.role)
    if (!body || Object.keys(body).some(key => key !== 'role') || !role) return reply.code(400).send({ error: 'invalid_tenant_role' })
    await db.identity.setTeamTenantMemberRole(request.user!.name, request.params.tenantId, request.params.userName, role)
    return reply.code(204).send()
  })
  app.delete<{ Params: { tenantId: string; userName: string } }>('/api/session/tenants/:tenantId/members/:userName', { preHandler: guard }, async (request, reply) => {
    await db.identity.removeTeamTenantMember(request.user!.name, request.params.tenantId, request.params.userName)
    return reply.code(204).send()
  })
  app.get<{ Params: { tenantId: string } }>('/api/session/tenants/:tenantId/invitations', { preHandler: guard }, async request =>
    db.identity.listTeamTenantInvitations(request.user!.name, request.params.tenantId))
  app.post<{ Params: { tenantId: string }; Body: unknown }>('/api/session/tenants/:tenantId/invitations', { preHandler: guard }, async (request, reply) => {
    const body = bodyOf(request.body), role = roleOf(body?.role)
    if (!body || Object.keys(body).some(key => !['target', 'role'].includes(key)) || typeof body.target !== 'string' || !role) {
      return reply.code(400).send({ error: 'invalid_tenant_invitation' })
    }
    const token = randomBytes(24).toString('base64url')
    const invitation = await db.identity.inviteTeamTenantMember(request.user!.name, request.params.tenantId, body.target, role, token, INVITATION_TTL_MS)
    return reply.code(201).send({ invitation, token })
  })
  app.delete<{ Params: { tenantId: string; invitationId: string } }>('/api/session/tenants/:tenantId/invitations/:invitationId', { preHandler: guard }, async (request, reply) => {
    await db.identity.revokeTeamTenantInvitation(request.user!.name, request.params.tenantId, request.params.invitationId)
    return reply.code(204).send()
  })
  app.get('/api/session/tenant-invitations', { preHandler: guard }, async request =>
    db.identity.listPendingTeamTenantInvitations(request.user!.name))
  app.post<{ Params: { token: string } }>('/api/session/tenant-invitations/:token', { preHandler: guard }, async request =>
    db.identity.acceptTeamTenantInvitation(request.user!.name, request.params.token))
}
