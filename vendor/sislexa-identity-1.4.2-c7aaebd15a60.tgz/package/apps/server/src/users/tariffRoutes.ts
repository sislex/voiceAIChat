import { REST } from '@voicechat/shared'
import { validTariffPlanInput } from '../../../../packages/contracts/src/accountAccess.js'
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import type { AuthDatabase } from '../ports.js'
import type { AuthenticateFn } from './auth.js'
import type { SessionHub } from './sessionHub.js'

export function registerTariffRoutes(app: FastifyInstance, db: AuthDatabase, authenticate: AuthenticateFn, hub?: SessionHub): void {
  const guard = (admin: boolean) => async (request: FastifyRequest, reply: FastifyReply) => {
    const verdict = await authenticate(request)
    if (!verdict.ok) return reply.code(verdict.status).send({ error: verdict.error })
    if (admin && verdict.user.role !== 'admin') return reply.code(403).send({ error: 'forbidden' })
    request.user = verdict.user
  }
  const notifyPlan = async (id: string) => {
    for (const assignment of await db.identity.listTariffAssignments()) if (assignment.tariffId === id) hub?.emit(assignment.userName)
  }
  app.get(REST.sessionAccountAccess, { preHandler: guard(false) }, async request => db.identity.getAccountAccess(request.user!.name, request.user!.account?.tenantId))
  app.get(REST.sessionTariffs, { preHandler: guard(true) }, async () => db.identity.listTariffPlans())
  app.post<{ Body: unknown }>(REST.sessionTariffs, { preHandler: guard(true) }, async (request, reply) => {
    if (!validTariffPlanInput(request.body) || request.body.expectedRevision !== undefined) return reply.code(400).send({ error: 'invalid_tariff' })
    const plan = await db.identity.saveTariffPlan(request.body)
    return reply.code(201).send(plan)
  })
  app.put<{ Params: { id: string }; Body: unknown }>(REST.sessionTariffs + '/:id', { preHandler: guard(true) }, async (request, reply) => {
    if (!validTariffPlanInput(request.body) || request.body.id !== request.params.id || request.body.expectedRevision === undefined) return reply.code(400).send({ error: 'invalid_tariff' })
    const plan = await db.identity.saveTariffPlan(request.body)
    await notifyPlan(plan.id)
    return plan
  })
  app.get(REST.sessionTariffAssignments, { preHandler: guard(true) }, async () => db.identity.listTariffAssignments())
  app.put<{ Params: { user: string }; Body: unknown }>(REST.sessionTariffAssignments + '/:user', { preHandler: guard(true) }, async (request, reply) => {
    const body = request.body as Record<string, unknown> | null
    if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).length !== 1 || typeof body.tariffId !== 'string' || body.tariffId.length > 64) return reply.code(400).send({ error: 'invalid_assignment' })
    const access = await db.identity.assignUserTariff(request.params.user, body.tariffId)
    hub?.emit(request.params.user)
    return access
  })
}
