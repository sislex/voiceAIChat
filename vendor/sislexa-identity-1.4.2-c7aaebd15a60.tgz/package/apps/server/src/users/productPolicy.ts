import { hasProductCapability } from '../../../../packages/contracts/src/accountAccess.js'
import type { AccountAccess, AuthenticatedAccount, ProductCapability } from '../../../../packages/contracts/src/accountAccess.js'
import type { AssistantKind, SessionUser } from '@voicechat/shared'

export function accountContext(access: AccountAccess): AuthenticatedAccount {
  return { ...(access.userId ? { userId: access.userId } : {}), tenantId: access.tenant.id, tenantKind: access.tenant.kind,
    membershipRole: access.membershipRole ?? 'owner', tariffId: access.tariff.id, tariffRevision: access.tariff.revision, capabilities: [...access.capabilities] }
}

export function conversationCapability(kind?: AssistantKind | null): ProductCapability {
  switch (kind) {
    case 'make': return 'make.use'
    case 'images': return 'image-studio.use'
    case 'web-recorder': return 'web-reader.use'
    case 'playwright-reader': return 'playwright-reader.use'
    case 'console-reader': return 'machines.use'
    case 'kanban': return 'projects.use'
    default: return 'chat.use'
  }
}

/** Generic conversation routes need the resource's stored assistant kind in Core. */
export function requestCapability(method: string, rawUrl: string): ProductCapability | null {
  const url = rawUrl.split('?')[0]!
  if (/^\/api\/(?:session|admin|me)(?:\/|$)/.test(url)) return null
  if (/^\/api\/(?:make|preview\/make(?:-shared)?)(?:\/|$)/.test(url)) return 'make.use'
  if (/^\/api\/image-studio(?:\/|$)/.test(url)) return 'image-studio.use'
  if (/^\/api\/browser(?:\/|$)/.test(url)) return 'playwright-reader.use'
  if (/^\/api\/preview(?:\/|$)/.test(url)) return 'web-reader.use'
  if (/^\/api\/(?:stt|whisper)(?:\/|$)/.test(url)) return 'voice.stt'
  if (/^\/api\/(?:tts|voices)(?:\/|$)/.test(url)) return 'voice.tts'
  if (/^\/api\/(?:projects|ci|qa|merge)(?:\/|$)/.test(url)) return 'projects.use'
  // A personal account may still list its machines when product execution is disabled.
  if (method === 'GET' && url === '/api/agents') return null
  if (/^\/api\/(?:agents|agent-groups|console-reader|fs|pty)(?:\/|$)/.test(url)) return 'machines.use'
  return null
}

export function productAccessError(user: SessionUser, method: string, url: string, headers: Record<string, unknown>): string | null {
  if (!user.account) return 'account_unavailable'
  const tenant = headers['x-sislexa-tenant-id']
  if (tenant !== undefined && tenant !== user.account.tenantId) return 'tenant_not_allowed'
  const capability = requestCapability(method, url)
  return capability && !hasProductCapability(user.account, capability) ? 'capability_unavailable' : null
}

export function sameAccountContext(left: SessionUser, right: SessionUser | null): boolean {
  const leftAccount = left.account as AuthenticatedAccount | undefined
  const rightAccount = right?.account as AuthenticatedAccount | undefined
  return !!right && right.name === left.name && right.role === left.role &&
    !!leftAccount && !!rightAccount && leftAccount.userId === rightAccount.userId && leftAccount.tenantId === rightAccount.tenantId &&
    leftAccount.tenantKind === rightAccount.tenantKind && leftAccount.membershipRole === rightAccount.membershipRole &&
    leftAccount.tariffId === rightAccount.tariffId && leftAccount.tariffRevision === rightAccount.tariffRevision &&
    [...leftAccount.capabilities].sort().join('\0') === [...rightAccount.capabilities].sort().join('\0')
}
