import {mkdirSync,readFileSync,existsSync} from 'node:fs'
import {join,resolve} from 'node:path'
import {fileURLToPath} from 'node:url'
import {createComponentRuntime} from '@sislexa/component-runtime'
import {applicationRuntimeMetadata} from '@voicechat/shared'
import {createIdentityCoreClient} from '../../../packages/client/src/rpc.js'
import {openIdentityStore} from './store/open.js'
import {loadOrCreateSecret} from './users/accounts.js'
import {createMailer} from './users/mailer.js'
import {buildIdentityServer} from './server.js'
import {registerIdentityAssets} from './static.js'
const e=process.env,dir=e.IDENTITY_DATA_DIR??'/data',port=Number(e.PORT??8798)
mkdirSync(dir,{recursive:true})
if(!e.SISLEXA_COMPONENT_CONFIG)throw Error('SISLEXA_COMPONENT_CONFIG is required')
const component=await createComponentRuntime({configFile:e.SISLEXA_COMPONENT_CONFIG,contractFile:fileURLToPath(new URL('../component-contract.json',import.meta.url)),metadata:applicationRuntimeMetadata('identity',{...e,VC_APPLICATION_VERSION:e.VC_APPLICATION_VERSION??'1.4.2',VC_APPLICATION_API_VERSION:'1.3.0',VC_APPLICATION_DATA_VERSION:'1.2.0'})})
const dependency=component.config.dependencies.some(d=>d.applicationId==='core')?component.dependency('core'):undefined
const remote=dependency?createIdentityCoreClient(dependency):undefined
const standalone={settings:{getAppConfig:async(key:string)=>key==='signup.enabled'?(e.IDENTITY_SIGNUP_ENABLED==='true'?'1':'0'):key==='signup.role'?'developer':null,getSettings:async()=>({loginNewDeviceEmails:false})},projects:{isProjectOwner:async()=>false,projectFeatures:async()=>({}) as never,attachInvitationsToNewUser:async()=>{}}}
const core=remote??standalone
const cleanup=remote as unknown as Parameters<typeof openIdentityStore>[0]['cleanup']|undefined
const disabled=async()=>{throw Error('Core cleanup is unavailable; user deletion was refused')}
const storage=await openIdentityStore({filename:join(dir,'identity.db'),databaseUrl:e.IDENTITY_DATABASE_URL,cleanup:cleanup??{chat:{deleteConversationsOfUser:disabled},machines:{deleteAgentsOfUser:disabled},settings:{deleteUserSettings:disabled},tasks:{unassignUser:disabled},projects:{detachDeletedUser:disabled}}})
const secret=e.IDENTITY_SESSION_SECRET_FILE?readFileSync(e.IDENTITY_SESSION_SECRET_FILE,'utf8').trim():loadOrCreateSecret(dir)
if(!secret)throw Error('Empty session secret')
if(e.IDENTITY_ADMIN_PASSWORD)await storage.store.ensureAdmin(e.IDENTITY_ADMIN_PASSWORD)
const {app}=await buildIdentityServer({database:{settings:core.settings,projects:core.projects,identity:storage.store},secret,authorize:(h,s)=>component.authorize(h,s),registerComponent:app=>component.register(app),publicUrl:e.IDENTITY_PUBLIC_URL,mailer:createMailer({smtpUrl:e.VC_SMTP_URL??null,mailFrom:e.VC_MAIL_FROM??null},message=>console.warn(message)),...(dependency?{coreUrl:dependency.url,accountFetch:dependency.publicFetchImpl}:{})})
registerIdentityAssets(app,resolve(fileURLToPath(new URL('../..',import.meta.url))))
app.addHook('onClose',async()=>{await storage.close()})
for(const signal of ['SIGINT','SIGTERM'] as const)process.once(signal,()=>{void app.close().catch(()=>{process.exitCode=1})})
await app.listen({host:e.HOST??'127.0.0.1',port})
