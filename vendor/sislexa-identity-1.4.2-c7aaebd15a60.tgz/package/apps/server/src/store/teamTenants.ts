import { createHash } from 'node:crypto'
import type {
  AccountAccess, TeamInvitationRole, TeamTenantInvitation, TeamTenantMember,
  TenantMembership, TenantMembershipRole
} from '../../../../packages/contracts/src/accountAccess.js'
import { DEFAULT_TARIFF_ID } from '../../../../packages/contracts/src/accountAccess.js'
import type { Sql } from '../../../../packages/storage-sql/src/types.js'
import type { TariffStore } from './tariffs.js'

const failure = (statusCode: number, message: string): Error => Object.assign(new Error(message), { statusCode })
const invitationHash = (token: string): string => createHash('sha256').update(token).digest('hex')
const targetOf = (target: string): string => target.trim().toLowerCase()

interface InvitationRow {
  id: string
  tenant_id: string
  tenant_name: string
  target: string
  role: TeamInvitationRole
  invited_by: string
  created_at: number
  expires_at: number
}

function invitationOf(row: InvitationRow): TeamTenantInvitation {
  return {
    id: row.id,
    tenantId: row.tenant_id,
    tenantName: row.tenant_name,
    target: row.target,
    role: row.role,
    invitedBy: row.invited_by,
    createdAt: row.created_at,
    expiresAt: row.expires_at
  }
}

/** Team membership is resolved only by Identity; callers never submit a trusted role. */
export class TeamTenantStore {
  constructor(
    private readonly sql: Sql,
    private readonly now: () => number,
    private readonly newId: () => string,
    private readonly tariffs: TariffStore
  ) {}

  private async role(userName: string, tenantId: string): Promise<TenantMembershipRole | null> {
    const row = await this.sql.get<{ role: TenantMembershipRole }>(
      'SELECT role FROM team_tenant_memberships WHERE tenant_id = ? AND user_name = ?', [tenantId, userName])
    return row?.role ?? null
  }

  private async requireRole(userName: string, tenantId: string, roles: TenantMembershipRole[]): Promise<TenantMembershipRole> {
    const role = await this.role(userName, tenantId)
    if (!role || !roles.includes(role)) throw failure(403, 'tenant_forbidden')
    return role
  }

  async list(userName: string): Promise<TenantMembership[]> {
    const personal = await this.tariffs.getAccess(userName)
    if (!personal) return []
    const ids = await this.sql.all<{ tenant_id: string }>(
      'SELECT tenant_id FROM team_tenant_memberships WHERE user_name = ? ORDER BY created_at, tenant_id', [userName])
    const teams = await Promise.all(ids.map(({ tenant_id }) => this.tariffs.getAccess(userName, tenant_id)))
    return [personal, ...teams.filter((item): item is AccountAccess => Boolean(item))]
      .map(({ tenant, membershipRole, tariff }) => ({ tenant, role: membershipRole ?? 'owner', tariff }))
  }

  async create(userName: string, name: string): Promise<TenantMembership> {
    const normalized = name.trim()
    if (!normalized || normalized.length > 80) throw failure(400, 'invalid_tenant')
    const id = this.newId(), at = this.now()
    await this.sql.transaction(async () => {
      await this.sql.run('INSERT INTO team_tenants (id, owner_user_name, name, created_at) VALUES (?, ?, ?, ?)', [id, userName, normalized, at])
      await this.sql.run(`INSERT INTO team_tenant_memberships (tenant_id, user_name, role, created_at)
        VALUES (?, ?, 'owner', ?)`, [id, userName, at])
      await this.sql.run('INSERT INTO team_tenant_tariffs (tenant_id, tariff_id, updated_at) VALUES (?, ?, ?)', [id, DEFAULT_TARIFF_ID, at])
    })
    const access = await this.tariffs.getAccess(userName, id)
    if (!access) throw new Error('Team tenant provisioning failed')
    return { tenant: access.tenant, role: access.membershipRole ?? 'owner', tariff: access.tariff }
  }

  async rename(actor: string, tenantId: string, name: string): Promise<TenantMembership> {
    await this.requireRole(actor, tenantId, ['owner', 'admin'])
    const normalized = name.trim()
    if (!normalized || normalized.length > 80) throw failure(400, 'invalid_tenant')
    await this.sql.run('UPDATE team_tenants SET name = ? WHERE id = ?', [normalized, tenantId])
    const access = await this.tariffs.getAccess(actor, tenantId)
    if (!access) throw failure(404, 'tenant_not_found')
    return { tenant: access.tenant, role: access.membershipRole ?? 'owner', tariff: access.tariff }
  }

  async delete(actor: string, tenantId: string): Promise<void> {
    await this.requireRole(actor, tenantId, ['owner'])
    await this.sql.run('DELETE FROM team_tenants WHERE id = ?', [tenantId])
  }

  async members(actor: string, tenantId: string): Promise<TeamTenantMember[]> {
    await this.requireRole(actor, tenantId, ['owner', 'admin', 'member'])
    const rows = await this.sql.all<{ user_name: string; role: TenantMembershipRole; created_at: number }>(
      `SELECT user_name, role, created_at FROM team_tenant_memberships
       WHERE tenant_id = ? ORDER BY CASE role WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 ELSE 2 END, user_name`, [tenantId])
    return rows.map(row => ({ userName: row.user_name, role: row.role, createdAt: row.created_at }))
  }

  async invite(actor: string, tenantId: string, target: string, role: TeamInvitationRole, token: string, ttlMs: number): Promise<TeamTenantInvitation> {
    await this.requireRole(actor, tenantId, ['owner', 'admin'])
    const normalized = targetOf(target)
    if (!normalized || normalized.length > 254 || !['admin', 'member'].includes(role) || ttlMs <= 0) throw failure(400, 'invalid_tenant_invitation')
    const existing = await this.sql.get<{ name: string }>(
      'SELECT name FROM users WHERE lower(name) = ? OR lower(COALESCE(email, \'\')) = ?', [normalized, normalized])
    if (existing && await this.role(existing.name, tenantId)) throw failure(409, 'tenant_member_exists')
    const id = this.newId(), at = this.now()
    await this.sql.transaction(async () => {
      await this.sql.run('DELETE FROM team_tenant_invitations WHERE tenant_id = ? AND target = ?', [tenantId, normalized])
      await this.sql.run(`INSERT INTO team_tenant_invitations
        (id, tenant_id, target, role, token_hash, invited_by, created_at, expires_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)`, [id, tenantId, normalized, role, invitationHash(token), actor, at, at + ttlMs])
    })
    const row = await this.sql.get<InvitationRow>(`SELECT i.*, t.name AS tenant_name FROM team_tenant_invitations i
      JOIN team_tenants t ON t.id = i.tenant_id WHERE i.id = ?`, [id])
    return invitationOf(row!)
  }

  async invitations(actor: string, tenantId: string): Promise<TeamTenantInvitation[]> {
    await this.requireRole(actor, tenantId, ['owner', 'admin'])
    await this.sql.run('DELETE FROM team_tenant_invitations WHERE expires_at < ?', [this.now()])
    const rows = await this.sql.all<InvitationRow>(`SELECT i.*, t.name AS tenant_name FROM team_tenant_invitations i
      JOIN team_tenants t ON t.id = i.tenant_id WHERE i.tenant_id = ? ORDER BY i.created_at DESC`, [tenantId])
    return rows.map(invitationOf)
  }

  async pending(userName: string): Promise<TeamTenantInvitation[]> {
    await this.sql.run('DELETE FROM team_tenant_invitations WHERE expires_at < ?', [this.now()])
    const rows = await this.sql.all<InvitationRow>(`SELECT i.*, t.name AS tenant_name FROM team_tenant_invitations i
      JOIN team_tenants t ON t.id = i.tenant_id JOIN users u ON u.name = ?
      WHERE i.target = lower(u.name) OR i.target = lower(COALESCE(u.email, '')) ORDER BY i.created_at DESC`, [userName])
    return rows.map(invitationOf)
  }

  async accept(userName: string, token: string): Promise<TenantMembership> {
    return this.sql.transaction(async () => {
      const row = await this.sql.get<InvitationRow & { user_email: string | null }>(`SELECT i.*, t.name AS tenant_name, u.email AS user_email
        FROM team_tenant_invitations i JOIN team_tenants t ON t.id = i.tenant_id JOIN users u ON u.name = ?
        WHERE i.token_hash = ?`, [userName, invitationHash(token)])
      if (!row || row.expires_at < this.now()) throw failure(404, 'tenant_invitation_not_found')
      if (row.target !== userName.toLowerCase() && row.target !== row.user_email?.toLowerCase()) throw failure(403, 'tenant_invitation_forbidden')
      await this.sql.run(`INSERT OR IGNORE INTO team_tenant_memberships (tenant_id, user_name, role, created_at)
        VALUES (?, ?, ?, ?)`, [row.tenant_id, userName, row.role, this.now()])
      await this.sql.run('DELETE FROM team_tenant_invitations WHERE id = ?', [row.id])
      const access = await this.tariffs.getAccess(userName, row.tenant_id)
      if (!access) throw new Error('Accepted team tenant is unavailable')
      return { tenant: access.tenant, role: access.membershipRole ?? 'member', tariff: access.tariff }
    })
  }

  async revokeInvitation(actor: string, tenantId: string, invitationId: string): Promise<void> {
    await this.requireRole(actor, tenantId, ['owner', 'admin'])
    await this.sql.run('DELETE FROM team_tenant_invitations WHERE id = ? AND tenant_id = ?', [invitationId, tenantId])
  }

  async setMemberRole(actor: string, tenantId: string, userName: string, role: TeamInvitationRole): Promise<void> {
    await this.requireRole(actor, tenantId, ['owner'])
    if (!['admin', 'member'].includes(role)) throw failure(400, 'invalid_tenant_role')
    const current = await this.role(userName, tenantId)
    if (!current) throw failure(404, 'tenant_member_not_found')
    if (current === 'owner') throw failure(409, 'tenant_owner_immutable')
    await this.sql.run('UPDATE team_tenant_memberships SET role = ? WHERE tenant_id = ? AND user_name = ?', [role, tenantId, userName])
  }

  async removeMember(actor: string, tenantId: string, userName: string): Promise<void> {
    const actorRole = await this.requireRole(actor, tenantId, ['owner', 'admin', 'member'])
    const current = await this.role(userName, tenantId)
    if (!current) throw failure(404, 'tenant_member_not_found')
    if (current === 'owner') throw failure(409, 'tenant_owner_immutable')
    const self = actor === userName
    if (!self && actorRole !== 'owner' && !(actorRole === 'admin' && current === 'member')) throw failure(403, 'tenant_forbidden')
    await this.sql.run('DELETE FROM team_tenant_memberships WHERE tenant_id = ? AND user_name = ?', [tenantId, userName])
  }
}
