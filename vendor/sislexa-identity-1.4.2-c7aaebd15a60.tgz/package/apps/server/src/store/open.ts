import {createLane} from '../../../../packages/storage-sql/src/lane.js'
import Database from 'better-sqlite3'
import {randomUUID} from 'node:crypto'
import {createPgSql} from '../../../../packages/storage-sql/src/pg.js'
import {createSqliteSql} from '../../../../packages/storage-sql/src/sqlite.js'
import {postgresSchemaFrom,postgresColumnUpgradePlan} from '../../../../packages/storage-sql/src/schema.js'
import {IdentityRepo} from './identity.js'
import {IDENTITY_SCHEMA} from './schema.js'
import {initializePersonalTenants} from './tenants.js'
import type {IdentityContext} from './context.js'
export async function openIdentityStore(options:{filename:string;databaseUrl?:string;cleanup:IdentityContext['repos']}) {
 const sql=options.databaseUrl ? createPgSql({connectionString:options.databaseUrl}) : createSqliteSql(new Database(options.filename))
 try {
 if(sql.engine==='postgres') {
  const schema=postgresSchemaFrom(IDENTITY_SCHEMA)
  await sql.transaction(async()=>{
   await sql.run('SELECT pg_advisory_xact_lock(?)',[7_260_119])
   await sql.exec(schema.tables.join('\n'))
   const existing=await sql.all<{table_name:string;column_name:string}>("SELECT table_name,column_name FROM information_schema.columns WHERE table_schema = current_schema()")
   const upgrade=postgresColumnUpgradePlan(schema.columns,existing);if(upgrade.sql)await sql.exec(upgrade.sql)
   await sql.exec(schema.afterColumnsSql)
   await initializePersonalTenants(sql,Date.now,randomUUID)
  })
 } else { await sql.exec('PRAGMA foreign_keys = ON'); await sql.exec(IDENTITY_SCHEMA); await initializePersonalTenants(sql,Date.now,randomUUID) }
 } catch(error) { await sql.close().catch(()=>{}); throw error }
 const ctx:IdentityContext={sql,newId:randomUUID,now:Date.now,closed:false,repos:options.cleanup}
 const implementation=new IdentityRepo(ctx),lane=createLane()
 const store=new Proxy(implementation,{get(target,key){
  if(key==='deleteUserData')return async(user:string)=>{
   // Remote cleanup cannot share a SQL transaction. Quarantine first and retain
   // the account on failure so the same idempotent operation can be retried.
   const account=await lane.run(()=>target.getUser(user));if(!account)return
   await lane.run(async()=>{await target.setUserBlocked(user,true);await target.revokeUserSessions(user)})
   await options.cleanup.chat.deleteConversationsOfUser(user)
   await options.cleanup.machines.deleteAgentsOfUser(user)
   await options.cleanup.settings.deleteUserSettings(user)
   await options.cleanup.tasks.unassignUser(user)
   await options.cleanup.projects.detachDeletedUser(user,(account.email??'').toLowerCase())
   await lane.run(()=>target.deleteUser(user))
  }
  const value=Reflect.get(target,key)
  return typeof value==='function'?(...args:unknown[])=>lane.run(()=>value.apply(target,args)):value
 }})
 return {store,sql,close:async()=>{await lane.idle();ctx.closed=true;await sql.close()}}
}
