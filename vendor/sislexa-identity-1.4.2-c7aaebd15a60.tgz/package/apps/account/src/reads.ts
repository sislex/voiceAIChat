import type { RendererApi } from '@shared/ipc'
export interface AccountReads {
 api: RendererApi
 cache: { onInvalidated(listener: (family?: string) => void): () => void }
 periodNow(now: number): number
 peek<K extends keyof RendererApi>(channel: K, ...args: Parameters<RendererApi[K]>): Awaited<ReturnType<RendererApi[K]>> | undefined
 fresh(channel: keyof RendererApi, ...args: unknown[]): boolean
}
const READ_CHANNELS = new Set(['me:profile', 'me:security', 'usage:report', 'llm:access', 'agents:list'])
const FRESH_MS = 30_000

// Each mounted account page owns its fallback cache. Core may supply a richer
// invalidation port, but a standalone page must actually load every empty tab.
export function accountReads(source: RendererApi): AccountReads {
 const entries = new Map<string, { value: unknown; expiresAt: number }>()
 const pending = new Map<string, Promise<unknown>>()
 const keyOf = (channel: PropertyKey, args: unknown[]) => JSON.stringify([channel, args])
 const current = (key: string) => {
  const entry = entries.get(key)
  if (entry && entry.expiresAt > Date.now()) return entry
  entries.delete(key)
  return undefined
 }
 const api = new Proxy(source, { get(target, channel) {
  const method = Reflect.get(target, channel)
  if (typeof channel !== 'string' || !READ_CHANNELS.has(channel) || typeof method !== 'function') return method
  return (...args: unknown[]) => {
   const key = keyOf(channel, args), cached = current(key)
   if (cached) return Promise.resolve(cached.value)
   const active = pending.get(key)
   if (active) return active
   const request = Promise.resolve().then(() => method.apply(target, args)).then(value => {
    if (entries.size >= 64) entries.delete(entries.keys().next().value!)
    entries.set(key, { value, expiresAt: Date.now() + FRESH_MS })
    return value
   }).finally(() => pending.delete(key))
   pending.set(key, request)
   return request
  }
 } })
 return {
  api, cache: { onInvalidated: () => () => {} }, periodNow: now => now,
  peek: (channel, ...args) => current(keyOf(channel, args))?.value as never,
  fresh: (channel, ...args) => current(keyOf(channel, args)) !== undefined
 }
}
