/** @jsxRuntime automatic */
import { useCallback, useEffect, useMemo, useState } from 'react'
import { Button, ErrorState, SectionHeader } from '@voicechat/ui-kit'
import type { TeamTenantClient, TeamTenantInvitation, TeamTenantMember, TenantMembership } from '../../../packages/contracts/src/accountAccess.js'

export function TeamTenants({ client, userName, onSelected = () => location.reload() }: { client: TeamTenantClient; userName: string; onSelected?: () => void }): JSX.Element {
  const [memberships, setMemberships] = useState<TenantMembership[]>([])
  const [members, setMembers] = useState<TeamTenantMember[]>([])
  const [invitations, setInvitations] = useState<TeamTenantInvitation[]>([])
  const [pending, setPending] = useState<TeamTenantInvitation[]>([])
  const [name, setName] = useState('')
  const [target, setTarget] = useState('')
  const [acceptToken, setAcceptToken] = useState('')
  const [inviteToken, setInviteToken] = useState('')
  const [error, setError] = useState('')
  const activeId = client.activeTenantId()
  const active = useMemo(() => memberships.find(item => item.tenant.id === activeId) ?? memberships.find(item => item.tenant.kind === 'personal'), [activeId, memberships])
  const refresh = useCallback(async () => {
    try {
      const [available, incoming] = await Promise.all([client.list(), client.pending()])
      setMemberships(available); setPending(incoming); setError('')
    } catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)) }
  }, [client])
  useEffect(() => { void refresh() }, [refresh])
  useEffect(() => {
    if (active?.tenant.kind !== 'team') { setMembers([]); setInvitations([]); return }
    void client.members(active.tenant.id).then(setMembers).catch(reason => setError(String(reason)))
    if (active.role === 'owner' || active.role === 'admin') void client.invitations(active.tenant.id).then(setInvitations).catch(reason => setError(String(reason)))
  }, [active?.tenant.id, active?.role, client])
  const mutate = async (operation: () => Promise<unknown>) => { try { await operation(); await refresh(); setError('') } catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)) } }
  return <section className="vcp account-page__fallback team-tenants" aria-label="Рабочие пространства команды">
    <SectionHeader title="Рабочие пространства" level={2} />
    {error && <ErrorState message="Не удалось выполнить действие" detail={error} onRetry={() => void refresh()} />}
    <label>Активное пространство<select value={active?.tenant.id ?? ''} onChange={event => {
      const next = memberships.find(item => item.tenant.id === event.target.value)
      client.select(next?.tenant.kind === 'team' ? next.tenant.id : null); onSelected()
    }}>{memberships.map(item => <option key={item.tenant.id} value={item.tenant.id}>{item.tenant.name} · {item.tenant.kind === 'personal' ? 'личное' : item.role}</option>)}</select></label>
    <form onSubmit={event => { event.preventDefault(); void mutate(async () => { await client.create(name); setName('') }) }}>
      <label>Название команды<input value={name} maxLength={80} required onChange={event => setName(event.target.value)} /></label>
      <Button type="submit">Создать пространство</Button>
    </form>
    {pending.length > 0 && <div><h3>Приглашения</h3><ul>{pending.map(item => <li key={item.id}>{item.tenantName} · {item.role}</li>)}</ul></div>}
    <form onSubmit={event => { event.preventDefault(); void mutate(async () => { await client.accept(acceptToken); setAcceptToken('') }) }}>
      <label>Токен приглашения<input value={acceptToken} required onChange={event => setAcceptToken(event.target.value)} /></label>
      <Button type="submit">Принять приглашение</Button>
    </form>
    {active?.tenant.kind === 'team' && <>
      <p>Владелец: {active.tenant.owner}. Ваша роль: {active.role}.</p>
      <ul>{members.map(member => <li key={member.userName}>{member.userName} · {member.role}</li>)}</ul>
      {(active.role === 'owner' || active.role === 'admin') && <form onSubmit={event => { event.preventDefault(); void mutate(async () => {
        const created = await client.invite(active.tenant.id, target, 'member'); setInviteToken(created.token); setTarget('')
        setInvitations(await client.invitations(active.tenant.id))
      }) }}>
        <label>Логин или email<input value={target} maxLength={254} required onChange={event => setTarget(event.target.value)} /></label>
        <Button type="submit">Пригласить участника</Button>
      </form>}
      {inviteToken && <p role="status">Одноразовый токен приглашения: <code>{inviteToken}</code></p>}
      {invitations.length > 0 && <div><h3>Ожидают принятия</h3><ul>{invitations.map(item => <li key={item.id}>{item.target} · {item.role}</li>)}</ul></div>}
      {active.role !== 'owner' && <Button onClick={() => void mutate(async () => { await client.removeMember(active.tenant.id, userName); client.select(null); onSelected() })}>Покинуть команду</Button>}
      {active.role === 'owner' && <Button onClick={() => void mutate(async () => { await client.delete(active.tenant.id); client.select(null); onSelected() })}>Удалить пространство</Button>}
    </>}
  </section>
}
