import type { SystemRole } from '@voicechat/shared'

/** Product entitlements are independent of system permissions and provider grants. */
export const PRODUCT_CAPABILITIES = [
  'chat.use', 'make.use', 'web-reader.use', 'playwright-reader.use',
  'image-studio.use', 'voice.stt', 'voice.tts', 'projects.use', 'machines.use'
] as const
export type ProductCapability = typeof PRODUCT_CAPABILITIES[number]

export interface PersonalTenant {
  id: string
  kind: 'personal'
  name: string
  owner: string
  createdAt: number
}

export type TenantMembershipRole = 'owner' | 'admin' | 'member'

export interface TeamTenant {
  id: string
  kind: 'team'
  name: string
  owner: string
  createdAt: number
}

export type Tenant = PersonalTenant | TeamTenant

export interface TenantMembership {
  tenant: Tenant
  role: TenantMembershipRole
  tariff: TariffPlan
}

export interface TeamTenantMember {
  userName: string
  role: TenantMembershipRole
  createdAt: number
}

export type TeamInvitationRole = Exclude<TenantMembershipRole, 'owner'>

export interface TeamTenantInvitation {
  id: string
  tenantId: string
  tenantName: string
  target: string
  role: TeamInvitationRole
  invitedBy: string
  createdAt: number
  expiresAt: number
}

export interface TariffPlan {
  id: string
  name: string
  capabilities: ProductCapability[]
  revision: number
  createdAt: number
  updatedAt: number
}

export interface TariffPlanInput {
  id: string
  name: string
  capabilities: ProductCapability[]
  /** Omit when creating; updates must match the current revision. */
  expectedRevision?: number
}

/** Trusted context resolved from current Identity data, never from client claims. */
export interface AuthenticatedAccount {
  /** Stable Identity subject; older providers omit it and cannot authorize billing. */
  userId?: string
  tenantId: string
  /** Optional during rolling upgrades; current Identity always resolves both fields live. */
  tenantKind?: Tenant['kind']
  membershipRole?: TenantMembershipRole
  tariffId: string
  tariffRevision: number
  capabilities: ProductCapability[]
}

export interface AccountAccess {
  /** Stable across account metadata changes; never derive this from the login name. */
  userId?: string
  userName: string
  systemRole: SystemRole
  tenant: Tenant
  /** Older shells omit this field until they adopt team-tenant contracts. */
  membershipRole?: TenantMembershipRole
  tariff: TariffPlan
  capabilities: ProductCapability[]
}

export const IDENTITY_TENANT_PATHS = {
  tenants: '/api/session/tenants',
  invitation: (token: string) => `/api/session/tenant-invitations/${encodeURIComponent(token)}`,
  members: (tenantId: string) => `/api/session/tenants/${encodeURIComponent(tenantId)}/members`,
  member: (tenantId: string, userName: string) => `/api/session/tenants/${encodeURIComponent(tenantId)}/members/${encodeURIComponent(userName)}`,
  invitations: (tenantId: string) => `/api/session/tenants/${encodeURIComponent(tenantId)}/invitations`,
  tenant: (tenantId: string) => `/api/session/tenants/${encodeURIComponent(tenantId)}`
} as const

export interface TariffAssignment {
  userName: string
  systemRole: SystemRole
  tenantId: string
  tariffId: string
}

/** Host-injected client shared by the independent Account UI and Core shells. */
export interface AccountTariffClient {
  getAccess(): Promise<AccountAccess>
  listPlans(): Promise<TariffPlan[]>
  savePlan(input: TariffPlanInput): Promise<TariffPlan>
  listAssignments(): Promise<TariffAssignment[]>
  assign(userName: string, tariffId: string): Promise<AccountAccess>
}

export interface TeamTenantClient {
  list(): Promise<TenantMembership[]>
  create(name: string): Promise<TenantMembership>
  rename(tenantId: string, name: string): Promise<TenantMembership>
  delete(tenantId: string): Promise<void>
  members(tenantId: string): Promise<TeamTenantMember[]>
  invite(tenantId: string, target: string, role: TeamInvitationRole): Promise<{ invitation: TeamTenantInvitation; token: string }>
  invitations(tenantId: string): Promise<TeamTenantInvitation[]>
  pending(): Promise<TeamTenantInvitation[]>
  accept(token: string): Promise<TenantMembership>
  revokeInvitation(tenantId: string, invitationId: string): Promise<void>
  setMemberRole(tenantId: string, userName: string, role: TeamInvitationRole): Promise<void>
  removeMember(tenantId: string, userName: string): Promise<void>
  activeTenantId(): string | null
  select(tenantId: string | null): void
}

export const DEFAULT_TARIFF_ID = 'standard'

export function isProductCapability(value: unknown): value is ProductCapability {
  return typeof value === 'string' && (PRODUCT_CAPABILITIES as readonly string[]).includes(value)
}

export function hasProductCapability(account: AuthenticatedAccount | undefined, capability: ProductCapability): boolean {
  return account?.capabilities.includes(capability) === true
}

/** Optimistic revisions prevent an old administration screen overwriting newer edits. */
export function validTariffPlanInput(value: unknown): value is TariffPlanInput {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const input = value as Record<string, unknown>
  if (Object.keys(input).some(key => !['id', 'name', 'capabilities', 'expectedRevision'].includes(key))) return false
  return typeof input.id === 'string' && /^[a-z][a-z0-9-]{0,63}$/.test(input.id) &&
    typeof input.name === 'string' && input.name.trim().length > 0 && input.name.length <= 80 &&
    Array.isArray(input.capabilities) && input.capabilities.every(isProductCapability) &&
    new Set(input.capabilities).size === input.capabilities.length &&
    (input.expectedRevision === undefined || (Number.isSafeInteger(input.expectedRevision) && Number(input.expectedRevision) > 0))
}
