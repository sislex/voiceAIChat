import type { TeamTenantClient } from '../../contracts/src/accountAccess.js'
import { IDENTITY_TENANT_PATHS } from '../../contracts/src/accountAccess.js'
import { authHeaders, credentialedFetch, getActiveTenantId, setActiveTenantId } from './browser.js'

async function failure(response: Response): Promise<Error> {
  const body = await response.json().catch(() => ({})) as { error?: string }
  return Object.assign(new Error(body.error ?? `Tenant HTTP ${response.status}`), { status: response.status })
}

export function makeTeamTenantClient(httpBase = ''): TeamTenantClient {
  const request = async <T>(path: string, method = 'GET', body?: unknown): Promise<T> => {
    const response = await credentialedFetch(httpBase + path, {
      method,
      headers: { ...authHeaders(), ...(body === undefined ? {} : { 'content-type': 'application/json' }) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) })
    })
    if (!response.ok) throw await failure(response)
    if (response.status === 204) return undefined as T
    return response.json() as Promise<T>
  }
  return {
    list: () => request(IDENTITY_TENANT_PATHS.tenants),
    create: name => request(IDENTITY_TENANT_PATHS.tenants, 'POST', { name }),
    rename: (tenantId, name) => request(IDENTITY_TENANT_PATHS.tenant(tenantId), 'PATCH', { name }),
    delete: tenantId => request(IDENTITY_TENANT_PATHS.tenant(tenantId), 'DELETE'),
    members: tenantId => request(IDENTITY_TENANT_PATHS.members(tenantId)),
    invite: (tenantId, target, role) => request(IDENTITY_TENANT_PATHS.invitations(tenantId), 'POST', { target, role }),
    invitations: tenantId => request(IDENTITY_TENANT_PATHS.invitations(tenantId)),
    pending: () => request('/api/session/tenant-invitations'),
    accept: token => request(IDENTITY_TENANT_PATHS.invitation(token), 'POST'),
    revokeInvitation: (tenantId, invitationId) => request(`${IDENTITY_TENANT_PATHS.invitations(tenantId)}/${encodeURIComponent(invitationId)}`, 'DELETE'),
    setMemberRole: (tenantId, userName, role) => request(IDENTITY_TENANT_PATHS.member(tenantId, userName), 'PUT', { role }),
    removeMember: (tenantId, userName) => request(IDENTITY_TENANT_PATHS.member(tenantId, userName), 'DELETE'),
    activeTenantId: getActiveTenantId,
    select: setActiveTenantId
  }
}
