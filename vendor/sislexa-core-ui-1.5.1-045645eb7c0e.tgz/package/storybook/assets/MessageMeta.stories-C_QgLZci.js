import{j as d}from"./jsx-runtime-BYYWji4R.js";import{userEvent as Q,within as p,expect as u}from"./index-DeN4tkzB.js";import{M as V}from"./MessageMeta-BjjguU6X.js";import{f as e}from"./chat-COYZgq2j.js";import"./ci-DFdZK10C.js";import"./machines-BUsHtEGO.js";import"./clarification-BhK1l2ki.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./ErrorState-CqsakWkx.js";import"./kb-CjYTCLN0.js";import"./view-BrHz5xl6.js";import"./images-CH23vBlI.js";import"./tools-D2dVYbOd.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./types-DFdjDDUq.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CA-icE-7.js";const xe={title:"Chat/MessageMeta",component:V,args:{meta:e()},decorators:[t=>d.jsx("div",{className:"msg ai",children:d.jsxs("div",{className:"mfoot",style:{paddingTop:120},children:[d.jsx("span",{className:"mtime",children:"10:01"}),d.jsx(t,{})]})})]},o={},r={args:{meta:{durationMs:1200,inputTokens:800,outputTokens:90}}},s={args:{meta:e({costUsd:void 0,model:"gpt-5-codex",request:{...e().request,provider:"codex",model:"gpt-5-codex",resumed:!1}})}},n={args:{meta:e({interrupted:!0})}},i={args:{meta:e({request:{...e().request,attachments:["/tmp/скриншот-1.png","/tmp/лог-рана.txt"],kbContext:{confidence:"high",sections:[{documentId:"ui",title:"ui.md",heading:"Витрина Storybook",sourcePath:"docs/kb/ui.md",anchor:"#storybook"},{documentId:"testing",title:"testing-operations.md",heading:"Тестовая матрица",sourcePath:"docs/kb/testing-operations.md",anchor:"#матрица"}]}}})}},c={play:async({canvasElement:t})=>{const a=p(t);await Q.hover(a.getByLabelText("Сведения об ответе").parentElement),await u(a.getByTestId("meta-tip")).toHaveTextContent("1.5k → 320")}},m={play:async({canvasElement:t})=>{await Q.click(p(t).getByLabelText("Сведения об ответе"));const a=p(document.body);await u(await a.findByTestId("meta-overlay")).toBeInTheDocument(),await u(a.getByTestId("meta-prompt")).toHaveTextContent("Как дела?")}};var l,g,h,y,x;o.parameters={...o.parameters,docs:{...(l=o.parameters)==null?void 0:l.docs,source:{originalSource:"{}",...(h=(g=o.parameters)==null?void 0:g.docs)==null?void 0:h.source},description:{story:"Обычный ход: иконка ⓘ. Сводка появляется по наведению, панель — по клику.",...(x=(y=o.parameters)==null?void 0:y.docs)==null?void 0:x.description}}};var T,v,k,b,w;r.parameters={...r.parameters,docs:{...(T=r.parameters)==null?void 0:T.docs,source:{originalSource:`{
  args: {
    meta: {
      durationMs: 1200,
      inputTokens: 800,
      outputTokens: 90
    }
  }
}`,...(k=(v=r.parameters)==null?void 0:v.docs)==null?void 0:k.source},description:{story:"Ход без деталей запроса (сохранён до появления `meta.request`): только метрики.",...(w=(b=r.parameters)==null?void 0:b.docs)==null?void 0:w.description}}};var I,M,f,E,B;s.parameters={...s.parameters,docs:{...(I=s.parameters)==null?void 0:I.docs,source:{originalSource:`{
  args: {
    meta: makeTurnMeta({
      costUsd: undefined,
      model: 'gpt-5-codex',
      request: {
        ...makeTurnMeta().request!,
        provider: 'codex',
        model: 'gpt-5-codex',
        resumed: false
      }
    })
  }
}`,...(f=(M=s.parameters)==null?void 0:M.docs)==null?void 0:f.source},description:{story:"Codex не сообщает стоимость хода — панель говорит об этом прямо.",...(B=(E=s.parameters)==null?void 0:E.docs)==null?void 0:B.description}}};var C,q,S,H,O;n.parameters={...n.parameters,docs:{...(C=n.parameters)==null?void 0:C.docs,source:{originalSource:`{
  args: {
    meta: makeTurnMeta({
      interrupted: true
    })
  }
}`,...(S=(q=n.parameters)==null?void 0:q.docs)==null?void 0:S.source},description:{story:"Ход прерван перезапуском сервера — статус видно и в сводке, и в панели.",...(O=(H=n.parameters)==null?void 0:H.docs)==null?void 0:O.description}}};var j,L,A,D,P;i.parameters={...i.parameters,docs:{...(j=i.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    meta: makeTurnMeta({
      request: {
        ...makeTurnMeta().request!,
        attachments: ['/tmp/скриншот-1.png', '/tmp/лог-рана.txt'],
        kbContext: {
          confidence: 'high',
          sections: [{
            documentId: 'ui',
            title: 'ui.md',
            heading: 'Витрина Storybook',
            sourcePath: 'docs/kb/ui.md',
            anchor: '#storybook'
          }, {
            documentId: 'testing',
            title: 'testing-operations.md',
            heading: 'Тестовая матрица',
            sourcePath: 'docs/kb/testing-operations.md',
            anchor: '#матрица'
          }]
        }
      }
    })
  }
}`,...(A=(L=i.parameters)==null?void 0:L.docs)==null?void 0:A.source},description:{story:"Ход с автодобавленной базой знаний и вложениями.",...(P=(D=i.parameters)==null?void 0:D.docs)==null?void 0:P.description}}};var W,N,K,U,_;c.parameters={...c.parameters,docs:{...(W=c.parameters)==null?void 0:W.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.hover(canvas.getByLabelText('Сведения об ответе').parentElement as HTMLElement);
    await expect(canvas.getByTestId('meta-tip')).toHaveTextContent('1.5k → 320');
  }
}`,...(K=(N=c.parameters)==null?void 0:N.docs)==null?void 0:K.source},description:{story:"Сводка по наведению: модель, токены, размер запроса, время и стоимость.",...(_=(U=c.parameters)==null?void 0:U.docs)==null?void 0:_.description}}};var R,z,F,G,J;m.parameters={...m.parameters,docs:{...(R=m.parameters)==null?void 0:R.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(within(canvasElement).getByLabelText('Сведения об ответе'));
    const dialog = within(document.body);
    await expect(await dialog.findByTestId('meta-overlay')).toBeInTheDocument();
    await expect(dialog.getByTestId('meta-prompt')).toHaveTextContent('Как дела?');
  }
}`,...(F=(z=m.parameters)==null?void 0:z.docs)==null?void 0:F.source},description:{story:"Панель «Что было отправлено модели»: промпт, контекст, окружение хода.",...(J=(G=m.parameters)==null?void 0:G.docs)==null?void 0:J.description}}};const Te=["Icon","OnlyMetrics","CodexWithoutCost","Interrupted","WithKbAndAttachments","TooltipOnHover","DetailsOpen"];export{s as CodexWithoutCost,m as DetailsOpen,o as Icon,n as Interrupted,r as OnlyMetrics,c as TooltipOnHover,i as WithKbAndAttachments,Te as __namedExportsOrder,xe as default};
