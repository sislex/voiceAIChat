import{j as c}from"./jsx-runtime-BYYWji4R.js";import{within as R,userEvent as W,waitFor as q,expect as z}from"./index-DeN4tkzB.js";import{M as J}from"./Markdown-CI5fIvek.js";import{M as P,a as A,b as Q,c as U,d as V}from"./chat-COYZgq2j.js";import"./ci-DFdZK10C.js";import"./machines-BUsHtEGO.js";import"./clarification-BhK1l2ki.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./clipboard-OV73WQR5.js";import"./core-BwXZ_Otv.js";import"./images-CH23vBlI.js";import"./tools-D2dVYbOd.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./types-DFdjDDUq.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CA-icE-7.js";import"./kb-CjYTCLN0.js";const ur={title:"Chat/Markdown",component:J,decorators:[n=>c.jsx("div",{className:"msg ai",children:c.jsx("div",{className:"bub",style:{maxWidth:720},children:c.jsx(n,{})})})]},r={args:{children:V}},e={args:{children:A}},s={args:{children:U}},a={args:{children:P}},o={args:{children:Q}},t={args:{children:A},play:async({canvasElement:n})=>{const B=R(n),[i]=B.getAllByRole("button",{name:"Копировать код"});await W.click(i),await q(()=>z(i).toHaveTextContent("✓"))}};var p,m,d,l,g;r.parameters={...r.parameters,docs:{...(p=r.parameters)==null?void 0:p.docs,source:{originalSource:`{
  args: {
    children: MD_TABLE
  }
}`,...(d=(m=r.parameters)==null?void 0:m.docs)==null?void 0:d.source},description:{story:"Таблица GFM: выравнивание колонок, инлайн-код и длинная ячейка.",...(g=(l=r.parameters)==null?void 0:l.docs)==null?void 0:g.description}}};var h,u,C,y,_;e.parameters={...e.parameters,docs:{...(h=e.parameters)==null?void 0:h.docs,source:{originalSource:`{
  args: {
    children: MD_CODE_LONG
  }
}`,...(C=(u=e.parameters)==null?void 0:u.docs)==null?void 0:C.source},description:{story:`Длинный код: подсветка (rehype-highlight сам определяет язык), кнопка
копирования в углу и строка без пробелов — она и проверяет скролл блока.`,...(_=(y=e.parameters)==null?void 0:y.docs)==null?void 0:_.description}}};var M,E,D,x,S;s.parameters={...s.parameters,docs:{...(M=s.parameters)==null?void 0:M.docs,source:{originalSource:`{
  args: {
    children: MD_LINKS
  }
}`,...(D=(E=s.parameters)==null?void 0:E.docs)==null?void 0:D.source},description:{story:"Ссылки: обычные, сноской и автоссылка GFM (все с target=_blank).",...(S=(x=s.parameters)==null?void 0:x.docs)==null?void 0:S.description}}};var v,L,k,w,N;a.parameters={...a.parameters,docs:{...(v=a.parameters)==null?void 0:v.docs,source:{originalSource:`{
  args: {
    children: MD_CHECKLIST
  }
}`,...(k=(L=a.parameters)==null?void 0:L.docs)==null?void 0:k.source},description:{story:"Чек-листы, включая вложенный, и нумерованный список.",...(N=(w=a.parameters)==null?void 0:w.docs)==null?void 0:N.description}}};var b,K,T,I,O;o.parameters={...o.parameters,docs:{...(b=o.parameters)==null?void 0:b.docs,source:{originalSource:`{
  args: {
    children: MD_KITCHEN_SINK
  }
}`,...(T=(K=o.parameters)==null?void 0:K.docs)==null?void 0:T.source},description:{story:"Всё сразу: заголовки, цитата, разделитель, зачёркивание, таблица, код.",...(O=(I=o.parameters)==null?void 0:I.docs)==null?void 0:O.description}}};var f,H,j,F,G;t.parameters={...t.parameters,docs:{...(f=t.parameters)==null?void 0:f.docs,source:{originalSource:`{
  args: {
    children: MD_CODE_LONG
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const [copy] = canvas.getAllByRole('button', {
      name: 'Копировать код'
    });
    await userEvent.click(copy);
    // Подпись меняется не сразу: копирование асинхронное (и через 1.5с вернётся ⧉).
    await waitFor(() => expect(copy).toHaveTextContent('✓'));
  }
}`,...(j=(H=t.parameters)==null?void 0:H.docs)==null?void 0:j.source},description:{story:"Копирование кода: кнопка ⧉ читает текст блока из DOM и на 1.5с превращается\nв ✓. В небезопасном контексте `navigator.clipboard` недоступен — тогда\nработает fallback на `execCommand`, и подпись всё равно меняется.",...(G=(F=t.parameters)==null?void 0:F.docs)==null?void 0:G.description}}};const Cr=["Table","LongCode","Links","Checklist","KitchenSink","CopyCode"];export{a as Checklist,t as CopyCode,o as KitchenSink,s as Links,e as LongCode,r as Table,Cr as __namedExportsOrder,ur as default};
