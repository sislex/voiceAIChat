/** Client projection of Core chat 1.0.0; provenance: docs/chat-client.md. */
export const CHAT_CLIENT_VERSION = 1 as const
export type ChatSettingValue = string | number | boolean | null
  | readonly ChatSettingValue[] | { readonly [key: string]: ChatSettingValue }
export type ChatSettingValues = Readonly<Record<string, ChatSettingValue>>
export interface ChatSettingsSnapshot {
  version: 1
  revision: number
  account: ChatSettingValues
  conversation: ChatSettingValues
  device: ChatSettingValues
}
export interface ChatSettingsPatch {
  version: 1
  expectedRevision: number
  owner: 'account' | 'conversation'
  values: ChatSettingValues
}
export interface ChatSettingsConflict {
  code: 'settings_revision_conflict'
  current: ChatSettingsSnapshot
}
export interface ChatCapabilityState {
  id: 'chat.text' | 'chat.attachments' | 'chat.queue' | 'chat.tools' | 'chat.voice.input' | 'chat.voice.output'
  available: boolean
  reason?: 'not-granted' | 'host-unsupported' | 'temporarily-unavailable'
  detail?: string
}
/** A server report, never proof of authenticated identity or permission. */
export interface ChatContext {
  version: 1
  capabilities: readonly ChatCapabilityState[]
  permissions: readonly string[]
  [key: string]: unknown
}
export type ChatReconnectResult =
  | { status: 'resumed'; cursor: string }
  | { status: 'resync-required'; reason: 'initial-connect' | 'cursor-expired' | 'scope-changed' | 'server-restarted' }
export interface ChatConnectionSnapshot {
  version: 1
  connectionId: string
  cursor: string
  context: ChatContext
  settings: ChatSettingsSnapshot
  reconnect: ChatReconnectResult
}
export interface ChatAttachment {
  id: string
  name: string
  path: string
  mimeType: string
  size: number
  agentId?: string
}
export interface ChatUpload {
  conversationId: string
  name: string
  dataBase64: string
  mimeType?: string
  agentId?: string
}
/** Core owns payload semantics; the envelope also carries additive messages. */
export interface ChatMessage { t: string; [key: string]: unknown }
export type ChatConnectionState = 'idle' | 'connecting' | 'synchronizing' | 'ready' | 'reconnecting' | 'closed' | 'disposed'
export type ChatClientEvent =
  | { type: 'state'; state: ChatConnectionState }
  | { type: 'ready'; snapshot: ChatConnectionSnapshot }
  | { type: 'settings'; settings: ChatSettingsSnapshot }
  | { type: 'message'; message: ChatMessage }
  | { type: 'binary'; data: ArrayBuffer | Blob }
  | { type: 'error'; error: Error }
export interface ChatTransportPort {
  readonly state: ChatConnectionState
  connect(): void
  disconnect(): void
  send(message: ChatMessage): void
  sendBinary(data: ArrayBuffer | ArrayBufferView<ArrayBuffer> | Blob): void
  subscribe(listener: (event: ChatClientEvent) => void): () => void
}
export interface ChatAttachmentsPort {
  upload(input: ChatUpload, signal?: AbortSignal): Promise<ChatAttachment>
}
export interface ChatSettingsPort {
  get(conversationId?: string, signal?: AbortSignal): Promise<ChatSettingsSnapshot>
  patch(patch: ChatSettingsPatch, conversationId?: string, signal?: AbortSignal): Promise<ChatSettingsSnapshot>
  getDevice(): ChatSettingValues
  setDevice(values: ChatSettingValues): void
}
export interface ChatCapabilitiesPort {
  discover(signal?: AbortSignal): Promise<ChatContext>
}
export interface ChatClient {
  readonly version: 1
  readonly transport: ChatTransportPort
  readonly attachments: ChatAttachmentsPort
  readonly settings: ChatSettingsPort
  readonly capabilities: ChatCapabilitiesPort
  dispose(): void
}
