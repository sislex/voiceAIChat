import { parseApplicationAttribution, type ApplicationAttribution } from './application.js'
import { parsePlatformOperationContext, type PlatformOperationContext } from './platformOperation.js'
import { billingAmount, parseBillingPrincipal, type BillingPrincipal, type BillingReservation } from './billing.js'
import { parseVersionedBillingUsageEvent, type VersionedBillingUsageEvent } from './billingReport.js'

export interface PlatformOperationContextV2 extends Omit<PlatformOperationContext, 'version'> {
  readonly version: 2
  readonly application: ApplicationAttribution
}
export type VersionedPlatformOperationContext = PlatformOperationContext | PlatformOperationContextV2

/** Legacy metadata remains legacy: attribution is never inferred from an actor,
 * module, or token. New callers must explicitly provide authoritative attribution. */
export function parseVersionedPlatformOperationContext(value: unknown): VersionedPlatformOperationContext {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Invalid platform operation context')
  const source = value as Record<string, unknown>
  if (source.version !== 2) return parsePlatformOperationContext(value)
  const { application, ...legacy } = source
  const context = parsePlatformOperationContext({ ...legacy, version: 1 })
  return Object.freeze({ ...context, version: 2, application: parseApplicationAttribution(application) })
}

export function attributePlatformOperationContext(
  context: PlatformOperationContext, application: ApplicationAttribution,
): PlatformOperationContextV2 {
  return parseVersionedPlatformOperationContext({ ...parsePlatformOperationContext(context), version: 2, application }) as PlatformOperationContextV2
}

/** Each hop supplies its own authenticated actor and resolved attribution. */
export function createChildPlatformOperationContextV2(
  parent: PlatformOperationContextV2, operationId: string, actorClientId: string, application: ApplicationAttribution,
): PlatformOperationContextV2 {
  const checked = parseVersionedPlatformOperationContext(parent)
  if (checked.version !== 2) throw Error('Expected v2 parent operation')
  const next = parseApplicationAttribution(application)
  if (next.originApplicationId !== checked.application.originApplicationId) throw Error('Cannot change origin application')
  return parseVersionedPlatformOperationContext({ ...checked, operationId, actorClientId,
    parentOperationId: checked.operationId, application: next }) as PlatformOperationContextV2
}

export interface BillingPrincipalV2 extends BillingPrincipal {
  readonly version: 2
  readonly application: ApplicationAttribution
}
export type VersionedBillingPrincipal = BillingPrincipal | BillingPrincipalV2

export interface BillingReservationV2 extends BillingReservation {
  readonly version: 2
  readonly application: ApplicationAttribution
}

/** Project one authoritative finalized settlement. The producer supplies a stable
 * event ID and settlement timestamp and persists them across delivery retries. */
export function billingReservationToUsageEvent(
  reservation: BillingReservation | BillingReservationV2, eventId: string, occurredAt: number,
): VersionedBillingUsageEvent {
  if (reservation.state !== 'settled' || !billingAmount(reservation.actualMicroUsd)) throw Error('Expected finalized billing settlement')
  const version = 'version' in reservation ? reservation.version : 1
  if (version !== 1 && version !== 2) throw Error('Unsupported billing reservation version')
  return parseVersionedBillingUsageEvent({ version, eventId, occurredAt, reservationId: reservation.id,
    operationId: reservation.operationId, userId: reservation.userId, tenantId: reservation.tenantId,
    environmentId: reservation.environmentId, actorClientId: reservation.actorClientId,
    originModuleId: reservation.originModuleId, actualMicroUsd: reservation.actualMicroUsd,
    ...(reservation.usage === undefined ? {} : { usage: reservation.usage }),
    ...(version === 2 && 'application' in reservation ? { application: reservation.application } : {}) })
}

export function parseVersionedBillingPrincipal(value: unknown): VersionedBillingPrincipal {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Invalid billing principal')
  const source = value as Record<string, unknown>
  if (source.version !== 2) return parseBillingPrincipal(value)
  const { version, application, ...legacy } = source
  return Object.freeze({ ...parseBillingPrincipal(legacy), version: 2, application: parseApplicationAttribution(application) })
}

/** Tenant mapping is resolved by the caller's authenticated billing authority;
 * billingAccountId is deliberately not treated as a tenant ID. */
export function platformOperationToBillingPrincipal(context: PlatformOperationContext, tenantId: string): BillingPrincipal
export function platformOperationToBillingPrincipal(context: PlatformOperationContextV2, tenantId: string): BillingPrincipalV2
export function platformOperationToBillingPrincipal(context: VersionedPlatformOperationContext, tenantId: string): VersionedBillingPrincipal
export function platformOperationToBillingPrincipal(context: VersionedPlatformOperationContext, tenantId: string): VersionedBillingPrincipal {
  const checked = parseVersionedPlatformOperationContext(context)
  return parseVersionedBillingPrincipal({ userId: checked.userId, tenantId, environmentId: checked.environmentId,
    actorClientId: checked.actorClientId, originModuleId: checked.originModuleId,
    ...(checked.version === 2 ? { version: 2, application: checked.application } : {}) })
}
