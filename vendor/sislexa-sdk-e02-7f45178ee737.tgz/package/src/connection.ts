import { createChatClient, type ChatClientOptions } from './chatClient.js'
import { createBrowserChatSession, type BrowserChatSessionOptions, type ChatSessionAdapter } from './chatSession.js'

/** SDK-owned version, independent of package and Core wire versions. */
export const CONNECTION_API_VERSION = 1 as const
export interface PublicClientOptions {
  clientId: string
  authorizationEndpoint: string
  tokenEndpoint: string
  redirectUri: string
  scope: readonly string[]
  sessionEndpoint: string
  baseUrl: string
  fetch?: typeof fetch
  now?: () => number
  refreshSkewMs?: number
}
export class ConnectionAuthorizationRequiredError extends Error {
  readonly code = 'connection_authorization_required'
  constructor() { super('Interactive authorization is required') }
}
export interface PublicClientSession extends ChatSessionAdapter {
  authorize(): Promise<string>
  completeAuthorization(callbackUrl: string, signal?: AbortSignal): Promise<void>
}
function secureUrl(value: string): URL {
  const url = new URL(value)
  if (url.protocol !== 'https:' || url.username || url.password || url.hash) throw Error('Expected HTTPS URL without credentials or fragment')
  return url
}
function base64url(bytes: Uint8Array): string {
  return btoa(String.fromCharCode(...bytes)).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_')
}
function random(): string { return base64url(crypto.getRandomValues(new Uint8Array(32))) }
function waitFor<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  signal.throwIfAborted()
  return new Promise((resolve, reject) => {
    const abort = () => { signal.removeEventListener('abort', abort); reject(signal.reason) }
    signal.addEventListener('abort', abort, { once: true })
    promise.then(value => { signal.removeEventListener('abort', abort); resolve(value) },
      error => { signal.removeEventListener('abort', abort); reject(error) })
  })
}

/** Authorization code + S256 PKCE, with memory-only tokens and no client secret. */
export function createPublicClientSession(options: PublicClientOptions): PublicClientSession {
  const authorization = secureUrl(options.authorizationEndpoint)
  const tokenEndpoint = secureUrl(options.tokenEndpoint).href
  const redirect = secureUrl(options.redirectUri)
  if (redirect.search) throw Error('Redirect URI must not contain a query')
  const sessionEndpoint = secureUrl(options.sessionEndpoint).href
  secureUrl(options.baseUrl)
  if (!options.clientId.trim() || options.scope.some(s => !s || /\s/.test(s))) throw Error('Invalid public client registration')
  const fetcher = options.fetch ?? globalThis.fetch.bind(globalThis)
  const now = options.now ?? Date.now
  const skew = options.refreshSkewMs ?? 15_000
  if (!Number.isSafeInteger(skew) || skew < 0) throw Error('Invalid refresh skew')
  let transaction: { state: string; verifier: string; expiresAt: number } | undefined
  let tokens: { access: string; refresh?: string; expiresAt: number } | undefined
  let epoch = 0
  let disposed = false
  let controller = new AbortController()
  let refreshing: Promise<void> | undefined
  function alive() { if (disposed) throw Error('Connection is disposed') }
  function clear() {
    epoch++; controller.abort(); controller = new AbortController()
    transaction = undefined; tokens = undefined; refreshing = undefined
  }
  async function exchange(body: URLSearchParams, expected: number, signal: AbortSignal) {
    body.set('client_id', options.clientId)
    const response = await fetcher(tokenEndpoint, { method: 'POST', body, signal,
      credentials: 'omit', redirect: 'error', cache: 'no-store', headers: { accept: 'application/json' } })
    signal.throwIfAborted()
    if (!response.ok) {
      if ([400, 401, 403].includes(response.status)) {
        if (expected === epoch) { clear(); browser.invalidate('revoked') }
        throw new ConnectionAuthorizationRequiredError()
      }
      throw Error(`OAuth token request failed (${response.status})`)
    }
    const data = await response.json() as Record<string, unknown>
    signal.throwIfAborted()
    if (expected !== epoch || disposed) throw Error('Authorization was invalidated')
    if (!data || typeof data.access_token !== 'string' || !data.access_token || /\s/.test(data.access_token)
      || typeof data.token_type !== 'string' || data.token_type.toLowerCase() !== 'bearer'
      || !Number.isSafeInteger(data.expires_in) || (data.expires_in as number) <= 0
      || !Number.isSafeInteger(now() + (data.expires_in as number) * 1000)
      || (data.refresh_token !== undefined && (typeof data.refresh_token !== 'string' || !data.refresh_token))) {
      clear(); browser.invalidate('revoked'); throw Error('Invalid OAuth token response')
    }
    tokens = { access: data.access_token, refresh: (data.refresh_token as string | undefined) ?? tokens?.refresh,
      expiresAt: now() + (data.expires_in as number) * 1000 }
  }
  async function access(signal: AbortSignal) {
    alive(); signal.throwIfAborted()
    if (!tokens) throw new ConnectionAuthorizationRequiredError()
    if (tokens.expiresAt - skew <= now()) {
      if (!tokens.refresh) { tokens = undefined; throw new ConnectionAuthorizationRequiredError() }
      if (!refreshing) {
        const pending = exchange(new URLSearchParams({ grant_type: 'refresh_token', refresh_token: tokens.refresh }), epoch, controller.signal)
          .finally(() => { if (refreshing === pending) refreshing = undefined })
        refreshing = pending
      }
      try {
        await waitFor(refreshing, signal)
      } catch (error) {
        // Revocation aborts the pending browser session too. Report the
        // authorization decision instead of that internal abort to callers.
        if (!tokens && !disposed) throw new ConnectionAuthorizationRequiredError()
        throw error
      }
    }
    if (!tokens) throw new ConnectionAuthorizationRequiredError()
    return tokens.access
  }
  const browser = createBrowserChatSession({ baseUrl: options.baseUrl, endpoint: sessionEndpoint,
    now, refreshSkewMs: skew, credentials: 'omit', fetch: async (url, init) => {
      const bearer = await access(init?.signal as AbortSignal)
      const expected = epoch
      const headers = new Headers(init?.headers); headers.set('authorization', `Bearer ${bearer}`)
      const response = await fetcher(url, { ...init, headers })
      if (expected === epoch && [401, 403, 410].includes(response.status)) clear()
      return response
    } })
  return {
    async authorize() {
      alive(); clear(); browser.invalidate('manual')
      const expected = epoch
      const verifier = random(), state = random()
      const challenge = base64url(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))))
      alive(); if (epoch !== expected) throw Error('Authorization was invalidated')
      transaction = { state, verifier, expiresAt: now() + 300_000 }
      const url = new URL(authorization)
      url.searchParams.set('response_type', 'code'); url.searchParams.set('client_id', options.clientId)
      url.searchParams.set('redirect_uri', redirect.href); url.searchParams.set('scope', options.scope.join(' '))
      url.searchParams.set('state', state); url.searchParams.set('code_challenge', challenge)
      url.searchParams.set('code_challenge_method', 'S256')
      return url.href
    },
    async completeAuthorization(callbackUrl, signal = new AbortController().signal) {
      alive(); signal.throwIfAborted()
      const url = new URL(callbackUrl), saved = transaction
      if (url.origin !== redirect.origin || url.pathname !== redirect.pathname || url.hash || url.username || url.password
        || !saved || saved.expiresAt <= now() || url.searchParams.getAll('state').length !== 1
        || url.searchParams.get('state') !== saved.state) throw Error('Invalid authorization callback')
      transaction = undefined
      if (url.searchParams.has('error')) throw new ConnectionAuthorizationRequiredError()
      if (url.searchParams.getAll('code').length !== 1 || !url.searchParams.get('code')) throw Error('Missing authorization code')
      await exchange(new URLSearchParams({ grant_type: 'authorization_code', code: url.searchParams.get('code')!,
        redirect_uri: redirect.href, code_verifier: saved.verifier }), epoch, AbortSignal.any([signal, controller.signal]))
      browser.invalidate('manual')
    },
    headers: signal => browser.headers(signal),
    socketUrl: (url, signal) => browser.socketUrl(url, signal),
    invalidate(reason) {
      if (reason === 'revoked' || reason === 'manual') clear()
      else if (tokens) tokens.expiresAt = 0
      browser.invalidate(reason)
    },
    dispose() { disposed = true; clear(); browser.dispose() }
  }
}

export type ConnectionOptions = Omit<ChatClientOptions, 'session' | 'headers' | 'socketUrl'> & {
  version: 1
  authentication: { mode: 'backend'; session?: Omit<BrowserChatSessionOptions, 'baseUrl' | 'fetch'> }
    | { mode: 'public-client'; session: PublicClientSession }
}
/** Creates an unconnected client; subscribe before calling transport.connect(). */
export function createConnection(options: ConnectionOptions) {
  if (options.version !== CONNECTION_API_VERSION) throw Error('Unsupported connection API version')
  if (!['backend', 'public-client'].includes(options.authentication.mode)) throw Error('Unsupported authentication mode')
  const session = options.authentication.mode === 'backend'
    ? createBrowserChatSession({ ...options.authentication.session, baseUrl: options.baseUrl, fetch: options.fetch })
    : options.authentication.session
  return createChatClient({ ...options, session })
}
