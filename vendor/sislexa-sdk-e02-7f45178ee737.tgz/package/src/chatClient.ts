import type { ChatClient, ChatClientEvent, ChatConnectionSnapshot, ChatConnectionState, ChatMessage,
  ChatSettingsPatch, ChatSettingsSnapshot, ChatSettingValues } from './chatContracts.js'
import { attachment, context, deviceKeys, record, revision, settings, snapshot, values } from './chatValidation.js'
import type { ChatSessionAdapter } from './chatSession.js'

export class ChatHttpError extends Error {
  constructor(public readonly status: number) { super(`Chat HTTP request failed (${status})`) }
}
export class ChatSettingsConflictError extends ChatHttpError {
  readonly code = 'settings_revision_conflict'
  constructor(public readonly current: ChatSettingsSnapshot) { super(409) }
}
/** Browser WebSocket and standards-compatible host adapters satisfy this boundary. */
export type ChatSocket = Pick<WebSocket, 'send' | 'close' | 'readyState' | 'binaryType' | 'onopen' | 'onmessage' | 'onerror' | 'onclose'>
export interface ChatClientOptions {
  baseUrl: string
  fetch?: typeof fetch
  createSocket?: (url: string) => ChatSocket
  /** Resolve fresh request credentials; never put long-lived application secrets here. */
  headers?: (signal: AbortSignal) => HeadersInit | Promise<HeadersInit>
  credentials?: RequestCredentials
  /** Optional host session adapter, called on every connection attempt. */
  socketUrl?: (url: string, signal: AbortSignal) => string | Promise<string>
  /** Memory-only short-lived browser session source for both HTTP and WebSocket. */
  session?: ChatSessionAdapter
  /** Fetch authoritative conversation/history/queue state before the port becomes ready. */
  resynchronize: (snapshot: ChatConnectionSnapshot, signal: AbortSignal) => Promise<void>
  reconnect?: { initialDelayMs?: number; maxDelayMs?: number; maxAttempts?: number; handshakeTimeoutMs?: number }
}

/** Creates one independent HTTP/WS client. No shared cache, socket, timer or device storage. */
export function createChatClient(options: ChatClientOptions): ChatClient {
  if (typeof options.resynchronize !== 'function') throw Error('Chat resynchronize adapter is required')
  const base = new URL(options.baseUrl)
  if (!['http:', 'https:'].includes(base.protocol) || base.username || base.password || base.search || base.hash) {
    throw Error('Chat baseUrl must be an HTTP(S) URL without credentials, query or fragment')
  }
  const endpoint = (path: string) => new URL(path, base).href
  const fetcher = options.fetch ?? globalThis.fetch.bind(globalThis)
  const socketFactory = options.createSocket ?? (url => new WebSocket(url))
  if (options.session && (options.headers || options.socketUrl)) throw Error('Chat session cannot be combined with credential hooks')
  const headers = options.session?.headers.bind(options.session) ?? options.headers
  const socketUrl = options.session?.socketUrl.bind(options.session) ?? options.socketUrl
  const resynchronize = options.resynchronize
  const credentials = options.credentials ?? 'same-origin'
  const retry = { initialDelayMs: 500, maxDelayMs: 30_000, maxAttempts: 8, handshakeTimeoutMs: 15_000, ...options.reconnect }
  for (const value of Object.values(retry)) if (!Number.isSafeInteger(value) || value < 0 || value > 2_147_483_647) throw Error('Invalid chat reconnect policy')
  if (retry.handshakeTimeoutMs === 0 || retry.maxDelayMs < retry.initialDelayMs) throw Error('Invalid chat reconnect policy')
  let state: ChatConnectionState = 'idle'
  let disposed = false
  let desired = false
  let generation = 0
  let attempts = 0
  let cursor: string | undefined
  let device: ChatSettingValues = {}
  let socket: ChatSocket | undefined
  let connection: AbortController | undefined
  let timer: ReturnType<typeof setTimeout> | undefined
  let handshake: ReturnType<typeof setTimeout> | undefined
  const requests = new Set<AbortController>()
  const listeners = new Set<(event: ChatClientEvent) => void>()
  function alive() { if (disposed) throw Error('Chat client is disposed') }
  function emit(event: ChatClientEvent) {
    for (const listener of [...listeners]) {
      // Consumer exceptions must not corrupt transport lifecycle or other subscribers.
      try { listener(structuredCloneEvent(event)) } catch { /* Subscriber owns its errors. */ }
    }
  }
  function setState(next: ChatConnectionState) { state = next; emit({ type: 'state', state }) }
  function localSettings(input: unknown) { return { ...settings(input), device: structuredClone(device) } }
  async function request(path: string, method: string, body?: unknown, signal?: AbortSignal): Promise<unknown> {
    alive()
    const controller = new AbortController()
    requests.add(controller)
    const abort = () => controller.abort()
    signal?.addEventListener('abort', abort, { once: true })
    if (signal?.aborted) abort()
    try {
      const h = new Headers(await headers?.(controller.signal))
      h.set('accept', 'application/json')
      if (body !== undefined) h.set('content-type', 'application/json')
      controller.signal.throwIfAborted()
      const response = await fetcher(endpoint(path), { method, headers: h, credentials,
        cache: 'no-store', redirect: 'error', signal: controller.signal,
        body: body === undefined ? undefined : JSON.stringify(body) })
      controller.signal.throwIfAborted()
      if (response.status === 409) {
        const conflict: unknown = await response.json()
        controller.signal.throwIfAborted()
        if (record(conflict) && conflict.code === 'settings_revision_conflict') {
          throw new ChatSettingsConflictError(localSettings(conflict.current))
        }
      }
      if (!response.ok) {
        if (response.status === 401) options.session?.invalidate('unauthorized')
        if (response.status === 403) options.session?.invalidate('revoked')
        throw new ChatHttpError(response.status)
      }
      const result: unknown = await response.json()
      controller.signal.throwIfAborted()
      return result
    } finally {
      signal?.removeEventListener('abort', abort)
      requests.delete(controller)
    }
  }
  function cleanup() {
    generation++
    clearTimeout(timer); clearTimeout(handshake)
    timer = handshake = undefined
    connection?.abort(); connection = undefined
    const old = socket; socket = undefined
    if (old) {
      old.onopen = old.onmessage = old.onclose = old.onerror = null
      try { old.close() } catch { /* A host socket may already be closed. */ }
    }
  }
  function fail(error: Error, terminal = false) {
    cleanup()
    if (!desired || disposed) return
    if (terminal || attempts >= retry.maxAttempts) {
      desired = false; cursor = undefined; setState('closed')
    } else {
      const delay = Math.min(retry.maxDelayMs, retry.initialDelayMs * 2 ** attempts++)
      setState('reconnecting')
      if (desired && !disposed) timer = setTimeout(() => { void open() }, delay)
    }
    emit({ type: 'error', error })
  }
  async function open() {
    if (!desired || disposed) return
    cleanup()
    const epoch = generation
    const controller = new AbortController(); connection = controller
    const current = () => epoch === generation && desired && !disposed
    setState(attempts ? 'reconnecting' : 'connecting')
    if (!current()) return
    handshake = setTimeout(() => { if (current()) fail(Error('Chat handshake timed out')) }, retry.handshakeTimeoutMs)
    try {
      const url = new URL(endpoint('/ws')); url.protocol = base.protocol === 'https:' ? 'wss:' : 'ws:'
      const target = socketUrl ? await socketUrl(url.href, controller.signal) : url.href
      if (!current()) return
      const ws = socketFactory(target); socket = ws; ws.binaryType = 'arraybuffer'
      let receivedReady = false
      const pending: ChatClientEvent[] = []
      function deliver(event: ChatClientEvent) {
        if (state === 'ready') emit(event)
        else if (receivedReady && state === 'synchronizing' && pending.length < 256) pending.push(event)
        else throw Error('Chat synchronization event buffer exceeded or handshake missing')
      }
      ws.onopen = () => {
        if (!current()) return
        try { ws.send(JSON.stringify({ t: 'chat.connect', v: 1, ...(cursor ? { cursor } : {}) })) }
        catch { fail(Error('Chat handshake send failed')) }
      }
      ws.onerror = () => { if (current()) fail(Error('Chat socket failed')) }
      ws.onclose = event => {
        if (!current()) return
        if (event.code === 4401 && options.session) options.session.invalidate('expired')
        if (event.code === 4403 && options.session) options.session.invalidate('revoked')
        fail(Error('Chat socket closed'), event.code === 4403 || [1008, 4401, 4403].includes(event.code) && !options.session)
      }
      ws.onmessage = event => {
        if (!current()) return
        if (typeof event.data !== 'string') {
          try {
            if (!(event.data instanceof ArrayBuffer || event.data instanceof Blob)) throw Error('Invalid binary frame')
            deliver({ type: 'binary', data: event.data })
          } catch { fail(Error('Unexpected chat binary frame'), true) }
          return
        }
        try {
          const message: unknown = JSON.parse(event.data)
          if (!record(message) || typeof message.t !== 'string') throw Error('Invalid chat message')
          if (message.t === 'chat.ready') {
            if (receivedReady) throw Error('Duplicate chat handshake')
            receivedReady = true
            const ready = snapshot(message.snapshot)
            ready.settings = localSettings(ready.settings)
            setState('synchronizing')
            if (!current()) return
            void (async () => {
              try {
                if (ready.reconnect.status === 'resync-required') await resynchronize(structuredClone(ready), controller.signal)
                if (!current()) return
                clearTimeout(handshake)
                cursor = ready.cursor; attempts = 0
                ready.settings = localSettings(ready.settings)
                setState('ready')
                if (current()) emit({ type: 'ready', snapshot: ready })
                for (const event of pending) { if (current()) emit(event) }
                pending.length = 0
              } catch { if (current()) fail(Error('Chat resynchronization failed')) }
            })()
          } else if (message.t === 'chat.settings.updated') {
            deliver({ type: 'settings', settings: localSettings(message.settings) })
          } else deliver({ type: 'message', message: message as ChatMessage })
        } catch { if (current()) fail(Error('Invalid chat protocol frame'), true) }
      }
    } catch { if (current()) fail(Error('Chat connection failed')) }
  }
  function send(data: string | ArrayBuffer | ArrayBufferView<ArrayBuffer> | Blob) {
    alive()
    if (state !== 'ready' || socket?.readyState !== 1) throw Error('Chat transport is not ready')
    try { socket.send(data) }
    catch { fail(Error('Chat send failed')); throw Error('Chat send failed; delivery is uncertain') }
  }
  function settingsPath(id?: string) {
    if (id !== undefined && !id) throw Error('Conversation ID is required')
    return id === undefined ? '/api/chat/settings' : `/api/conversations/${encodeURIComponent(id)}/settings`
  }
  return {
    version: 1,
    transport: {
      get state() { return state },
      connect() { alive(); if (desired) return; desired = true; attempts = 0; void open() },
      disconnect() { alive(); desired = false; cleanup(); cursor = undefined; setState('closed') },
      send(message) {
        if (!record(message) || typeof message.t !== 'string' || !message.t || message.t === 'chat.connect') throw Error('Invalid outbound chat message')
        send(JSON.stringify(message))
      },
      sendBinary: send,
      subscribe(listener) { alive(); listeners.add(listener); return () => { listeners.delete(listener) } }
    },
    attachments: {
      async upload(input, signal) {
        if (!input.conversationId || !input.name || !input.dataBase64
          || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(input.dataBase64)
          || input.dataBase64.length > 4 * Math.ceil(32 * 1024 * 1024 / 3)) throw Error('Invalid chat upload')
        const byteLength = input.dataBase64.length / 4 * 3 - (input.dataBase64.endsWith('==') ? 2 : input.dataBase64.endsWith('=') ? 1 : 0)
        if (byteLength > 32 * 1024 * 1024) throw Error('Chat upload exceeds 32 MiB')
        return attachment(await request('/api/uploads', 'POST', { conversationId: input.conversationId, name: input.name,
          dataBase64: input.dataBase64, mimeType: input.mimeType, agentId: input.agentId }, signal))
      }
    },
    settings: {
      async get(id, signal) { return localSettings(await request(settingsPath(id), 'GET', undefined, signal)) },
      async patch(patch: ChatSettingsPatch, id, signal) {
        if (patch.version !== 1 || !['account', 'conversation'].includes(patch.owner)
          || (patch.owner === 'conversation' && !id)) throw Error('Invalid chat settings patch')
        revision(patch.expectedRevision); values(patch.values)
        if (Object.keys(patch.values).some(key => deviceKeys.includes(key))) throw Error('Device settings cannot be persisted')
        return localSettings(await request(settingsPath(id), 'PATCH', {
          version: 1, owner: patch.owner, expectedRevision: patch.expectedRevision, values: structuredClone(patch.values)
        }, signal))
      },
      getDevice() { alive(); return structuredClone(device) },
      setDevice(input) {
        alive(); values(input)
        if (Object.keys(input).some(key => !deviceKeys.includes(key))) throw Error('Invalid device setting')
        device = { ...device, ...structuredClone(input) }
      }
    },
    capabilities: { async discover(signal) { return context(await request('/api/chat/context', 'GET', undefined, signal)) } },
    dispose() {
      if (disposed) return
      disposed = true; desired = false; cleanup()
      for (const controller of requests) controller.abort()
      requests.clear(); device = {}; cursor = undefined
      options.session?.dispose()
      setState('disposed'); listeners.clear()
    }
  }
}

function structuredCloneEvent(event: ChatClientEvent): ChatClientEvent {
  return structuredClone(event)
}
