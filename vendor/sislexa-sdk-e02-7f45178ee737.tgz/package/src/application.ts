import { assertPlatformIdentifier } from './platformOperation.js'

/** Registry metadata, not evidence that the caller controls this application. */
export interface RegisteredApplication {
  readonly version: 1
  readonly applicationId: string
  readonly identityIssuer: string
  readonly clientId: string
  readonly environmentId: string
  readonly status: 'active' | 'disabled'
}

/** An authority-issued grant; parsing does not verify its issuer or revocation. */
export interface ApplicationDelegation {
  readonly version: 1
  readonly delegationId: string
  readonly originApplicationId: string
  readonly executorApplicationId: string
  readonly identityIssuer: string
  readonly userId: string
  readonly environmentId: string
  readonly scopes: readonly string[]
  readonly issuedAt: number
  readonly expiresAt: number
}

/** Token ID is an opaque audit reference, never authentication material. Modules remain
 * separate product/execution dimensions on the containing operation or event. */
export interface ApplicationAttribution {
  readonly version: 1
  readonly originApplicationId: string
  readonly executorApplicationId: string
  readonly tokenId: string | null
  readonly delegationId: string | null
}

function record(value: unknown, fields: readonly string[]): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Invalid application contract')
  const source = value as Record<string, unknown>
  if (source.version !== 1 || Object.keys(source).some(key => !fields.includes(key))) {
    throw Error('Unsupported application contract')
  }
  return source
}

export function parseRegisteredApplication(value: unknown): RegisteredApplication {
  const source = record(value, ['version', 'applicationId', 'identityIssuer', 'clientId', 'environmentId', 'status'])
  for (const key of ['applicationId', 'identityIssuer', 'clientId', 'environmentId']) assertPlatformIdentifier(source[key], key)
  if (source.status !== 'active' && source.status !== 'disabled') throw Error('Invalid application status')
  return Object.freeze({ version: 1, applicationId: source.applicationId as string,
    identityIssuer: source.identityIssuer as string, clientId: source.clientId as string,
    environmentId: source.environmentId as string, status: source.status })
}

export function parseApplicationDelegation(value: unknown): ApplicationDelegation {
  const source = record(value, ['version', 'delegationId', 'originApplicationId', 'executorApplicationId',
    'identityIssuer', 'userId', 'environmentId', 'scopes', 'issuedAt', 'expiresAt'])
  for (const key of ['delegationId', 'originApplicationId', 'executorApplicationId', 'identityIssuer', 'userId', 'environmentId']) {
    assertPlatformIdentifier(source[key], key)
  }
  if (!Array.isArray(source.scopes) || source.scopes.length === 0) throw Error('Invalid delegation scopes')
  for (const scope of source.scopes) assertPlatformIdentifier(scope, 'scope')
  if (new Set(source.scopes).size !== source.scopes.length) throw Error('Duplicate delegation scope')
  for (const key of ['issuedAt', 'expiresAt']) {
    if (!Number.isSafeInteger(source[key]) || Number(source[key]) < 0) throw Error('Invalid delegation time')
  }
  if (Number(source.expiresAt) <= Number(source.issuedAt)) throw Error('Invalid delegation interval')
  return Object.freeze({ version: 1, delegationId: source.delegationId as string,
    originApplicationId: source.originApplicationId as string, executorApplicationId: source.executorApplicationId as string,
    identityIssuer: source.identityIssuer as string, userId: source.userId as string,
    environmentId: source.environmentId as string, scopes: Object.freeze([...source.scopes] as string[]),
    issuedAt: source.issuedAt as number, expiresAt: source.expiresAt as number })
}

export function parseApplicationAttribution(value: unknown): ApplicationAttribution {
  const source = record(value, ['version', 'originApplicationId', 'executorApplicationId', 'tokenId', 'delegationId'])
  for (const key of ['originApplicationId', 'executorApplicationId']) assertPlatformIdentifier(source[key], key)
  for (const key of ['tokenId', 'delegationId']) if (source[key] !== null) assertPlatformIdentifier(source[key], key)
  if (source.originApplicationId !== source.executorApplicationId && source.delegationId === null) {
    throw Error('Cross-application attribution requires delegation')
  }
  return Object.freeze({ version: 1, originApplicationId: source.originApplicationId as string,
    executorApplicationId: source.executorApplicationId as string, tokenId: source.tokenId as string | null,
    delegationId: source.delegationId as string | null })
}

/** These fields must come from a verified token/session, never the request body. */
export interface AuthenticatedApplicationActor {
  readonly identityIssuer: string
  readonly clientId: string
  readonly userId: string
  readonly environmentId: string
  readonly tokenId: string | null
}

/** Concrete boundary adapter over trusted registry/grant records. The caller must
 * authenticate the actor and fetch current, authorized, non-revoked records.
 * Exact scopes only: no implicit wildcard or transitive grant expansion. */
export function resolveApplicationAttribution(input: {
  actor: AuthenticatedApplicationActor
  origin: RegisteredApplication
  executor: RegisteredApplication
  delegation?: ApplicationDelegation
  requiredScope: string
  now: number
}): ApplicationAttribution {
  const { actor } = input
  for (const key of ['identityIssuer', 'clientId', 'userId', 'environmentId'] as const) assertPlatformIdentifier(actor[key], key)
  if (actor.tokenId !== null) assertPlatformIdentifier(actor.tokenId, 'tokenId')
  assertPlatformIdentifier(input.requiredScope, 'requiredScope')
  if (!Number.isSafeInteger(input.now) || input.now < 0) throw Error('Invalid attribution time')
  const origin = parseRegisteredApplication(input.origin), executor = parseRegisteredApplication(input.executor)
  for (const app of [origin, executor]) {
    if (app.status !== 'active' || app.environmentId !== actor.environmentId || app.identityIssuer !== actor.identityIssuer) {
      throw Error('Application registration does not match authenticated authority')
    }
  }
  if (executor.clientId !== actor.clientId) throw Error('Executor does not match authenticated client')
  if (origin.applicationId === executor.applicationId && origin.clientId !== executor.clientId) throw Error('Conflicting application registration')
  const grant = input.delegation === undefined ? undefined : parseApplicationDelegation(input.delegation)
  if (grant && (grant.originApplicationId !== origin.applicationId || grant.executorApplicationId !== executor.applicationId
    || grant.identityIssuer !== actor.identityIssuer || grant.userId !== actor.userId || grant.environmentId !== actor.environmentId
    || input.now < grant.issuedAt || input.now >= grant.expiresAt || !grant.scopes.includes(input.requiredScope))) {
    throw Error('Delegation does not match authenticated execution')
  }
  return parseApplicationAttribution({ version: 1, originApplicationId: origin.applicationId,
    executorApplicationId: executor.applicationId, tokenId: actor.tokenId, delegationId: grant?.delegationId ?? null })
}
