/** Portable, versioned description of a short-lived browser chat session. */
export interface ChatBrowserSession {
  version: 1
  sessionId: string
  accessToken: string
  expiresAt: number
  socketUrl?: string
}

export type ChatSessionInvalidationReason = 'expired' | 'unauthorized' | 'revoked' | 'manual'

export interface ChatSessionAdapter {
  headers(signal: AbortSignal): Promise<HeadersInit>
  socketUrl(url: string, signal: AbortSignal): Promise<string>
  invalidate(reason: ChatSessionInvalidationReason): void
  dispose(): void
}

export interface BrowserChatSessionOptions {
  baseUrl: string
  fetch?: typeof fetch
  credentials?: RequestCredentials
  endpoint?: string
  refreshSkewMs?: number
  now?: () => number
}

export class ChatSessionRevokedError extends Error {
  readonly code = 'chat_session_revoked'
  constructor() { super('Chat session was revoked') }
}

function session(value: unknown, now: number): ChatBrowserSession {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw Error('Invalid chat session')
  const item = value as Record<string, unknown>
  if (item.version !== 1 || typeof item.sessionId !== 'string' || !item.sessionId
    || typeof item.accessToken !== 'string' || !item.accessToken
    || !Number.isSafeInteger(item.expiresAt) || (item.expiresAt as number) <= now
    || (item.socketUrl !== undefined && (typeof item.socketUrl !== 'string' || !item.socketUrl))) {
    throw Error('Invalid or expired chat session')
  }
  return structuredClone(item) as unknown as ChatBrowserSession
}

/**
 * Acquires and refreshes browser sessions in memory. It never reads or writes
 * localStorage, sessionStorage, cookies, or another persistent credential store.
 */
export function createBrowserChatSession(options: BrowserChatSessionOptions): ChatSessionAdapter {
  const base = new URL(options.baseUrl)
  if (!['http:', 'https:'].includes(base.protocol) || base.username || base.password || base.search || base.hash) {
    throw Error('Chat session baseUrl must be an HTTP(S) URL without credentials, query or fragment')
  }
  const fetcher = options.fetch ?? globalThis.fetch.bind(globalThis)
  const endpoint = new URL(options.endpoint ?? '/api/chat/session', base).href
  const credentials = options.credentials ?? 'same-origin'
  const now = options.now ?? Date.now
  const skew = options.refreshSkewMs ?? 15_000
  if (!Number.isSafeInteger(skew) || skew < 0) throw Error('Invalid chat session refresh skew')
  let current: ChatBrowserSession | undefined
  let pending: Promise<ChatBrowserSession> | undefined
  let pendingController: AbortController | undefined
  let generation = 0
  let disposed = false
  let revoked = false
  async function acquire(signal: AbortSignal): Promise<ChatBrowserSession> {
    signal.throwIfAborted()
    if (disposed) throw Error('Chat session adapter is disposed')
    if (revoked) throw new ChatSessionRevokedError()
    if (current && current.expiresAt - skew > now()) return current
    if (!pending) {
      const controller = new AbortController()
      const epoch = generation
      pendingController = controller
      pending = (async () => {
        const response = await fetcher(endpoint, { method: 'POST', credentials, cache: 'no-store', redirect: 'error',
          headers: { accept: 'application/json' }, signal: controller.signal })
        if (response.status === 401 || response.status === 403 || response.status === 410) {
          if (epoch === generation) revoked = true
          throw new ChatSessionRevokedError()
        }
        if (!response.ok) throw Error(`Chat session acquisition failed (${response.status})`)
        const value = session(await response.json(), now())
        if (disposed || revoked || epoch !== generation) throw Error('Chat session acquisition was invalidated')
        current = value
        return value
      })().finally(() => {
        if (pendingController === controller) { pending = undefined; pendingController = undefined }
      })
    }
    return new Promise<ChatBrowserSession>((resolve, reject) => {
      const abort = () => { signal.removeEventListener('abort', abort); reject(signal.reason) }
      signal.addEventListener('abort', abort, { once: true })
      pending!.then(value => { signal.removeEventListener('abort', abort); resolve(value) },
        error => { signal.removeEventListener('abort', abort); reject(error) })
    })
  }
  return {
    async headers(signal) { return { authorization: `Bearer ${(await acquire(signal)).accessToken}` } },
    async socketUrl(url, signal) {
      const value = await acquire(signal)
      if (value.socketUrl) {
        const target = new URL(value.socketUrl, base)
        if (target.protocol === 'http:') target.protocol = 'ws:'
        else if (target.protocol === 'https:') target.protocol = 'wss:'
        if (!['ws:', 'wss:'].includes(target.protocol)) throw Error('Invalid chat session socket URL')
        return target.href
      }
      const target = new URL(url)
      target.searchParams.set('session', value.accessToken)
      return target.href
    },
    invalidate(reason) {
      generation++
      current = undefined
      pendingController?.abort()
      pendingController = undefined
      pending = undefined
      if (reason === 'revoked') revoked = true
      else if (reason === 'manual') revoked = false
    },
    dispose() { disposed = true; generation++; current = undefined; pendingController?.abort(); pendingController = undefined; pending = undefined }
  }
}

export interface ServerChatCredentialOptions {
  credential: string | ((signal: AbortSignal) => string | Promise<string>)
  header?: string
  scheme?: string
}

/** Server-only adapter: keep the long-lived credential in the trusted host. */
export function createServerChatCredentialAdapter(options: ServerChatCredentialOptions) {
  const header = options.header ?? 'authorization'
  const scheme = options.scheme ?? 'Bearer'
  if (!header || /[\r\n:]/.test(header) || /[\r\n]/.test(scheme)) throw Error('Invalid credential header')
  return async (signal: AbortSignal): Promise<HeadersInit> => {
    signal.throwIfAborted()
    const credentialValue = typeof options.credential === 'function' ? await options.credential(signal) : options.credential
    signal.throwIfAborted()
    if (!credentialValue || /[\r\n]/.test(credentialValue)) throw Error('Invalid server chat credential')
    return { [header]: scheme ? `${scheme} ${credentialValue}` : credentialValue }
  }
}
