import { createServerChatCredentialAdapter, type ChatBrowserSession } from './chatSession.js'

export interface ConnectionBackendOptions {
  browserOrigin: string
  upstreamSessionEndpoint: string
  applicationCredential: (signal: AbortSignal) => string | Promise<string>
  /** Resolve a user bearer from the host's authenticated server session, never request JSON. */
  userAccessToken: (request: Request) => Promise<string | null>
  fetch?: typeof fetch
  now?: () => number
}

/** Framework-free backend-for-frontend handler for POST /api/chat/session. */
export function createConnectionSessionHandler(options: ConnectionBackendOptions) {
  const origin = new URL(options.browserOrigin).origin
  const upstream = new URL(options.upstreamSessionEndpoint)
  if (upstream.protocol !== 'https:' || upstream.username || upstream.password || upstream.hash) throw Error('Invalid upstream session endpoint')
  const credential = createServerChatCredentialAdapter({ credential: options.applicationCredential,
    header: 'x-app-credential', scheme: '' })
  const fetcher = options.fetch ?? globalThis.fetch.bind(globalThis)
  const reply = (status: number, body: unknown) => Response.json(body, { status,
    headers: { 'cache-control': 'no-store', 'vary': 'Origin' } })
  return async (request: Request): Promise<Response> => {
    if (request.method !== 'POST') return reply(405, { error: 'method_not_allowed' })
    if (request.headers.get('origin') !== origin) return reply(403, { error: 'origin_denied' })
    try {
      const user = await options.userAccessToken(request)
      if (!user) return reply(401, { error: 'authentication_required' })
      const headers = new Headers(await credential(request.signal))
      headers.set('authorization', `Bearer ${user}`); headers.set('accept', 'application/json')
      const response = await fetcher(upstream, { method: 'POST', headers, signal: request.signal,
        credentials: 'omit', redirect: 'error', cache: 'no-store' })
      if (!response.ok) return reply([401, 403, 410].includes(response.status) ? response.status : 502, { error: 'session_unavailable' })
      const data = await response.json() as ChatBrowserSession
      if (!data || data.version !== 1 || typeof data.sessionId !== 'string' || !data.sessionId
        || typeof data.accessToken !== 'string' || !data.accessToken || /\s/.test(data.accessToken)
        || !Number.isSafeInteger(data.expiresAt) || data.expiresAt <= (options.now ?? Date.now)()) throw Error('Invalid upstream session')
      if (data.socketUrl !== undefined) {
        const socket = new URL(data.socketUrl, upstream)
        if (!['https:', 'wss:'].includes(socket.protocol) || socket.username || socket.password) throw Error('Invalid session socket')
      }
      // Project only the browser contract; never forward upstream debug or identity fields.
      return reply(200, { version: 1, sessionId: data.sessionId, accessToken: data.accessToken,
        expiresAt: data.expiresAt, ...(data.socketUrl === undefined ? {} : { socketUrl: data.socketUrl }) })
    } catch { return reply(502, { error: 'session_unavailable' }) }
  }
}
