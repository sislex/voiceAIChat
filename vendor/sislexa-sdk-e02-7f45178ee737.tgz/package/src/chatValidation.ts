import type { ChatAttachment, ChatConnectionSnapshot, ChatContext, ChatSettingsSnapshot, ChatSettingValues } from './chatContracts.js'

export function record(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}
function jsonValue(value: unknown, depth = 0): boolean {
  if (depth > 8) return false
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return true
  if (typeof value === 'number') return Number.isFinite(value)
  if (Array.isArray(value)) return value.every(item => jsonValue(item, depth + 1))
  return record(value) && Object.entries(value).every(([key, item]) =>
    !['__proto__', 'constructor', 'prototype'].includes(key) && jsonValue(item, depth + 1))
}
export function values(value: unknown): asserts value is ChatSettingValues {
  if (!record(value) || !jsonValue(value)) throw Error('Invalid chat settings values')
}
export function revision(value: unknown): void {
  if (!Number.isSafeInteger(value) || (value as number) < 0) throw Error('Invalid chat settings revision')
}
export const deviceKeys = ['micDeviceId', 'outputDeviceId', 'compactView', 'panelWidth', 'mobileTab']
export function settings(value: unknown): ChatSettingsSnapshot {
  if (!record(value) || value.version !== 1) throw Error('Unsupported chat settings')
  revision(value.revision)
  values(value.account); values(value.conversation); values(value.device)
  return structuredClone(value) as unknown as ChatSettingsSnapshot
}
export function context(value: unknown): ChatContext {
  if (!record(value) || value.version !== 1 || !Array.isArray(value.permissions)
    || !value.permissions.every(p => typeof p === 'string') || !Array.isArray(value.capabilities)) {
    throw Error('Unsupported chat context')
  }
  const ids = new Set<string>()
  for (const cap of value.capabilities) {
    if (!record(cap) || typeof cap.id !== 'string' || ids.has(cap.id)
      || !['chat.text', 'chat.attachments', 'chat.queue', 'chat.tools', 'chat.voice.input', 'chat.voice.output'].includes(cap.id)
      || typeof cap.available !== 'boolean'
      || (cap.available ? cap.reason !== undefined : !['not-granted', 'host-unsupported', 'temporarily-unavailable'].includes(String(cap.reason)))
      || (cap.detail !== undefined && typeof cap.detail !== 'string')) throw Error('Invalid chat capability')
    ids.add(cap.id)
  }
  return structuredClone(value) as unknown as ChatContext
}
export function snapshot(value: unknown): ChatConnectionSnapshot {
  if (!record(value) || value.version !== 1 || typeof value.connectionId !== 'string' || !value.connectionId
    || typeof value.cursor !== 'string' || !value.cursor || !record(value.reconnect)) throw Error('Invalid chat handshake')
  const r = value.reconnect
  if (r.status === 'resumed' ? typeof r.cursor !== 'string' || !r.cursor
    : r.status !== 'resync-required' || !['initial-connect', 'cursor-expired', 'scope-changed', 'server-restarted'].includes(String(r.reason))) {
    throw Error('Invalid chat reconnect result')
  }
  return { ...structuredClone(value), context: context(value.context), settings: settings(value.settings) } as unknown as ChatConnectionSnapshot
}
export function attachment(value: unknown): ChatAttachment {
  if (!record(value) || !['id', 'name', 'path', 'mimeType'].every(key => typeof value[key] === 'string' && value[key])
    || !Number.isSafeInteger(value.size) || (value.size as number) < 0
    || (value.agentId !== undefined && typeof value.agentId !== 'string')) throw Error('Invalid chat attachment')
  return structuredClone(value) as unknown as ChatAttachment
}
