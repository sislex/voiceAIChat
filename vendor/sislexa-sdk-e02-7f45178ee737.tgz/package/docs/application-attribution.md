# Registered applications and origin attribution

These contracts are owned by the SDK. The extracted v1 source provenance in
`source-origin.json` remains unchanged. They have no runtime dependencies.

## Wire versions and identity dimensions

`RegisteredApplication`, `ApplicationDelegation`, and `ApplicationAttribution`
each carry `version: 1`. Application-aware operations, platform usage events,
billing principals, reservations, and billing usage events carry `version: 2`.
The old operation/event v1 and unversioned billing principal/reservation shapes
remain supported, without adding fields or inferring missing application IDs.
Unknown versions fail closed. Application-aware payloads require `application`;
they cannot silently downgrade to legacy payloads.

| Field | Meaning |
| --- | --- |
| `application.originApplicationId` | Registered application that initiated the work; retained across hops |
| `application.executorApplicationId` | Registered application executing this hop |
| `actorClientId` | Authenticated OAuth/service client for this hop, not an application ID |
| `application.tokenId` | Opaque audit reference for this hop, or explicit null for a tokenless session; never authentication material |
| `application.delegationId` | Authority-issued grant reference; required when origin and executor differ |
| `originModuleId` | Original product/module attribution; independent of application identity |
| `executorModuleId` | Module executing a platform usage leaf |

Registry records bind an application to an issuer, client and environment, with
an active/disabled status. Delegations bind an origin/executor pair to a user,
issuer, environment, nonempty exact scopes, and a half-open validity interval
`[issuedAt, expiresAt)` in epoch milliseconds. Scope wildcards and transitive
delegation are not inferred. Each executor needs its own authorized grant from
the original application. Money remains integer micro-USD.

## Service boundary adapter

First authenticate the session or token using the service's Identity integration.
Load current registry records and a currently authorized, non-revoked delegation
from the authoritative service. Never accept those records or actor identity
directly from a request body. `resolveApplicationAttribution` checks their binding,
active status, grant scope and expiry; it does not verify signatures, perform
registry I/O, check revocation, or turn structurally valid metadata into identity.
The required scope and current time must be supplied by the service.

```ts
const application = resolveApplicationAttribution({
  actor: authenticatedActor,
  origin: originRegistration,
  executor: executorRegistration,
  delegation: currentDelegation,
  requiredScope: 'execute',
  now: Date.now(),
})
const context = attributePlatformOperationContext(legacyContext, application)
const principal = platformOperationToBillingPrincipal(context, authorizedTenantId)
```

The operation's user, issuer, environment and actor must come from the same
authenticated boundary. `attributePlatformOperationContext` is a structural
adapter; it cannot establish that relationship from attribution IDs alone.
Tenant mapping is explicit: a billing account ID is not assumed to be a tenant ID.

Use `createChildPlatformOperationContextV2` with the next hop's authenticated
client and newly resolved attribution. It retains payer, user, environment,
project, root operation, origin module and origin application, and replaces the
executor/token/grant references. It rejects origin changes and invalid ancestry.

Persist the complete v2 principal/application with each reservation. After an
authoritative settlement, `billingReservationToUsageEvent` projects a settled
reservation to the matching v1/v2 usage event. Supply a stable event ID and the
persisted settlement timestamp on every retry. Non-settled reservations and
invalid monetary amounts are rejected; the adapter does not settle the ledger.

## Consumers and compatibility

Keep existing v1 parsers for v1-only integrations. Mixed-version readers use
`parseVersionedPlatformOperationContext`, `parseVersionedBillingPrincipal`,
`parseVersionedPlatformUsageEvent`, and `parseVersionedBillingUsageEvent`.
The existing usage summary functions accept both event versions and still group
by origin module. Their deduplication fingerprints include application attribution,
so retries that change origin, executor, token or delegation are conflicts.
Legacy events have unknown application origin; never substitute actor or module.

Roll out mixed-version readers before enabling v2 writers. Preserve full v2
metadata through persistence and delivery; do not send it through v1-only
projection code. Consumer deployment is separate from this SDK change: publish
only after the owner gate passes, pin each consumer to the exact approved release
archive/version, and retain its release-source provenance. No consumer migration,
registry provisioning, grant issuance, or operator commissioning is performed by
these portable contracts.
