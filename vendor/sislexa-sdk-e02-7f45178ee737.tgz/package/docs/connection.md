# Connection API (E02)

The SDK root exports `createConnection`, `createPublicClientSession` and
`createConnectionSessionHandler`. All use standard Fetch/WebSocket/Web Crypto;
no framework, database or runtime package import is required. SDK owns these
adapters. Core continues to own chat wire v1 and session authorization; Identity
owns OAuth registration, consent, token validation and revocation. Existing
source provenance is unchanged. No dependency snapshot was supplied for E02.

## Backend-mediated browser

Mount this handler on the application's same-origin `/api/chat/session` route:

```ts
import { createConnectionSessionHandler } from '@sislexa/sdk'

export const sessionHandler = createConnectionSessionHandler({
  browserOrigin: 'https://app.example',
  upstreamSessionEndpoint: 'https://core.example/api/chat/session',
  applicationCredential: signal => secretManager.read('chat-application', signal),
  async userAccessToken(request) {
    const session = await hostSessions.authenticate(request)
    return session?.coreAudienceAccessToken ?? null
  }
})
// Framework route: return sessionHandler(theStandardRequest).
```

`secretManager` and `hostSessions` are host integration points, not SDK globals.
The concrete handler rejects non-POST and foreign/missing Origin, obtains the
user token exclusively from the authenticated host session, and calls Core with
Bearer user authorization and `x-app-credential`. It does not forward browser
JSON, cookies, identity claims or upstream diagnostic fields. Configure secure,
HttpOnly, SameSite host cookies. Core must validate both credentials, audience,
tenant/resource grants and revocation before minting a short-lived session.
The endpoint and application header are the E02 integration contract; confirm
support in the selected Core release before commissioning.

```ts
import { createConnection } from '@sislexa/sdk'

const client = createConnection({
  version: 1,
  baseUrl: 'https://app.example',
  authentication: { mode: 'backend' },
  resynchronize: (snapshot, signal) => history.reload(snapshot, signal)
})
client.transport.subscribe(event => view.accept(event))
client.transport.connect()
// Unmount/logout: client.dispose()
```

The app proxy exposes the Core chat routes described in [chat-client.md](chat-client.md).
Only short-lived session credentials reach the browser. Never bundle server
credentials, use browser-provided user IDs as identity, or cache session responses.

## Apps without a backend: public client + PKCE

Register a **public** client with exact HTTPS callback URI, permitted origins,
scopes and Core audience. No client secret is configured. Identity must support
authorization code, S256 PKCE, CORS token POSTs, and public-client refresh-token
rotation with reuse detection. Core's session endpoint must accept that user
access token directly with CORS for the registered app origin.

```ts
import { createConnection, createPublicClientSession } from '@sislexa/sdk'

const session = createPublicClientSession({
  clientId: 'registered-public-app',
  authorizationEndpoint: 'https://identity.example/oauth/authorize',
  tokenEndpoint: 'https://identity.example/oauth/token',
  redirectUri: 'https://app.example/oauth/callback',
  scope: ['chat', 'offline_access'],
  baseUrl: 'https://core.example',
  sessionEndpoint: 'https://core.example/api/chat/session'
})
// Open a blank popup synchronously during the user's click, then navigate it:
const popup = window.open('about:blank', 'sislexa-authorization')
if (!popup) throw Error('Popup blocked')
popup.location.href = await session.authorize()
const receive = async (event: MessageEvent) => {
  if (event.origin !== location.origin || event.source !== popup
    || event.data?.type !== 'sislexa-oauth-callback'
    || typeof event.data.url !== 'string') return
  window.removeEventListener('message', receive)
  try {
    await session.completeAuthorization(event.data.url)
    const client = createConnection({ version: 1, baseUrl: 'https://core.example',
      credentials: 'omit', authentication: { mode: 'public-client', session },
      resynchronize: (snapshot, signal) => history.reload(snapshot, signal) })
    client.transport.subscribe(event => view.accept(event))
    client.transport.connect()
    // Retain client for teardown; client.dispose() clears tokens and sockets.
  } catch (error) { session.dispose(); view.showSignInError(error) }
  finally { popup.close() }
}
window.addEventListener('message', receive)
```

The callback page contains no third-party scripts and uses `Referrer-Policy:
no-referrer`. Its script forwards the URL only to the exact application origin,
then removes the authorization parameters:

```ts
window.opener?.postMessage({ type: 'sislexa-oauth-callback', url: location.href },
  'https://app.example')
history.replaceState(null, '', location.pathname)
```

Configure popup-compatible opener policy. The host must remove the listener and
dispose the adapter if the popup closes or the user cancels; it should impose a
five-minute UI timeout. State/verifier expire after five minutes and callbacks
are single-use. This in-memory flow requires the original page to stay alive;
full-page navigation or reload requires a new authorization. Do not persist
refresh/access tokens in localStorage, URL parameters or analytics. The OAuth
access token is exchanged for a chat session, never placed in the socket URL.
Prefer Core-issued session-bound socket URLs; redact the fallback short-lived
`session` query parameter from proxy logs.

## Refresh, reconnect and compatibility

Session acquisition is coalesced and refreshes 15 seconds before expiry. The
public adapter refreshes OAuth tokens when a new chat session needs them, retains
a rotated refresh token, and invalidates stale asynchronous results. Tokens use
OAuth `expires_in` seconds; chat sessions use integer Unix-millisecond `expiresAt`.
Without a refresh grant, expiry requires interactive authorization. HTTP 401 /
WS 4401 invalidate the session and force token refresh on the next attempt;
403 / 4403 stop authorization. Token endpoint 400/401/403 clears tokens. A fresh
`authorize()` starts another interactive flow; `invalidate('manual')` clears
public-client tokens. Dispose and recreate when principal or tenant changes.

The existing bounded reconnect/cursor/resynchronization behavior is retained.
No HTTP mutations are automatically replayed. See [chat-client.md](chat-client.md)
for retry bounds, revocation, settings and attachment behavior. Authorization
cannot be inferred from capability reports or schema validation.

| Boundary | Supported version / migration |
| --- | --- |
| SDK connection options | `version: 1`; unknown versions rejected |
| Core chat handshake/settings/context | v1, existing U03 compatibility checks |
| Browser session response | v1; unknown versions and expired sessions rejected |
| Identity protocol | OAuth authorization code + S256 PKCE, Bearer tokens |
| Existing SDK consumers | Existing factories remain exported and unchanged |

This additive API is staged for the next SDK minor release (1.3.0); package
1.2.0 remains the checkout baseline, not a claim that the new API is published.
Run `npm ci` and `npm run gate`, select the release version, produce a clean
immutable provenance archive using the existing release process, then pin that
exact version/archive and integrity in each consumer lockfile. Never replace an
existing release or consume a mutable branch. Old consumers can retain their
existing factories while upgrading. Core and Identity must be deployed with the
session/OAuth contracts above before switching consumers.

Code completion is separate from operator commissioning: register the real
public/confidential applications and redirects, configure CORS/proxies/cookie
policy and secret-manager adapters, verify real user/tenant resource isolation,
consent, refresh rotation/reuse rejection, revocation, expiry and reconnect on
both host surfaces. These operations and publication are not performed here.

## Verification

`connection.test.ts` covers S256 derivation, exact callback/state matching,
single-use/expiry, refresh rotation, revocation, stale completion, incompatible
versions and the backend credential boundary. `connection.integration.test.ts`
uses native HTTP/Fetch for code exchange, verifier checking, refresh and session
minting; it binds only the second assigned `DELIVERY_PORTS` port and closes its
fixture. Existing chat integration tests cover native WebSocket reconnect.
These protocol fixtures do not replace real Identity/Core commissioning.
Sandbox execution failures must be rerun by the supervisor, never marked as skips.
