# Sislexa SDK

Portable operation attribution, normalized usage aggregation and billing contracts.
Run `npm ci` and `npm run gate`; build outputs have no runtime dependencies.

This initial extraction is staged from Core shared contracts. `source-origin.json`
records its immutable source commit and original file hashes. Core remains authoritative
until its adapters switch to this release; do not evolve the two copies separately.

The validators check data shape only. Service callers must derive user and tenant
identity from Identity, authenticate the calling application, and preserve the
origin module across nested calls. Micro-USD amounts use bounded safe integers.
Null policy limits mean unlimited; zero explicitly denies new consumption.

## Execution accounting (1.1)

Billing contracts are owned here; Core's platform SDK adapter uses the published
release. Existing operation/usage snapshots retain their source provenance.
`executionBound: "unbounded"` explicitly identifies an executor without a proven
monetary bound and requires a zero hold. Billing admits it only under an unlimited
monetary policy; omitting the marker preserves the legacy bounded wire shape.
A zero hold by itself must never be used to bypass this distinction.

Settlement evidence keeps disjoint token counts and distinguishes a provider cost
from an estimate. Estimates carry a complete integer micro-USD-per-million-token
price snapshot. `priceUsageMicroUsd` uses integer arithmetic and rounds up once
after summing categories. Unknown model prices must remain unresolved rather than
being fabricated as zero. Validators check structure, not producer authorization.

## Consumer release archives

Version 1.1.1 preserves the public API and publishes clean-commit source and archive
provenance through `npm run pack:release`. Builds precede packing. Consumer archives
exclude owner test files; the full owner gate still runs those tests and validates
package contents. Consumer upgrades follow separately.

Version 1.1.2 also excludes Node checks named `*.check.mjs` and `*.spec.*`;
archive validation uses the same broader test-file boundary.

## Finalized usage reporting

`BillingUsageEvent` is the portable, versioned projection of one finalized ledger
settlement. `summarizeBillingUsage` isolates one user, tenant and environment,
deduplicates retries, and returns raw token categories, integer micro-USD totals,
UTC day buckets and deterministic module shares in basis points. It is a reporting
contract only: Billing remains the authority for ledger persistence and access.

## Registered applications and delegation

Versioned application registration, delegation and attribution contracts separate
the originating application from its executor, authenticated client, token reference
and module. V2 operation and billing adapters preserve attribution across service
hops and settlement reporting; legacy payloads remain supported without invented
application identities. See [the integration and migration guide](docs/application-attribution.md)
for trust boundaries, wire versions and pinned consumer rollout.

## Chat client ports

`createChatClient` provides isolated transport/reconnect, attachment upload,
revisioned settings and capability discovery ports with concrete Fetch/WebSocket
adapters. See [the client integration guide](docs/chat-client.md) for lifecycle,
Core contract provenance, tests and the pinned release commissioning boundary.
Short-lived browser-session and trusted-server credential adapters keep long-lived
application credentials out of browser storage and define expiry/revocation reconnect behavior.

## Connection integration

`createConnection` exposes the versioned connection API. Backend-mediated browsers
use `createConnectionSessionHandler`; applications without a backend use
`createPublicClientSession` with authorization code/S256 PKCE and token refresh.
See [connection integration](docs/connection.md) for examples, trust boundaries,
version compatibility and the publication/commissioning steps.
