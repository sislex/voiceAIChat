import{j as d}from"./jsx-runtime-BYYWji4R.js";import{expect as X,within as Z,userEvent as ee}from"./index-DeN4tkzB.js";import{M as te}from"./MessageActivity-5vFHiusu.js";import{o as re,p as m}from"./chat-COYZgq2j.js";import"./ci-DFdZK10C.js";import"./machines-CpV6q5fJ.js";import"./clarification-g58U83f7.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./view-BrHz5xl6.js";import"./animations-CzQhBjHJ.js";import"./images-CH23vBlI.js";import"./tools-D2dVYbOd.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./types-DFdjDDUq.js";import"./agentProtocol-ChPLBt7B.js";import"./version-B-iWu5V0.js";import"./devProcess-BR7jm11E.js";import"./kb-FQoQkx7T.js";const Se={title:"Chat/MessageActivity",component:te,args:{activity:re,detailed:!1},decorators:[t=>d.jsx("div",{className:"msg ai",children:d.jsx("div",{className:"bub",style:{maxWidth:720},children:d.jsx(t,{})})})]},r={},a={args:{detailed:!0}},s={args:{detailed:!0,execTarget:"MacBook"}},i={args:{live:!0,voice:"thinking",activity:[m({summary:"Bash: npm test"})]}},n={args:{live:!0,voice:"speaking",activity:[m({kind:"thinking",summary:"Думаю над правкой"})]}},o={args:{detailed:!0,activity:Array.from({length:24},(t,e)=>m({kind:e%3===0?"tool_use":e%3===1?"tool_result":"thinking",summary:e%3===1?`✓ результат шага ${e}`:`Bash: шаг ${e} очень длинной команды с аргументами --reporter=verbose --coverage`,detail:`подробности действия ${e}`}))}},c={args:{detailed:!0},play:async({canvasElement:t})=>{const e=Z(t);await ee.click(e.getByText("Bash: ls -la")),await X(e.getByTestId("activity-raw")).toHaveTextContent('{"type":"assistant"}')}},p={args:{detailed:!0,activity:[m({tool:"mcp__browser__navigate",toolUseId:"nav-1",summary:"mcp__browser__navigate: example.test"}),m({kind:"tool_result",toolUseId:"nav-1",summary:"✓ страница открыта",detail:JSON.stringify({ok:!0,route:{engine:"web_reader_panel",place:"user_panel",sessionId:"c0ffee0012345678",url:"https://example.test/",machine:null,ip:null}})})]},play:async({canvasElement:t})=>{await X(Z(t).getByTestId("browser-route")).toHaveTextContent("машина: неизвестно")}};var l,u,v,y,g;r.parameters={...r.parameters,docs:{...(l=r.parameters)==null?void 0:l.docs,source:{originalSource:"{}",...(v=(u=r.parameters)==null?void 0:u.docs)==null?void 0:v.source},description:{story:"Свёрнуто: только счётчик действий — так выглядит завершённый ход по умолчанию.",...(g=(y=r.parameters)==null?void 0:y.docs)==null?void 0:g.description}}};var _,h,k,x,w;a.parameters={...a.parameters,docs:{...(_=a.parameters)==null?void 0:_.docs,source:{originalSource:`{
  args: {
    detailed: true
  }
}`,...(k=(h=a.parameters)==null?void 0:h.docs)==null?void 0:k.source},description:{story:"Подробно: секция на каждое действие, детали раскрываются кликом.",...(w=(x=a.parameters)==null?void 0:x.docs)==null?void 0:w.description}}};var B,S,f,T,b;s.parameters={...s.parameters,docs:{...(B=s.parameters)==null?void 0:B.docs,source:{originalSource:`{
  args: {
    detailed: true,
    execTarget: 'MacBook'
  }
}`,...(f=(S=s.parameters)==null?void 0:S.docs)==null?void 0:f.source},description:{story:"Команды шли на машину — у каждой секции метка «где».",...(b=(T=s.parameters)==null?void 0:T.docs)==null?void 0:b.description}}};var A,E,I,C,M;i.parameters={...i.parameters,docs:{...(A=i.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    live: true,
    voice: 'thinking',
    activity: [makeActivity({
      summary: 'Bash: npm test'
    })]
  }
}`,...(I=(E=i.parameters)==null?void 0:E.docs)==null?void 0:I.source},description:{story:"Живой ход: спиннер и фраза статуса вместо тишины.",...(M=(C=i.parameters)==null?void 0:C.docs)==null?void 0:M.description}}};var j,$,L,O,H;n.parameters={...n.parameters,docs:{...(j=n.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    live: true,
    voice: 'speaking',
    activity: [makeActivity({
      kind: 'thinking',
      summary: 'Думаю над правкой'
    })]
  }
}`,...(L=($=n.parameters)==null?void 0:$.docs)==null?void 0:L.source},description:{story:"Живой ход во время озвучки предыдущего ответа: фраза статуса другая.",...(H=(O=n.parameters)==null?void 0:O.docs)==null?void 0:H.description}}};var N,U,R,W,D;o.parameters={...o.parameters,docs:{...(N=o.parameters)==null?void 0:N.docs,source:{originalSource:`{
  args: {
    detailed: true,
    activity: Array.from({
      length: 24
    }, (_, i) => makeActivity({
      kind: i % 3 === 0 ? 'tool_use' : i % 3 === 1 ? 'tool_result' : 'thinking',
      summary: i % 3 === 1 ? \`✓ результат шага \${i}\` : \`Bash: шаг \${i} очень длинной команды с аргументами --reporter=verbose --coverage\`,
      detail: \`подробности действия \${i}\`
    }))
  }
}`,...(R=(U=o.parameters)==null?void 0:U.docs)==null?void 0:R.source},description:{story:"Много действий: 24 секции — проверка плотности длинного хода.",...(D=(W=o.parameters)==null?void 0:W.docs)==null?void 0:D.description}}};var J,Y,G,V,q;c.parameters={...c.parameters,docs:{...(J=c.parameters)==null?void 0:J.docs,source:{originalSource:`{
  args: {
    detailed: true
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByText('Bash: ls -la'));
    await expect(canvas.getByTestId('activity-raw')).toHaveTextContent('{"type":"assistant"}');
  }
}`,...(G=(Y=c.parameters)==null?void 0:Y.docs)==null?void 0:G.source},description:{story:"Раскрытая секция: сырой stream-json и детали — по клику, как в проде.",...(q=(V=c.parameters)==null?void 0:V.docs)==null?void 0:q.description}}};var z,F,K,P,Q;p.parameters={...p.parameters,docs:{...(z=p.parameters)==null?void 0:z.docs,source:{originalSource:`{
  args: {
    detailed: true,
    activity: [makeActivity({
      tool: 'mcp__browser__navigate',
      toolUseId: 'nav-1',
      summary: 'mcp__browser__navigate: example.test'
    }), makeActivity({
      kind: 'tool_result',
      toolUseId: 'nav-1',
      summary: '✓ страница открыта',
      detail: JSON.stringify({
        ok: true,
        route: {
          engine: 'web_reader_panel',
          place: 'user_panel',
          sessionId: 'c0ffee0012345678',
          url: 'https://example.test/',
          machine: null,
          ip: null
        }
      })
    })]
  },
  play: async ({
    canvasElement
  }) => {
    await expect(within(canvasElement).getByTestId('browser-route')).toHaveTextContent('машина: неизвестно');
  }
}`,...(K=(F=p.parameters)==null?void 0:F.docs)==null?void 0:K.source},description:{story:"Браузерный инструмент: под вызовом — строка маршрута из результата (`route`).",...(Q=(P=p.parameters)==null?void 0:P.docs)==null?void 0:Q.description}}};const fe=["Count","Detailed","OnMachine","Live","LiveWhileSpeaking","ManySections","ExpandedSection","BrowserRoute"];export{p as BrowserRoute,r as Count,a as Detailed,c as ExpandedSection,i as Live,n as LiveWhileSpeaking,o as ManySections,s as OnMachine,fe as __namedExportsOrder,Se as default};
