import{j as p}from"./jsx-runtime-BYYWji4R.js";import{within as m,userEvent as r}from"./index-DeN4tkzB.js";import{I as c}from"./IntegrationTokens-LRbqYGSv.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";const I={title:"Projects/IntegrationTokens",component:c},n={render:()=>{let t=[];return p.jsx(c,{projectId:"p1",api:{"integrationTokens:list":async()=>t,"integrationTokens:create":async({name:e})=>{const a={id:"demo",projectId:"p1",name:e,scopes:["tasks:external"],createdAt:1,lastUsedAt:null};return t=[a],{token:crypto.randomUUID(),integration:a}},"integrationTokens:revoke":async()=>{t=[]}}})},play:async({canvasElement:t})=>{const e=m(t);await e.findByText("Токенов пока нет"),await r.type(e.getByLabelText("Название интеграции"),"Delivery"),await r.click(e.getByRole("button",{name:"Создать токен"})),await e.findByLabelText("Новый токен интеграции")}};var o,s,i;n.parameters={...n.parameters,docs:{...(o=n.parameters)==null?void 0:o.docs,source:{originalSource:`{
  render: () => {
    let rows: IntegrationTokenView[] = [];
    return <IntegrationTokens projectId="p1" api={{
      'integrationTokens:list': async () => rows,
      'integrationTokens:create': async ({
        name
      }) => {
        const integration: IntegrationTokenView = {
          id: 'demo',
          projectId: 'p1',
          name,
          scopes: ['tasks:external'],
          createdAt: 1,
          lastUsedAt: null
        };
        rows = [integration];
        return {
          token: crypto.randomUUID(),
          integration
        };
      },
      'integrationTokens:revoke': async () => {
        rows = [];
      }
    }} />;
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await canvas.findByText('Токенов пока нет');
    await userEvent.type(canvas.getByLabelText('Название интеграции'), 'Delivery');
    await userEvent.click(canvas.getByRole('button', {
      name: 'Создать токен'
    }));
    await canvas.findByLabelText('Новый токен интеграции');
  }
}`,...(i=(s=n.parameters)==null?void 0:s.docs)==null?void 0:i.source}}};const f=["CreateOnce"];export{n as CreateOnce,f as __namedExportsOrder,I as default};
