import{j as K}from"./jsx-runtime-BYYWji4R.js";import{userEvent as r,within as d}from"./index-DeN4tkzB.js";import{a as Tn}from"./fakeApi-DKB7iRmJ.js";import{EnvironmentsPanel as _}from"./EnvironmentsPanel-Bo0L9zmZ.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-B7_8z7_h.js";import"./types-DFdjDDUq.js";import"./tools-D2dVYbOd.js";import"./agentProtocol-ChPLBt7B.js";import"./devProcess-BR7jm11E.js";import"./projects-B9njsDhM.js";import"./projectTypes-C-9aONcK.js";import"./ci-DFdZK10C.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./dateFormat-Mm5g7L0f.js";import"./release-C-C1sGXa.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./environmentsBridge-NusNCUKG.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";const t={id:"test-stand",projectId:"p1",name:"Проверка",mode:"managed",state:"draft",storageId:"storage-1",machines:["machine-1"],checkoutPath:"/storage/stand/app",composeProject:"sx-test-stand",port:null,createdBy:"owner",createdAt:1,updatedAt:1},Dn=[{agentId:"machine-1",name:"Готовая машина",path:"",reposRoot:"",storageId:"storage-1",storage:{id:"storage-1",machineId:"machine-1",rootPath:"/storage",status:"ready",formatVersion:1}},{agentId:"machine-2",name:"Хранилище недоступно",path:"",reposRoot:"",storageId:"storage-2",storage:{id:"storage-2",machineId:"machine-2",rootPath:"/storage",status:"offline",formatVersion:1}}],$=[{key:"VC_ADMIN_PASSWORD",label:"Пароль администратора",secret:!0,required:!0,generated:!1,set:!0,value:null,source:"user",updatedBy:"owner",updatedAt:1},{key:"VC_PUBLIC_URL",label:"Публичный адрес",secret:!1,required:!1,generated:!1,set:!0,value:"https://stand.example",source:"user",updatedBy:"owner",updatedAt:1}],Kn={environmentId:t.id,machineId:"machine-1",checkedAt:1,ready:!1,port:17800,checks:[{id:"docker",status:"passed",message:"Docker доступен"},{id:"memory",status:"warning",message:"Рекомендуется 8 ГБ"},{id:"disk",status:"failed",message:"Недостаточно места"}]},o=Date.UTC(2026,9,2,9,0),a=n=>n.repeat(40),M="https://github.com/sislex/sislexa-kanban",x="https://github.com/sislex/make",O="https://github.com/sislex/sielexa-ui",B={mode:"external",storageId:null,state:"ready",composeProject:null,port:null,id:"production",projectId:"p1",name:"Production",machines:["prod-89.125.68.35"],checkoutPath:"/root/ChatAI/voiceAIChat",createdBy:"admin",createdAt:o,updatedAt:o},_n={...B,id:"staging",name:"Staging",machines:["makbook-m1"],checkoutPath:"/Users/alex/stage"},P=[{core:null,id:"c2",environmentId:"production",revision:2,note:"Kanban 0.1.2 на проверку",createdBy:"admin",createdAt:o-6e5,modules:[{repository:M,version:"0.1.2",commit:a("b")},{repository:x,version:"1.3.1",commit:a("e")},{repository:O,version:"0.1.4",commit:a("d")}]},{core:null,id:"c1",environmentId:"production",revision:1,note:"Initial observation",createdBy:"admin",createdAt:o-864e5,modules:[{repository:M,version:"0.1.1",commit:a("a")},{repository:x,version:"1.3.1",commit:a("e")},{repository:O,version:"0.1.3",commit:a("3")}]}],On=[{repository:M,name:"Kanban",services:["kanban"],desired:{version:"0.1.2",commit:a("b")},actual:{version:"0.1.1",commit:a("a")},action:"switch",reason:null},{repository:x,name:"Make",services:["make-api","make-worker"],desired:{version:"1.3.1",commit:a("e")},actual:{version:"1.3.1",commit:a("e")},action:"none",reason:null}],$n={repository:O,name:"UI Kit",services:[],desired:{version:"0.1.4",commit:a("d")},actual:{version:"0.1.3",commit:a("3")},action:"needs_core_release",reason:"Module is embedded in Core"},R=(n,e="")=>({service:"kanban",from:`ghcr.io/sislex/kanban:${a("a")}`,to:`ghcr.io/sislex/kanban:${a("b")}`,status:n,log:e}),j={kind:"apply",id:"op1",environmentId:"production",configurationId:"c2",previousConfigurationId:"c1",status:"succeeded",steps:[R("passed",`pulling
switching
healthy`)],startedBy:"admin",startedAt:o-3e5,finishedAt:o-24e4,error:null},s={...j,id:"op2",status:"health_check",steps:[R("running",`pulling
switching`)],startedAt:o-2e4,finishedAt:null},Vn={baseBranch:"main",applications:[{repository:M,name:"Kanban",applicationId:"kanban",current:null,releases:[{version:"0.1.3",commit:a("c"),publishedAt:"2026-10-02T08:00:00Z"},{version:"0.1.2",commit:a("b"),publishedAt:"2026-10-01T08:00:00Z"}]},{repository:x,name:"Make",applicationId:"make",current:null,releases:[{version:"1.3.2",commit:a("f"),publishedAt:"2026-10-01T09:30:00Z"},{version:"1.3.1",commit:a("e"),publishedAt:"2026-09-30T18:00:00Z"}]}]};function c(n={}){const e={observation:{environmentId:"production",machineId:B.machines[0],observedAt:o,core:{version:"0.1.360",commit:a("9")},services:[]},core:{desired:null,actual:{version:"0.1.360",commit:a("9")},action:"none"},modules:n.modules??On},m=n.configurations??P;return{"environments:list":async()=>n.list??[B,_n],"environments:configurations":async()=>m,"environments:saveConfiguration":async({modules:C,note:jn})=>({...m[0],id:"c3",revision:3,modules:C,note:jn}),"environments:observe":async()=>e.observation,"environments:diff":async()=>e,"environments:apply":async()=>({...s,status:"pending",steps:[R("pending")]}),"environments:operations":async()=>n.operations??[j],"environments:rollback":async()=>({...s,id:"op3",configurationId:"c1",status:"pending",steps:[R("pending")]})}}function Pn(){const n=Tn();return n["releases:composition"]=async()=>Vn,n}const ue={title:"Operations/Releases/EnvironmentsPanel",component:_,args:{projectId:"p1",baseBranch:"main",owner:!0,environments:c(),api:Pn(),onComposeCore:()=>{}},render:n=>K.jsx("div",{style:{maxWidth:960,padding:16},children:K.jsx(_,{...n})})},p={},l={args:{environments:{...c({list:[{...t,machines:["primary","worker"]}],operations:[]}),"environments:links":async()=>["pending","open","down"].map((n,e)=>({id:String(e),environmentId:t.id,service:`service-${e}`,clientMachineId:"worker",serverMachineId:"primary",servicePort:8080,listenPort:17e3+e,transport:e===0?"vpn":"tunnel",address:e===0?"10.20.0.5:8080":`127.0.0.1:${17e3+e}`,state:n})),"environments:provision":async()=>({...s,kind:"provision",steps:["links","snapshot","restore"].map(n=>({kind:"stage",service:n,from:null,to:"ready",status:"running",log:""}))})}},play:async({canvasElement:n})=>{const e=d(n);await r.selectOptions(await e.findByLabelText("База стенда"),"production-snapshot"),await r.click(await e.findByRole("button",{name:"Изменить версии"})),await r.selectOptions(await e.findByLabelText("Машины Kanban"),["primary","worker"])}},u={args:{environments:c({operations:[s,j]})}},v={args:{environments:c({modules:[...On,$n]})}},g={args:{environments:c({list:[],configurations:[],operations:[]})}},y={args:{owner:!1,onComposeCore:void 0}},h={parameters:{viewport:{defaultViewport:"mobile1"}}},f={play:async({canvasElement:n})=>{const e=d(n);await r.click(await e.findByRole("button",{name:"Изменить версии"})),await r.selectOptions(await e.findByLabelText("Выбрать версию Kanban"),`0.1.3@${a("c")}`)}},T={...c({list:[t,B],configurations:[],operations:[]}),"environments:create":async({id:n,name:e,machineId:m,storageId:C})=>({...t,id:n,name:e,machines:[m],storageId:C}),"environments:readiness":async()=>Kn,"environments:settings":async()=>$,"environments:saveSettings":async()=>$,"environments:update":async({publicHost:n,lanAccess:e})=>({...t,publicHost:n,lanAccess:e}),"environments:provision":async()=>({...s,kind:"provision",id:"provision",status:"preparing",steps:[{kind:"stage",service:"readiness",from:null,to:"ready",status:"running",log:""}]}),"environments:remove":async()=>({...s,kind:"remove",id:"remove",status:"removing",steps:[{kind:"stage",service:"down",from:null,to:"stopped",status:"running",log:""}]})},D=Pn();D["projects:get"]=async()=>({machines:Dn});const i={args:{environments:T,api:D}},k={args:{environments:{...T,"environments:list":async()=>[{...t,state:"ready",port:17800}],"environments:configurations":async()=>[{...P[0],environmentId:t.id}]},api:D}},b={schemaVersion:1,standId:"c04-mac",machineId:"makbook-m1",baseEnvironmentId:"production",components:Object.fromEntries(["core","core-ui","make","kanban","playwright-reader","image-studio"].map((n,e)=>[n,{repository:n==="core"?"sislex/voiceAIChat":`sislex/${n}`,sha:String(e+1).repeat(40),source:n==="core-ui"?"dev":"base",...n==="core-ui"?{devBuildId:`1.5.4-dev.${String(e+1).repeat(12)}`,url:"https://c04.tail.example"}:{}}]))},w={args:{environments:{...c(),"devStands:list":async()=>[b],"devStands:create":async()=>b,"devStands:start":async()=>b,"devStands:reset":async()=>b}}},S={...i,play:async({canvasElement:n})=>{await r.click(await d(n).findByRole("button",{name:"Новое окружение"}))}},I={...i,play:async({canvasElement:n})=>{await r.click(await d(n).findByRole("button",{name:"Проверить машину"}))}},A={...i,play:async({canvasElement:n})=>{await r.click(await d(n).findByRole("button",{name:"Настройки и секреты"}))}},E={args:{environments:{...T,"environments:list":async()=>[{...t,state:"ready",port:17800,publicHost:"stand.example.com",lanAccess:!0}],"environments:configurations":async()=>[{...P[0],environmentId:t.id}],"environments:operations":async()=>[{...s,kind:"migrate",id:"migrate",status:"preparing",steps:[{kind:"stage",service:"files",from:null,to:"copied",status:"running",log:""}]}],"environments:migrate":async()=>({...s,kind:"migrate"}),"environments:cutover":async()=>({...s,kind:"cutover"}),"environments:cancel":async()=>({...s,kind:"migrate",status:"failed",error:"Cancelled"})}}};var V,L,U;p.parameters={...p.parameters,docs:{...(V=p.parameters)==null?void 0:V.docs,source:{originalSource:"{}",...(U=(L=p.parameters)==null?void 0:L.docs)==null?void 0:U.source}}};var N,Z,q;l.parameters={...l.parameters,docs:{...(N=l.parameters)==null?void 0:N.docs,source:{originalSource:`{
  args: {
    environments: {
      ...environments({
        list: [{
          ...managedEnvironment,
          machines: ['primary', 'worker']
        }],
        operations: []
      }),
      'environments:links': async () => (['pending', 'open', 'down'] as const).map((state, index) => ({
        id: String(index),
        environmentId: managedEnvironment.id,
        service: \`service-\${index}\`,
        clientMachineId: 'worker',
        serverMachineId: 'primary',
        servicePort: 8080,
        listenPort: 17000 + index,
        transport: index === 0 ? 'vpn' : 'tunnel',
        address: index === 0 ? '10.20.0.5:8080' : \`127.0.0.1:\${17000 + index}\`,
        state
      })),
      'environments:provision': async () => ({
        ...running,
        kind: 'provision',
        steps: ['links', 'snapshot', 'restore'].map(service => ({
          kind: 'stage',
          service,
          from: null,
          to: 'ready',
          status: 'running',
          log: ''
        }))
      })
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.selectOptions(await canvas.findByLabelText('База стенда'), 'production-snapshot');
    await userEvent.click(await canvas.findByRole('button', {
      name: 'Изменить версии'
    }));
    await userEvent.selectOptions(await canvas.findByLabelText('Машины Kanban'), ['primary', 'worker']);
  }
}`,...(q=(Z=l.parameters)==null?void 0:Z.docs)==null?void 0:q.source}}};var H,W,F;u.parameters={...u.parameters,docs:{...(H=u.parameters)==null?void 0:H.docs,source:{originalSource:`{
  args: {
    environments: environments({
      operations: [running, succeeded]
    })
  }
}`,...(F=(W=u.parameters)==null?void 0:W.docs)==null?void 0:F.source}}};var z,G,J;v.parameters={...v.parameters,docs:{...(z=v.parameters)==null?void 0:z.docs,source:{originalSource:`{
  args: {
    environments: environments({
      modules: [...modules, embedded]
    })
  }
}`,...(J=(G=v.parameters)==null?void 0:G.docs)==null?void 0:J.source}}};var Q,X,Y;g.parameters={...g.parameters,docs:{...(Q=g.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  args: {
    environments: environments({
      list: [],
      configurations: [],
      operations: []
    })
  }
}`,...(Y=(X=g.parameters)==null?void 0:X.docs)==null?void 0:Y.source}}};var nn,en,an;y.parameters={...y.parameters,docs:{...(nn=y.parameters)==null?void 0:nn.docs,source:{originalSource:`{
  args: {
    owner: false,
    onComposeCore: undefined
  }
}`,...(an=(en=y.parameters)==null?void 0:en.docs)==null?void 0:an.source}}};var sn,tn,rn;h.parameters={...h.parameters,docs:{...(sn=h.parameters)==null?void 0:sn.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(rn=(tn=h.parameters)==null?void 0:tn.docs)==null?void 0:rn.source}}};var on,cn,dn;f.parameters={...f.parameters,docs:{...(on=f.parameters)==null?void 0:on.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByRole('button', {
      name: 'Изменить версии'
    }));
    await userEvent.selectOptions(await canvas.findByLabelText('Выбрать версию Kanban'), \`0.1.3@\${sha('c')}\`);
  }
}`,...(dn=(cn=f.parameters)==null?void 0:cn.docs)==null?void 0:dn.source}}};var mn,pn,ln;i.parameters={...i.parameters,docs:{...(mn=i.parameters)==null?void 0:mn.docs,source:{originalSource:`{
  args: {
    environments: managedApi,
    api: projectApi
  }
}`,...(ln=(pn=i.parameters)==null?void 0:pn.docs)==null?void 0:ln.source}}};var un,vn,gn;k.parameters={...k.parameters,docs:{...(un=k.parameters)==null?void 0:un.docs,source:{originalSource:`{
  args: {
    environments: {
      ...managedApi,
      'environments:list': async () => [{
        ...managedEnvironment,
        state: 'ready',
        port: 17800
      }],
      'environments:configurations': async () => [{
        ...configurations[0]!,
        environmentId: managedEnvironment.id
      }]
    },
    api: projectApi
  }
}`,...(gn=(vn=k.parameters)==null?void 0:vn.docs)==null?void 0:gn.source}}};var yn,hn,fn;w.parameters={...w.parameters,docs:{...(yn=w.parameters)==null?void 0:yn.docs,source:{originalSource:`{
  args: {
    environments: {
      ...environments(),
      'devStands:list': async () => [devStand],
      'devStands:create': async () => devStand,
      'devStands:start': async () => devStand,
      'devStands:reset': async () => devStand
    }
  }
}`,...(fn=(hn=w.parameters)==null?void 0:hn.docs)==null?void 0:fn.source}}};var kn,bn,wn;S.parameters={...S.parameters,docs:{...(kn=S.parameters)==null?void 0:kn.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Новое окружение'
    }));
  }
}`,...(wn=(bn=S.parameters)==null?void 0:bn.docs)==null?void 0:wn.source}}};var Sn,In,An;I.parameters={...I.parameters,docs:{...(Sn=I.parameters)==null?void 0:Sn.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Проверить машину'
    }));
  }
}`,...(An=(In=I.parameters)==null?void 0:In.docs)==null?void 0:An.source}}};var En,Mn,xn;A.parameters={...A.parameters,docs:{...(En=A.parameters)==null?void 0:En.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Настройки и секреты'
    }));
  }
}`,...(xn=(Mn=A.parameters)==null?void 0:Mn.docs)==null?void 0:xn.source}}};var Bn,Rn,Cn;E.parameters={...E.parameters,docs:{...(Bn=E.parameters)==null?void 0:Bn.docs,source:{originalSource:`{
  args: {
    environments: {
      ...managedApi,
      'environments:list': async () => [{
        ...managedEnvironment,
        state: 'ready',
        port: 17800,
        publicHost: 'stand.example.com',
        lanAccess: true
      }],
      'environments:configurations': async () => [{
        ...configurations[0]!,
        environmentId: managedEnvironment.id
      }],
      'environments:operations': async () => [{
        ...running,
        kind: 'migrate',
        id: 'migrate',
        status: 'preparing',
        steps: [{
          kind: 'stage',
          service: 'files',
          from: null,
          to: 'copied',
          status: 'running',
          log: ''
        }]
      }],
      'environments:migrate': async () => ({
        ...running,
        kind: 'migrate'
      }),
      'environments:cutover': async () => ({
        ...running,
        kind: 'cutover'
      }),
      'environments:cancel': async () => ({
        ...running,
        kind: 'migrate',
        status: 'failed',
        error: 'Cancelled'
      })
    }
  }
}`,...(Cn=(Rn=E.parameters)==null?void 0:Rn.docs)==null?void 0:Cn.source}}};const ve=["SwitchOneService","MultiMachineSnapshot","Applying","EmbeddedModules","NotObserved","ReadOnlyMember","Mobile","EditVersions","ManagedDraft","ManagedReady","DevelopmentStand","CreateManaged","MachineReadiness","SettingsAndSecrets","ProductionMigrationReadOnly"];export{u as Applying,S as CreateManaged,w as DevelopmentStand,f as EditVersions,v as EmbeddedModules,I as MachineReadiness,i as ManagedDraft,k as ManagedReady,h as Mobile,l as MultiMachineSnapshot,g as NotObserved,E as ProductionMigrationReadOnly,y as ReadOnlyMember,A as SettingsAndSecrets,p as SwitchOneService,ve as __namedExportsOrder,ue as default};
