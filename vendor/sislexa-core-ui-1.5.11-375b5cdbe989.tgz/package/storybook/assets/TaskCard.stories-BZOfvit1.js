import{j as S}from"./jsx-runtime-BYYWji4R.js";import{T as Wa}from"./TaskCard-C36-gt96.js";import{m as e,e as r}from"./fixtures-Dc-pZDy3.js";import{s as Ka}from"./boardProjectsFixtures-C0cu0r8X.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./merge-CBY8VSWw.js";import"./ci-DFdZK10C.js";import"./types-DFdjDDUq.js";import"./ciFormat-BG9i2Mqq.js";import"./ansi-DtpFsZ9v.js";import"./kanbanMeta-CBiUCx3-.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Avatar-Ds_00F2y.js";import"./mediaQuery-CCkbYk-e.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./icons-M-fant0Z.js";import"./ExternalTask-iYnT0NjD.js";import"./projects-B9njsDhM.js";const y={args:{task:Ka.tasks[1],projectName:"Подпроект",showProjectBadge:!0}},La=e({id:"ep1",type:"epic",title:"Платёжная система"}),T={args:{task:e({title:"C20: Environments UI",external:{source:"Delivery",externalId:"C20",managed:!0,url:"https://delivery.example/tasks/C20"}})}},lr={title:"Kanban/TaskCard",component:Wa,args:{projectName:"Голос Чат",allTasks:[La],doneColumnIds:new Set(["done"]),dragging:!1,onOpen:()=>{},onUpdate:()=>{},onDelete:()=>{},onMoveTop:()=>{},onMoveBottom:()=>{}},decorators:[M=>S.jsx("div",{className:"jboard",style:{padding:16},children:S.jsx("div",{className:"jcol",style:{width:272},children:S.jsx("div",{className:"jcol-body",style:{padding:"8px 6px"},children:S.jsx(M,{})})})})]},t={args:{task:e({title:"Поправить отступ в шапке"})}},n={args:{task:e({title:"Интеграция платёжного шлюза",parentId:"ep1"})}},s={args:{task:e({title:"Срочно: падает прод",flagged:!0,priority:"urgent"})}},o={args:{task:e({id:"full",title:"Оплата картой: полный сценарий с 3-DS подтверждением",parentId:"ep1",labels:["payments","critical"],storyPoints:8,dueDate:Date.now()-24*60*60*1e3,flagged:!0,assignee:"bob",priority:"high",seq:42}),allTasks:[La,e({id:"ch1",parentId:"full",columnId:"done",title:"Форма"}),e({id:"ch2",parentId:"full",columnId:"wip",title:"Шлюз"})]}},i={args:{task:e({title:"Выпущено в прод",columnId:"done",assignee:"admin"})}},c={args:{task:e({title:"Спроектировать и реализовать сценарий обработки переполнения текста, включая перенос строк и обрезание СловаБезПробеловКотороеОченьДлинное"+"ещёдлиннее".repeat(8)})}},m={args:{task:e({title:"Меня тащат"}),dragging:!0}},p={args:{task:{id:"br",projectId:"p1",columnId:"x",type:"task",parentId:"ghost",title:"Битая задача",description:"",acceptanceCriteria:"",priority:"medium",assignee:null,labels:[],skills:[],storyPoints:null,dueDate:null,flagged:!1,seq:0,position:0,createdAt:1,updatedAt:1}}},d={args:{task:e({title:"Ран выполняется"}),ciSummary:r(),onStartCi:()=>{},onOpenCiRun:()=>{}}},u={args:{task:e({title:"Модель исправляет ошибку"}),ciSummary:r({slotProgress:{done:4,total:6,phase:"Модель исправляет ошибку",fixing:!0}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},l={args:{task:e({title:"Есть вопросы к пользователю"}),ciSummary:r({status:"awaiting_input",awaitingInput:!0,slotProgress:{done:3,total:6,phase:"Модель ждёт ответа"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},g={args:{task:e({title:"Ран упал"}),ciSummary:r({status:"failed",modelActive:!1,slotProgress:{done:4,total:6,phase:"Финальные команды (1/2)"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},k={args:{task:e({title:"Готово к пересборке прода"}),ciSummary:r({status:"success",modelActive:!1,slotProgress:{done:6,total:6,phase:"Резюме"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},a=(M,Va={})=>e({columnId:M,...Va}),C={args:{columnSemanticType:"backlog",task:a("backlog",{labels:["ui"],storyPoints:3}),onStartPreparation:()=>{}}},f={args:{columnSemanticType:"preparation",task:a("preparation",{taskPreparationStatus:"running"}),onStartPreparation:()=>{}}},h={args:{columnSemanticType:"preparation",task:a("preparation",{taskPreparationStatus:"failed",taskPreparationError:"Не заполнены критерии приёмки"}),onStartPreparation:()=>{}}},P={args:{columnSemanticType:"ready",task:a("ready",{skills:["storybook","a11y"],agentId:"prod-10e"}),onStartCi:()=>{}}},A={args:{columnSemanticType:"development",task:a("development"),ciSummary:r(),onOpenCiRun:()=>{}}},I={args:{columnSemanticType:"component_qa",task:a("component_qa",{latestRunResult:{id:"qa-1",kind:"component_qa",status:"success",outcome:"success",createdAt:1,finishedAt:2}})}},R={args:{columnSemanticType:"integration_tests",task:a("integration_tests")}},_={args:{columnSemanticType:"automated_qa",task:a("automated_qa",{latestRunResult:{id:"qa-2",kind:"automated_qa",status:"failed",outcome:"failure",createdAt:1,finishedAt:2}})}},b={args:{columnSemanticType:"manual_qa",task:a("manual_qa")}},q={args:{columnSemanticType:"awaiting_merge",task:a("awaiting_merge",{mergeSourceBranch:"feature/CHAT-375",mergePermitted:!0,mergeMachineBound:!0}),onStartMerge:()=>{}}},v={args:{columnSemanticType:"merge",task:a("merge",{mergeSourceBranch:"feature/CHAT-375",activeMergeRunId:"merge-1"})}},w={args:{columnSemanticType:"done",task:a("done",{mergeSourceBranch:"feature/CHAT-375",doneAt:Date.UTC(2026,7,29),latestRunResult:{id:"run-1",kind:"merge",status:"success",outcome:"success",createdAt:1,finishedAt:2}})}},x={args:{columnSemanticType:"cancelled",task:a("cancelled",{taskPreparationError:"Отменено пользователем"})}},D={args:{columnSemanticType:"decision_required",task:a("decision_required",{taskPreparationError:"Нужно выбрать стратегию миграции"})}},j={args:{columnSemanticType:"development",task:a("development",{title:"Длинный мобильный заголовок карточки задачи ".repeat(4)}),ciSummary:r(),onOpenCiRun:()=>{}},parameters:{viewport:{defaultViewport:"mobile1"}}};var B,E,O;y.parameters={...y.parameters,docs:{...(B=y.parameters)==null?void 0:B.docs,source:{originalSource:`{
  args: {
    task: subprojectBoard.tasks[1],
    projectName: 'Подпроект',
    showProjectBadge: true
  }
}`,...(O=(E=y.parameters)==null?void 0:E.docs)==null?void 0:O.source}}};var Q,F,H;T.parameters={...T.parameters,docs:{...(Q=T.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'C20: Environments UI',
      external: {
        source: 'Delivery',
        externalId: 'C20',
        managed: true,
        url: 'https://delivery.example/tasks/C20'
      }
    })
  }
}`,...(H=(F=T.parameters)==null?void 0:F.docs)==null?void 0:H.source}}};var N,U,L,V,W;t.parameters={...t.parameters,docs:{...(N=t.parameters)==null?void 0:N.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Поправить отступ в шапке'
    })
  }
}`,...(L=(U=t.parameters)==null?void 0:U.docs)==null?void 0:L.source},description:{story:"Минимальная задача: только заголовок, тип и приоритет по умолчанию.",...(W=(V=t.parameters)==null?void 0:V.docs)==null?void 0:W.description}}};var K,z,G,J,X;n.parameters={...n.parameters,docs:{...(K=n.parameters)==null?void 0:K.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Интеграция платёжного шлюза',
      parentId: 'ep1'
    })
  }
}`,...(G=(z=n.parameters)==null?void 0:z.docs)==null?void 0:G.source},description:{story:"С чипом эпика-родителя.",...(X=(J=n.parameters)==null?void 0:J.docs)==null?void 0:X.description}}};var Y,Z,$,ee,ae;s.parameters={...s.parameters,docs:{...(Y=s.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Срочно: падает прод',
      flagged: true,
      priority: 'urgent'
    })
  }
}`,...($=(Z=s.parameters)==null?void 0:Z.docs)==null?void 0:$.source},description:{story:"Помечена флагом — жёлтая карточка.",...(ae=(ee=s.parameters)==null?void 0:ee.docs)==null?void 0:ae.description}}};var re,te,ne,se,oe;o.parameters={...o.parameters,docs:{...(re=o.parameters)==null?void 0:re.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      id: 'full',
      title: 'Оплата картой: полный сценарий с 3-DS подтверждением',
      parentId: 'ep1',
      labels: ['payments', 'critical'],
      storyPoints: 8,
      dueDate: Date.now() - 24 * 60 * 60 * 1000,
      flagged: true,
      assignee: 'bob',
      priority: 'high',
      seq: 42
    }),
    allTasks: [epic, makeTask({
      id: 'ch1',
      parentId: 'full',
      columnId: 'done',
      title: 'Форма'
    }), makeTask({
      id: 'ch2',
      parentId: 'full',
      columnId: 'wip',
      title: 'Шлюз'
    })]
  }
}`,...(ne=(te=o.parameters)==null?void 0:te.docs)==null?void 0:ne.source},description:{story:"Все атрибуты сразу: эпик, метки, флаг, просроченный срок, поинты, аватар, подзадачи.",...(oe=(se=o.parameters)==null?void 0:se.docs)==null?void 0:oe.description}}};var ie,ce,me,pe,de;i.parameters={...i.parameters,docs:{...(ie=i.parameters)==null?void 0:ie.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Выпущено в прод',
      columnId: 'done',
      assignee: 'admin'
    })
  }
}`,...(me=(ce=i.parameters)==null?void 0:ce.docs)==null?void 0:me.source},description:{story:"В колонке «Готово» — ключ зачёркнут.",...(de=(pe=i.parameters)==null?void 0:pe.docs)==null?void 0:de.description}}};var ue,le,ge,ke,Se;c.parameters={...c.parameters,docs:{...(ue=c.parameters)==null?void 0:ue.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Спроектировать и реализовать сценарий обработки переполнения текста, включая перенос строк и обрезание СловаБезПробеловКотороеОченьДлинное' + 'ещёдлиннее'.repeat(8)
    })
  }
}`,...(ge=(le=c.parameters)==null?void 0:le.docs)==null?void 0:ge.source},description:{story:"Очень длинный заголовок и слово без пробелов.",...(Se=(ke=c.parameters)==null?void 0:ke.docs)==null?void 0:Se.description}}};var ye,Te,Ce,fe,he;m.parameters={...m.parameters,docs:{...(ye=m.parameters)==null?void 0:ye.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Меня тащат'
    }),
    dragging: true
  }
}`,...(Ce=(Te=m.parameters)==null?void 0:Te.docs)==null?void 0:Ce.source},description:{story:"Состояние перетаскивания.",...(he=(fe=m.parameters)==null?void 0:fe.docs)==null?void 0:he.description}}};var Pe,Ae,Ie,Re,_e;p.parameters={...p.parameters,docs:{...(Pe=p.parameters)==null?void 0:Pe.docs,source:{originalSource:`{
  args: {
    task: {
      id: 'br',
      projectId: 'p1',
      columnId: 'x',
      type: 'task',
      parentId: 'ghost',
      title: 'Битая задача',
      description: '',
      acceptanceCriteria: '',
      priority: 'medium',
      assignee: null,
      labels: [],
      skills: [],
      storyPoints: null,
      dueDate: null,
      flagged: false,
      seq: 0,
      position: 0,
      createdAt: 1,
      updatedAt: 1
    } as Task
  }
}`,...(Ie=(Ae=p.parameters)==null?void 0:Ae.docs)==null?void 0:Ie.source},description:{story:"Битые данные (через каст) — компонент не падает на уровне карточки.",...(_e=(Re=p.parameters)==null?void 0:Re.docs)==null?void 0:_e.description}}};var be,qe,ve,we,xe;d.parameters={...d.parameters,docs:{...(be=d.parameters)==null?void 0:be.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Ран выполняется'
    }),
    ciSummary: makeCiSummary(),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(ve=(qe=d.parameters)==null?void 0:qe.docs)==null?void 0:ve.source},description:{story:"Ран идёт: голубая рамка медленно «дышит», запуск недоступен — только лента.",...(xe=(we=d.parameters)==null?void 0:we.docs)==null?void 0:xe.description}}};var De,je,Me,Be,Ee;u.parameters={...u.parameters,docs:{...(De=u.parameters)==null?void 0:De.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Модель исправляет ошибку'
    }),
    ciSummary: makeCiSummary({
      slotProgress: {
        done: 4,
        total: 6,
        phase: 'Модель исправляет ошибку',
        fixing: true
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(Me=(je=u.parameters)==null?void 0:je.docs)==null?void 0:Me.source},description:{story:"Шаг упал, модель разбирается: медленное красное мигание.",...(Ee=(Be=u.parameters)==null?void 0:Be.docs)==null?void 0:Ee.description}}};var Oe,Qe,Fe,He,Ne;l.parameters={...l.parameters,docs:{...(Oe=l.parameters)==null?void 0:Oe.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Есть вопросы к пользователю'
    }),
    ciSummary: makeCiSummary({
      status: 'awaiting_input',
      awaitingInput: true,
      slotProgress: {
        done: 3,
        total: 6,
        phase: 'Модель ждёт ответа'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(Fe=(Qe=l.parameters)==null?void 0:Qe.docs)==null?void 0:Fe.source},description:{story:"Ран ждёт ответа пользователя: частое жёлтое мигание.",...(Ne=(He=l.parameters)==null?void 0:He.docs)==null?void 0:Ne.description}}};var Ue,Le,Ve,We,Ke;g.parameters={...g.parameters,docs:{...(Ue=g.parameters)==null?void 0:Ue.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Ран упал'
    }),
    ciSummary: makeCiSummary({
      status: 'failed',
      modelActive: false,
      slotProgress: {
        done: 4,
        total: 6,
        phase: 'Финальные команды (1/2)'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(Ve=(Le=g.parameters)==null?void 0:Le.docs)==null?void 0:Ve.source},description:{story:"Ран свалился окончательно: частое красное мигание.",...(Ke=(We=g.parameters)==null?void 0:We.docs)==null?void 0:Ke.description}}};var ze,Ge,Je,Xe,Ye;k.parameters={...k.parameters,docs:{...(ze=k.parameters)==null?void 0:ze.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Готово к пересборке прода'
    }),
    ciSummary: makeCiSummary({
      status: 'success',
      modelActive: false,
      slotProgress: {
        done: 6,
        total: 6,
        phase: 'Резюме'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(Je=(Ge=k.parameters)==null?void 0:Ge.docs)==null?void 0:Je.source},description:{story:"Разработка закончена, ждёт пересборки прода: статичная зелёная рамка.",...(Ye=(Xe=k.parameters)==null?void 0:Xe.docs)==null?void 0:Ye.description}}};var Ze,$e,ea;C.parameters={...C.parameters,docs:{...(Ze=C.parameters)==null?void 0:Ze.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'backlog',
    task: stageTask('backlog', {
      labels: ['ui'],
      storyPoints: 3
    }),
    onStartPreparation: () => {}
  }
}`,...(ea=($e=C.parameters)==null?void 0:$e.docs)==null?void 0:ea.source}}};var aa,ra,ta;f.parameters={...f.parameters,docs:{...(aa=f.parameters)==null?void 0:aa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'preparation',
    task: stageTask('preparation', {
      taskPreparationStatus: 'running'
    }),
    onStartPreparation: () => {}
  }
}`,...(ta=(ra=f.parameters)==null?void 0:ra.docs)==null?void 0:ta.source}}};var na,sa,oa;h.parameters={...h.parameters,docs:{...(na=h.parameters)==null?void 0:na.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'preparation',
    task: stageTask('preparation', {
      taskPreparationStatus: 'failed',
      taskPreparationError: 'Не заполнены критерии приёмки'
    }),
    onStartPreparation: () => {}
  }
}`,...(oa=(sa=h.parameters)==null?void 0:sa.docs)==null?void 0:oa.source}}};var ia,ca,ma;P.parameters={...P.parameters,docs:{...(ia=P.parameters)==null?void 0:ia.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'ready',
    task: stageTask('ready', {
      skills: ['storybook', 'a11y'],
      agentId: 'prod-10e'
    }),
    onStartCi: () => {}
  }
}`,...(ma=(ca=P.parameters)==null?void 0:ca.docs)==null?void 0:ma.source}}};var pa,da,ua;A.parameters={...A.parameters,docs:{...(pa=A.parameters)==null?void 0:pa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'development',
    task: stageTask('development'),
    ciSummary: makeCiSummary(),
    onOpenCiRun: () => {}
  }
}`,...(ua=(da=A.parameters)==null?void 0:da.docs)==null?void 0:ua.source}}};var la,ga,ka;I.parameters={...I.parameters,docs:{...(la=I.parameters)==null?void 0:la.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'component_qa',
    task: stageTask('component_qa', {
      latestRunResult: {
        id: 'qa-1',
        kind: 'component_qa',
        status: 'success',
        outcome: 'success',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(ka=(ga=I.parameters)==null?void 0:ga.docs)==null?void 0:ka.source}}};var Sa,ya,Ta;R.parameters={...R.parameters,docs:{...(Sa=R.parameters)==null?void 0:Sa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'integration_tests',
    task: stageTask('integration_tests')
  }
}`,...(Ta=(ya=R.parameters)==null?void 0:ya.docs)==null?void 0:Ta.source}}};var Ca,fa,ha;_.parameters={..._.parameters,docs:{...(Ca=_.parameters)==null?void 0:Ca.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'automated_qa',
    task: stageTask('automated_qa', {
      latestRunResult: {
        id: 'qa-2',
        kind: 'automated_qa',
        status: 'failed',
        outcome: 'failure',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(ha=(fa=_.parameters)==null?void 0:fa.docs)==null?void 0:ha.source}}};var Pa,Aa,Ia;b.parameters={...b.parameters,docs:{...(Pa=b.parameters)==null?void 0:Pa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'manual_qa',
    task: stageTask('manual_qa')
  }
}`,...(Ia=(Aa=b.parameters)==null?void 0:Aa.docs)==null?void 0:Ia.source}}};var Ra,_a,ba;q.parameters={...q.parameters,docs:{...(Ra=q.parameters)==null?void 0:Ra.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'awaiting_merge',
    task: stageTask('awaiting_merge', {
      mergeSourceBranch: 'feature/CHAT-375',
      mergePermitted: true,
      mergeMachineBound: true
    }),
    onStartMerge: () => {}
  }
}`,...(ba=(_a=q.parameters)==null?void 0:_a.docs)==null?void 0:ba.source}}};var qa,va,wa;v.parameters={...v.parameters,docs:{...(qa=v.parameters)==null?void 0:qa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'merge',
    task: stageTask('merge', {
      mergeSourceBranch: 'feature/CHAT-375',
      activeMergeRunId: 'merge-1'
    })
  }
}`,...(wa=(va=v.parameters)==null?void 0:va.docs)==null?void 0:wa.source}}};var xa,Da,ja;w.parameters={...w.parameters,docs:{...(xa=w.parameters)==null?void 0:xa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'done',
    task: stageTask('done', {
      mergeSourceBranch: 'feature/CHAT-375',
      doneAt: Date.UTC(2026, 7, 29),
      latestRunResult: {
        id: 'run-1',
        kind: 'merge',
        status: 'success',
        outcome: 'success',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(ja=(Da=w.parameters)==null?void 0:Da.docs)==null?void 0:ja.source}}};var Ma,Ba,Ea;x.parameters={...x.parameters,docs:{...(Ma=x.parameters)==null?void 0:Ma.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'cancelled',
    task: stageTask('cancelled', {
      taskPreparationError: 'Отменено пользователем'
    })
  }
}`,...(Ea=(Ba=x.parameters)==null?void 0:Ba.docs)==null?void 0:Ea.source}}};var Oa,Qa,Fa;D.parameters={...D.parameters,docs:{...(Oa=D.parameters)==null?void 0:Oa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'decision_required',
    task: stageTask('decision_required', {
      taskPreparationError: 'Нужно выбрать стратегию миграции'
    })
  }
}`,...(Fa=(Qa=D.parameters)==null?void 0:Qa.docs)==null?void 0:Fa.source}}};var Ha,Na,Ua;j.parameters={...j.parameters,docs:{...(Ha=j.parameters)==null?void 0:Ha.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'development',
    task: stageTask('development', {
      title: 'Длинный мобильный заголовок карточки задачи '.repeat(4)
    }),
    ciSummary: makeCiSummary(),
    onOpenCiRun: () => {}
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(Ua=(Na=j.parameters)==null?void 0:Na.docs)==null?void 0:Ua.source}}};const gr=["SubprojectBadge","ExternalManaged","Minimal","WithEpicChip","Flagged","AllAttributes","DoneColumn","LongTitle","Dragging","BrokenData","CiRunning","CiFixing","CiAwaitingInput","CiFailed","CiSuccess","StageBacklog","StagePreparation","StagePreparationError","StageReady","StageInProgress","StageComponentQa","StageIntegrationQa","StageAutomatedQa","StageManualQa","StageAwaitingMerge","StageMerge","StageDone","StageCancelled","StageDecisionRequired","MobileLongTitle"];export{o as AllAttributes,p as BrokenData,l as CiAwaitingInput,g as CiFailed,u as CiFixing,d as CiRunning,k as CiSuccess,i as DoneColumn,m as Dragging,T as ExternalManaged,s as Flagged,c as LongTitle,t as Minimal,j as MobileLongTitle,_ as StageAutomatedQa,q as StageAwaitingMerge,C as StageBacklog,x as StageCancelled,I as StageComponentQa,D as StageDecisionRequired,w as StageDone,A as StageInProgress,R as StageIntegrationQa,b as StageManualQa,v as StageMerge,f as StagePreparation,h as StagePreparationError,P as StageReady,y as SubprojectBadge,n as WithEpicChip,gr as __namedExportsOrder,lr as default};
