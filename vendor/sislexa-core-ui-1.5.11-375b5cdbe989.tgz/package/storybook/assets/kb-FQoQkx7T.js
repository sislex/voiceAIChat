const s=["usage","user","project"],t={usage:"Использование",user:"Настройки пользователя",project:"Разработка проекта"};function a(e){return Math.ceil(Math.max(0,e)/4)}export{s as K,t as a,a as e};
