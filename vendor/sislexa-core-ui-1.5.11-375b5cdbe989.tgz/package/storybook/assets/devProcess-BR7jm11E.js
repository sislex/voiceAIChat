const e={"devProcess.start":!0,"devProcess.stop":!0,"devProcess.status":!0,"devProcess.logs":!0},r=Object.keys(e);[...r.map(s=>`${s}.result`)];
