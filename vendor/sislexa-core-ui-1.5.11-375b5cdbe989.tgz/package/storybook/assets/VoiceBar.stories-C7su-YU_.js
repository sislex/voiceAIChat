import{j as a}from"./jsx-runtime-BYYWji4R.js";import{r as y}from"./index-ClcD9ViR.js";import{fn as s,within as W,userEvent as l,expect as p}from"./index-DeN4tkzB.js";import{V as P}from"./VoiceBar-BXSfylpN.js";import{q as $}from"./chat-COYZgq2j.js";import"./ci-DFdZK10C.js";import"./machines-CpV6q5fJ.js";import"./clarification-g58U83f7.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";import"./hotkeys-4oJJtujI.js";import"./types-DFdjDDUq.js";import"./autoGrow-CoBFBF9S.js";import"./view-BrHz5xl6.js";import"./animations-CzQhBjHJ.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./icons-M-fant0Z.js";import"./images-CH23vBlI.js";import"./tools-D2dVYbOd.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./agentProtocol-ChPLBt7B.js";import"./version-B-iWu5V0.js";import"./devProcess-BR7jm11E.js";import"./kb-FQoQkx7T.js";const d=()=>{},ds={title:"Chat/VoiceBar",component:P,args:{state:"idle",draft:"",diarization:!0,detectedSpeakers:[],attachments:[],onDraftChange:s(),onSubmitText:s(),onStartVoice:s(),onStopVoice:s(),onStopSpeak:s(),onCancelRequest:s(),onAddFiles:s(),onRemoveAttachment:s(),defaultCollapsed:!1},decorators:[t=>a.jsx("div",{style:{maxWidth:860},children:a.jsx(t,{})})]},h={},F={args:{contextUsage:{usedTokens:184320,windowTokens:2e5,provider:"codex",model:"gpt-5",measuredAt:Date.now()},onNewThreadWithSummary:s(async()=>{})}},z={args:{draft:"Сохранённый черновик беседы. Длинный текст остаётся доступным для редактирования."},decorators:[t=>a.jsx("div",{style:{width:390,maxWidth:"100%"},children:a.jsx(t,{})})]},U={args:{attachments:[{localId:"pasted",name:"clipboard.svg",status:"ready",previewUrl:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="80" height="60"%3E%3Crect width="80" height="60" fill="skyblue"/%3E%3C/svg%3E'}]}},v={args:{draft:"Разберись, почему упал шаг npm test в последнем ране."}},f={args:{state:"listening",detectedSpeakers:[1,2]}},w={args:{state:"listening",detectedSpeakers:[1],diarization:!1}},x={args:{state:"transcribing"}},ja=`
  .waiting-in-feed-story { display: grid; min-height: 420px; grid-template-rows: 1fr auto; }
  .waiting-in-feed-story__timeline {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    gap: 10px;
    min-height: 260px;
    padding: 20px 14px;
    background: var(--bg);
  }
  .waiting-in-feed-story__message {
    align-self: flex-end;
    max-width: min(76%, 560px);
    padding: 9px 12px;
    border-radius: 14px 14px 4px 14px;
    background: var(--accent);
    color: white;
  }
  .waiting-in-feed-story__preparing {
    align-self: flex-start;
    display: flex;
    align-items: center;
    gap: 7px;
    min-height: 26px;
    color: var(--text-dim);
    font-size: 13px;
  }
  .waiting-in-feed-story__dots { letter-spacing: 2px; color: var(--accent); }
`,S={args:{state:"thinking",draft:"Следующее сообщение в очередь"},render:t=>a.jsxs("div",{className:"waiting-in-feed-story",children:[a.jsx("style",{children:ja}),a.jsxs("div",{className:"waiting-in-feed-story__timeline",role:"log","aria-label":"Сообщения",children:[a.jsx("div",{className:"waiting-in-feed-story__message",children:"Проверь, почему последний тест падает только в CI"}),a.jsxs("div",{className:"waiting-in-feed-story__preparing",role:"status",children:[a.jsx("span",{className:"waiting-in-feed-story__dots","aria-hidden":"true",children:"•••"}),a.jsx("span",{children:"Готовим ответ…"})]})]}),a.jsx(P,{...t})]})},T={args:{state:"thinking",replyStarted:!0,draft:"А ещё проверь кэш npm"}},C={args:{state:"speaking"}},b={args:{voiceInputEnabled:!1}},_a=`
  .attachment-preview-story .attchips { align-items: flex-end; }
  .attachment-preview-story .attpreview-image {
    background:
      linear-gradient(145deg, transparent 55%, rgba(255,255,255,.22) 56% 64%, transparent 65%),
      radial-gradient(circle at 72% 28%, #ffd166 0 7px, transparent 8px),
      linear-gradient(155deg, #7db7e8 0 48%, #4f8f6a 49% 67%, #315f49 68%);
  }
  .attachment-preview-story .attpreview-image > span { display: none; }
`,g={decorators:[t=>a.jsxs("div",{className:"attachment-preview-story",children:[a.jsx("style",{children:_a}),a.jsx(t,{})]})],args:{draft:"Вот скриншот и лог рана",attachments:[$({name:"скриншот-падения.png"}),$({name:"ci-run-1934.log",mimeType:"text/plain"})]}},k={args:{layout:"centered",draft:"",userDisplayName:"Анна"}},E={args:{layout:"docked",draft:"Следующее сообщение"}},I={args:{draft:`Первая строка
Вторая строка
Третья строка`}},B={args:{draft:Array.from({length:10},(t,e)=>`Строка ${e+1}: детали задачи`).join(`
`)}},A={args:{draft:`Первая строка
Вторая строка
Третья строка`},play:async({canvasElement:t})=>{const e=W(t);await l.click(e.getByTestId("composer-size-toggle")),await p(e.getByLabelText("Поле ввода сообщения").closest(".voicebar")).toHaveClass("voicebar--expanded")}},M={args:{draft:"Посмотри изображение",attachments:[{localId:"processing-image",status:"processing",name:"большой-скриншот.png",mimeType:"image/png"}]}},j={decorators:g.decorators,args:{draft:"Посмотри изображение",attachments:[{localId:"ready-image",status:"ready",name:"готовый-скриншот.png",mimeType:"image/png"}]}},_={args:{draft:"Посмотри изображение",onRetryAttachment:s(),attachments:[{localId:"error-image",status:"error",name:"сломанный-скриншот.png",mimeType:"image/png",error:"Не удалось загрузить"}]}},D={args:{draft:"Три изображения",onRetryAttachment:s(),attachments:[{localId:"processing",status:"processing",name:"обработка.png",mimeType:"image/png"},{localId:"ready",status:"ready",name:"готово.png",mimeType:"image/png"},{localId:"error",status:"error",name:"ошибка.png",mimeType:"image/png",error:"Сеть недоступна"}]}},Aa=Array.from({length:5},(t,e)=>({id:`queue-${e+1}`,conversationId:"storybook-chat",messageId:`message-${e+1}`,text:e===1?"Очень длинное ожидающее сообщение, проверяющее перенос текста и доступность действий при увеличенном размере шрифта.":`Ожидающее сообщение ${e+1}`,attachments:e===0?["image-upload","document-upload"]:[],...e===0?{attachmentDetails:[{uploadId:"image-upload",path:"/fixtures/image.png",name:"image.png",mimeType:"image/png",size:1024},{uploadId:"document-upload",path:"/fixtures/document.pdf",name:"document.pdf",mimeType:"application/pdf",size:2048}]}:{},position:e+1,status:"queued",createdAt:e+1}));function Da(t){const[e,m]=y.useState(Aa);return a.jsx(P,{...t,queuedTurns:e,onEditQueued:(r,n)=>{var i;m(c=>c.map(o=>o.id===r?{...o,text:n}:o)),(i=t.onEditQueued)==null||i.call(t,r,n)},onDeleteQueued:r=>{var n;m(i=>i.filter(c=>c.id!==r).map((c,o)=>({...c,position:o+1}))),(n=t.onDeleteQueued)==null||n.call(t,r)},onSendQueuedNow:r=>{var n;m(i=>{const c=i.find(o=>o.id===r);return c?[c,...i.filter(o=>o.id!==r)].map((o,Ma)=>({...o,position:Ma+1})):i}),(n=t.onSendQueuedNow)==null||n.call(t,r)}})}const u={render:t=>a.jsx(Da,{...t}),args:{state:"thinking",queuedTurns:Aa,onEditQueued:s(),onDeleteQueued:s(),onSendQueuedNow:s()},play:async({canvasElement:t})=>{const e=W(t);await p(e.getAllByTestId("turn-queue-item")).toHaveLength(3),await l.click(e.getByRole("button",{name:"Показать ещё 2"})),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(5),await l.click(e.getByRole("button",{name:"Отправить сейчас сообщение № 5"})),await p(e.getAllByTestId("turn-queue-item")[0]).toHaveTextContent("Ожидающее сообщение 5")}},R={args:{...u.args,defaultCollapsed:!0,allowCollapse:!0},parameters:{viewport:{defaultViewport:"mobile1"}},play:async({canvasElement:t})=>{const e=W(t);await p(e.queryByLabelText("Поле ввода сообщения")).not.toBeInTheDocument(),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(3),await l.click(e.getByRole("button",{name:"Показать ещё 2"})),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(5)}},q={args:{...u.args,queuePaused:!0,requestError:"Движок недоступен"}},L={args:{allowCollapse:!0,defaultCollapsed:!0,draft:"Проверь, почему шаг npm test падает только в CI"},parameters:{viewport:{defaultViewport:"mobile1"}}},N={args:{allowCollapse:!0,defaultCollapsed:!0,state:"thinking"},parameters:{viewport:{defaultViewport:"mobile1"}}},Q={args:{permissionMode:"acceptEdits",onChangePermissionMode:s()}};function Ra({initial:t="",state:e="idle"}){const[m,r]=y.useState(t),[n,i]=y.useState([]);return a.jsxs("div",{style:{maxWidth:860},children:[n.length>0&&a.jsx("ul",{className:"attchips","data-testid":"sent-messages",children:n.map((c,o)=>a.jsx("li",{className:"attchip",children:c},o))}),a.jsx(P,{defaultCollapsed:!1,state:e,draft:m,diarization:!0,detectedSpeakers:[],attachments:[],onDraftChange:r,onSubmitText:()=>{i(c=>[...c,m]),r("")},onStartVoice:d,onStopVoice:d,onStopSpeak:d,onCancelRequest:d,onAddFiles:d,onRemoveAttachment:d})]})}function qa(){const[t,e]=y.useState("Создай компонент"),[m,r]=y.useState("plan"),[n,i]=y.useState(null);return a.jsxs("div",{children:[n&&a.jsxs("p",{role:"status",children:["Первая отправка: ",n==="acceptEdits"?"Разработка":"План"]}),a.jsx(P,{defaultCollapsed:!1,state:"idle",draft:t,diarization:!0,detectedSpeakers:[],attachments:[],permissionMode:m,onChangePermissionMode:r,onDraftChange:e,onSubmitText:()=>i(m),onStartVoice:d,onStopVoice:d,onStopSpeak:d,onCancelRequest:d,onAddFiles:d,onRemoveAttachment:d})]})}const V={render:()=>a.jsx(qa,{}),play:async({canvasElement:t})=>{const e=W(t);await l.click(e.getByRole("button",{name:"Разработка"})),await l.click(e.getByLabelText("Отправить сообщение")),await p(e.getByRole("status")).toHaveTextContent("Первая отправка: Разработка")}},H={render:()=>a.jsx(Ra,{}),play:async({canvasElement:t})=>{const e=W(t);await l.type(e.getByLabelText("Поле ввода сообщения"),"Проверь гейт пакета ui"),await l.click(e.getByLabelText("Отправить сообщение")),await p(e.getByTestId("sent-messages")).toHaveTextContent("Проверь гейт пакета ui"),await p(e.getByLabelText("Поле ввода сообщения")).toHaveValue("")}};var O,G,J,K,X;h.parameters={...h.parameters,docs:{...(O=h.parameters)==null?void 0:O.docs,source:{originalSource:"{}",...(J=(G=h.parameters)==null?void 0:G.docs)==null?void 0:J.source},description:{story:"Простой: композер пуст, кнопка справа — микрофон.",...(X=(K=h.parameters)==null?void 0:K.docs)==null?void 0:X.description}}};var Y,Z,ee;F.parameters={...F.parameters,docs:{...(Y=F.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  args: {
    contextUsage: {
      usedTokens: 184_320,
      windowTokens: 200_000,
      provider: 'codex',
      model: 'gpt-5',
      measuredAt: Date.now()
    },
    onNewThreadWithSummary: fn(async () => undefined)
  }
}`,...(ee=(Z=F.parameters)==null?void 0:Z.docs)==null?void 0:ee.source}}};var te,ae,se;z.parameters={...z.parameters,docs:{...(te=z.parameters)==null?void 0:te.docs,source:{originalSource:`{
  args: {
    draft: 'Сохранённый черновик беседы. Длинный текст остаётся доступным для редактирования.'
  },
  decorators: [Story => <div style={{
    width: 390,
    maxWidth: '100%'
  }}><Story /></div>]
}`,...(se=(ae=z.parameters)==null?void 0:ae.docs)==null?void 0:se.source}}};var re,ne,oe;U.parameters={...U.parameters,docs:{...(re=U.parameters)==null?void 0:re.docs,source:{originalSource:`{
  args: {
    attachments: [{
      localId: 'pasted',
      name: 'clipboard.svg',
      status: 'ready',
      previewUrl: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="80" height="60"%3E%3Crect width="80" height="60" fill="skyblue"/%3E%3C/svg%3E'
    }]
  }
}`,...(oe=(ne=U.parameters)==null?void 0:ne.docs)==null?void 0:oe.source}}};var ie,ce,de,pe,me;v.parameters={...v.parameters,docs:{...(ie=v.parameters)==null?void 0:ie.docs,source:{originalSource:`{
  args: {
    draft: 'Разберись, почему упал шаг npm test в последнем ране.'
  }
}`,...(de=(ce=v.parameters)==null?void 0:ce.docs)==null?void 0:de.source},description:{story:"Набранный черновик: микрофон сменился на «отправить».",...(me=(pe=v.parameters)==null?void 0:pe.docs)==null?void 0:me.description}}};var le,ue,ge,ye,he;f.parameters={...f.parameters,docs:{...(le=f.parameters)==null?void 0:le.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    detectedSpeakers: [1, 2]
  }
}`,...(ge=(ue=f.parameters)==null?void 0:ue.docs)==null?void 0:ge.source},description:{story:"Запись: волна, «Готово» и строка обнаруженных говорящих.",...(he=(ye=f.parameters)==null?void 0:ye.docs)==null?void 0:he.description}}};var ve,fe,we,xe,Se;w.parameters={...w.parameters,docs:{...(ve=w.parameters)==null?void 0:ve.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    detectedSpeakers: [1],
    diarization: false
  }
}`,...(we=(fe=w.parameters)==null?void 0:fe.docs)==null?void 0:we.source},description:{story:"Запись без диаризации: чипы говорящих становятся общим «Вы».",...(Se=(xe=w.parameters)==null?void 0:xe.docs)==null?void 0:Se.description}}};var Te,Ce,be,ke,Ee;x.parameters={...x.parameters,docs:{...(Te=x.parameters)==null?void 0:Te.docs,source:{originalSource:`{
  args: {
    state: 'transcribing'
  }
}`,...(be=(Ce=x.parameters)==null?void 0:Ce.docs)==null?void 0:be.source},description:{story:"Распознавание: транскрипт финализируется, композер ещё заблокирован.",...(Ee=(ke=x.parameters)==null?void 0:ke.docs)==null?void 0:Ee.description}}};var Ie,Be,Ae,Me,je;S.parameters={...S.parameters,docs:{...(Ie=S.parameters)==null?void 0:Ie.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    draft: 'Следующее сообщение в очередь'
  },
  render: args => <div className="waiting-in-feed-story">
      <style>{waitingInFeedStoryCss}</style>
      <div className="waiting-in-feed-story__timeline" role="log" aria-label="Сообщения">
        <div className="waiting-in-feed-story__message">Проверь, почему последний тест падает только в CI</div>
        <div className="waiting-in-feed-story__preparing" role="status">
          <span className="waiting-in-feed-story__dots" aria-hidden="true">•••</span>
          <span>Готовим ответ…</span>
        </div>
      </div>
      <VoiceBar {...args} />
    </div>
}`,...(Ae=(Be=S.parameters)==null?void 0:Be.docs)==null?void 0:Ae.source},description:{story:"До первого фрагмента подготовка видна в ленте, не увеличивая нижнюю панель.",...(je=(Me=S.parameters)==null?void 0:Me.docs)==null?void 0:je.description}}};var _e,De,Re,qe,Le;T.parameters={...T.parameters,docs:{...(_e=T.parameters)==null?void 0:_e.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    replyStarted: true,
    draft: 'А ещё проверь кэш npm'
  }
}`,...(Re=(De=T.parameters)==null?void 0:De.docs)==null?void 0:Re.source},description:{story:"Пошёл стрим ответа: композер снова доступен под черновик, отправка — нет.",...(Le=(qe=T.parameters)==null?void 0:qe.docs)==null?void 0:Le.description}}};var Ne,Qe,Ve,He,We;C.parameters={...C.parameters,docs:{...(Ne=C.parameters)==null?void 0:Ne.docs,source:{originalSource:`{
  args: {
    state: 'speaking'
  }
}`,...(Ve=(Qe=C.parameters)==null?void 0:Qe.docs)==null?void 0:Ve.source},description:{story:"Озвучка ответа: композер доступен, красная кнопка останавливает речь.",...(We=(He=C.parameters)==null?void 0:He.docs)==null?void 0:We.description}}};var Pe,Fe,ze,Ue,$e;b.parameters={...b.parameters,docs:{...(Pe=b.parameters)==null?void 0:Pe.docs,source:{originalSource:`{
  args: {
    voiceInputEnabled: false
  }
}`,...(ze=(Fe=b.parameters)==null?void 0:Fe.docs)==null?void 0:ze.source},description:{story:"Микрофон недоступен: движок распознавания не поднялся (нет модели, нет доступа\nк устройству) — голосовой ввод выключен целиком, кнопки микрофона нет, и в\nпростое панель молчит вместо подсказки про пробел. Текст самой ошибки живёт в\nбаннере ленты (`ChatColumn`, сториз `WithError`).",...($e=(Ue=b.parameters)==null?void 0:Ue.docs)==null?void 0:$e.description}}};var Oe,Ge,Je,Ke,Xe;g.parameters={...g.parameters,docs:{...(Oe=g.parameters)==null?void 0:Oe.docs,source:{originalSource:`{
  decorators: [Story => <div className="attachment-preview-story">
      <style>{attachmentPreviewStoryCss}</style>
      <Story />
    </div>],
  args: {
    draft: 'Вот скриншот и лог рана',
    attachments: [makeUpload({
      name: 'скриншот-падения.png'
    }), makeUpload({
      name: 'ci-run-1934.log',
      mimeType: 'text/plain'
    })]
  }
}`,...(Je=(Ge=g.parameters)==null?void 0:Ge.docs)==null?void 0:Je.source},description:{story:"Изображение показано миниатюрой с именем снизу; прочие файлы остаются чипами.",...(Xe=(Ke=g.parameters)==null?void 0:Ke.docs)==null?void 0:Xe.description}}};var Ye,Ze,et,tt,at;k.parameters={...k.parameters,docs:{...(Ye=k.parameters)==null?void 0:Ye.docs,source:{originalSource:`{
  args: {
    layout: 'centered',
    draft: '',
    userDisplayName: 'Анна'
  }
}`,...(et=(Ze=k.parameters)==null?void 0:Ze.docs)==null?void 0:et.source},description:{story:"Пустой чат: композер по центру с приветствием.",...(at=(tt=k.parameters)==null?void 0:tt.docs)==null?void 0:at.description}}};var st,rt,nt,ot,it;E.parameters={...E.parameters,docs:{...(st=E.parameters)==null?void 0:st.docs,source:{originalSource:`{
  args: {
    layout: 'docked',
    draft: 'Следующее сообщение'
  }
}`,...(nt=(rt=E.parameters)==null?void 0:rt.docs)==null?void 0:nt.source},description:{story:"Разговор начат: композер закреплён внизу колонки.",...(it=(ot=E.parameters)==null?void 0:ot.docs)==null?void 0:it.description}}};var ct,dt,pt,mt,lt;I.parameters={...I.parameters,docs:{...(ct=I.parameters)==null?void 0:ct.docs,source:{originalSource:`{
  args: {
    draft: 'Первая строка\\nВторая строка\\nТретья строка'
  }
}`,...(pt=(dt=I.parameters)==null?void 0:dt.docs)==null?void 0:pt.source},description:{story:"Поле начинается с одной строки и растёт на каждую новую строку текста.",...(lt=(mt=I.parameters)==null?void 0:mt.docs)==null?void 0:lt.description}}};var ut,gt,yt,ht,vt;B.parameters={...B.parameters,docs:{...(ut=B.parameters)==null?void 0:ut.docs,source:{originalSource:`{
  args: {
    draft: Array.from({
      length: 10
    }, (_, index) => \`Строка \${index + 1}: детали задачи\`).join('\\n')
  }
}`,...(yt=(gt=B.parameters)==null?void 0:gt.docs)==null?void 0:yt.source},description:{story:"После четырёх строк высота ограничена, текст прокручивается внутри поля.",...(vt=(ht=B.parameters)==null?void 0:ht.docs)==null?void 0:vt.description}}};var ft,wt,xt,St,Tt;A.parameters={...A.parameters,docs:{...(ft=A.parameters)==null?void 0:ft.docs,source:{originalSource:`{
  args: {
    draft: 'Первая строка\\nВторая строка\\nТретья строка'
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByTestId('composer-size-toggle'));
    await expect(canvas.getByLabelText('Поле ввода сообщения').closest('.voicebar')).toHaveClass('voicebar--expanded');
  }
}`,...(xt=(wt=A.parameters)==null?void 0:wt.docs)==null?void 0:xt.source},description:{story:"Редактор раскрыт вручную; play оставляет story в раскрытом состоянии.",...(Tt=(St=A.parameters)==null?void 0:St.docs)==null?void 0:Tt.description}}};var Ct,bt,kt,Et,It;M.parameters={...M.parameters,docs:{...(Ct=M.parameters)==null?void 0:Ct.docs,source:{originalSource:`{
  args: {
    draft: 'Посмотри изображение',
    attachments: [{
      localId: 'processing-image',
      status: 'processing',
      name: 'большой-скриншот.png',
      mimeType: 'image/png'
    }]
  }
}`,...(kt=(bt=M.parameters)==null?void 0:bt.docs)==null?void 0:kt.source},description:{story:"Изображение обрабатывается: плитка зарезервирована, отправка заблокирована.",...(It=(Et=M.parameters)==null?void 0:Et.docs)==null?void 0:It.description}}};var Bt,At,Mt,jt,_t;j.parameters={...j.parameters,docs:{...(Bt=j.parameters)==null?void 0:Bt.docs,source:{originalSource:`{
  decorators: WithAttachments.decorators,
  args: {
    draft: 'Посмотри изображение',
    attachments: [{
      localId: 'ready-image',
      status: 'ready',
      name: 'готовый-скриншот.png',
      mimeType: 'image/png'
    }]
  }
}`,...(Mt=(At=j.parameters)==null?void 0:At.docs)==null?void 0:Mt.source},description:{story:"Изображение готово и может быть отправлено.",...(_t=(jt=j.parameters)==null?void 0:jt.docs)==null?void 0:_t.description}}};var Dt,Rt,qt,Lt,Nt;_.parameters={..._.parameters,docs:{...(Dt=_.parameters)==null?void 0:Dt.docs,source:{originalSource:`{
  args: {
    draft: 'Посмотри изображение',
    onRetryAttachment: fn(),
    attachments: [{
      localId: 'error-image',
      status: 'error',
      name: 'сломанный-скриншот.png',
      mimeType: 'image/png',
      error: 'Не удалось загрузить'
    }]
  }
}`,...(qt=(Rt=_.parameters)==null?void 0:Rt.docs)==null?void 0:qt.source},description:{story:"Ошибка изображения: плитка сохраняется, доступны повтор и удаление.",...(Nt=(Lt=_.parameters)==null?void 0:Lt.docs)==null?void 0:Nt.description}}};var Qt,Vt,Ht,Wt,Pt;D.parameters={...D.parameters,docs:{...(Qt=D.parameters)==null?void 0:Qt.docs,source:{originalSource:`{
  args: {
    draft: 'Три изображения',
    onRetryAttachment: fn(),
    attachments: [{
      localId: 'processing',
      status: 'processing',
      name: 'обработка.png',
      mimeType: 'image/png'
    }, {
      localId: 'ready',
      status: 'ready',
      name: 'готово.png',
      mimeType: 'image/png'
    }, {
      localId: 'error',
      status: 'error',
      name: 'ошибка.png',
      mimeType: 'image/png',
      error: 'Сеть недоступна'
    }]
  }
}`,...(Ht=(Vt=D.parameters)==null?void 0:Vt.docs)==null?void 0:Ht.source},description:{story:"Смешанные статусы вложений явно блокируют отправку до устранения проблем.",...(Pt=(Wt=D.parameters)==null?void 0:Wt.docs)==null?void 0:Pt.description}}};var Ft,zt,Ut,$t,Ot;u.parameters={...u.parameters,docs:{...(Ft=u.parameters)==null?void 0:Ft.docs,source:{originalSource:`{
  render: args => <MessageQueueDemo {...args} />,
  args: {
    state: 'thinking',
    queuedTurns,
    onEditQueued: fn(),
    onDeleteQueued: fn(),
    onSendQueuedNow: fn()
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(3);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать ещё 2'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(5);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Отправить сейчас сообщение № 5'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')[0]).toHaveTextContent('Ожидающее сообщение 5');
  }
}`,...(Ut=(zt=u.parameters)==null?void 0:zt.docs)==null?void 0:Ut.source},description:{story:"Свёрнутая очередь показывает первые три элемента и счётчик остальных.",...(Ot=($t=u.parameters)==null?void 0:$t.docs)==null?void 0:Ot.description}}};var Gt,Jt,Kt,Xt,Yt;R.parameters={...R.parameters,docs:{...(Gt=R.parameters)==null?void 0:Gt.docs,source:{originalSource:`{
  args: {
    ...MessageQueue.args,
    defaultCollapsed: true,
    allowCollapse: true
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await expect(canvas.queryByLabelText('Поле ввода сообщения')).not.toBeInTheDocument();
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(3);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать ещё 2'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(5);
  }
}`,...(Kt=(Jt=R.parameters)==null?void 0:Jt.docs)==null?void 0:Kt.source},description:{story:"Мобильный дефолт: очередь доступна, хотя само поле ввода свёрнуто.",...(Yt=(Xt=R.parameters)==null?void 0:Xt.docs)==null?void 0:Yt.description}}};var Zt,ea,ta,aa,sa;q.parameters={...q.parameters,docs:{...(Zt=q.parameters)==null?void 0:Zt.docs,source:{originalSource:`{
  args: {
    ...MessageQueue.args,
    queuePaused: true,
    requestError: 'Движок недоступен'
  }
}`,...(ta=(ea=q.parameters)==null?void 0:ea.docs)==null?void 0:ta.source},description:{story:"Ошибка текущего хода оставляет ожидающие элементы на явной паузе.",...(sa=(aa=q.parameters)==null?void 0:aa.docs)==null?void 0:sa.description}}};var ra,na,oa,ia,ca;L.parameters={...L.parameters,docs:{...(ra=L.parameters)==null?void 0:ra.docs,source:{originalSource:`{
  args: {
    allowCollapse: true,
    defaultCollapsed: true,
    draft: 'Проверь, почему шаг npm test падает только в CI'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(oa=(na=L.parameters)==null?void 0:na.docs)==null?void 0:oa.source},description:{story:`Свёрнутый композер — то, с чего чат открывается: поле убрано в строку, в ней
черновик (иначе вложения или состояние хода). Так под ленту сообщений
отдаётся вся высота колонки.`,...(ca=(ia=L.parameters)==null?void 0:ia.docs)==null?void 0:ca.description}}};var da,pa,ma,la,ua;N.parameters={...N.parameters,docs:{...(da=N.parameters)==null?void 0:da.docs,source:{originalSource:`{
  args: {
    allowCollapse: true,
    defaultCollapsed: true,
    state: 'thinking'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(ma=(pa=N.parameters)==null?void 0:pa.docs)==null?void 0:ma.source},description:{story:"Свёрнут во время хода: кнопка остановки остаётся в строке, а не прячется.",...(ua=(la=N.parameters)==null?void 0:la.docs)==null?void 0:ua.description}}};var ga,ya,ha,va,fa;Q.parameters={...Q.parameters,docs:{...(ga=Q.parameters)==null?void 0:ga.docs,source:{originalSource:`{
  args: {
    permissionMode: 'acceptEdits',
    onChangePermissionMode: fn()
  }
}`,...(ha=(ya=Q.parameters)==null?void 0:ya.docs)==null?void 0:ha.source},description:{story:"Переключатель режима: план / разработка (в простое активен, в ходе заблокирован).",...(fa=(va=Q.parameters)==null?void 0:va.docs)==null?void 0:fa.description}}};var wa,xa,Sa,Ta,Ca;V.parameters={...V.parameters,docs:{...(wa=V.parameters)==null?void 0:wa.docs,source:{originalSource:`{
  render: () => <PermissionModeFirstSendDemo />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Разработка'
    }));
    await userEvent.click(canvas.getByLabelText('Отправить сообщение'));
    await expect(canvas.getByRole('status')).toHaveTextContent('Первая отправка: Разработка');
  }
}`,...(Sa=(xa=V.parameters)==null?void 0:xa.docs)==null?void 0:Sa.source},description:{story:"Выбранный режим разработки применяется уже к первой отправке.",...(Ca=(Ta=V.parameters)==null?void 0:Ta.docs)==null?void 0:Ca.description}}};var ba,ka,Ea,Ia,Ba;H.parameters={...H.parameters,docs:{...(ba=H.parameters)==null?void 0:ba.docs,source:{originalSource:`{
  render: () => <ControlledVoiceBar />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByLabelText('Поле ввода сообщения'), 'Проверь гейт пакета ui');
    await userEvent.click(canvas.getByLabelText('Отправить сообщение'));
    await expect(canvas.getByTestId('sent-messages')).toHaveTextContent('Проверь гейт пакета ui');
    await expect(canvas.getByLabelText('Поле ввода сообщения')).toHaveValue('');
  }
}`,...(Ea=(ka=H.parameters)==null?void 0:ka.docs)==null?void 0:Ea.source},description:{story:`Отправка сообщения: набрать текст → кнопка микрофона сменилась на «отправить» →
клик отправляет и очищает поле. Enter делает то же (Shift+Enter — перенос).`,...(Ba=(Ia=H.parameters)==null?void 0:Ia.docs)==null?void 0:Ba.description}}};const ps=["Idle","ContextNearlyFull","RestoredDraft390","PastedImage","WithDraft","Listening","ListeningWithoutDiarization","Transcribing","WaitingForModel","ReplyStreaming","Speaking","MicUnavailable","WithAttachments","EmptyCentered","ConversationDocked","Multiline","CappedScroll","Expanded","AttachmentProcessing","AttachmentReady","AttachmentError","AttachmentMixedStatuses","MessageQueue","MessageQueueCollapsedComposer","MessageQueuePausedAfterError","Collapsed","CollapsedWhileThinking","ModeToggle","PermissionModeOnFirstSend","SendMessage"];export{_ as AttachmentError,D as AttachmentMixedStatuses,M as AttachmentProcessing,j as AttachmentReady,B as CappedScroll,L as Collapsed,N as CollapsedWhileThinking,F as ContextNearlyFull,E as ConversationDocked,k as EmptyCentered,A as Expanded,h as Idle,f as Listening,w as ListeningWithoutDiarization,u as MessageQueue,R as MessageQueueCollapsedComposer,q as MessageQueuePausedAfterError,b as MicUnavailable,Q as ModeToggle,I as Multiline,U as PastedImage,V as PermissionModeOnFirstSend,T as ReplyStreaming,z as RestoredDraft390,H as SendMessage,C as Speaking,x as Transcribing,S as WaitingForModel,g as WithAttachments,v as WithDraft,ps as __namedExportsOrder,ds as default};
