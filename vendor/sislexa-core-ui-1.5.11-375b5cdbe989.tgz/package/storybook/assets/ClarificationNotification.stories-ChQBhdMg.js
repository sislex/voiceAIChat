import{j as e}from"./jsx-runtime-BYYWji4R.js";import{within as N,userEvent as y,expect as A,fn as n}from"./index-DeN4tkzB.js";import"./tools-D2dVYbOd.js";import"./ci-DFdZK10C.js";import"./machines-CpV6q5fJ.js";import{l as S,c as h}from"./clarification-g58U83f7.js";import{C as j}from"./ClarificationNotification-DYRRSkp4.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./types-DFdjDDUq.js";import"./agentProtocol-ChPLBt7B.js";import"./version-B-iWu5V0.js";import"./devProcess-BR7jm11E.js";import"./time-CfyNS7J_.js";import"./kb-FQoQkx7T.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";const K={id:"chatai-clarification-notification",title:"ChatAI/ClarificationNotification",component:j,args:{notification:h,onOpen:n(),onDismiss:n()},decorators:[i=>e.jsx("div",{style:{maxWidth:420},children:e.jsx(i,{})})]},a={play:async({args:i,canvasElement:w})=>{const C=N(w);await y.click(C.getByRole("button",{name:"Перейти к задаче"})),await A(i.onOpen).toHaveBeenCalledWith(h)}},t={args:{notification:S}},o={args:{state:"stale"}},r={args:{error:"Проект или вопрос временно недоступен. Повторите переход."}};var s,c,m;a.parameters={...a.parameters,docs:{...(s=a.parameters)==null?void 0:s.docs,source:{originalSource:`{
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Перейти к задаче'
    }));
    await expect(args.onOpen).toHaveBeenCalledWith(clarificationNotification);
  }
}`,...(m=(c=a.parameters)==null?void 0:c.docs)==null?void 0:m.source}}};var p,l,f;t.parameters={...t.parameters,docs:{...(p=t.parameters)==null?void 0:p.docs,source:{originalSource:`{
  args: {
    notification: longClarificationNotification
  }
}`,...(f=(l=t.parameters)==null?void 0:l.docs)==null?void 0:f.source}}};var d,g,u;o.parameters={...o.parameters,docs:{...(d=o.parameters)==null?void 0:d.docs,source:{originalSource:`{
  args: {
    state: 'stale'
  }
}`,...(u=(g=o.parameters)==null?void 0:g.docs)==null?void 0:u.source}}};var v,x,E;r.parameters={...r.parameters,docs:{...(v=r.parameters)==null?void 0:v.docs,source:{originalSource:`{
  args: {
    error: 'Проект или вопрос временно недоступен. Повторите переход.'
  }
}`,...(E=(x=r.parameters)==null?void 0:x.docs)==null?void 0:E.source}}};const M=["Active","LongQuestion","StaleAfterAnswer","NavigationError"];export{a as Active,t as LongQuestion,r as NavigationError,o as StaleAfterAnswer,M as __namedExportsOrder,K as default};
