/// <reference types="vite/client" />
import { describe, expect, it } from 'vitest'
import { render } from '@testing-library/react'
import { composeStories, setProjectAnnotations } from '@storybook/react'
import { UiProviders } from '@voicechat/ui-kit'
import { expectNoCriticalViolations } from '@voicechat/ui-foundation/test/a11y'

// Keep the host's provider boundary while making story discovery application-owned.
setProjectAnnotations({
  decorators: [(Story) => <div className="app" data-theme="light"><UiProviders><Story /></UiProviders></div>]
})
const modules = import.meta.glob<Record<string, unknown>>('./**/*.stories.tsx', { eager: true })
const stories = Object.entries(modules).flatMap(([path, module]) =>
  Object.entries(composeStories(module as Parameters<typeof composeStories>[0])).map(
    ([name, Story]) => ({ name: `${path} / ${name}`, Story: Story as () => JSX.Element })
  )
)

describe('sessions-app stories', () => {
  it('includes the required product states and discovers all stories', () => {
    const module = modules['./SessionsApp.stories.tsx']
    for (const name of ["Default", "SingleDevice", "ReadOnly", "LoadFailed", "Empty"]) {
      expect(module).toHaveProperty(name)
    }
    expect(stories.length).toBeGreaterThanOrEqual(5)
  })

  it.each(stories)('$name has no serious or critical accessibility violations', async ({ Story }) => {
    render(<Story />)
    // Scan the whole document, including any dialogs rendered through portals.
    await expectNoCriticalViolations()
  }, 120_000)
})
