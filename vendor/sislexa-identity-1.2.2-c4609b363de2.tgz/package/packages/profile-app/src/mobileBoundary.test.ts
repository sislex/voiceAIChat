import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { expect, it } from 'vitest'

it('uses the shared 720px mobile boundary', () => {
  const css = readFileSync(resolve(process.cwd(), 'src/styles.css'), 'utf8')
  const boundaries = [...css.matchAll(/@media\s*\((min|max)-width:\s*(\d+)px\)/g)]
  expect(boundaries.length).toBeGreaterThan(0)
  for (const [, kind, width] of boundaries) expect(Number(width)).toBe(kind === 'max' ? 720 : 721)
})
