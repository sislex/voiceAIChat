/** @jsxRuntime automatic */
// Тосты — короткие сообщения о результате действия: «Скопировано», «Настройки
// сохранены», текст упавшего запроса. Нужны потому, что у половины операций
// результат не виден: удалась она или нет, пользователь понимал только по тому,
// изменился ли экран.
//
// Правила стека (почему так, а не «показать всё»):
//   • успех/факт закрываются сами через TOAST_DURATION_MS (с действием —
//     TOAST_ACTION_DURATION_MS), ошибка — только
//     крестиком: её нужно успеть прочитать, а часто и скопировать;
//   • наведение мышью останавливает отсчёт — иначе тост с кнопкой «Повторить»
//     исчезает под курсором ровно в момент клика;
//   • видимых тостов не больше TOAST_VISIBLE_MAX, остальные ждут очереди:
//     пачка ошибок от одного сломанного запроса иначе застилает пол-экрана.
//
// Доступность: контейнер — живая область aria-live="polite", ошибки повышают
// её до assertive на себе (role="alert"), чтобы их прочитали сразу. Контейнер
// смонтирован всегда: живая область должна существовать до появления текста,
// иначе скринридер молчит. Клики он не перехватывает (pointer-events: none).

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode
} from 'react'
import { createPortal } from 'react-dom'
import { useLocaleSource, type UiLocaleSource } from './localeSource'
import { MOBILE_QUERY, useMediaQuery } from './mediaQuery'

export type ToastKind = 'success' | 'error' | 'info'

/** Кнопка в тосте: «Повторить» у неудавшегося запроса, «Отменить» и т.п. */
export interface ToastAction {
  label: string
  onClick: () => void
}

export interface ToastOptions {
  /** Optional application store keeps already visible messages in the selected language. */
  localeSource?: UiLocaleSource
  /** Independent applications can localize the dismiss control and content language. */
  closeLabel?: string
  lang?: string
  action?: ToastAction
  /** Suppress persistence for sensitive messages. */
  history?: boolean
  /** Сколько держать на экране, мс. 0 — до крестика (так ведут себя ошибки). */
  duration?: number
}

export interface ToastApi {
  success: (text: string, options?: ToastOptions) => string
  error: (text: string, options?: ToastOptions) => string
  info: (text: string, options?: ToastOptions) => string
  dismiss: (id: string) => void
  clear?: () => void
}

/** Автозакрытие обычного тоста. */
export const TOAST_DURATION_MS = 4000

/**
 * Тост с действием живёт дольше обычного: 4 секунды — это время прочитать
 * текст, но не время решить и нажать «Вернуть» после удаления пачки файлов.
 * Кнопка отмены, которая исчезает раньше, чем до неё дотягиваются, — это не
 * отмена. Заодно снимается гонка в тестах: они ловили её в том же окне.
 */
export const TOAST_ACTION_DURATION_MS = 12000
/** Сколько тостов видно одновременно; остальные ждут в очереди. */
export const TOAST_VISIBLE_MAX = 3
/** Шаг обратного отсчёта: один таймер на весь стек, пауза — просто его остановка. */
const TICK_MS = 200
const CLOSE_LABEL = 'Закрыть уведомление'
const ICON: Record<ToastKind, string> = { success: '✓', error: '!', info: 'i' }

interface ToastItem {
  localeSource?: ToastOptions['localeSource']
  closeLabel?: string
  lang?: string
  id: string
  count: number
  kind: ToastKind
  text: string
  action?: ToastAction
  /** 0 — по времени не закрывать. */
  duration: number
}

function ToastMessage({ item, dismiss }: { item: ToastItem; dismiss: (id: string) => void }): JSX.Element {
  const { lang, translate } = useLocaleSource(item.localeSource, item.lang)
  return (
    <div
      lang={lang}
      className={`vc-toast vc-toast--${item.kind}`}
      data-testid={`toast-${item.kind}`}
      role={item.kind === 'error' ? 'alert' : 'status'}
      // Handle Escape locally so a notification does not intercept dialog or application shortcuts.
      onKeyDown={(event) => {
        if (event.key !== 'Escape') return
        event.stopPropagation()
        dismiss(item.id)
      }}
    >
      <span className="vc-toast-icon" aria-hidden="true">
        {ICON[item.kind]}
      </span>
      <span className="vc-toast-text">{translate(item.text)}{item.count > 1 && <span aria-label={`${item.count} повторения`}> ×{item.count}</span>}</span>
      {item.action && (
        <button
          className="vc-toast-action"
          onClick={() => {
            item.action?.onClick()
            dismiss(item.id)
          }}
        >
          {translate(item.action.label)}
        </button>
      )}
      <button className="vc-toast-close" aria-label={translate(item.closeLabel ?? CLOSE_LABEL)} title={translate(item.closeLabel ?? CLOSE_LABEL)} onClick={() => dismiss(item.id)}>
        ✕
      </button>
    </div>
  )
}

const ToastContext = createContext<ToastApi | null>(null)

let seq = 0
const toastSessionId = Math.random().toString(36).slice(2)
const nextId = (): string => `toast-${toastSessionId}-${++seq}`

export interface ToastProviderProps {
  children: ReactNode
  /**
   * Селектор элемента у нижней кромки, который тостам нельзя перекрывать
   * (композер VoiceBar на телефоне: стек стоит над ним, а не поверх). Элемента
   * на странице нет — отступа тоже нет, поэтому на страницах-утилитах тосты
   * прижаты к низу.
   */
  avoidSelector?: string
}

export function ToastProvider({ children, avoidSelector }: ToastProviderProps): JSX.Element {
  const [items, setItems] = useState<ToastItem[]>([])
  const [hovered, setHovered] = useState(false)
  const [held, setHeld] = useState(false)
  const [focused, setFocused] = useState(false)
  useEffect(() => {
    if (!held) return
    const release = (): void => setHeld(false)
    window.addEventListener('pointerup', release)
    window.addEventListener('pointercancel', release)
    window.addEventListener('blur', release)
    return () => { window.removeEventListener('pointerup', release); window.removeEventListener('pointercancel', release); window.removeEventListener('blur', release) }
  }, [held])
  const paused = hovered || held || focused
  const itemsRef = useRef<ToastItem[]>([])
  itemsRef.current = items
  // Остаток времени живёт в ref: перезапуск таймера (новый тост, пауза) не
  // должен обнулять отсчёт уже показанным.
  const left = useRef(new Map<string, number>())
  const phone = useMediaQuery(MOBILE_QUERY)

  const dismiss = useCallback((id: string): void => {
    left.current.delete(id)
    itemsRef.current = itemsRef.current.filter(item => item.id !== id)
    setItems((all) => all.filter((item) => item.id !== id))
  }, [])

  const push = useCallback((kind: ToastKind, text: string, options?: ToastOptions): string => {
    const existing = !options?.action ? itemsRef.current.find(item => !item.action && item.kind === kind && item.text === text && item.lang === options?.lang && item.localeSource === options?.localeSource) : undefined
    const id = existing?.id ?? nextId()
    if (options?.history !== false && typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('vc:toast', { detail: { id, kind, text, time: Date.now() } }))
    const duration = options?.duration ?? (kind === 'error' ? 0 : options?.action ? TOAST_ACTION_DURATION_MS : TOAST_DURATION_MS)
    const next = existing
      ? itemsRef.current.map(item => item.id === id ? { ...item, count: item.count + 1 } : item)
      : [...itemsRef.current, { id, count: 1, kind, text, duration, localeSource: options?.localeSource, closeLabel: options?.closeLabel, lang: options?.lang, ...(options?.action ? { action: options.action } : {}) }]
    itemsRef.current = next
    setItems(next)
    return id
  }, [])

  const api = useMemo<ToastApi>(
    () => ({
      success: (text, options) => push('success', text, options),
      error: (text, options) => push('error', text, options),
      info: (text, options) => push('info', text, options),
      dismiss,
      clear: () => { left.current.clear(); itemsRef.current = []; setItems([]) }
    }),
    [push, dismiss]
  )

  const visible = items.slice(0, TOAST_VISIBLE_MAX)

  // Обратный отсчёт: один интервал на весь стек. Считаем только видимые — тост
  // из очереди начинает жить, когда его показали, а не когда поставили в стек.
  useEffect(() => {
    const auto = visible.filter((item) => item.duration > 0)
    if (paused || auto.length === 0) return
    const timer = setInterval(() => {
      const expired: string[] = []
      for (const item of auto) {
        const rest = (left.current.get(item.id) ?? item.duration) - TICK_MS
        left.current.set(item.id, rest)
        if (rest <= 0) expired.push(item.id)
      }
      if (expired.length === 0) return
      expired.forEach((id) => left.current.delete(id))
      setItems((all) => all.filter((item) => !expired.includes(item.id)))
    }, TICK_MS)
    return () => clearInterval(timer)
    // items → новый список видимых; paused → остановка/возобновление отсчёта.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items, paused])

  // Отступ от нижней кромки: высота композера, если он на странице есть.
  // Меряем по факту, а не константой: композер растёт вместе с текстом и
  // вложениями, а на страницах-утилитах его вовсе нет.
  const [avoidHeight, setAvoidHeight] = useState(0)
  useLayoutEffect(() => {
    if (!avoidSelector || visible.length === 0) return
    const node = document.querySelector<HTMLElement>(avoidSelector)
    const measure = (): void => setAvoidHeight(node?.offsetHeight ?? 0)
    measure()
    window.addEventListener('resize', measure)
    const observer = node && typeof ResizeObserver === 'function' ? new ResizeObserver(measure) : null
    observer?.observe(node as HTMLElement)
    return () => {
      window.removeEventListener('resize', measure)
      observer?.disconnect()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [avoidSelector, visible.length])

  // Безопасная зона снизу: страница узнаёт высоту стека и может отодвинуть свои
  // нижние элементы управления. Без этого тост на телефоне ложился поверх
  // «+ Создать» на канбане и буквально перехватывал нажатие — контейнер клики не
  // ловит, но само тело тоста ловит, а лечь ему на 390px некуда.
  const stackRef = useRef<HTMLDivElement | null>(null)
  useLayoutEffect(() => {
    const root = typeof document === 'undefined' ? null : document.documentElement
    if (!root) return
    if (!phone || visible.length === 0) {
      root.style.removeProperty('--vc-toast-inset')
      return
    }
    const measure = (): void => {
      const height = stackRef.current?.offsetHeight ?? 0
      root.style.setProperty('--vc-toast-inset', `${height + 12}px`)
    }
    measure()
    const observer = stackRef.current && typeof ResizeObserver === 'function' ? new ResizeObserver(measure) : null
    if (stackRef.current) observer?.observe(stackRef.current)
    return () => {
      observer?.disconnect()
      root.style.removeProperty('--vc-toast-inset')
    }
  }, [phone, visible.length, avoidHeight])

  const viewport = (
    <div
      ref={stackRef}
      className={`vc-toasts${phone ? ' vc-toasts--phone' : ''}`}
      // Отступ нужен только на телефоне: на десктопе стек стоит в углу, где
      // композера нет.
      style={phone ? { bottom: `calc(${avoidHeight}px + 12px + var(--vc-shell-bottom, 0px))` } : undefined}
      data-testid="toasts"
      // Each toast owns its announcement; a live parent would announce it twice.
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onFocusCapture={() => setFocused(true)}
      onBlurCapture={(event) => { if (!event.currentTarget.contains(event.relatedTarget)) setFocused(false) }}
      onPointerDown={() => setHeld(true)}
      onPointerUp={() => setHeld(false)}
      onPointerCancel={() => setHeld(false)}
      onLostPointerCapture={() => setHeld(false)}
    >
      {visible.map((item) => <ToastMessage key={item.id} item={item} dismiss={dismiss} />)}
    </div>
  )

  return (
    <ToastContext.Provider value={api}>
      {children}
      {typeof document !== 'undefined' ? createPortal(viewport, document.body) : null}
    </ToastContext.Provider>
  )
}

/** Доступ к тостам. Требует ToastProvider — в приложении он стоит в корне App. */
export function useToast(): ToastApi {
  const api = useContext(ToastContext)
  if (!api) throw new Error('useToast: нет ToastProvider — оберните дерево в <ToastProvider>')
  return api
}
