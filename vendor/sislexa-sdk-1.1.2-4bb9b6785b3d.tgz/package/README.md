# Sislexa SDK

Portable operation attribution, normalized usage aggregation and billing contracts.
Run `npm ci` and `npm run gate`; build outputs have no runtime dependencies.

This initial extraction is staged from Core shared contracts. `source-origin.json`
records its immutable source commit and original file hashes. Core remains authoritative
until its adapters switch to this release; do not evolve the two copies separately.

The validators check data shape only. Service callers must derive user and tenant
identity from Identity, authenticate the calling application, and preserve the
origin module across nested calls. Micro-USD amounts use bounded safe integers.
Null policy limits mean unlimited; zero explicitly denies new consumption.

## Execution accounting (1.1)

Billing contracts are owned here; Core's platform SDK adapter uses the published
release. Existing operation/usage snapshots retain their source provenance.
`executionBound: "unbounded"` explicitly identifies an executor without a proven
monetary bound and requires a zero hold. Billing admits it only under an unlimited
monetary policy; omitting the marker preserves the legacy bounded wire shape.
A zero hold by itself must never be used to bypass this distinction.

Settlement evidence keeps disjoint token counts and distinguishes a provider cost
from an estimate. Estimates carry a complete integer micro-USD-per-million-token
price snapshot. `priceUsageMicroUsd` uses integer arithmetic and rounds up once
after summing categories. Unknown model prices must remain unresolved rather than
being fabricated as zero. Validators check structure, not producer authorization.

## Consumer release archives

Version 1.1.1 preserves the public API and publishes clean-commit source and archive
provenance through `npm run pack:release`. Builds precede packing. Consumer archives
exclude owner test files; the full owner gate still runs those tests and validates
package contents. Consumer upgrades follow separately.

Version 1.1.2 also excludes Node checks named `*.check.mjs` and `*.spec.*`;
archive validation uses the same broader test-file boundary.
