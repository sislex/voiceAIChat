import { fileURLToPath } from 'node:url'
import { createComponentRuntime } from '@sislexa/component-runtime'
import { applicationRuntimeMetadata } from '@voicechat/shared'
import Fastify from 'fastify'
import {
  createRpcDispatcher, RpcError, INTERNAL_IMAGE_STUDIO_SERVICE_PATH, IMAGE_STUDIO_SERVICE_METHODS,
  IMAGE_STUDIO_HEALTH_PATH, IMAGE_STUDIO_GENERATION_TIMEOUT_MS, type RpcRequest
} from '@voicechat/shared'
import type { ImageStudioCore } from '../core.js'
import { createImageStudioModule } from '../module.js'
import type { ImageStudioStandaloneConfig } from './config.js'
import { HttpImageStudioCore } from './httpCore.js'
import { registerForwardedAuth } from './auth.js'

export async function buildImageStudioServer(opts: {
  config: ImageStudioStandaloneConfig
  core?: ImageStudioCore
  fetchImpl?: typeof fetch
  logger?: boolean
}) {
  const config = { ...opts.config }
  if (!config.componentConfigPath && !config.internalToken) throw new Error('Image Studio standalone requires VC_INTERNAL_TOKEN')
  if (!config.mcpSecret) throw new Error('Image Studio standalone requires VC_MCP_SECRET')
  const app = Fastify({ logger: opts.logger ?? false })
  const component = config.componentConfigPath ? await createComponentRuntime({
    contractFile: fileURLToPath(new URL('../../component-contract.json', import.meta.url)),
    configFile: config.componentConfigPath, metadata: applicationRuntimeMetadata('image-studio', process.env), fetchImpl: opts.fetchImpl,
  }) : undefined
  component?.register(app)
  const dependency = component?.dependency('core', { timeoutMs: IMAGE_STUDIO_GENERATION_TIMEOUT_MS })
  if (dependency) { config.coreUrl = dependency.url; config.internalToken = dependency.token }
  const fetchImpl = dependency?.fetchImpl ?? opts.fetchImpl
  const core = opts.core ?? new HttpImageStudioCore({ coreUrl: config.coreUrl, token: config.internalToken, fetchImpl })
  registerForwardedAuth(app, { coreUrl: config.coreUrl, token: config.internalToken, fetchImpl })
  const studio = createImageStudioModule({ dataDir: config.dataDir, core, mcpSecret: config.mcpSecret })
  studio.register(app)
  const dispatch = createRpcDispatcher(studio.service, IMAGE_STUDIO_SERVICE_METHODS)
  // Секрет проверяется до разбора тела: пользовательский Bearer здесь не подходит.
  app.register(async (internal) => {
    internal.addHook('onRequest', async (req, reply) => {
      const verdict = component ? component.authorize(req.headers.authorization, 'image-studio.service') : { ok: req.headers.authorization === `Bearer ${config.internalToken}`, status: 401 }
      if (!verdict.ok) return reply.code('status' in verdict ? verdict.status : 401).send({ error: 'component_access_denied' })
    })
    internal.post<{ Body: RpcRequest }>(INTERNAL_IMAGE_STUDIO_SERVICE_PATH, async (req, reply) => {
      try { return { result: await dispatch(req.body ?? { method: '', args: [] }) } } catch (error) {
        return reply.code(error instanceof RpcError ? error.status : 500).send({ error: error instanceof Error ? error.message : String(error) })
      }
    })
  })
  app.get(IMAGE_STUDIO_HEALTH_PATH, async () => ({ application: applicationRuntimeMetadata('image-studio', process.env), ok: true, service: 'image-studio', version: config.version }))
  return { app, studio }
}
