import Fastify from 'fastify'
import { expect, it } from 'vitest'
import { registerForwardedAuth } from './auth.js'
it('forwards tenant hints to the authoritative verifier and never executes a denied request', async () => {
  const app = Fastify()
  let calls = 0
  const fetchImpl: typeof fetch = async (_url, init) => {
    const body = JSON.parse(String(init?.body))
    expect(body.headers['x-sislexa-tenant-id']).toBe('foreign-tenant')
    expect(body.headers.authorization).toBe('Bearer user-credential')
    calls++
    return Response.json({ ok: false, status: 403, error: 'tenant_not_allowed' })
  }
  registerForwardedAuth(app, { coreUrl: 'http://core.test', token: 'service-credential', fetchImpl })
  let executed = false
  app.get('/api/probe', async () => { executed = true; return {} })
  try {
    for (let n = 0; n < 2; n++) {
      const result = await app.inject({ url: '/api/probe', headers: { authorization: 'Bearer user-credential', 'x-sislexa-tenant-id': 'foreign-tenant' } })
      expect(result.statusCode).toBe(403)
    }
    expect(calls).toBe(2)
    expect(executed).toBe(false)
  } finally { await app.close() }
})
