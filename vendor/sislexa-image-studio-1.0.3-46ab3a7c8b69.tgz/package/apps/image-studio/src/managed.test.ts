import { it, expect } from 'vitest'
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createComponentRuntime } from '@sislexa/component-runtime'
import { buildImageStudioServer } from './standalone/server.js'
import { loadImageStudioStandaloneConfig as config } from './standalone/config.js'
const build = async (options: Parameters<typeof buildImageStudioServer>[0]) => (await buildImageStudioServer(options)).app
it('enforces provider scopes and immediate revocation without sharing the legacy secret', async () => {
 const root=mkdtempSync(join(tmpdir(),'managed-image-studio-'))
 const configFile=join(root,'config.json')
 const installation={schemaVersion:1,environmentId:'test',registryDirectory:join(root,'registry'),grants:[{consumerId:'core',scopes:['image-studio.service'],maxTtlSeconds:3600}],legacyScopes:[],dependencies:[{applicationId:'core',url:'http://127.0.0.1:1',tokenFile:join(root,'core.token')}]}
 writeFileSync(configFile,JSON.stringify(installation),{mode:0o600})
 const issuer=await createComponentRuntime({contractFile:fileURLToPath(new URL('../component-contract.json',import.meta.url)),configFile,metadata:{applicationId:'image-studio',version:'1.0.0',apiVersion:'1.1.0',dataVersion:'1.0.0',commit:'a'.repeat(40)}})
 const token=issuer.registry!.issue('core',['image-studio.service'],60)
 const app=await build({config:config({SISLEXA_COMPONENT_CONFIG:configFile,VC_DATA_DIR:root,VC_TTS_DATA_DIR:root,VC_MCP_SECRET:'test-only',VC_PIPER_BIN:'/missing/piper',VC_SAY_BIN:'/missing/say'})})
 try {
  expect((await app.inject('/v1/component')).statusCode).toBe(200)
  expect((await app.inject({method:'POST',url:'/internal/image-studio/service', payload: { method: 'promptContext', args: ['test'] }})).statusCode).toBe(401)
  expect((await app.inject({method:'POST',url:'/internal/image-studio/service', payload: { method: 'promptContext', args: ['test'] },headers:{authorization:'Bearer '+token.token}})).statusCode).toBe(200)
  issuer.registry!.revoke(token.principal.tokenId)
  expect((await app.inject({method:'POST',url:'/internal/image-studio/service', payload: { method: 'promptContext', args: ['test'] },headers:{authorization:'Bearer '+token.token}})).statusCode).toBe(401)
 } finally {await app.close();issuer.close();rmSync(root,{recursive:true,force:true})}
})
