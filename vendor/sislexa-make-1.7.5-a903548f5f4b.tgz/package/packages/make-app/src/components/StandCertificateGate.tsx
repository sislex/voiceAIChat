import { useEffect, useState, type ReactNode } from 'react'
import { mt, useMakeLocale } from '../i18n'

/** An opaque response is enough to establish TLS reachability before mounting. */
export function StandCertificateGate({ url, enabled = true, children }: {
  url: string
  enabled?: boolean
  children: ReactNode
}) {
  useMakeLocale()
  const target = new URL(url, window.location.href)
  const needsProbe = enabled && window.location.protocol === 'http:' && target.protocol === 'https:'
  return needsProbe
    ? <CertificateProbe key={url} url={url} origin={target.origin}>{children}</CertificateProbe>
    : <>{children}</>
}

function CertificateProbe({ url, origin, children }: { url: string; origin: string; children: ReactNode }) {
  const [status, setStatus] = useState<'pending' | 'failed' | 'ready'>('pending')
  const [attempt, setAttempt] = useState(0)
  useEffect(() => {
    let active = true
    void (async () => {
      try {
        await fetch(url, { mode: 'no-cors', cache: 'no-store' })
        if (active) setStatus('ready')
      } catch {
        if (active) setStatus('failed')
      }
    })()
    return () => { active = false }
  }, [url, attempt])
  if (status === 'ready') return <>{children}</>
  return <div className="make-empty-note" role="status">
    <p>{mt(status === 'failed' ? 'standCertificateHint' : 'standCertificateChecking')}</p>
    <a href={origin + '/'} target="_blank" rel="noopener noreferrer">{mt('standCertificateOpen')}</a>
    {status === 'failed' && <button type="button" onClick={() => {
      setStatus('pending')
      setAttempt(value => value + 1)
    }}>{mt('standCertificateRetry')}</button>}
  </div>
}
