export interface ElementSource {
  file: string
  line: number
  column?: number
  component?: string
  owners?: string[]
  package?: string
}

export interface LocatedElement {
  source?: ElementSource
  story?: { id: string; title?: string }
}

// The Make server package has no DOM lib; browser Elements are structurally objects here.
type Element = object

/** Locate React development source metadata without depending on React internals at build time. */
export function locateElement(node: Element, options: { href: string }): LocatedElement {
  type Fiber = {
    return?: Fiber | null
    _debugSource?: { fileName?: unknown; lineNumber?: unknown; columnNumber?: unknown } | null
    _debugOwner?: Fiber | null
    type?: { displayName?: unknown; name?: unknown } | null
  }

  const fiberKey = Object.keys(node).find((key) => key.startsWith('__reactFiber$'))
  if (!fiberKey) return {}
  let fiber = (node as unknown as Record<string, Fiber | undefined>)[fiberKey]
  while (fiber && !fiber._debugSource) fiber = fiber.return ?? undefined
  const debugSource = fiber?._debugSource
  if (!fiber || !debugSource || typeof debugSource.fileName !== 'string' || typeof debugSource.lineNumber !== 'number') return {}

  const componentName = (owner: Fiber | null | undefined): string | undefined => {
    const name = owner?.type?.displayName ?? owner?.type?.name
    return typeof name === 'string' && name ? name : undefined
  }
  const component = componentName(fiber._debugOwner)
  const owners: string[] = []
  let owner = fiber._debugOwner?._debugOwner
  while (owner && owners.length < 5) {
    const name = componentName(owner)
    if (name) owners.push(name)
    owner = owner._debugOwner
  }

  let file = debugSource.fileName.replace(/[?#].*$/, '').replace(/^\/?@fs\//, '/').replace(/\\/g, '/')
  const repositoryPath = file.match(/(?:^|\/)((?:packages|apps)\/.*)$/)
  if (repositoryPath) file = repositoryPath[1]
  else file = file.replace(/^\.\//, '')

  const source: ElementSource = { file, line: debugSource.lineNumber }
  if (typeof debugSource.columnNumber === 'number') source.column = debugSource.columnNumber
  if (component) source.component = component
  if (owners.length) source.owners = owners
  const segments = file.split('/')
  if ((segments[0] === 'packages' || segments[0] === 'apps') && segments[1]) source.package = `${segments[0]}/${segments[1]}`

  const result: LocatedElement = { source }
  let url: URL
  try { url = new URL(options.href) } catch { return result }
  if (!url.pathname.endsWith('/iframe.html') && url.pathname !== 'iframe.html') return result
  const id = url.searchParams.get('id')
  if (!id) return result

  const preview = (globalThis as typeof globalThis & { __STORYBOOK_PREVIEW__?: any }).__STORYBOOK_PREVIEW__
  const story = preview?.currentRender?.storyContext ?? preview?.storyStoreValue?.fromId?.(id) ??
    preview?.storyStore?.fromId?.(id) ?? preview?.storyStoreValue?.storyIndex?.entries?.[id]
  result.story = { id }
  if (typeof story?.title === 'string' && story.title) result.story.title = story.title
  return result
}

export const INSPECTOR_SOURCE_LOCATOR = `(${locateElement.toString()})`
