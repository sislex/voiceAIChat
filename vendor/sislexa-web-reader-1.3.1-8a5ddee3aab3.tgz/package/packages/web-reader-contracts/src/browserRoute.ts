// Where a Browser MCP action actually ran. Every browser tool result of `/mcp/preview` carries a
// top-level `route` field with this shape, and `browser_capabilities` reports per-engine support.
// Consumers (Core UI, Make chat) render these values as is; field names are part of the contract.

/** Engine that executes browser actions for a reader session. */
export type BrowserEngine = 'web_reader_panel' | 'playwright_chromium'

/**
 * Place where an action was executed:
 * - `user_panel` — the user's Web Reader panel (page is fetched through the server proxy);
 * - `server_proxy` — the Web Reader server itself, without touching a page (proxy cookie jar);
 * - `browser_runner` — the isolated Chromium of the browser-runner.
 */
export type BrowserRoutePlace = 'user_panel' | 'server_proxy' | 'browser_runner'

export interface BrowserRoute {
  engine: BrowserEngine
  place: BrowserRoutePlace
  /** Reader conversation id that owns the browser session. */
  sessionId: string
  /** Current page URL when known. */
  url: string | null
  /** Runner machine name from Web Reader configuration; null when unknown or for the panel. */
  machine: string | null
  /** Runner IP address from Web Reader configuration; null when unknown or for the panel. */
  ip: string | null
}

export interface BrowserEngineCapabilities {
  engine: BrowserEngine
  available: boolean
  /** Why the engine is unavailable now; null when available. */
  reason: string | null
  /** Registered MCP tool names that work on this engine. */
  actions: string[]
}

export interface BrowserCapabilities {
  sessionId: string
  engines: BrowserEngineCapabilities[]
}

export const BROWSER_ENGINES: readonly BrowserEngine[] = ['web_reader_panel', 'playwright_chromium']
export const BROWSER_ROUTE_PLACES: readonly BrowserRoutePlace[] = ['user_panel', 'server_proxy', 'browser_runner']

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value)
const isNullableString = (value: unknown): value is string | null => value === null || typeof value === 'string'

export function isBrowserEngine(value: unknown): value is BrowserEngine {
  return typeof value === 'string' && (BROWSER_ENGINES as readonly string[]).includes(value)
}

export function isBrowserRoute(value: unknown): value is BrowserRoute {
  if (!isRecord(value)) return false
  return isBrowserEngine(value.engine)
    && typeof value.place === 'string' && (BROWSER_ROUTE_PLACES as readonly string[]).includes(value.place)
    && typeof value.sessionId === 'string'
    && isNullableString(value.url)
    && isNullableString(value.machine)
    && isNullableString(value.ip)
}

export function isBrowserCapabilities(value: unknown): value is BrowserCapabilities {
  if (!isRecord(value) || typeof value.sessionId !== 'string' || !Array.isArray(value.engines)) return false
  return value.engines.every((engine) => isRecord(engine)
    && isBrowserEngine(engine.engine)
    && typeof engine.available === 'boolean'
    && isNullableString(engine.reason)
    && Array.isArray(engine.actions) && engine.actions.every((action) => typeof action === 'string'))
}
