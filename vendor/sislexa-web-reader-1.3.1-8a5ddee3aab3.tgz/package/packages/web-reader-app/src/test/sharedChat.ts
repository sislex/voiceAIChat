import { createChatStore, type ChatClient } from '@voicechat/chat-app'
import { DEFAULT_SETTINGS, type Conversation } from '@voicechat/shared/types'
import { vi } from 'vitest'

export function readerConversation(id: string): Conversation {
  return { id, title: id, createdAt: 1, updatedAt: 1, messageCount: 0,
    claudeSessionId: null, execTarget: null, workdir: null, skillNames: [],
    llmProvider: null, llmModel: null, permissionMode: null, lastExecTarget: null,
    scope: 'web-reader', assistantKind: 'web-recorder', previewUrl: 'https://example.test' }
}

export function sharedChatFixture() {
  const rows = new Map(['a', 'b'].map(id => [id, readerConversation(id)]))
  const api = {
    'conversations:list': vi.fn(async () => [...rows.values()]),
    'conversations:get': vi.fn(async ({ id }: { id: string }) => ({ conversation: rows.get(id)!, messages: [] })),
    'conversations:taskContext': vi.fn(async () => null),
    'conversations:setPreviewUrl': vi.fn(async ({ id, previewUrl }: { id: string; previewUrl: string | null }) => {
      const row = { ...rows.get(id)!, previewUrl }; rows.set(id, row); return row
    }),
    'uploads:add': vi.fn(async () => ({ id: 'shot', path: '/uploads/shot', name: 'shot.png', mimeType: 'image/png', size: 3 })),
    'messages:add': vi.fn(async (args: Parameters<ChatClient['messages:add']>[0]) => ({ ...args, id: args.messageId ?? 'message', createdAt: 1 })),
    turn: { enabled: true, send: vi.fn() }
  }
  const client = api as unknown as ChatClient
  const store = createChatStore({ chat: client, prefs: { get: () => null, set() {}, remove() {} },
    download: { file() {} }, getSettings: () => DEFAULT_SETTINGS, listAgents: () => [],
    voice: { state: () => 'idle', dispatch: () => true, restoreThinking: () => true,
      beginTurn() {}, speakDelta() {}, finishStreamedTurn: () => false, speakReply() {},
      autoSpeakActive: () => false, cancelSpeech() {}, cancelTimers() {}, resetForChatSwitch() {} } })
  return { store, client, api }
}
