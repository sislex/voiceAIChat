import type { ChatStore } from '@voicechat/chat-app'
import type { PreviewElementPayload } from '@voicechat/browser-contracts/previewInspector'
import type { WebRecorderAreaScreenshot } from '@voicechat/web-reader-contracts/webRecorder'

/** One mounted reader session owns its selection and callbacks. */
export function createPageSelectionAdapter(store: ChatStore, conversationId: string) {
  let disposed = false
  let selection: PreviewElementPayload | null = null
  let knownMessages = new Set<string>()
  const listeners = new Set<() => void>()
  const active = () => !disposed && store.getState().activeId === conversationId
  const clear = () => { selection = null; listeners.forEach(listener => listener()) }
  const unsubscribe = store.subscribe(() => {
    if (!selection) return
    const state = store.getState()
    if (!active() || state.messages.some(message => !knownMessages.has(message.id) &&
      message.meta?.previewElement?.selector === selection?.selector &&
      message.meta?.previewElement?.pageUrl === selection?.pageUrl)) clear()
  })
  return {
    getState: () => selection,
    subscribe(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener) } },
    clear,
    onSelectElement(element: PreviewElementPayload) {
      if (!active()) return
      selection = element
      knownMessages = new Set(store.getState().messages.map(message => message.id))
      listeners.forEach(listener => listener())
    },
    onAsk(text: string) {
      if (!active()) return
      const draft = store.getState().draft
      store.actions.setDraft(draft ? `${draft}\n${text}` : text)
    },
    async onAreaScreenshot(shot: WebRecorderAreaScreenshot) {
      if (!active()) return
      const match = /^data:(image\/(?:png|jpeg));base64,([A-Za-z0-9+/=]+)$/.exec(shot.dataUrl)
      if (!match || shot.dataUrl.length > 2 * 1024 * 1024) throw new Error('Invalid reader screenshot')
      const bytes = Uint8Array.from(atob(match[2]), char => char.charCodeAt(0))
      const file = new File([bytes], `reader-selection.${match[1] === 'image/png' ? 'png' : 'jpg'}`, { type: match[1] })
      await store.actions.addAttachment(file)
    },
    dispose() { disposed = true; unsubscribe(); selection = null; listeners.clear() }
  }
}
