import { WebReaderFrame } from './WebReaderFrame'
import type { WebReaderFrameProps } from './panelContract'
import { WebReaderWidget, type WebReaderWidgetProps } from './WebReaderWidget'

/** Existing hosts retain the preview-only contract until they supply shared chat ports. */
export function WebReaderSurface(props: WebReaderFrameProps | WebReaderWidgetProps): JSX.Element {
  return 'chat' in props ? <WebReaderWidget {...props} /> : <WebReaderFrame {...props} />
}
