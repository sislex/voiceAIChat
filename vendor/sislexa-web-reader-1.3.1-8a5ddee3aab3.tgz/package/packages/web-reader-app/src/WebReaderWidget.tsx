import { useEffect, useState, useSyncExternalStore } from 'react'
import { SharedChat, ChatSettings, type SharedChatProps, type ChatSettingField } from '@sislexa/chat-ui'
import { createSettingsController, type RevisionedSettingsPort } from '@voicechat/chat-app/runtime/settingsController'
import { createWebReaderChatAdapter } from '@voicechat/chat-app/runtime/hostAdapters'
import type { ChatClient, ChatStore } from '@voicechat/chat-app'
import { SplitChatWorkspace } from '@voicechat/chat-app'
import { WebReaderFrame } from './WebReaderFrame'
import type { WebReaderFrameProps } from './panelContract'
import { createPageSelectionAdapter } from './pageSelectionAdapter'
import type { ReaderChatPort } from './contracts'

export interface WebReaderWidgetProps {
  chat: Omit<SharedChatProps, 'skin'>
  frame: Omit<WebReaderFrameProps, 'onSelectElement' | 'onAsk' | 'onAreaScreenshot'>
  settings?: { port: RevisionedSettingsPort; fields: readonly ChatSettingField[] }
  mobilePane?: 'chat' | 'browser'
}

/** The key retires page context and settings when switching conversations. */
export function WebReaderWidget(props: WebReaderWidgetProps): JSX.Element {
  return <ReaderSession key={props.frame.conversationId} {...props} />
}

function ReaderSession({ chat, frame, settings, mobilePane }: WebReaderWidgetProps): JSX.Element {
  const state = useSyncExternalStore(chat.store.subscribe, chat.store.getState, chat.store.getState)
  const [adapter, setAdapter] = useState<ReturnType<typeof createPageSelectionAdapter> | null>(null)
  const [controller, setController] = useState<ReturnType<typeof createSettingsController> | null>(null)
  const [error, setError] = useState<string | null>(null)
  useEffect(() => {
    let alive = true
    const next = createPageSelectionAdapter(chat.store, frame.conversationId)
    setAdapter(next)
    setError(null)
    if (chat.store.getState().activeId !== frame.conversationId) {
      void chat.store.actions.ensureSectionConversations('web-reader').then(() => {
        if (!alive) return false
        return chat.store.actions.selectConversation(frame.conversationId)
      }).then(ok => {
        if (alive && !ok) setError('Не удалось открыть чат Reader')
      }).catch(() => { if (alive) setError('Не удалось открыть чат Reader') })
    }
    return () => { alive = false; next.dispose() }
  }, [chat.store, frame.conversationId])
  useEffect(() => {
    if (!settings) { setController(null); return }
    const next = createSettingsController(settings.port, frame.conversationId)
    setController(next)
    void next.load()
    return () => next.dispose()
  }, [settings?.port, frame.conversationId, chat.store])
  useEffect(() => { adapter?.clear() }, [adapter, frame.conversationUrl, frame.projectUrl])
  if (error) return <p role="alert">{error}</p>
  if (!adapter || state.activeId !== frame.conversationId || state.loadingMessages) return <p role="status">Загрузка чата Reader…</p>
  return <BoundReader chat={chat} frame={frame} adapter={adapter} controller={controller} settings={settings} mobilePane={mobilePane} />
}

function BoundReader({ chat, frame, adapter, controller, settings, mobilePane }: WebReaderWidgetProps & {
  adapter: ReturnType<typeof createPageSelectionAdapter>
  controller: ReturnType<typeof createSettingsController> | null
}): JSX.Element {
  const selection = useSyncExternalStore(adapter.subscribe, adapter.getState, adapter.getState)
  const [error, setError] = useState<string | null>(null)
  return <section className="web-reader-widget" aria-label="Web Reader">
    <SplitChatWorkspace mobilePane={mobilePane === 'browser' ? 'right' : 'chat'} chat={<div className="web-reader-widget-chat">
      <SharedChat {...chat} skin="widget" composer={{ ...chat.composer, previewElement: selection }} />
      {selection && <button onClick={adapter.clear}>Убрать выделение страницы</button>}
      {settings && controller && <details><summary>Настройки чата</summary><ChatSettings controller={controller} owner="conversation" fields={settings.fields} /></details>}
      {error && <p role="alert">{error}</p>}
    </div>} rightPane={<WebReaderFrame {...frame}
      onSelectElement={adapter.onSelectElement}
      onAsk={adapter.onAsk}
      onAreaScreenshot={shot => { void adapter.onAreaScreenshot(shot).catch(() => setError('Не удалось прикрепить снимок страницы')) }}
      onSave={async url => { adapter.clear(); await frame.onSave(url) }} />} />
  </section>
}

/** Use the U04 adapter for scoped CRUD and persisted preview URLs. */
export function createWidgetReaderChatPort(store: ChatStore, client: ChatClient,
  props: (conversationId: string) => Omit<WebReaderWidgetProps, 'chat'> & { chat: Omit<SharedChatProps, 'store' | 'skin'> }): ReaderChatPort {
  const render = (id: string | null, mobilePane?: 'chat' | 'browser') => {
    if (!id) return null
    const value = props(id)
    return <WebReaderWidget {...value} mobilePane={mobilePane} frame={{ ...value.frame, conversationId: id }} chat={{ ...value.chat, store }} />
  }
  return { ...createWebReaderChatAdapter(store, client, render), renderWorkspace: render }
}
