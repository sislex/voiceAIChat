// Shared compatibility runner. Tests stay with the owner; Core is a pinned fixture.
import { execFileSync, spawnSync } from 'node:child_process'
import { mkdirSync, readFileSync, writeFileSync, existsSync, rmSync, cpSync } from 'node:fs'
import { resolve, join } from 'node:path'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'

export function fixtureCommit(value) {
  if (!/^[a-f0-9]{40}$/.test(value ?? '')) throw Error('Core fixture requires a full immutable commit SHA')
  return value
}
export function fixtureSuites(config, root) {
  if (!config.suites?.length || new Set(config.suites).size !== config.suites.length) throw Error('Expected unique system suites')
  for (const file of config.suites)
    if (!/^[\w-]+\.e2e\.test\.ts$/.test(file) || !existsSync(join(root, 'system-tests', file))) throw Error('Missing or invalid system suite: ' + file)
  return config.suites
}
export function checkedRun(command, args, options = {}, execute = spawnSync) {
  const result = execute(command, args, { stdio: 'inherit', ...options })
  if (result.error || result.status !== 0) throw Object.assign(result.error ?? Error('Failed: ' + command + ' ' + args.join(' ')), { exitCode: result.status || 1 })
}
export function runSystemTests(root) {
  const started = Date.now()
  const config = JSON.parse(readFileSync(join(root, 'system-tests/core-fixture.json')))
  if (config.core.repository !== 'https://github.com/sislex/voiceAIChat.git') throw Error('Unexpected Core fixture repository')
  const commit = fixtureCommit(process.env.SISLEXA_TEST_CORE_COMMIT ?? config.core.commit)
  const suites = fixtureSuites(config, root)
  const subject = process.env.SISLEXA_TEST_SUBJECT ?? 'owner'
  if (!['owner', 'installed'].includes(subject)) throw Error('Invalid system test subject')
  console.log(`[system] ${config.package}, subject=${subject}, Core=${commit}`)
  const fixture = join(root, '.cache/core-system', commit)
  const output = join(root, 'artifacts/system-tests'); mkdirSync(output, { recursive: true })
  const run = (command, args, cwd = root) => checkedRun(command, args, { cwd })
  if (!existsSync(join(fixture, '.git'))) {
    mkdirSync(fixture, { recursive: true })
    run('git', ['init', '--quiet'], fixture)
    run('git', ['remote', 'add', 'origin', config.core.repository], fixture)
  }
  const sha = () => execFileSync('git', ['rev-parse', 'HEAD'], { cwd: fixture, encoding: 'utf8' }).trim()
  if (!existsSync(join(fixture, 'package-lock.json'))) {
    run('git', ['fetch', '--depth=1', 'origin', commit], fixture)
    run('git', ['checkout', '--detach', commit], fixture)
  }
  if (sha() !== commit) throw Error('Core fixture commit mismatch')
  const lockHash = createHash('sha256').update(readFileSync(join(fixture, 'package-lock.json'))).digest('hex')
  const stamp = join(fixture, '.installed-lock')
  if (subject === 'installed' || !existsSync(stamp) || readFileSync(stamp, 'utf8') !== lockHash || !existsSync(join(fixture, 'node_modules/.bin/vitest'))) {
    run('npm', ['ci'], fixture); writeFileSync(stamp, lockHash)
  }
  // Rebuild on every run: a cached fixture must never test yesterday's owner code.
  if (subject === 'owner') run('npm', ['run', 'build'])
  const target = join(fixture, 'node_modules', config.package)
  if (subject === 'installed') {
    console.log('[system] Testing exact dependencies from the Core lockfile')
  } else if (config.package === '@sislexa/core-ui') {
    rmSync(join(target, 'web'), { recursive: true, force: true })
    cpSync(join(root, 'apps/web/dist'), join(target, 'web'), { recursive: true })
  } else {
    const packed = JSON.parse(execFileSync('npm', ['pack', '--ignore-scripts', '--json', '--pack-destination', output], { cwd: root, encoding: 'utf8', maxBuffer: 10 * 1024 * 1024 }))[0]
    rmSync(target, { recursive: true, force: true }); mkdirSync(target, { recursive: true })
    run('tar', ['-xzf', join(output, packed.filename), '--strip-components=1', '-C', target])
    // This is test provenance, never a release artifact.
    writeFileSync(join(target, 'release-source.json'), JSON.stringify({ repository: config.package, commit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(), version: packed.version, testFixture: true }))
  }
  if (!existsSync(join(fixture, 'node_modules/@sislexa/core-ui/web/index.html'))) throw Error('Missing Core UI fixture: system scenarios must not skip')
  const tests = join(fixture, 'owner-system-tests')
  rmSync(tests, { recursive: true, force: true }); mkdirSync(tests)
  for (const file of suites) cpSync(join(root, 'system-tests', file), join(tests, file))
  const aliases = { '@sislexa/core-test-host/server': join(fixture, 'apps/server/src/server.ts'), '@sislexa/core-test-host/config': join(fixture, 'apps/server/src/config.ts') }
  writeFileSync(join(tests, 'vitest.config.mjs'), `export default ${JSON.stringify({ resolve: { alias: aliases }, test: { include: suites.map(file => 'owner-system-tests/' + file), environment: 'node', fileParallelism: false, testTimeout: 120000, hookTimeout: 120000, expect: { poll: { timeout: 10000 } } } }, null, 2)}`)
  let exitCode = 0
  try {
    checkedRun('npm', ['exec', '--', 'vitest', 'run', '--config', 'owner-system-tests/vitest.config.mjs'], { cwd: fixture, env: { ...process.env, SISLEXA_TEST_CORE_ROOT: fixture } })
  } catch (error) { exitCode = error.exitCode || 1; throw error }
  finally { writeFileSync(join(output, 'result.json'), JSON.stringify({ coreCommit: commit, subject, ownerPackage: config.package, suites, seconds: (Date.now() - started) / 1000, exitCode }, null, 2) + '\n') }
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  try { runSystemTests(resolve(import.meta.dirname, '..')) }
  catch (error) { console.error(error); process.exitCode = error.exitCode || 1 }
}
