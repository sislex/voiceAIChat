import { execFileSync } from 'node:child_process'

const commit = execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
const tag = `${process.env.COMPOSE_PROJECT_NAME ?? 'web-reader'}-frontend-budget:${commit}`
const version = JSON.parse(execFileSync(process.execPath, ['-p', 'JSON.stringify(require("./packages/web-reader-app/package.json").version)'], { encoding: 'utf8' }))
const run = (args) => execFileSync('docker', args, { stdio: 'inherit' })
try {
  run(['build', '--target', 'frontend', '--build-arg', `APPLICATION_COMMIT=${commit}`,
    '--build-arg', `APPLICATION_VERSION=${version}`, '-t', tag, '.'])
  const bytes = Number(execFileSync('docker', ['image', 'inspect', '--format', '{{.Size}}', tag], { encoding: 'utf8' }).trim())
  console.log(JSON.stringify({ image: tag, bytes, budgetBytes: 200_000_000 }))
  if (!Number.isSafeInteger(bytes) || bytes <= 0 || bytes >= 200_000_000) throw new Error('Frontend image must be smaller than 200 MB')
  run(['run', '--rm', '--network', 'none', '--entrypoint', 'node', tag, '-e',
    "if(require('node:fs').existsSync('/app/node_modules'))process.exit(1)"])
} finally {
  // Remove only the task-owned tag, never prune shared Docker state.
  try { run(['image', 'rm', tag]) } catch {}
}
