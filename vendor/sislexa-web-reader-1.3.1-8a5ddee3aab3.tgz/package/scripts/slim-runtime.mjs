import { build } from 'esbuild'
import { cpSync, mkdirSync, readdirSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL, fileURLToPath } from 'node:url'

export async function buildFrontendServer(output) {
  const result = await build({
    entryPoints: [fileURLToPath(new URL('application-frontend-server.mjs', import.meta.url))],
    outfile: join(output, 'scripts/application-frontend-server.mjs'),
    bundle: true, platform: 'node', format: 'esm', target: 'node22',
    sourcemap: false, metafile: true,
  })
  for (const output of Object.values(result.metafile.outputs)) {
    if (output.imports.some(item => !item.path.startsWith('node:'))) {
      throw new Error('Frontend server must use only Node built-ins at runtime')
    }
  }
}

// Preserve runtime TypeScript and package metadata, but omit development artifacts.
export function stripDevelopmentFiles(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name)
    if (entry.isSymbolicLink()) continue
    if (entry.isDirectory()) {
      if (['test', 'tests', '__tests__', '__mocks__', 'stories', 'coverage'].includes(entry.name)) rmSync(path, { recursive: true })
      else stripDevelopmentFiles(path)
    } else if (/\.(?:test|spec|stories)\.[cm]?[jt]sx?$|\.map$/.test(entry.name)) rmSync(path)
  }
}

export function stageApi(output) {
  mkdirSync(output, { recursive: true })
  for (const path of ['package.json', 'node_modules',
    'apps/web-reader/package.json', 'apps/web-reader/src', 'apps/web-reader/component-contract.json',
    'packages/web-reader-contracts/package.json', 'packages/web-reader-contracts/src',
    'apps/web-recorder/package.json', 'apps/web-recorder/dist']) {
    cpSync(path, join(output, path), { recursive: true, verbatimSymlinks: true })
  }
  stripDevelopmentFiles(output)
}

if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href) {
  if (process.argv[2] === 'api') stageApi('runtime-api')
  else await buildFrontendServer('runtime-frontend')
}
