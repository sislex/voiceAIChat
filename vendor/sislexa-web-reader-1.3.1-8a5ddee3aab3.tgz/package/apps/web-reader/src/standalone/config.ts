import { fileURLToPath } from 'node:url'
import { readBrowserRunnerLocation, type BrowserRunnerLocation } from '../mcp/runnerLocation.js'

export interface WebReaderConfig {
  host: string
  port: number
  coreUrl: string
  componentConfigPath?: string
  internalToken: string
  mcpSecret: string
  playwrightReaderUrl: string
  webRecorderDir: string
  version: string | null
  /** Declared location of the Chromium browser-runner for Browser MCP routes. */
  browserRunner?: BrowserRunnerLocation
}
export function loadWebReaderConfig(env: NodeJS.ProcessEnv = process.env): WebReaderConfig {
  const coreUrl = env.VC_CORE_URL || 'http://127.0.0.1:8787'
  if (!env.SISLEXA_COMPONENT_CONFIG && env.VC_PLAYWRIGHT_READER_MODE === 'remote' && !env.VC_PLAYWRIGHT_READER_URL) throw new Error('VC_PLAYWRIGHT_READER_MODE=remote требует VC_PLAYWRIGHT_READER_URL')
  return {
    host: env.HOST || '127.0.0.1', port: Number(env.PORT || 8795), coreUrl,
    componentConfigPath: env.SISLEXA_COMPONENT_CONFIG,
    internalToken: env.VC_INTERNAL_TOKEN || '', mcpSecret: env.VC_MCP_SECRET || '',
    playwrightReaderUrl: env.VC_PLAYWRIGHT_READER_MODE === 'embedded' ? coreUrl : env.VC_PLAYWRIGHT_READER_URL || coreUrl,
    webRecorderDir: env.VC_WEB_RECORDER_DIR || fileURLToPath(new URL('../../../web-recorder/dist', import.meta.url)),
    version: env.VC_RELEASE_VERSION || null,
    browserRunner: readBrowserRunnerLocation(env)
  }
}
