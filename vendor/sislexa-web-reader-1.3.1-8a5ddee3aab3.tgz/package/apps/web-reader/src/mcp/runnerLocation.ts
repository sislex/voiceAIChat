import { isIP } from 'node:net'

/**
 * Where the Playwright Chromium browser-runner lives, as configured for this Web Reader service.
 * Runner metadata does not report it, so the operator declares it once at startup; unset values stay
 * null and the UI shows the location as unknown. The user panel never has a runner location.
 */
export interface BrowserRunnerLocation {
  machine: string | null
  ip: string | null
}

export const BROWSER_RUNNER_MACHINE_ENV = 'SISLEXA_BROWSER_RUNNER_MACHINE'
export const BROWSER_RUNNER_IP_ENV = 'SISLEXA_BROWSER_RUNNER_IP'

export function readBrowserRunnerLocation(env: NodeJS.ProcessEnv = process.env): BrowserRunnerLocation {
  const machine = env[BROWSER_RUNNER_MACHINE_ENV]?.trim() || null
  const ip = env[BROWSER_RUNNER_IP_ENV]?.trim() || null
  if (machine !== null && machine.length > 255) throw new Error(`${BROWSER_RUNNER_MACHINE_ENV} must be at most 255 characters`)
  if (ip !== null && !isIP(ip)) throw new Error(`${BROWSER_RUNNER_IP_ENV} must be an IPv4 or IPv6 address`)
  return { machine, ip }
}
