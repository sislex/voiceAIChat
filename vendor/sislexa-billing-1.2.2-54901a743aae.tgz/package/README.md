# Sislexa Billing

Independent budget reservations and settlement service. It owns a durable SQLite
ledger; Identity supplies live users and tenant IDs, and provider-issued grants
authorize calling applications. Analytics is not a spending authority.

The published reservation, settlement, reporting attribution, idempotency, and
historical-record contracts are documented in [docs/attribution-contracts.md](docs/attribution-contracts.md).
Consumer contract tests may import `BILLING_CONTRACT_FIXTURES`,
`BILLING_HISTORICAL_RECORD_POLICY`, `BILLING_PRODUCT_CAPABILITIES`, and
`reservationPrincipal` from the package root.

## Development and operation

Use Node >=22.13, `npm ci`, `npm run gate` and `npm start`. Configure
`SISLEXA_COMPONENT_CONFIG` from `config.example.json`, `BILLING_DATA_DIR`, `HOST`
and `PORT` (default loopback 8800). Runtime metadata uses the common
`VC_APPLICATION_VERSION`, `VC_APPLICATION_API_VERSION`, `VC_APPLICATION_COMMIT`
and `VC_APPLICATION_DATA_VERSION` variables. Secrets must be private files and
never committed. Identity must provide stable subjects (version >=1.2.0) and
API >=1.4.0 with delegated billing admission for this service build.

`/v1/component`, `/v1/ready` and `/v1/component/authorize` implement managed
component discovery and grants. Consumers need `billing.reserve` and/or
`billing.execute`. Reserve/start requests carry the caller's component bearer
and the user's bearer in `x-sislexa-user-authorization`; both are validated.
The service derives the user, tenant, environment and actor. Only Core can
attribute different supported origin modules; other callers use their own ID.

For a standalone application grant, Core sets `x-sislexa-delegated-billing: 1`,
passes the original grant in the user-authorization header, and supplies its
verified application attribution. Billing requires Core's `billing.reserve` or
`billing.execute` component grant and calls Identity's component-only delegated
billing admission route at both reserve and start. The returned live subject and
capabilities determine the ledger principal; revocation blocks starting new
work. This mode cannot access account, policy, or report APIs and does not create
a general user session. Configure Billing's Identity dependency with
`identity.delegation.billing-admission` before enabling the mode in Core.

`GET /api/billing/account` requires the user's bearer and reports that tenant.
`GET /api/billing/usage?from=<ms>&to=<ms>` returns only that stable user's
finalized ledger history, module shares, raw token categories and UTC daily
totals for a period of at most 366 days. A trusted reporting service may use
`POST /v1/billing/usage-report` with `billing.report` plus the delegated user
authorization header; the component credential cannot select another user.
The report's `applications` buckets group by verified origin application ID,
including a `null` bucket for legacy records. Each bucket reports settled
requests, cost, input/output/cache token categories and `missingUsageEvents`.
Buckets reconcile exactly to account totals; missing usage evidence contributes
cost and request count but never invented token counts. The application token
category fields require Billing component API 1.2.0.
`PUT /api/billing/policy` requires a live system administrator and changes that
administrator's own tenant policy using `expectedRevision`. Cookie-only requests
are rejected. Cross-tenant administration and account UI are a later integration.

## Accounting semantics

Amounts are integer micro-USD, not floating-point dollar values. Null limits are
unlimited; zero is explicit. Monthly limits use UTC and admission-time attribution.
An admitted request counts even when cancelled. Active reservations from previous
months retain their concurrency slot; settlement belongs to their original month.
No money is credited or collected by this service version.

Policies and balances belong to `(environment, tenant)`, so every member of a
team consumes the same request, concurrency and monetary budget. Reservations
still retain the stable user ID that created them for ownership checks and usage
analytics; one team member cannot inspect or settle another member's reservation.

Admission, limits and idempotency use BEGIN IMMEDIATE transactions. Parallel
connections/workers contend on the same database. Reusing an operation ID with
changed identity or input is rejected. Persist operation IDs and expiry inputs
before retrying. A reservation may start once, expire before starting, become
uncertain, or settle once with an immutable event ID. Retry responses are stable. A start response has `transitioned: true` only for
the winning claim; a replay returns false and must not execute another provider
call. A lost claim response requires reconciliation, not blind execution retry.
An uncertain/running operation never releases money merely because its TTL passed.
The owning executor can settle incurred work after the user's session is revoked;
new admission and start still require current user authority and capabilities.

Executors must enforce the reserved bound. This service does not turn an unbounded
CLI invocation into a prepaid-safe provider call. Actual overage is recorded rather
than hidden, reducing later availability; provider contract violations require
reconciliation. Runtime integration must reject unsupported bounded execution when
a finite budget is enforced. No end-to-end Core budget enforcement is claimed yet.

Version 1.1 accepts `executionBound: "unbounded"` only with `maxMicroUsd: 0` and
an unlimited monetary policy. Request and concurrency limits still apply. A
finite monetary policy cannot replace an unlimited policy while an unbounded
reservation is reserved, running or uncertain; settle or reconcile it first.
The admission and policy-update checks share the same database transaction lock.

Settlement may carry `usage` with model, complete disjoint token counters and
`costSource: "provider" | "estimate"`. Estimates require an immutable complete
price snapshot in integer micro-USD per million tokens. The ledger independently
recomputes the estimate and rejects mismatches. Every usage field participates in
settlement idempotency; changing counters or prices on retry cannot silently
replace evidence. `GET /v1/billing/reservations/:id` requires `billing.execute`
from the owning component and returns durable status/evidence even after user
logout. It cannot admit or start new work with a revoked user session.

Usage evidence is stored in an additive table, preserving legacy settlement
rows and their replay fingerprints. Version 1.0 cannot enforce the unbounded
marker: rollback requires pausing new admissions and reconciling all unbounded
work before restoring older code. Do not run both service versions concurrently.

Deploy one durable database, not replicas with independent files. Keep its WAL
with the database and use SQLite's consistent online backup API. Current tests
cover concurrent workers, isolation, restart/replay, period rollover, revoked
sessions/grants, capability changes, policy conflicts and actual HTTP Identity
boundaries. Production rollout requires immutable source/dependency pins and
operator backup/restore evidence.

## Consumer archives (1.1.2)

`npm run pack:release` builds from a clean commit and records source and archive
hashes. Consumers install the published archive through its public exports.
Internal tests remain in this owner repository and run in `npm run gate`; they
are excluded from consumer archives. Package boundary checks reject tests, stories
and nested dependencies. This release changes packaging only; service rollout
and Core adapter removal are separate acceptance steps.

Version 1.1.3 removes the unused sessions-core installation peer. Billing receives
its authenticated principal through its existing Identity/component-runtime ports
and has no session-store implementation imports; requiring a private session
workspace prevented consumers from removing Core compatibility adapters. The
full gate runs after a fresh installation without that dependency.

## Owner image publication

The Check workflow runs the complete owner gate. Version tags publish Linux AMD64
images from the exact tested commit; `workflow_dispatch` accepts an existing
`release_ref` tag to publish an already released source revision. The tag must
match package.json. Images carry version and commit tags under `ghcr.io/sislex/`.
Deployment selects an immutable commit/digest and preserves installation settings
and data volumes; publication itself does not deploy a service.
