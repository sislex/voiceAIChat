import{j as o}from"./jsx-runtime-BYYWji4R.js";import{r as wt}from"./index-ClcD9ViR.js";import{within as c,userEvent as n,expect as i,fn as a}from"./index-DeN4tkzB.js";import{C as ut}from"./ChatColumn-BwxBGWYO.js";import{V as xt}from"./VoiceBar-BXSfylpN.js";import{A as gt,S as Et,m as p,e as l,f as F,g as Mt,h as bt,i as vt,j as yt,k as kt,l as Tt,T as ft,n as St,b as O}from"./chat-COYZgq2j.js";import"./ci-DFdZK10C.js";import{m as ht,a as Bt,b as It,c as Ct}from"./machines-Dwf6SHZ7.js";import"./clarification-g58U83f7.js";import{T as At}from"./time-CfyNS7J_.js";import{A as Lt}from"./version-B-iWu5V0.js";import"./devProcess-BR7jm11E.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-DfK2HARR.js";import"./questions-Bk4wc6lB.js";import"./tools-D2dVYbOd.js";import"./images-CH23vBlI.js";import"./view-BrHz5xl6.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./clipboard-OV73WQR5.js";import"./Markdown-D3RuqcxH.js";import"./core-BwXZ_Otv.js";import"./lazyScreen-CooZxeYV.js";import"./Skeleton-42oMjovX.js";import"./ErrorState-CqsakWkx.js";import"./autoGrow-CoBFBF9S.js";import"./MessageMeta-C77-zjcA.js";import"./kb-FQoQkx7T.js";import"./MessageImage-BtAQ-NXb.js";import"./animations-CzQhBjHJ.js";import"./ToolFrame-CqCmqPT9.js";import"./QuestionsForm-BIFaA7UX.js";import"./MessageTimeline-DfHSVMjJ.js";import"./MessageActivity-5vFHiusu.js";import"./machineHealth-DVSppiWW.js";import"./uiPerformance-R53OMrUM.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./useHotkeys-CjtRU-3i.js";import"./hotkeys-4oJJtujI.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";import"./persistence-Y4P2JfJq.js";import"./mediaQuery-CCkbYk-e.js";import"./types-DFdjDDUq.js";import"./icons-M-fant0Z.js";import"./agentProtocol-ChPLBt7B.js";const m=()=>{};function V(e="idle"){return o.jsx(xt,{defaultCollapsed:!1,state:e,draft:"",diarization:!0,detectedSpeakers:e==="listening"?[1,2]:[],attachments:[],onDraftChange:m,onSubmitText:m,onStartVoice:m,onStopVoice:m,onStopSpeak:m,onCancelRequest:m,onAddFiles:m,onRemoveAttachment:m})}const Rt=[ht({id:"m1",name:"MacBook",version:Lt,lastSeen:Date.now(),telemetry:It({ts:Date.now()})}),Ct({id:"m2",name:"Сборочный сервер"})];function Ut(){return[p({id:"u1",text:"Почему на последнем ране упал шаг с тестами?",execTarget:"m1"}),l({id:"a1",text:ft,execTarget:"m1",createdAt:At+45e3,meta:F({activity:St,durationMs:45e3,costUsd:.183,inputTokens:82400,outputTokens:1240})})]}const Ba={title:"Chat/ChatColumn",component:ut,parameters:{layout:"fullscreen"},args:{title:"Разбор упавшего рана",state:"idle",messages:Ut(),liveSegments:[],diarization:!0,agents:Rt,execTarget:"m1",aiLabel:"Claude",canSpeak:!0,permissionMode:"acceptEdits",voiceBar:V(),onSpeakMessage:a(),onDeleteMessage:a(),onEditMessage:a(),onExport:a(),onRenameTitle:a(),onOpenConversationSettings:a(),onChangeExecTarget:a()},decorators:[e=>o.jsx("div",{className:"app",style:{height:"90vh",display:"grid",gridTemplateColumns:"minmax(0, 1fr)"},children:o.jsx("div",{className:"chat-page",style:{gridColumn:1},children:o.jsx(e,{})})})]},_={render:e=>{const[s,t]=wt.useState(!1);return o.jsxs("div",{style:{height:700,display:"flex",flexDirection:"column",minWidth:0},children:[o.jsx("button",{onClick:()=>t(!0),children:"Получить новый ответ"}),o.jsx(ut,{...e,conversationId:"story-unread",messages:[...bt(),...s?[l({id:"new-story-reply",text:"Новый ответ"})]:[]]})]})},play:async({canvasElement:e})=>{const s=c(e),t=s.getByTestId("scroll");t.dispatchEvent(new Event("wheel",{bubbles:!0})),t.scrollTop=0,t.dispatchEvent(new Event("scroll",{bubbles:!0})),await n.click(s.getByText("Получить новый ответ")),await i(s.findByText("↓ Новые сообщения (1)")).resolves.toBeTruthy()}},N={args:{messages:[l({text:O})]},play:async({canvasElement:e})=>{const s=c(e);await n.click(s.getByText("Поиск")),await n.type(s.getByLabelText("Найти в беседе"),"код"),await n.click(s.getByLabelText("Меню беседы")),await n.click(s.getByText("Компактная лента"))}},W={args:{conversationId:"failed",failedSubmits:[{operationId:"op",conversationId:"failed",text:"Сообщение с вложением",attachmentIds:["upload"],error:"Нет соединения",retrying:!1}],onRetryFailedSubmit:a(),onDeleteFailedSubmit:a()}},j={decorators:[e=>o.jsx("div",{style:{width:"100%",maxWidth:390,minWidth:0,height:750},children:o.jsx(e,{})})],args:{messages:[l({text:O})]}},d={play:async({canvasElement:e})=>{const s=c(e).getByRole("button",{name:"Копировать вопрос"});await i(s).toHaveClass("copymsg"),await i(s).not.toHaveClass("copymsg--copied")}},u={play:async({canvasElement:e})=>{const t=c(e).getByRole("button",{name:"Копировать вопрос"}),r=t.closest(".me .bub");if(!r)throw new Error("User message bubble not found");await n.hover(r),await i(t).toHaveClass("copymsg")}},g={play:async({canvasElement:e})=>{const s=c(e).getByRole("button",{name:"Копировать вопрос"});s.focus(),await i(s).toHaveFocus()}},b={decorators:[e=>o.jsx("div",{"data-theme":"dark",style:{height:"100%"},children:o.jsx(e,{})})],play:async({canvasElement:e})=>{const r=c(e).getByRole("button",{name:"Копировать вопрос"}).closest(".me .bub");if(!r)throw new Error("User message bubble not found");await n.hover(r)}},v={play:async({canvasElement:e})=>{const t=c(e).getByRole("button",{name:"Копировать ответ"}),r=t.closest(".ai .bub");if(!r)throw new Error("Model message bubble not found");await n.hover(r),t.focus(),await i(t).toHaveFocus()}},y={play:async({canvasElement:e})=>{const t=c(e).getByRole("button",{name:"Копировать вопрос"});await n.click(t),await i(t).toHaveClass("copymsg--copied")}},h={args:{messages:[],onExport:void 0}},w={args:{messages:[],loadingMessages:!0}},x={args:{loadingMessages:!0}},E={args:{state:"thinking",streamingReply:Et,liveActivity:gt,liveUsage:vt(),voiceBar:V("thinking")}},M={args:{state:"thinking",liveActivity:gt,liveUsage:vt(),voiceBar:V("thinking")}},k={args:{state:"listening",liveSegments:Mt(),voiceBar:V("listening")}},T={args:{error:"Микрофон недоступен: браузер не дал доступ к устройству записи",onDismissError:a()}},f={args:{modelMissing:!0,modelLabel:"large-v3-turbo",onDownloadModel:a()}},S={args:{modelMissing:!0,modelLabel:"large-v3-turbo",downloading:!0,downloadPercent:42}},B={args:{messages:[p({text:"Сделай CI-шаг для витрины"}),yt()],onAnswerQuestions:a()}},I={args:{messages:[p({text:"старт"}),yt({id:"a-ci",meta:{ciInteraction:{runId:"run-1",interactionId:"it-1"}}}),p({id:"u-after",text:"а пока посмотрю лог"})],onAnswerCiInteraction:a()}},C={args:{messages:[p({text:"Построй график и открой консоль"}),kt(),Tt("console")],machineOps:Bt(),agents:[ht({id:"m1",name:"MacBook"})],onSwitchUtility:a(),onOpenMachines:a(),onOpenImageInExplorer:a()}},A={args:{permissionMode:"plan",messages:[p({text:"Составь план"}),l({id:"a-plan",text:O,meta:F({request:{...F().request,permissionMode:"plan"}})})],onExecutePlan:a(),voiceBar:V()}},L={args:{messages:[p({text:"Опиши архитектуру"}),l({id:"a-int",text:"Начал описывать, но не успел закон",meta:F({interrupted:!0})})]}},R={args:{messages:bt()}},U={args:{onToggleSidebar:a(),messages:[p({id:"u-mobile-copy",text:"Проверь перенос длинной ссылки: https://example.test/very/long/unbroken/path/that/must/not/escape/the/message/bubble?query=mobile-copy-button"}),l({id:"a-mobile-copy",text:"Кнопка остаётся внутри пузыря, а текст переносится."})]},parameters:{viewport:{defaultViewport:"mobile2"}},play:async({canvasElement:e})=>{const r=c(e).getByRole("button",{name:"Копировать вопрос"}).closest(".me .bub");if(!r)throw new Error("User message bubble not found");await n.hover(r)}},H={play:async({canvasElement:e})=>{const s=c(e);await n.click(s.getByLabelText("Изменить сообщение"));const t=s.getByLabelText("Редактирование сообщения");await n.clear(t),await n.type(t,"Почему упал шаг npm test и как это починить?"),await i(t).toHaveValue("Почему упал шаг npm test и как это починить?"),await i(s.getByRole("button",{name:"Отправить"})).toBeEnabled()}},D={play:async({canvasElement:e})=>{const s=c(e),t=s.getByLabelText("Переключить вид действий");await n.click(t),await i(s.getAllByTestId("activity-brief")).toHaveLength(2),await n.click(t),await i(s.getAllByTestId("activity-section").length).toBeGreaterThan(1)}};var Q,K,q;_.parameters={..._.parameters,docs:{...(Q=_.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  render: args => {
    const [extra, setExtra] = useState(false);
    return <div style={{
      height: 700,
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0
    }}>
      <button onClick={() => setExtra(true)}>Получить новый ответ</button>
      <ChatColumn {...args} conversationId="story-unread" messages={[...makeLongThread(), ...(extra ? [makeAiMessage({
        id: 'new-story-reply',
        text: 'Новый ответ'
      })] : [])]} />
    </div>;
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const scroll = canvas.getByTestId('scroll');
    scroll.dispatchEvent(new Event('wheel', {
      bubbles: true
    }));
    scroll.scrollTop = 0;
    scroll.dispatchEvent(new Event('scroll', {
      bubbles: true
    }));
    await userEvent.click(canvas.getByText('Получить новый ответ'));
    await expect(canvas.findByText('↓ Новые сообщения (1)')).resolves.toBeTruthy();
  }
}`,...(q=(K=_.parameters)==null?void 0:K.docs)==null?void 0:q.source}}};var P,G,Y;N.parameters={...N.parameters,docs:{...(P=N.parameters)==null?void 0:P.docs,source:{originalSource:`{
  args: {
    messages: [makeAiMessage({
      text: MD_KITCHEN_SINK
    })]
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByText('Поиск'));
    await userEvent.type(canvas.getByLabelText('Найти в беседе'), 'код');
    await userEvent.click(canvas.getByLabelText('Меню беседы'));
    await userEvent.click(canvas.getByText('Компактная лента'));
  }
}`,...(Y=(G=N.parameters)==null?void 0:G.docs)==null?void 0:Y.source}}};var X,z,J;W.parameters={...W.parameters,docs:{...(X=W.parameters)==null?void 0:X.docs,source:{originalSource:`{
  args: {
    conversationId: 'failed',
    failedSubmits: [{
      operationId: 'op',
      conversationId: 'failed',
      text: 'Сообщение с вложением',
      attachmentIds: ['upload'],
      error: 'Нет соединения',
      retrying: false
    }],
    onRetryFailedSubmit: fn(),
    onDeleteFailedSubmit: fn()
  }
}`,...(J=(z=W.parameters)==null?void 0:z.docs)==null?void 0:J.source}}};var Z,$,ee;j.parameters={...j.parameters,docs:{...(Z=j.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  decorators: [Story => <div style={{
    width: '100%',
    maxWidth: 390,
    minWidth: 0,
    height: 750
  }}><Story /></div>],
  args: {
    messages: [makeAiMessage({
      text: MD_KITCHEN_SINK
    })]
  }
}`,...(ee=($=j.parameters)==null?void 0:$.docs)==null?void 0:ee.source}}};var se,te,ae,ne,re;d.parameters={...d.parameters,docs:{...(se=d.parameters)==null?void 0:se.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const button = within(canvasElement).getByRole('button', {
      name: 'Копировать вопрос'
    });
    await expect(button).toHaveClass('copymsg');
    await expect(button).not.toHaveClass('copymsg--copied');
  }
}`,...(ae=(te=d.parameters)==null?void 0:te.docs)==null?void 0:ae.source},description:{story:"Обычная беседа: кнопка вопроса есть в DOM, но в покое визуально скрыта.",...(re=(ne=d.parameters)==null?void 0:ne.docs)==null?void 0:re.description}}};var oe,ie,ce,me,pe;u.parameters={...u.parameters,docs:{...(oe=u.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
    await expect(button).toHaveClass('copymsg');
  }
}`,...(ce=(ie=u.parameters)==null?void 0:ie.docs)==null?void 0:ce.source},description:{story:"Наведение на пользовательский пузырь раскрывает кнопку вопроса.",...(pe=(me=u.parameters)==null?void 0:me.docs)==null?void 0:pe.description}}};var le,de,ue,ge,be;g.parameters={...g.parameters,docs:{...(le=g.parameters)==null?void 0:le.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const button = within(canvasElement).getByRole('button', {
      name: 'Копировать вопрос'
    });
    button.focus();
    await expect(button).toHaveFocus();
  }
}`,...(ue=(de=g.parameters)==null?void 0:de.docs)==null?void 0:ue.source},description:{story:"Клавиатурный фокус раскрывает кнопку и сохраняет нативную активацию.",...(be=(ge=g.parameters)==null?void 0:ge.docs)==null?void 0:be.description}}};var ve,ye,he,we,xe;b.parameters={...b.parameters,docs:{...(ve=b.parameters)==null?void 0:ve.docs,source:{originalSource:`{
  decorators: [Story => <div data-theme="dark" style={{
    height: '100%'
  }}><Story /></div>],
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
  }
}`,...(he=(ye=b.parameters)==null?void 0:ye.docs)==null?void 0:he.source},description:{story:"Тёмная тема сохраняет контраст пользовательской кнопки в видимом состоянии.",...(xe=(we=b.parameters)==null?void 0:we.docs)==null?void 0:xe.description}}};var Ee,Me,ke,Te,fe;v.parameters={...v.parameters,docs:{...(Ee=v.parameters)==null?void 0:Ee.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать ответ'
    });
    const bubble = button.closest('.ai .bub');
    if (!bubble) throw new Error('Model message bubble not found');
    await userEvent.hover(bubble);
    button.focus();
    await expect(button).toHaveFocus();
  }
}`,...(ke=(Me=v.parameters)==null?void 0:Me.docs)==null?void 0:ke.source},description:{story:"Ответ модели сохраняет прежнее раскрытие при наведении и фокусе.",...(fe=(Te=v.parameters)==null?void 0:Te.docs)==null?void 0:fe.description}}};var Se,Be,Ie,Ce,Ae;y.parameters={...y.parameters,docs:{...(Se=y.parameters)==null?void 0:Se.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    await userEvent.click(button);
    await expect(button).toHaveClass('copymsg--copied');
  }
}`,...(Ie=(Be=y.parameters)==null?void 0:Be.docs)==null?void 0:Ie.source},description:{story:"Успешное копирование вопроса: видимое подтверждение закреплено для visual-check.",...(Ae=(Ce=y.parameters)==null?void 0:Ce.docs)==null?void 0:Ae.description}}};var Le,Re,Ue,He,De;h.parameters={...h.parameters,docs:{...(Le=h.parameters)==null?void 0:Le.docs,source:{originalSource:`{
  args: {
    messages: [],
    onExport: undefined
  }
}`,...(Ue=(Re=h.parameters)==null?void 0:Re.docs)==null?void 0:Ue.source},description:{story:"Пустая беседа: подсказка объясняет следующий шаг, а не констатирует пустоту.",...(De=(He=h.parameters)==null?void 0:He.docs)==null?void 0:De.description}}};var Ve,_e,Ne,We,je;w.parameters={...w.parameters,docs:{...(Ve=w.parameters)==null?void 0:Ve.docs,source:{originalSource:`{
  args: {
    messages: [],
    loadingMessages: true
  }
}`,...(Ne=(_e=w.parameters)==null?void 0:_e.docs)==null?void 0:Ne.source},description:{story:"Первая загрузка истории: скелетон реплик той же геометрии, что у сообщений.",...(je=(We=w.parameters)==null?void 0:We.docs)==null?void 0:je.description}}};var Fe,Oe,Qe,Ke,qe;x.parameters={...x.parameters,docs:{...(Fe=x.parameters)==null?void 0:Fe.docs,source:{originalSource:`{
  args: {
    loadingMessages: true
  }
}`,...(Qe=(Oe=x.parameters)==null?void 0:Oe.docs)==null?void 0:Qe.source},description:{story:"Повторная загрузка: лента остаётся на месте, сверху — индикатор обновления.",...(qe=(Ke=x.parameters)==null?void 0:Ke.docs)==null?void 0:qe.description}}};var Pe,Ge,Ye,Xe,ze;E.parameters={...E.parameters,docs:{...(Pe=E.parameters)==null?void 0:Pe.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    streamingReply: STREAMING_TEXT,
    liveActivity: ACTIVITY_LIVE,
    liveUsage: makeUsage(),
    voiceBar: bar('thinking')
  }
}`,...(Ye=(Ge=E.parameters)==null?void 0:Ge.docs)==null?void 0:Ye.source},description:{story:`Стриминг ответа: токены идут, действия чередуются с текстом, внизу пузыря
дубль статуса — при длинном ответе верхняя строка уезжает из вида.`,...(ze=(Xe=E.parameters)==null?void 0:Xe.docs)==null?void 0:ze.description}}};var Je,Ze,$e,es,ss;M.parameters={...M.parameters,docs:{...(Je=M.parameters)==null?void 0:Je.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    liveActivity: ACTIVITY_LIVE,
    liveUsage: makeUsage(),
    voiceBar: bar('thinking')
  }
}`,...($e=(Ze=M.parameters)==null?void 0:Ze.docs)==null?void 0:$e.source},description:{story:"Запрос ушёл, токенов ещё нет: блок «обрабатывает запрос» с живой активностью.",...(ss=(es=M.parameters)==null?void 0:es.docs)==null?void 0:ss.description}}};var ts,as,ns,rs,os;k.parameters={...k.parameters,docs:{...(ts=k.parameters)==null?void 0:ts.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    liveSegments: makeLiveSegments(),
    voiceBar: bar('listening')
  }
}`,...(ns=(as=k.parameters)==null?void 0:as.docs)==null?void 0:ns.source},description:{story:"Запись голоса: живой транскрипт по говорящим над композером.",...(os=(rs=k.parameters)==null?void 0:rs.docs)==null?void 0:os.description}}};var is,cs,ms,ps,ls;T.parameters={...T.parameters,docs:{...(is=T.parameters)==null?void 0:is.docs,source:{originalSource:`{
  args: {
    error: 'Микрофон недоступен: браузер не дал доступ к устройству записи',
    onDismissError: fn()
  }
}`,...(ms=(cs=T.parameters)==null?void 0:cs.docs)==null?void 0:ms.source},description:{story:"Ошибка движка баннером над лентой (закрывается крестиком).",...(ls=(ps=T.parameters)==null?void 0:ps.docs)==null?void 0:ls.description}}};var ds,us,gs,bs,vs;f.parameters={...f.parameters,docs:{...(ds=f.parameters)==null?void 0:ds.docs,source:{originalSource:`{
  args: {
    modelMissing: true,
    modelLabel: 'large-v3-turbo',
    onDownloadModel: fn()
  }
}`,...(gs=(us=f.parameters)==null?void 0:us.docs)==null?void 0:gs.source},description:{story:"Модель распознавания не скачана — баннер первого запуска с кнопкой.",...(vs=(bs=f.parameters)==null?void 0:bs.docs)==null?void 0:vs.description}}};var ys,hs,ws,xs,Es;S.parameters={...S.parameters,docs:{...(ys=S.parameters)==null?void 0:ys.docs,source:{originalSource:`{
  args: {
    modelMissing: true,
    modelLabel: 'large-v3-turbo',
    downloading: true,
    downloadPercent: 42
  }
}`,...(ws=(hs=S.parameters)==null?void 0:hs.docs)==null?void 0:ws.source},description:{story:"Скачивание модели идёт: вместо кнопки — процент.",...(Es=(xs=S.parameters)==null?void 0:xs.docs)==null?void 0:Es.description}}};var Ms,ks,Ts,fs,Ss;B.parameters={...B.parameters,docs:{...(Ms=B.parameters)==null?void 0:Ms.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Сделай CI-шаг для витрины'
    }), makeQuestionsMessage()],
    onAnswerQuestions: fn()
  }
}`,...(Ts=(ks=B.parameters)==null?void 0:ks.docs)==null?void 0:Ts.source},description:{story:"Уточняющие вопросы модели: форма ответов под последним сообщением.",...(Ss=(fs=B.parameters)==null?void 0:fs.docs)==null?void 0:Ss.description}}};var Bs,Is,Cs,As,Ls;I.parameters={...I.parameters,docs:{...(Bs=I.parameters)==null?void 0:Bs.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'старт'
    }), makeQuestionsMessage({
      id: 'a-ci',
      meta: {
        ciInteraction: {
          runId: 'run-1',
          interactionId: 'it-1'
        }
      }
    }), makeUserMessage({
      id: 'u-after',
      text: 'а пока посмотрю лог'
    })],
    onAnswerCiInteraction: fn()
  }
}`,...(Cs=(Is=I.parameters)==null?void 0:Is.docs)==null?void 0:Cs.source},description:{story:"Вопрос CI-рана, продублированный в чат: ответ уйдёт в ран, а не новым ходом.",...(Ls=(As=I.parameters)==null?void 0:As.docs)==null?void 0:Ls.description}}};var Rs,Us,Hs,Ds,Vs;C.parameters={...C.parameters,docs:{...(Rs=C.parameters)==null?void 0:Rs.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Построй график и открой консоль'
    }), makeImageMessage(), makeToolMessage('console')],
    machineOps: makeMachineOps(),
    // Машина нужна самой карточке: её шапка называет, где выполняются команды.
    agents: [makeAgent({
      id: 'm1',
      name: 'MacBook'
    })],
    onSwitchUtility: fn(),
    onOpenMachines: fn(),
    onOpenImageInExplorer: fn()
  }
}`,...(Hs=(Us=C.parameters)==null?void 0:Us.docs)==null?void 0:Hs.source},description:{story:"Ответ с картинкой и встроенной консолью машины (оба блока вырезаны из текста).",...(Vs=(Ds=C.parameters)==null?void 0:Ds.docs)==null?void 0:Vs.description}}};var _s,Ns,Ws,js,Fs;A.parameters={...A.parameters,docs:{...(_s=A.parameters)==null?void 0:_s.docs,source:{originalSource:`{
  args: {
    permissionMode: 'plan',
    messages: [makeUserMessage({
      text: 'Составь план'
    }), makeAiMessage({
      id: 'a-plan',
      text: MD_KITCHEN_SINK,
      meta: makeTurnMeta({
        request: {
          ...makeTurnMeta().request!,
          permissionMode: 'plan'
        }
      })
    })],
    onExecutePlan: fn(),
    voiceBar: bar()
  }
}`,...(Ws=(Ns=A.parameters)==null?void 0:Ns.docs)==null?void 0:Ws.source},description:{story:"Плановый ответ: под ним предложение выполнить тот же запрос в разработке.",...(Fs=(js=A.parameters)==null?void 0:js.docs)==null?void 0:Fs.description}}};var Os,Qs,Ks,qs,Ps;L.parameters={...L.parameters,docs:{...(Os=L.parameters)==null?void 0:Os.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Опиши архитектуру'
    }), makeAiMessage({
      id: 'a-int',
      text: 'Начал описывать, но не успел закон',
      meta: makeTurnMeta({
        interrupted: true
      })
    })]
  }
}`,...(Ks=(Qs=L.parameters)==null?void 0:Qs.docs)==null?void 0:Ks.source},description:{story:"Ход прерван перезапуском сервера: сохранена набранная часть, есть пометка.",...(Ps=(qs=L.parameters)==null?void 0:qs.docs)==null?void 0:Ps.description}}};var Gs,Ys,Xs,zs,Js;R.parameters={...R.parameters,docs:{...(Gs=R.parameters)==null?void 0:Gs.docs,source:{originalSource:`{
  args: {
    messages: makeLongThread()
  }
}`,...(Xs=(Ys=R.parameters)==null?void 0:Ys.docs)==null?void 0:Xs.source},description:{story:"Длинная переписка: 24 сообщения — скролл и автоскролл вниз.",...(Js=(zs=R.parameters)==null?void 0:zs.docs)==null?void 0:Js.description}}};var Zs,$s,et,st,tt;U.parameters={...U.parameters,docs:{...(Zs=U.parameters)==null?void 0:Zs.docs,source:{originalSource:`{
  args: {
    onToggleSidebar: fn(),
    messages: [makeUserMessage({
      id: 'u-mobile-copy',
      text: 'Проверь перенос длинной ссылки: https://example.test/very/long/unbroken/path/that/must/not/escape/the/message/bubble?query=mobile-copy-button'
    }), makeAiMessage({
      id: 'a-mobile-copy',
      text: 'Кнопка остаётся внутри пузыря, а текст переносится.'
    })]
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile2'
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
  }
}`,...(et=($s=U.parameters)==null?void 0:$s.docs)==null?void 0:et.source},description:{story:"Телефон: сайдбар выдвижной, поэтому в шапке появляется ☰.",...(tt=(st=U.parameters)==null?void 0:st.docs)==null?void 0:tt.description}}};var at,nt,rt,ot,it;H.parameters={...H.parameters,docs:{...(at=H.parameters)==null?void 0:at.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByLabelText('Изменить сообщение'));
    const area = canvas.getByLabelText('Редактирование сообщения');
    await userEvent.clear(area);
    await userEvent.type(area, 'Почему упал шаг npm test и как это починить?');
    await expect(area).toHaveValue('Почему упал шаг npm test и как это починить?');
    await expect(canvas.getByRole('button', {
      name: 'Отправить'
    })).toBeEnabled();
  }
}`,...(rt=(nt=H.parameters)==null?void 0:nt.docs)==null?void 0:rt.source},description:{story:`Правка своей реплики: ✏️ открывает поле на месте пузыря (2–4 строки),
«Отправить» перезапускает ход с новым текстом.`,...(it=(ot=H.parameters)==null?void 0:ot.docs)==null?void 0:it.description}}};var ct,mt,pt,lt,dt;D.parameters={...D.parameters,docs:{...(ct=D.parameters)==null?void 0:ct.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByLabelText('Переключить вид действий');
    await userEvent.click(button);
    // Секций действий в ответе две (по обе стороны абзацев) — обе сворачиваются
    // в свою строку-сводку, поэтому здесь \`getAllBy\`, а не \`getBy\`.
    await expect(canvas.getAllByTestId('activity-brief')).toHaveLength(2);
    await userEvent.click(button);
    await expect(canvas.getAllByTestId('activity-section').length).toBeGreaterThan(1);
  }
}`,...(pt=(mt=D.parameters)==null?void 0:mt.docs)==null?void 0:pt.source},description:{story:"Переключение вида действий у ответа: минимально → кратко → подробно.",...(dt=(lt=D.parameters)==null?void 0:lt.docs)==null?void 0:dt.description}}};const Ia=["NewMessages","SearchAndCompact","FailedSubmission","MobileComposer390","Conversation","UserMessageHovered","UserMessageFocused","UserMessageHoveredDark","ModelMessageHovered","UserMessageCopied","EmptyConversation","LoadingMessages","RefreshingMessages","Streaming","Thinking","Listening","WithError","ModelMissing","ModelDownloading","WithQuestions","WithCiQuestion","WithMachineWidgets","PlanReady","InterruptedAnswer","LongThread","MobileViewport","EditingMessage","ActivityModeSwitch"];export{D as ActivityModeSwitch,d as Conversation,H as EditingMessage,h as EmptyConversation,W as FailedSubmission,L as InterruptedAnswer,k as Listening,w as LoadingMessages,R as LongThread,j as MobileComposer390,U as MobileViewport,S as ModelDownloading,v as ModelMessageHovered,f as ModelMissing,_ as NewMessages,A as PlanReady,x as RefreshingMessages,N as SearchAndCompact,E as Streaming,M as Thinking,y as UserMessageCopied,g as UserMessageFocused,u as UserMessageHovered,b as UserMessageHoveredDark,I as WithCiQuestion,T as WithError,C as WithMachineWidgets,B as WithQuestions,Ia as __namedExportsOrder,Ba as default};
