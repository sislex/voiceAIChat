import type { ComponentRuntime } from '@sislexa/component-runtime'
import { BillingError } from './store.js'
import type { BillingAuthority } from './server.js'

export function componentAuthority(runtime: ComponentRuntime): BillingAuthority {
  const identity = runtime.dependency('identity', { timeoutMs: 10_000 })
  return {
    environmentId: runtime.config.environmentId,
    async verifyComponent(authorization, scope) {
      const result = runtime.registry?.authorize(authorization, [scope])
      if (!result?.ok) throw new BillingError(result?.status ?? 401, 'component_access_denied')
      return { consumerId: result.principal.consumerId }
    },
    async verifyUser(authorization) {
      const response = await identity.fetchImpl(identity.url+'/v1/identity/verify', {
        method: 'POST', headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ request: { method: 'GET', url: '/api/me', headers: { authorization } } })
      })
      if (!response.ok) throw new BillingError(503, 'identity_unavailable')
      const verdict = await response.json() as { ok?: boolean; status?: number; user?: {
        role?: string; mustChangePassword?: boolean; account?: { userId?: string; tenantId?: string; capabilities?: unknown }
      } }
      if (verdict.ok !== true) throw new BillingError(verdict.status === 403 ? 403 : 401, 'user_access_denied')
      const user = verdict.user, account = user?.account
      if (user?.mustChangePassword) throw new BillingError(403, 'password_change_required')
      if (typeof account?.userId !== 'string' || !account.userId || typeof account.tenantId !== 'string' || !account.tenantId ||
        typeof user?.role !== 'string' || !Array.isArray(account.capabilities) || !account.capabilities.every(c => typeof c === 'string')) {
        throw new BillingError(503, 'stable_identity_required')
      }
      return { userId: account.userId, tenantId: account.tenantId, role: user.role, capabilities: account.capabilities as string[] }
    }
  }
}
