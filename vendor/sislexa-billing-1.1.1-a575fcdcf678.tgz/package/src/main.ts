import { mkdirSync } from 'node:fs'
import { resolve } from 'node:path'
import { createComponentRuntime } from '@sislexa/component-runtime'
import { applicationRuntimeMetadata } from '@voicechat/shared'
import { BillingStore } from './store.js'
import { buildBillingServer } from './server.js'
import { componentAuthority } from './authority.js'

process.umask(0o077)
const configFile = process.env.SISLEXA_COMPONENT_CONFIG
if (!configFile) throw Error('SISLEXA_COMPONENT_CONFIG is required')
const directory = resolve(process.env.BILLING_DATA_DIR ?? './data')
mkdirSync(directory, { recursive: true, mode: 0o700 })
const runtime = await createComponentRuntime({ configFile, contractFile: new URL('../component-contract.json', import.meta.url).pathname,
  metadata: applicationRuntimeMetadata('billing', process.env) })
const store = new BillingStore(resolve(directory, 'billing.sqlite'))
const app = buildBillingServer(store, componentAuthority(runtime))
runtime.register(app)
app.addHook('onClose', async () => store.close())
const port = Number(process.env.PORT ?? 8800)
if (!Number.isInteger(port) || port < 1 || port > 65535) throw Error('Invalid port')
try { await app.listen({ host: process.env.HOST ?? '127.0.0.1', port }) }
catch (error) { await app.close(); throw error }
for (const signal of ['SIGTERM', 'SIGINT'] as const) process.once(signal, () => { void app.close().then(() => { process.exitCode = 0 }) })
