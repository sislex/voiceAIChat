import { afterEach, expect, it } from 'vitest'
import Fastify from 'fastify'
import { mkdtempSync, writeFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { spawn } from 'node:child_process'
import { createServer } from 'node:net'
import { createComponentRuntime } from '@sislexa/component-runtime'
import { componentAuthority } from './authority.js'
import { buildBillingServer } from './server.js'
import { BillingStore } from './store.js'

const cleanup: Array<() => void | Promise<void>> = []
afterEach(async () => { for (const fn of cleanup.splice(0).reverse()) await fn() })

it('uses provider-issued grants and live Identity verdicts across real HTTP boundaries', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'billing-authority-'))
  cleanup.push(() => rmSync(dir, { recursive: true, force: true }))
  const write = (name: string, value: unknown) => { const path = join(dir, name); writeFileSync(path, JSON.stringify(value), { mode: 0o600 }); return path }
  const metadata = (applicationId: string, version: string) => ({ applicationId, version, apiVersion: '1.1.0', dataVersion: '1.0.0', commit: 'a'.repeat(40) })
  const identity = await createComponentRuntime({
    contractFile: write('identity-contract.json', { schemaVersion: 1, applicationId: 'identity', provides: ['identity.verify'], legacyScopes: [], dependencies: [] }),
    configFile: write('identity-config.json', { schemaVersion: 1, environmentId: 'test', legacyScopes: [], registryDirectory: join(dir, 'identity-provider'), grants: [{ consumerId: 'billing', scopes: ['identity.verify'], maxTtlSeconds: 3600 }], dependencies: [] }),
    metadata: metadata('identity', '1.2.0')
  })
  const identityApp = Fastify(); identity.register(identityApp)
  let revoked = false, stableIdentity = true
  identityApp.post<{ Body: { request: { headers: { authorization: string } } } }>('/v1/identity/verify', async (req, reply) => {
    const grant = identity.registry!.authorize(req.headers.authorization, ['identity.verify'])
    if (!grant.ok) return reply.code(grant.status).send({ error: 'denied' })
    if (revoked || req.body.request.headers.authorization !== 'Bearer fixture-user') return { ok: false, status: 401 }
    return { ok: true, user: { name: 'login', role: 'developer', account: { ...(stableIdentity ? { userId: 'subject' } : {}), tenantId: 'tenant', capabilities: ['chat.use'] } } }
  })
  await identityApp.listen({ host: '127.0.0.1', port: 0 }); cleanup.push(() => identityApp.close())
  const identityToken = identity.registry!.issue('billing', ['identity.verify'], 3600)
  const tokenFile = join(dir, 'identity.token'); writeFileSync(tokenFile, identityToken.token, { mode: 0o600 })
  const identityUrl = 'http://127.0.0.1:'+(identityApp.server.address() as { port: number }).port
  const runtime = await createComponentRuntime({
    contractFile: new URL('../component-contract.json', import.meta.url).pathname,
    configFile: write('billing-config.json', { schemaVersion: 1, environmentId: 'test', legacyScopes: [], registryDirectory: join(dir, 'billing-provider'), grants: [{ consumerId: 'core', scopes: ['billing.reserve', 'billing.execute'], maxTtlSeconds: 3600 }], dependencies: [{ applicationId: 'identity', url: identityUrl, tokenFile }] }),
    metadata: metadata('billing', '1.0.0')
  })
  const store = new BillingStore(':memory:'); cleanup.push(() => store.close())
  const app = buildBillingServer(store, componentAuthority(runtime)); runtime.register(app); cleanup.push(() => app.close())
  const grant = runtime.registry!.issue('core', ['billing.reserve', 'billing.execute'], 3600)
  const headers = { authorization: 'Bearer '+grant.token, 'x-sislexa-user-authorization': 'Bearer fixture-user' }
  const payload = { operationId: 'op', maxMicroUsd: 10, expiresAt: Date.now()+60_000, originModuleId: 'chat' }
  expect((await app.inject('/v1/ready')).json().ok).toBe(true)
  const admitted = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers, payload })
  expect(admitted.statusCode).toBe(201)
  expect(admitted.json()).toMatchObject({ userId: 'subject', tenantId: 'tenant', actorClientId: 'core' })
  expect((await app.inject({ url: '/api/billing/account', headers: { authorization: headers.authorization } })).statusCode).toBe(401)
  stableIdentity = false
  expect((await app.inject({ url: '/api/billing/account', headers: { authorization: 'Bearer fixture-user' } })).statusCode).toBe(503)
  stableIdentity = true; revoked = true
  expect((await app.inject({ method: 'POST', url: '/v1/billing/reservations/'+admitted.json().id+'/start', headers, payload: {} })).statusCode).toBe(401)
  revoked = false; runtime.registry!.revoke(grant.principal.tokenId)
  expect((await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers, payload })).statusCode).toBe(401)
  const probe = createServer(); await new Promise<void>(resolve => probe.listen(0, '127.0.0.1', resolve))
  const port = (probe.address() as { port: number }).port
  await new Promise<void>((resolve, reject) => probe.close(error => error ? reject(error) : resolve()))
  const child = spawn(process.execPath, ['--import', 'tsx', 'dist/main.js'], {
    cwd: new URL('../', import.meta.url), stdio: ['ignore', 'ignore', 'pipe'],
    env: { ...process.env, HOST: '127.0.0.1', PORT: String(port), BILLING_DATA_DIR: join(dir, 'process-data'),
      SISLEXA_COMPONENT_CONFIG: join(dir, 'billing-config.json'), VC_APPLICATION_VERSION: '1.0.0',
      VC_APPLICATION_API_VERSION: '1.0.0', VC_APPLICATION_DATA_VERSION: '1.0.0', VC_APPLICATION_COMMIT: 'b'.repeat(40) }
  })
  let processErrors = ''
  child.stderr.on('data', chunk => { processErrors += String(chunk) })
  cleanup.push(async () => {
    if (child.exitCode !== null || child.signalCode !== null) return
    await new Promise<void>(resolve => { child.once('exit', () => resolve()); child.kill('SIGTERM') })
  })
  const deadline = Date.now() + 10_000
  let ready = false
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw Error('Standalone startup failed: '+processErrors)
    try { ready = (await fetch('http://127.0.0.1:'+port+'/v1/ready')).ok; if (ready) break } catch {}
    await new Promise(resolve => setTimeout(resolve, 50))
  }
  expect(ready, processErrors).toBe(true)
  const metadataResponse = await fetch('http://127.0.0.1:'+port+'/v1/component')
  expect((await metadataResponse.json() as { application: { commit: string } }).application.commit).toBe('b'.repeat(40))
  const processAccount = await fetch('http://127.0.0.1:'+port+'/api/billing/account', { headers: { authorization: 'Bearer fixture-user' } })
  expect(processAccount.ok).toBe(true)
  expect((await processAccount.json() as { tenantId: string }).tenantId).toBe('tenant')
  identity.registry!.revoke(identityToken.principal.tokenId)
  expect((await app.inject({ url: '/api/billing/account', headers: { authorization: 'Bearer fixture-user' } })).statusCode).toBe(503)
}, 15_000)
