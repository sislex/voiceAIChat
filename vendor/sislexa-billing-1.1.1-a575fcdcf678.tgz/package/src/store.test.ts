import { afterEach, expect, it } from 'vitest'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Worker } from 'node:worker_threads'
import { BillingStore } from './store.js'
import type { BillingPrincipal, BillingUsageEvidence } from '@sislexa/sdk'

const principal: BillingPrincipal = { userId: 'subject-a', tenantId: 'tenant-a', environmentId: 'test', actorClientId: 'core', originModuleId: 'chat' }
const baseTime = Date.UTC(2026, 8, 20)
const cleanup: Array<() => void> = []
afterEach(() => { for (const fn of cleanup.splice(0).reverse()) fn() })
function fixture() {
  const directory = mkdtempSync(join(tmpdir(), 'sislexa-ledger-'))
  cleanup.push(() => rmSync(directory, { recursive: true, force: true }))
  const filename = join(directory, 'billing.sqlite')
  let now = baseTime
  const store = new BillingStore(filename, () => now)
  cleanup.push(() => store.close())
  return { store, filename, setNow: (value: number) => { now = value } }
}
const input = (operationId = 'op', maxMicroUsd = 60) => ({ operationId, maxMicroUsd, expiresAt: baseTime + 60_000 })
const unbounded = (operationId = 'op') => ({ ...input(operationId, 0), executionBound: 'unbounded' as const })
const finitePolicy = { monthlyMicroUsd: 100, monthlyRequests: null, maxConcurrent: null }
const evidence = (): BillingUsageEvidence => ({ model: 'test-model', costSource: 'estimate',
  tokens: { inputTokens: 101, outputTokens: 3, cacheReadTokens: 99, cacheWriteTokens: 7 },
  prices: { inputTokens: 200_000, outputTokens: 1_200_000, cacheReadTokens: 20_000, cacheWriteTokens: 250_000 } })

it('rejects unbounded execution under every finite budget without consuming a request', () => {
  const { store } = fixture()
  for (const [revision, amount] of [0, 100].entries()) {
    store.setPolicy('test', 'tenant-a', { ...finitePolicy, monthlyMicroUsd: amount }, revision)
    expect(() => store.reserve(principal, unbounded())).toThrow('execution_cost_not_bounded')
    expect(store.balance('test', 'tenant-a').requests).toBe(0)
  }
  expect(() => store.reserve(principal, { ...unbounded(), maxMicroUsd: 1 })).toThrow('invalid_reservation')
})

it('applies request and concurrency limits to explicit unbounded execution', () => {
  const { store } = fixture()
  store.setPolicy('test', 'tenant-a', { monthlyMicroUsd: null, monthlyRequests: 2, maxConcurrent: 1 }, 0)
  const first = store.reserve(principal, unbounded())
  expect(() => store.reserve(principal, unbounded('second'))).toThrow('concurrency_limit_reached')
  store.transition(principal, first.id, 'release')
  const second = store.reserve(principal, unbounded('second'))
  store.transition(principal, second.id, 'start')
  store.settle(principal, second.id, 'actual', 28, evidence())
  expect(() => store.reserve(principal, unbounded('third'))).toThrow('request_limit_reached')
  expect(store.balance('test', 'tenant-a')).toMatchObject({ requests: 2, spentMicroUsd: 28, active: 0 })
})

it('serializes finite policy changes against unbounded admission and retains uncertain holds', () => {
  const { store, filename, setNow } = fixture()
  const second = new BillingStore(filename, () => baseTime)
  cleanup.push(() => second.close())
  const run = store.reserve(principal, unbounded())
  for (const state of ['reserved', 'running', 'uncertain'] as const) {
    if (state !== 'reserved') store.transition(principal, run.id, state === 'running' ? 'start' : 'uncertain')
    expect(() => second.setPolicy('test', 'tenant-a', finitePolicy, 0)).toThrow('unbounded_execution_active')
    expect(second.balance('test', 'tenant-a').policyRevision).toBe(0)
  }
  expect(second.setPolicy('other', 'tenant-a', finitePolicy, 0)).toBe(1)
  expect(second.setPolicy('test', 'other', finitePolicy, 0)).toBe(1)
  setNow(baseTime + 300_000)
  expect(() => store.setPolicy('test', 'tenant-a', finitePolicy, 0)).toThrow('unbounded_execution_active')
  store.settle(principal, run.id, 'settled', 28, evidence())
  expect(second.setPolicy('test', 'tenant-a', finitePolicy, 0)).toBe(1)
  expect(() => second.reserve(principal, unbounded('next'))).toThrow('execution_cost_not_bounded')
})

it('allows finite policies after an unstarted unbounded reservation expires', () => {
  const { store, setNow } = fixture()
  const run = store.reserve(principal, unbounded())
  setNow(baseTime + 60_000)
  expect(store.setPolicy('test', 'tenant-a', finitePolicy, 0)).toBe(1)
  expect(store.reservation(principal, run.id).state).toBe('released')
  expect(() => store.transition(principal, run.id, 'start')).toThrow('invalid_reservation_state')
})

it('persists immutable usage evidence and rejects changed settlement retries after restart', () => {
  const { store, filename } = fixture()
  const run = store.reserve(principal, input())
  store.transition(principal, run.id, 'start')
  const usage = evidence()
  store.settle(principal, run.id, 'actual', 28, usage)
  usage.tokens = { ...usage.tokens, inputTokens: 999 }
  const reopened = new BillingStore(filename, () => baseTime)
  cleanup.push(() => reopened.close())
  expect(reopened.reservation(principal, run.id).usage).toEqual(evidence())
  expect(reopened.settle(principal, run.id, 'actual', 28, evidence()).usage).toEqual(evidence())
  for (const changed of [undefined, { ...evidence(), model: 'other' },
    { ...evidence(), tokens: { ...evidence().tokens, inputTokens: 102 } },
    { ...evidence(), costSource: 'provider' as const, prices: undefined }]) {
    expect(() => reopened.settle(principal, run.id, 'actual', 28, changed)).toThrow('settlement_replay_conflict')
  }
  expect(reopened.balance('test', 'tenant-a')).toMatchObject({ spentMicroUsd: 28, active: 0 })
  expect(() => reopened.reservation({ ...principal, userId: 'foreign' }, run.id)).toThrow('reservation_not_found')
})

it('leaves work unsettled when estimated cost or evidence is invalid', () => {
  const { store } = fixture()
  const run = store.reserve(principal, input())
  store.transition(principal, run.id, 'start')
  expect(() => store.settle(principal, run.id, 'actual', 27, evidence())).toThrow('usage_price_mismatch')
  expect(() => store.settle(principal, run.id, 'actual', 0, { ...evidence(), prices: undefined })).toThrow('invalid_usage_evidence')
  expect(() => store.settle(principal, run.id, 'actual', 0, {
    ...evidence(), tokens: { ...evidence().tokens, inputTokens: Number.MAX_SAFE_INTEGER }
  })).toThrow('invalid_usage_evidence')
  expect(store.reservation(principal, run.id)).toMatchObject({ state: 'running', actualMicroUsd: null })
  expect(store.balance('test', 'tenant-a')).toMatchObject({ spentMicroUsd: 0, active: 1 })
  expect(store.settle(principal, run.id, 'actual', 28, evidence()).state).toBe('settled')
})

it('serializes two connections and reserves against the same remaining budget', () => {
  const { store, filename } = fixture(), second = new BillingStore(filename, () => baseTime)
  cleanup.push(() => second.close())
  store.setPolicy('test', 'tenant-a', { monthlyMicroUsd: 100, monthlyRequests: null, maxConcurrent: null }, 0)
  const r = store.reserve(principal, input())
  expect(() => second.reserve({ ...principal, originModuleId: 'make' }, input('other'))).toThrow('budget_exhausted')
  store.transition(principal, r.id, 'start'); store.settle(principal, r.id, 'event', 40)
  expect(second.balance('test', 'tenant-a')).toMatchObject({ spentMicroUsd: 40, reservedMicroUsd: 0, availableMicroUsd: 60 })
  expect(second.reserve(principal, input('other')).state).toBe('reserved')
})

it('deduplicates admission and settlement across process restarts and rejects changed retries', () => {
  const { store, filename } = fixture()
  const r = store.reserve(principal, input())
  expect(store.reserve(principal, input()).id).toBe(r.id)
  expect(store.balance('test', 'tenant-a').requests).toBe(1)
  expect(() => store.reserve(principal, input('op', 61))).toThrow('operation_replay_conflict')
  expect(() => store.reserve({ ...principal, userId: 'other' }, input())).toThrow('operation_replay_conflict')
  expect(store.transition(principal, r.id, 'start').transitioned).toBe(true)
  expect(store.transition(principal, r.id, 'start').transitioned).toBe(false)
  store.settle(principal, r.id, 'event', 10)
  const reopened = new BillingStore(filename, () => baseTime)
  cleanup.push(() => reopened.close())
  expect(reopened.settle(principal, r.id, 'event', 10).actualMicroUsd).toBe(10)
  expect(() => reopened.settle(principal, r.id, 'event', 11)).toThrow('settlement_replay_conflict')
  expect(() => reopened.settle(principal, r.id, 'new-event', 10)).toThrow('invalid_reservation_state')
  expect(reopened.balance('test', 'tenant-a').spentMicroUsd).toBe(10)
})

it('releases only unstarted expired reservations and retains uncertain execution holds', () => {
  const { store, setNow } = fixture()
  const unstarted = store.reserve(principal, input('unstarted'))
  const running = store.reserve(principal, input('running'))
  store.transition(principal, running.id, 'start')
  setNow(baseTime + 60_001)
  expect(store.balance('test', 'tenant-a')).toMatchObject({ reservedMicroUsd: 60, active: 1, requests: 2 })
  expect(store.reserve(principal, input('unstarted')).state).toBe('released')
  expect(() => store.transition(principal, unstarted.id, 'start')).toThrow('invalid_reservation_state')
  expect(() => store.transition(principal, running.id, 'release')).toThrow('invalid_reservation_state')
  store.transition(principal, running.id, 'uncertain')
  expect(() => store.transition(principal, running.id, 'start')).toThrow('invalid_reservation_state')
  expect(store.balance('test', 'tenant-a').reservedMicroUsd).toBe(60)
  store.settle(principal, running.id, 'partial-cancelled', 12)
  expect(store.balance('test', 'tenant-a')).toMatchObject({ spentMicroUsd: 12, active: 0, reservedMicroUsd: 0 })
})

it('isolates tenants, environments, subjects and executing clients', () => {
  const { store } = fixture(), r = store.reserve(principal, input())
  for (const extra of [{ tenantId: 'foreign' }, { environmentId: 'foreign' }, { userId: 'foreign' }, { actorClientId: 'foreign' }, { originModuleId: 'foreign' }]) {
    expect(() => store.transition({ ...principal, ...extra }, r.id, 'start')).toThrow('reservation_not_found')
  }
  expect(store.balance('production', 'tenant-a').reservedMicroUsd).toBe(0)
  expect(store.balance('test', 'other').reservedMicroUsd).toBe(0)
})

it('enforces concurrency and request counts independently and protects policy revisions', () => {
  const { store } = fixture()
  expect(store.setPolicy('test', 'tenant-a', { monthlyMicroUsd: null, monthlyRequests: 1, maxConcurrent: 1 }, 0)).toBe(1)
  expect(() => store.setPolicy('test', 'tenant-a', { monthlyMicroUsd: null, monthlyRequests: null, maxConcurrent: null }, 0)).toThrow('policy_revision_conflict')
  const r = store.reserve(principal, input())
  store.transition(principal, r.id, 'release')
  expect(() => store.reserve(principal, input('next'))).toThrow('request_limit_reached')
  store.setPolicy('test', 'tenant-a', { monthlyMicroUsd: null, monthlyRequests: null, maxConcurrent: 1 }, 1)
  store.reserve(principal, input('next'))
  expect(() => store.reserve(principal, input('third'))).toThrow('concurrency_limit_reached')
})

it('rolls monthly counters in UTC while keeping prior-period running work in concurrency limits', () => {
  const { store, setNow } = fixture()
  store.setPolicy('test', 'tenant-a', { monthlyMicroUsd: 100, monthlyRequests: 1, maxConcurrent: 1 }, 0)
  const r = store.reserve(principal, input()); store.transition(principal, r.id, 'start')
  setNow(Date.UTC(2026, 9, 1))
  expect(store.balance('test', 'tenant-a')).toMatchObject({ period: '2026-10', requests: 0, reservedMicroUsd: 0, active: 1 })
  expect(() => store.reserve(principal, { ...input('oct'), expiresAt: Date.UTC(2026, 9, 1) + 60_000 })).toThrow('concurrency_limit_reached')
  store.settle(principal, r.id, 'late-september', 20)
  expect(store.balance('test', 'tenant-a')).toMatchObject({ spentMicroUsd: 0, active: 0 })
})

it('records incurred overage rather than hiding a provider contract violation', () => {
  const { store } = fixture()
  store.setPolicy('test', 'tenant-a', { monthlyMicroUsd: 100, monthlyRequests: null, maxConcurrent: null }, 0)
  const r = store.reserve(principal, input()); store.transition(principal, r.id, 'start')
  store.settle(principal, r.id, 'overage', 110)
  expect(store.balance('test', 'tenant-a')).toMatchObject({ spentMicroUsd: 110, availableMicroUsd: 0 })
  expect(() => store.reserve(principal, input('next', 0))).toThrow('budget_exhausted')
})

it('prevents concurrent worker processes from over-reserving one budget', async () => {
  const { store, filename } = fixture()
  store.setPolicy('test', 'tenant-a', { monthlyMicroUsd: 100, monthlyRequests: null, maxConcurrent: null }, 0)
  const moduleUrl = new URL('../dist/store.js', import.meta.url).href
  const results = await Promise.all(Array.from({ length: 6 }, (_, i) => new Promise<string>((resolve, reject) => {
    const worker = new Worker(`const { parentPort, workerData } = require('node:worker_threads');
      import(workerData.moduleUrl).then(({BillingStore})=>{
        const store = new BillingStore(workerData.filename,()=>workerData.now);
        try { store.reserve(workerData.principal,workerData.input);parentPort.postMessage('ok') }
        catch(e) { parentPort.postMessage(e.message) } finally { store.close() }
      }).catch(e=>{throw e})`, { eval: true, workerData: { moduleUrl, filename, now: baseTime, principal, input: input('worker-'+i) } })
    let message = ''
    worker.on('message', value => { message = value })
    worker.once('error', reject)
    worker.once('exit', code => code === 0 ? resolve(message) : reject(Error('Worker failed')))
  })))
  expect(results.filter(value => value === 'ok')).toHaveLength(1)
  expect(results.filter(value => value === 'budget_exhausted')).toHaveLength(5)
  expect(store.balance('test', 'tenant-a').reservedMicroUsd).toBe(60)
})
