import { afterEach, expect, it } from 'vitest'
import { BillingError, BillingStore } from './store.js'
import { buildBillingServer, type VerifiedUser } from './server.js'

const close: Array<() => Promise<void>> = []
afterEach(async () => { for (const fn of close.splice(0)) await fn() })
function fixture() {
  const store = new BillingStore(':memory:')
  let revoked = false
  let account: VerifiedUser = { userId: 'subject', tenantId: 'tenant', role: 'developer', capabilities: ['chat.use', 'make.use'] }
  const app = buildBillingServer(store, {
    environmentId: 'test',
    async verifyUser(token) {
      if (token !== 'Bearer user' || revoked) throw new BillingError(401, 'user_session_required')
      return account
    },
    async verifyComponent(token, scope) {
      if (token === 'Bearer service') return { consumerId: 'core' }
      if (token === 'Bearer make') return { consumerId: 'make' }
      if (token === 'Bearer reserve-only' && scope === 'billing.reserve') return { consumerId: 'core' }
      throw new BillingError(403, 'component_access_denied')
    }
  })
  close.push(async () => { await app.close(); store.close() })
  return { app, store, revoke: () => { revoked = true }, setAccount: (value: VerifiedUser) => { account = value } }
}
const service = { authorization: 'Bearer service', 'x-sislexa-user-authorization': 'Bearer user' }
const reservation = () => ({ operationId: 'op', maxMicroUsd: 100, expiresAt: Date.now() + 60_000, originModuleId: 'chat' })

it('requires both user identity and component authority, rejecting forged billing identities', async () => {
  const { app } = fixture()
  for (const headers of [{}, { authorization: 'Bearer user' }, { authorization: 'Bearer service' }]) {
    const r = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers, payload: reservation() })
    expect([401, 403]).toContain(r.statusCode)
  }
  const forged = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: service, payload: { ...reservation(), tenantId: 'foreign' } })
  expect(forged.statusCode).toBe(400)
  for (const extra of [{ operationId: 'bad\n' }, { maxMicroUsd: '10' }, { maxMicroUsd: 0.1 }]) {
    expect((await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: service, payload: { ...reservation(), ...extra } })).statusCode).toBe(400)
  }
  const wrongOrigin = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: { ...service, authorization: 'Bearer make' }, payload: reservation() })
  expect(wrongOrigin.statusCode).toBe(403)
  const admitted = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: service, payload: reservation() })
  expect(admitted.statusCode).toBe(201)
  expect(admitted.json()).toMatchObject({ userId: 'subject', tenantId: 'tenant', actorClientId: 'core', originModuleId: 'chat' })
})

it('checks current capabilities again at start and allows settlement of incurred work after logout', async () => {
  const { app, revoke, setAccount } = fixture()
  const r = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: service, payload: reservation() })
  const path = '/v1/billing/reservations/'+r.json().id
  setAccount({ userId: 'subject', tenantId: 'tenant', role: 'developer', capabilities: [] })
  expect((await app.inject({ method: 'POST', url: path+'/start', headers: service, payload: {} })).statusCode).toBe(403)
  setAccount({ userId: 'subject', tenantId: 'tenant', role: 'developer', capabilities: ['chat.use'] })
  expect((await app.inject({ method: 'POST', url: path+'/start', headers: service, payload: {} })).statusCode).toBe(200)
  revoke()
  expect((await app.inject({ method: 'POST', url: path+'/start', headers: service, payload: {} })).statusCode).toBe(401)
  const settled = await app.inject({ method: 'POST', url: path+'/settle', headers: { authorization: 'Bearer service' }, payload: { eventId: 'actual', actualMicroUsd: 40 } })
  expect(settled.statusCode).toBe(200)
  expect(settled.json().actualMicroUsd).toBe(40)
})

it('rejects settlement by another component or a grant without executor scope', async () => {
  const { app } = fixture()
  const r = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: service, payload: reservation() })
  const url = '/v1/billing/reservations/'+r.json().id+'/settle'
  for (const [token, expected] of [['make', 404], ['reserve-only', 403], ['user', 403]] as const) {
    expect((await app.inject({ method: 'POST', url, headers: { authorization: 'Bearer '+token }, payload: { eventId: 'attempt', actualMicroUsd: 0 } })).statusCode).toBe(expected)
    expect((await app.inject({ url: url.replace('/settle', ''), headers: { authorization: 'Bearer '+token } })).statusCode).toBe(expected)
  }
})

it('exposes durable usage only to the owning executor, including after user logout', async () => {
  const { app, revoke } = fixture()
  const admitted = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: service,
    payload: { ...reservation(), maxMicroUsd: 0, executionBound: 'unbounded' } })
  expect(admitted.statusCode).toBe(201)
  const path = '/v1/billing/reservations/'+admitted.json().id
  expect((await app.inject({ method: 'POST', url: path+'/start', headers: service, payload: {} })).statusCode).toBe(200)
  const usage = { model: 'test-model', costSource: 'provider',
    tokens: { inputTokens: 1, outputTokens: 2, cacheReadTokens: 0, cacheWriteTokens: 0 } }
  revoke()
  const settled = await app.inject({ method: 'POST', url: path+'/settle', headers: { authorization: 'Bearer service' },
    payload: { eventId: 'actual', actualMicroUsd: 5, usage } })
  expect(settled.statusCode).toBe(200)
  const result = await app.inject({ url: path, headers: { authorization: 'Bearer service' } })
  expect(result.statusCode).toBe(200)
  expect(result.json()).toMatchObject({ usage, actualMicroUsd: 5, executionBound: 'unbounded', state: 'settled' })
  expect(result.headers['cache-control']).toBe('no-store')
})

it('rejects unbounded admission against finite policy and invalid usage at the HTTP boundary', async () => {
  const { app, store } = fixture()
  store.setPolicy('test', 'tenant', { monthlyMicroUsd: 10, monthlyRequests: null, maxConcurrent: null }, 0)
  const denied = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: service,
    payload: { ...reservation(), maxMicroUsd: 0, executionBound: 'unbounded' } })
  expect(denied.statusCode).toBe(402)
  expect(denied.json().error).toBe('execution_cost_not_bounded')
  const admitted = await app.inject({ method: 'POST', url: '/v1/billing/reservations', headers: service,
    payload: { ...reservation(), maxMicroUsd: 10 } })
  const path = '/v1/billing/reservations/'+admitted.json().id
  await app.inject({ method: 'POST', url: path+'/start', headers: service, payload: {} })
  for (const usage of [
    { model: 'test', costSource: 'estimate', tokens: { inputTokens: 1, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 } },
    { model: 'test', costSource: 'provider', tokens: { inputTokens: '1', outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 } },
    { model: 'test', costSource: 'provider', tokens: { inputTokens: 1, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }, tenantId: 'other' }
  ]) {
    expect((await app.inject({ method: 'POST', url: path+'/settle', headers: { authorization: 'Bearer service' },
      payload: { eventId: 'actual', actualMicroUsd: 0, usage } })).statusCode).toBe(400)
  }
  expect((await app.inject({ url: path, headers: { authorization: 'Bearer service' } })).json().state).toBe('running')
})

it('keeps policy administration separate from user access and never accepts cookie-only writes', async () => {
  const { app, setAccount } = fixture()
  const payload = { policy: { monthlyMicroUsd: 1000, monthlyRequests: 10, maxConcurrent: 2 }, expectedRevision: 0 }
  expect((await app.inject({ method: 'PUT', url: '/api/billing/policy', headers: { authorization: 'Bearer user' }, payload })).statusCode).toBe(403)
  setAccount({ userId: 'subject', tenantId: 'tenant', role: 'admin', capabilities: [] })
  expect((await app.inject({ method: 'PUT', url: '/api/billing/policy', headers: { cookie: 'vc_session=user' }, payload })).statusCode).toBe(401)
  expect((await app.inject({ method: 'PUT', url: '/api/billing/policy', headers: { authorization: 'Bearer user' }, payload })).statusCode).toBe(200)
  expect((await app.inject({ method: 'PUT', url: '/api/billing/policy', headers: { authorization: 'Bearer user' }, payload })).statusCode).toBe(409)
  const account = await app.inject({ url: '/api/billing/account', headers: { authorization: 'Bearer user' } })
  expect(account.statusCode).toBe(200); expect(account.json().availableMicroUsd).toBe(1000)
  expect(account.headers['cache-control']).toBe('no-store')
  expect((await app.inject({ url: '/api/billing/account', headers: { authorization: 'Bearer user', 'x-sislexa-tenant-id': 'foreign' } })).statusCode).toBe(403)
  expect((await app.inject({ url: '/api/billing/account', headers: { authorization: 'Bearer service' } })).statusCode).toBe(401)
})
