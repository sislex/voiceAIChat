# Sislexa Billing

Independent budget reservations and settlement service. It owns a durable SQLite
ledger; Identity supplies live users and tenant IDs, and provider-issued grants
authorize calling applications. Analytics is not a spending authority.

## Development and operation

Use Node >=22.13, `npm ci`, `npm run gate` and `npm start`. Configure
`SISLEXA_COMPONENT_CONFIG` from `config.example.json`, `BILLING_DATA_DIR`, `HOST`
and `PORT` (default loopback 8800). Runtime metadata uses the common
`VC_APPLICATION_VERSION`, `VC_APPLICATION_API_VERSION`, `VC_APPLICATION_COMMIT`
and `VC_APPLICATION_DATA_VERSION` variables. Secrets must be private files and
never committed. Identity must provide stable subjects (version >=1.2.0).

`/v1/component`, `/v1/ready` and `/v1/component/authorize` implement managed
component discovery and grants. Consumers need `billing.reserve` and/or
`billing.execute`. Reserve/start requests carry the caller's component bearer
and the user's bearer in `x-sislexa-user-authorization`; both are validated.
The service derives the user, tenant, environment and actor. Only Core can
attribute different supported origin modules; other callers use their own ID.

`GET /api/billing/account` requires the user's bearer and reports that tenant.
`PUT /api/billing/policy` requires a live system administrator and changes that
administrator's own tenant policy using `expectedRevision`. Cookie-only requests
are rejected. Cross-tenant administration and account UI are a later integration.

## Accounting semantics

Amounts are integer micro-USD, not floating-point dollar values. Null limits are
unlimited; zero is explicit. Monthly limits use UTC and admission-time attribution.
An admitted request counts even when cancelled. Active reservations from previous
months retain their concurrency slot; settlement belongs to their original month.
No money is credited or collected by this service version.

Admission, limits and idempotency use BEGIN IMMEDIATE transactions. Parallel
connections/workers contend on the same database. Reusing an operation ID with
changed identity or input is rejected. Persist operation IDs and expiry inputs
before retrying. A reservation may start once, expire before starting, become
uncertain, or settle once with an immutable event ID. Retry responses are stable. A start response has `transitioned: true` only for
the winning claim; a replay returns false and must not execute another provider
call. A lost claim response requires reconciliation, not blind execution retry.
An uncertain/running operation never releases money merely because its TTL passed.
The owning executor can settle incurred work after the user's session is revoked;
new admission and start still require current user authority and capabilities.

Executors must enforce the reserved bound. This service does not turn an unbounded
CLI invocation into a prepaid-safe provider call. Actual overage is recorded rather
than hidden, reducing later availability; provider contract violations require
reconciliation. Runtime integration must reject unsupported bounded execution when
a finite budget is enforced. No end-to-end Core budget enforcement is claimed yet.

Version 1.1 accepts `executionBound: "unbounded"` only with `maxMicroUsd: 0` and
an unlimited monetary policy. Request and concurrency limits still apply. A
finite monetary policy cannot replace an unlimited policy while an unbounded
reservation is reserved, running or uncertain; settle or reconcile it first.
The admission and policy-update checks share the same database transaction lock.

Settlement may carry `usage` with model, complete disjoint token counters and
`costSource: "provider" | "estimate"`. Estimates require an immutable complete
price snapshot in integer micro-USD per million tokens. The ledger independently
recomputes the estimate and rejects mismatches. Every usage field participates in
settlement idempotency; changing counters or prices on retry cannot silently
replace evidence. `GET /v1/billing/reservations/:id` requires `billing.execute`
from the owning component and returns durable status/evidence even after user
logout. It cannot admit or start new work with a revoked user session.

Usage evidence is stored in an additive table, preserving legacy settlement
rows and their replay fingerprints. Version 1.0 cannot enforce the unbounded
marker: rollback requires pausing new admissions and reconciling all unbounded
work before restoring older code. Do not run both service versions concurrently.

Deploy one durable database, not replicas with independent files. Keep its WAL
with the database and use SQLite's consistent online backup API. Current tests
cover concurrent workers, isolation, restart/replay, period rollover, revoked
sessions/grants, capability changes, policy conflicts and actual HTTP Identity
boundaries. Production rollout requires immutable source/dependency pins and
operator backup/restore evidence.
