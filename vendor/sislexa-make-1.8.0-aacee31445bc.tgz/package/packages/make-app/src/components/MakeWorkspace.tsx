import { useMemo, useState, useSyncExternalStore } from 'react'
import { createMakeProjectClient } from '../lib/makeProjectAdapter'
import { SharedChat, ChatSettings, type SharedChatProps, type ChatSettingField } from '@sislexa/chat-ui'
import type { MakeChatRuntime } from '../lib/makeChatAdapter'
import type { MakePaneProps } from '../panelContract'
import { MakePane } from './MakePane'
import { mt, useMakeLocale, describeMakeError } from '../i18n'
import type { createMakeChatTools } from '../lib/makeChatTools'

export interface MakeWorkspaceProps extends Omit<MakePaneProps, 'onInsertToChat' | 'onAskAssistant' | 'onAttachImage' | 'onEditorContext' | 'turnActive' | 'lastRequest' | 'askOnly' | 'onAskOnlyChange'> {
  chat: MakeChatRuntime
  /** Session identity supplied by the host; project membership is not a system role. */
  sessionUser?: { role?: string } | null
  settings: SharedChatProps['settings']
  settingsFields?: readonly ChatSettingField[]
  chatColumn?: SharedChatProps['column']
  chatComposer?: SharedChatProps['composer']
  capabilities?: SharedChatProps['capabilities']
  tools: Omit<ReturnType<typeof createMakeChatTools>, 'projectFs'> & Partial<Pick<ReturnType<typeof createMakeChatTools>, 'projectFs'>>
}

/** Released widget skin alongside Make's editor; the host starts and disposes the runtime. */
export function MakeWorkspace({ chat, sessionUser, settings, settingsFields, chatColumn, chatComposer, capabilities, tools, ...pane }: MakeWorkspaceProps) {
  useMakeLocale()
  const state = useSyncExternalStore(chat.store.subscribe, chat.store.getState, chat.store.getState)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [standSettingsOpen, setStandSettingsOpen] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const projectClient = useMemo(() => pane.projectClient ?? createMakeProjectClient(pane.api, undefined, tools.projectFs), [pane.projectClient, pane.api, tools.projectFs])
  const run = (operation: Promise<unknown>) => { void operation.catch(cause => setError(describeMakeError(cause))) }
  const permissionMode = state.activeConversation?.permissionMode ?? settings.permissionMode
  const fields: readonly ChatSettingField[] = settingsFields ?? [
    { key: 'llmProvider', label: mt('makeChatProvider'), type: 'select', options: [{ value: 'claude', label: 'Claude' }, { value: 'codex', label: 'Codex' }] },
    { key: 'model', label: mt('makeChatClaudeModel'), type: 'text' },
    { key: 'codexModel', label: mt('makeChatCodexModel'), type: 'text' },
    { key: 'permissionMode', label: mt('makeChatPermission'), type: 'select', options: [
      { value: 'plan', label: mt('makeChatPlan') },
      { value: 'acceptEdits', label: mt('makeChatAcceptEdits') },
      { value: 'bypassPermissions', label: mt('makeChatBypassPermissions') }
    ] }
  ]
  // Do not expose a previous conversation while the host loads the requested one.
  if (state.activeId !== pane.conversationId) return <p role="status">{mt('loadingMakeChat')}</p>
  return <div className="make-workspace">
    <div className="make-workspace__chat">
      {error && <p role="alert">{error}</p>}
      <SharedChat skin="widget" store={chat.store} settings={settings} capabilities={capabilities}
        composer={{ ...chatComposer, readServerFile: tools.readServerFile,
          onChangePermissionMode: mode => run(chat.settings.save('conversation', { permissionMode: mode })) }}
        column={{ ...chatColumn, ...tools, ...(capabilities?.tools === false ? { machineOps: undefined } : {}), onOpenConversationSettings: () => { setSettingsOpen(open => !open); if (pane.projectId) setStandSettingsOpen(true) },
          onMakeRestore: snapshotId => run(pane.api['make:restore']({ conversationId: pane.conversationId, snapshotId })) }} />
      {settingsOpen && <ChatSettings controller={chat.settings} owner="conversation" fields={fields} />}
    </div>
    <MakePane {...pane} canEditQuota={sessionUser ? sessionUser.role === 'admin' : pane.canEditQuota} standSettingsOpen={standSettingsOpen} onStandSettingsClose={() => setStandSettingsOpen(false)} conversationTitle={pane.conversationTitle ?? state.activeConversation?.title} projectClient={projectClient} onInsertToChat={capabilities?.text === false ? undefined : chat.onInsertToChat}
      onAskAssistant={capabilities?.text === false ? undefined : text => run(chat.onAskAssistant(text))}
      onAttachImage={capabilities?.attachments === false ? undefined : file => run(chat.onAttachImage(file))} onEditorContext={chat.onEditorContext}
      askOnly={permissionMode === 'plan'} onAskOnlyChange={on => run(chat.settings.save('conversation', { permissionMode: on ? 'plan' : 'acceptEdits' }))}
      turnActive={Object.hasOwn(state.activeTurns, pane.conversationId) || state.preparingReply}
      lastRequest={[...state.messages].reverse().find(message => message.role !== 'ai')?.text ?? null} />
  </div>
}
