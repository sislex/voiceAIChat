# Chat client ports (U03)

`createChatClient` exports a version-1, framework-free client through the SDK root.
It implements four replaceable ports: transport, attachments, settings and
capability discovery. The concrete adapters use standard Fetch and WebSocket;
they have no runtime package imports and work in browsers and Node 22.19+.
Native host transports can supply `fetch` and `createSocket` explicitly.

## Ownership and source provenance

Core owns the wire contract. The client projections in `src/chatContracts.ts`
follow `sislex/voiceAIChat` commit
`ce64a0867b141ee15be703ee148b78e65b44051f`, specifically
`packages/shared/src/chatContract.ts` (contract `sislexa.core.chat` 1.0.0,
artifact SHA-256 `a11dfc0d9dd95abbb455198e6050019b4a7355b0af12df7bdf6790b1293112d4`),
`packages/shared/src/protocol.ts` and the existing `/api/uploads` implementation
in `apps/server/src/server.ts`. SDK owns the client ports and implementations.
These are client projections, not a transfer of Core's settings or authorization
ownership. Existing `source-origin.json` remains unchanged.

The supplied Core snapshot documents the revisioned settings/context routes and
chat handshake as contracts for subsequent server implementation. This adapter
does not silently fall back to legacy `/api/settings`. Commissioning requires a
Core release implementing C03/U02 and host integration through U04; it is separate
from completion of this SDK code. No publication or consumer upgrade is performed
here. Release operators must run `npm ci` and `npm run gate`, publish an immutable
SDK artifact with provenance, and pin that exact artifact/version in consumers
alongside the compatible Core release. Do not point consumers at mutable branches.

## Usage

```ts
import { createChatClient, ChatSettingsConflictError } from '@sislexa/sdk'

const client = createChatClient({
  baseUrl: 'https://core.example',
  // Same-origin browser cookies are the default. This callback must reload
  // authoritative history, active turn and queue using the host's Core API.
  resynchronize: async (snapshot, signal) => {
    await reloadConversationState({ snapshot, signal })
  }
})
const unsubscribe = client.transport.subscribe(event => {
  if (event.type === 'message') renderCoreMessage(event.message)
  if (event.type === 'settings') invalidateSettingsViews(event.settings)
})
client.transport.connect()
client.settings.setDevice({ micDeviceId: 'default' })
const current = await client.settings.get('conversation-id')
try {
  await client.settings.patch({ version: 1, owner: 'conversation',
    expectedRevision: current.revision, values: { model: 'chosen-model' }
  }, 'conversation-id')
} catch (error) {
  if (error instanceof ChatSettingsConflictError) showConflict(error.current)
  else throw error
}
const attachment = await client.attachments.upload({
  conversationId: 'conversation-id', name: 'note.txt',
  dataBase64: 'aGVsbG8=', mimeType: 'text/plain'
})
// Pass attachment.id in the existing Core claude.send attachments array.
// On unmount:
unsubscribe()
client.dispose()
```

Example host functions above belong to the consuming runtime. The SDK forwards
Core JSON `{t, ...}` messages and binary audio without depending on UI or tool
payload types. Only send after `transport.state === 'ready'`. The handshake frame
is managed by the adapter and cannot be sent through `transport.send`.

## Wire mapping and settings

| Port | Concrete operation |
| --- | --- |
| transport | `/ws`, `chat.connect` v1, `chat.ready`, JSON/binary frames |
| attachments.upload | `POST /api/uploads`, JSON name/base64/conversationId, optional MIME/agent |
| settings.get/patch | `GET`/`PATCH /api/chat/settings` or `/api/conversations/:id/settings` |
| capabilities.discover | `GET /api/chat/context` |

`baseUrl` supplies the origin; endpoint paths are absolute. A reverse proxy must
expose these paths. Conversation IDs are URL-encoded. Uploads are limited to
32 MiB decoded, and return Core upload IDs and preview metadata. No mutation is
automatically replayed after ambiguous delivery. HTTP errors expose status through
`ChatHttpError`, without logging response bodies or credentials. HTTP 409 with
`settings_revision_conflict` returns a typed error with the authoritative current
snapshot; the caller resolves the conflict explicitly.

Account and conversation values remain Core-owned. The server validates canonical
setting names and semantics. Device keys (`micDeviceId`, `outputDeviceId`,
`compactView`, `panelWidth`, `mobileTab`) remain in per-client memory and cannot
be sent in a persisted patch. `setDevice` merges local values, and returned
snapshots replace any server device values with the client's own values. The SDK
does not invent global localStorage keys or cache settings/capabilities. Settings
notifications are invalidations; hosts should refetch their conversation scope.

## Reconnect, authentication and lifecycle

Each socket open sends a fresh `chat.connect`, with this client's last handshake
cursor on automatic reconnect. Only `chat.ready` commits a cursor; the contract
defines no cursor advancement for generic frames. Fresh context and settings
replace previous handshake data. `resync-required` calls the required host
`resynchronize` adapter before readiness, including initial connection. That
adapter must reload authoritative state and respect its AbortSignal. Up to 256
events arriving during recovery are buffered and delivered after readiness;
overflow closes the connection rather than silently losing events. Applications
must not treat the cursor as a delivery or exactly-once guarantee.

Transient failures retry with bounded exponential delay (500 ms to 30 seconds,
at most eight retries by default). A 15-second handshake/recovery deadline covers
session acquisition and snapshot reload. Settings can override these bounds.
Malformed handshakes, unsupported versions and authorization close codes
1008/4401/4403 stop retries. Other close codes exhaust the finite retry budget.
`connect` is idempotent while active; after terminal failure a new explicit
`connect` starts without the old cursor. Explicit `disconnect` clears the cursor
and socket timers; pending independent HTTP calls continue. `dispose` also aborts
all HTTP requests, clears subscribers/device state and permanently closes the
client. Stale callbacks cannot revive a disconnected/disposed client.

`headers(signal)` obtains fresh per-request session headers. The optional
`socketUrl(url, signal)` hook acquires a host-specific short-lived WebSocket
session on every attempt. Cookie sessions need neither hook. Cross-origin cookie
use requires explicit `credentials: 'include'` and server CORS/CSRF configuration.
Do not supply long-lived application credentials or put them in browser storage.
Changing authenticated principal/tenant requires disposing the old client and
creating a new one. Credentials, application attribution, resource grants and
capability shape validation never authenticate the user: Core must authorize each
operation. Capability availability is a UI feature report, not permission.

## Validation and operational acceptance

Unit tests cover isolation, stale callbacks, recovery buffering, bounded retries,
protocol rejection, revision conflicts, JSON requests, device ownership and aborts.
The integration test uses native HTTP/Fetch and RFC 6455 WebSocket connections for
two simultaneous clients, including upload, settings, capability discovery,
reconnect cursors and independent teardown. Its short-lived fixture binds the
first `DELIVERY_PORTS` port in delivery runs (an ephemeral port outside delivery).
No service persists after the test. Sandbox loopback denial requires the
supervisor to run this test; it must not be converted into a passing skip.

Operator acceptance after publishing the compatible Core/SDK pair must exercise
real Identity sessions, expiry/revocation, resource authorization, canonical
settings persistence and both host surfaces. The contract fixture verifies SDK
wire behavior; it does not claim those server integrations are commissioned.
