import{j as T}from"./jsx-runtime-BYYWji4R.js";import{userEvent as r,within as m}from"./index-DeN4tkzB.js";import{a as Rn}from"./fakeApi-DFeC8AIq.js";import{EnvironmentsPanel as K}from"./EnvironmentsPanel-Cn0INptU.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-CpATlK0I.js";import"./types-DFdjDDUq.js";import"./tools-D2dVYbOd.js";import"./agentProtocol-ChPLBt7B.js";import"./projects-B9njsDhM.js";import"./projectTypes-C-9aONcK.js";import"./ci-DFdZK10C.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./dateFormat-Mm5g7L0f.js";import"./release-C-C1sGXa.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./environmentsBridge-CN0iPIbY.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";const t={id:"test-stand",projectId:"p1",name:"Проверка",mode:"managed",state:"draft",storageId:"storage-1",machines:["machine-1"],checkoutPath:"/storage/stand/app",composeProject:"sx-test-stand",port:null,createdBy:"owner",createdAt:1,updatedAt:1},Cn=[{agentId:"machine-1",name:"Готовая машина",path:"",reposRoot:"",storageId:"storage-1",storage:{id:"storage-1",machineId:"machine-1",rootPath:"/storage",status:"ready",formatVersion:1}},{agentId:"machine-2",name:"Хранилище недоступно",path:"",reposRoot:"",storageId:"storage-2",storage:{id:"storage-2",machineId:"machine-2",rootPath:"/storage",status:"offline",formatVersion:1}}],_=[{key:"VC_ADMIN_PASSWORD",label:"Пароль администратора",secret:!0,required:!0,generated:!1,set:!0,value:null,source:"user",updatedBy:"owner",updatedAt:1},{key:"VC_PUBLIC_URL",label:"Публичный адрес",secret:!1,required:!1,generated:!1,set:!0,value:"https://stand.example",source:"user",updatedBy:"owner",updatedAt:1}],Pn={environmentId:t.id,machineId:"machine-1",checkedAt:1,ready:!1,port:17800,checks:[{id:"docker",status:"passed",message:"Docker доступен"},{id:"memory",status:"warning",message:"Рекомендуется 8 ГБ"},{id:"disk",status:"failed",message:"Недостаточно места"}]},o=Date.UTC(2026,9,2,9,0),a=n=>n.repeat(40),E="https://github.com/sislex/sislexa-kanban",M="https://github.com/sislex/make",R="https://github.com/sislex/sielexa-ui",S={mode:"external",storageId:null,state:"ready",composeProject:null,port:null,id:"production",projectId:"p1",name:"Production",machines:["prod-89.125.68.35"],checkoutPath:"/root/ChatAI/voiceAIChat",createdBy:"admin",createdAt:o,updatedAt:o},On={...S,id:"staging",name:"Staging",machines:["makbook-m1"],checkoutPath:"/Users/alex/stage"},C=[{core:null,id:"c2",environmentId:"production",revision:2,note:"Kanban 0.1.2 на проверку",createdBy:"admin",createdAt:o-6e5,modules:[{repository:E,version:"0.1.2",commit:a("b")},{repository:M,version:"1.3.1",commit:a("e")},{repository:R,version:"0.1.4",commit:a("d")}]},{core:null,id:"c1",environmentId:"production",revision:1,note:"Initial observation",createdBy:"admin",createdAt:o-864e5,modules:[{repository:E,version:"0.1.1",commit:a("a")},{repository:M,version:"1.3.1",commit:a("e")},{repository:R,version:"0.1.3",commit:a("3")}]}],Sn=[{repository:E,name:"Kanban",services:["kanban"],desired:{version:"0.1.2",commit:a("b")},actual:{version:"0.1.1",commit:a("a")},action:"switch",reason:null},{repository:M,name:"Make",services:["make-api","make-worker"],desired:{version:"1.3.1",commit:a("e")},actual:{version:"1.3.1",commit:a("e")},action:"none",reason:null}],jn={repository:R,name:"UI Kit",services:[],desired:{version:"0.1.4",commit:a("d")},actual:{version:"0.1.3",commit:a("3")},action:"needs_core_release",reason:"Module is embedded in Core"},x=(n,e="")=>({service:"kanban",from:`ghcr.io/sislex/kanban:${a("a")}`,to:`ghcr.io/sislex/kanban:${a("b")}`,status:n,log:e}),P={kind:"apply",id:"op1",environmentId:"production",configurationId:"c2",previousConfigurationId:"c1",status:"succeeded",steps:[x("passed",`pulling
switching
healthy`)],startedBy:"admin",startedAt:o-3e5,finishedAt:o-24e4,error:null},s={...P,id:"op2",status:"health_check",steps:[x("running",`pulling
switching`)],startedAt:o-2e4,finishedAt:null},Tn={baseBranch:"main",applications:[{repository:E,name:"Kanban",applicationId:"kanban",current:null,releases:[{version:"0.1.3",commit:a("c"),publishedAt:"2026-10-02T08:00:00Z"},{version:"0.1.2",commit:a("b"),publishedAt:"2026-10-01T08:00:00Z"}]},{repository:M,name:"Make",applicationId:"make",current:null,releases:[{version:"1.3.2",commit:a("f"),publishedAt:"2026-10-01T09:30:00Z"},{version:"1.3.1",commit:a("e"),publishedAt:"2026-09-30T18:00:00Z"}]}]};function c(n={}){const e={observation:{environmentId:"production",machineId:S.machines[0],observedAt:o,core:{version:"0.1.360",commit:a("9")},services:[]},core:{desired:null,actual:{version:"0.1.360",commit:a("9")},action:"none"},modules:n.modules??Sn},d=n.configurations??C;return{"environments:list":async()=>n.list??[S,On],"environments:configurations":async()=>d,"environments:saveConfiguration":async({modules:B,note:Bn})=>({...d[0],id:"c3",revision:3,modules:B,note:Bn}),"environments:observe":async()=>e.observation,"environments:diff":async()=>e,"environments:apply":async()=>({...s,status:"pending",steps:[x("pending")]}),"environments:operations":async()=>n.operations??[P],"environments:rollback":async()=>({...s,id:"op3",configurationId:"c1",status:"pending",steps:[x("pending")]})}}function xn(){const n=Rn();return n["releases:composition"]=async()=>Tn,n}const ie={title:"Operations/Releases/EnvironmentsPanel",component:K,args:{projectId:"p1",baseBranch:"main",owner:!0,environments:c(),api:xn(),onComposeCore:()=>{}},render:n=>T.jsx("div",{style:{maxWidth:960,padding:16},children:T.jsx(K,{...n})})},p={},l={args:{environments:{...c({list:[{...t,machines:["primary","worker"]}],operations:[]}),"environments:links":async()=>["pending","open","down"].map((n,e)=>({id:String(e),environmentId:t.id,service:`service-${e}`,clientMachineId:"worker",serverMachineId:"primary",servicePort:8080,listenPort:17e3+e,transport:e===0?"vpn":"tunnel",address:e===0?"10.20.0.5:8080":`127.0.0.1:${17e3+e}`,state:n})),"environments:provision":async()=>({...s,kind:"provision",steps:["links","snapshot","restore"].map(n=>({kind:"stage",service:n,from:null,to:"ready",status:"running",log:""}))})}},play:async({canvasElement:n})=>{const e=m(n);await r.selectOptions(await e.findByLabelText("База стенда"),"production-snapshot"),await r.click(await e.findByRole("button",{name:"Изменить версии"})),await r.selectOptions(await e.findByLabelText("Машины Kanban"),["primary","worker"])}},u={args:{environments:c({operations:[s,P]})}},v={args:{environments:c({modules:[...Sn,jn]})}},g={args:{environments:c({list:[],configurations:[],operations:[]})}},y={args:{owner:!1,onComposeCore:void 0}},h={parameters:{viewport:{defaultViewport:"mobile1"}}},f={play:async({canvasElement:n})=>{const e=m(n);await r.click(await e.findByRole("button",{name:"Изменить версии"})),await r.selectOptions(await e.findByLabelText("Выбрать версию Kanban"),`0.1.3@${a("c")}`)}},O={...c({list:[t,S],configurations:[],operations:[]}),"environments:create":async({id:n,name:e,machineId:d,storageId:B})=>({...t,id:n,name:e,machines:[d],storageId:B}),"environments:readiness":async()=>Pn,"environments:settings":async()=>_,"environments:saveSettings":async()=>_,"environments:update":async({publicHost:n,lanAccess:e})=>({...t,publicHost:n,lanAccess:e}),"environments:provision":async()=>({...s,kind:"provision",id:"provision",status:"preparing",steps:[{kind:"stage",service:"readiness",from:null,to:"ready",status:"running",log:""}]}),"environments:remove":async()=>({...s,kind:"remove",id:"remove",status:"removing",steps:[{kind:"stage",service:"down",from:null,to:"stopped",status:"running",log:""}]})},j=xn();j["projects:get"]=async()=>({machines:Cn});const i={args:{environments:O,api:j}},k={args:{environments:{...O,"environments:list":async()=>[{...t,state:"ready",port:17800}],"environments:configurations":async()=>[{...C[0],environmentId:t.id}]},api:j}},b={...i,play:async({canvasElement:n})=>{await r.click(await m(n).findByRole("button",{name:"Новое окружение"}))}},w={...i,play:async({canvasElement:n})=>{await r.click(await m(n).findByRole("button",{name:"Проверить машину"}))}},I={...i,play:async({canvasElement:n})=>{await r.click(await m(n).findByRole("button",{name:"Настройки и секреты"}))}},A={args:{environments:{...O,"environments:list":async()=>[{...t,state:"ready",port:17800,publicHost:"stand.example.com",lanAccess:!0}],"environments:configurations":async()=>[{...C[0],environmentId:t.id}],"environments:operations":async()=>[{...s,kind:"migrate",id:"migrate",status:"preparing",steps:[{kind:"stage",service:"files",from:null,to:"copied",status:"running",log:""}]}],"environments:migrate":async()=>({...s,kind:"migrate"}),"environments:cutover":async()=>({...s,kind:"cutover"}),"environments:cancel":async()=>({...s,kind:"migrate",status:"failed",error:"Cancelled"})}}};var D,L,V;p.parameters={...p.parameters,docs:{...(D=p.parameters)==null?void 0:D.docs,source:{originalSource:"{}",...(V=(L=p.parameters)==null?void 0:L.docs)==null?void 0:V.source}}};var $,U,N;l.parameters={...l.parameters,docs:{...($=l.parameters)==null?void 0:$.docs,source:{originalSource:`{
  args: {
    environments: {
      ...environments({
        list: [{
          ...managedEnvironment,
          machines: ['primary', 'worker']
        }],
        operations: []
      }),
      'environments:links': async () => (['pending', 'open', 'down'] as const).map((state, index) => ({
        id: String(index),
        environmentId: managedEnvironment.id,
        service: \`service-\${index}\`,
        clientMachineId: 'worker',
        serverMachineId: 'primary',
        servicePort: 8080,
        listenPort: 17000 + index,
        transport: index === 0 ? 'vpn' : 'tunnel',
        address: index === 0 ? '10.20.0.5:8080' : \`127.0.0.1:\${17000 + index}\`,
        state
      })),
      'environments:provision': async () => ({
        ...running,
        kind: 'provision',
        steps: ['links', 'snapshot', 'restore'].map(service => ({
          kind: 'stage',
          service,
          from: null,
          to: 'ready',
          status: 'running',
          log: ''
        }))
      })
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.selectOptions(await canvas.findByLabelText('База стенда'), 'production-snapshot');
    await userEvent.click(await canvas.findByRole('button', {
      name: 'Изменить версии'
    }));
    await userEvent.selectOptions(await canvas.findByLabelText('Машины Kanban'), ['primary', 'worker']);
  }
}`,...(N=(U=l.parameters)==null?void 0:U.docs)==null?void 0:N.source}}};var Z,q,H;u.parameters={...u.parameters,docs:{...(Z=u.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    environments: environments({
      operations: [running, succeeded]
    })
  }
}`,...(H=(q=u.parameters)==null?void 0:q.docs)==null?void 0:H.source}}};var W,F,z;v.parameters={...v.parameters,docs:{...(W=v.parameters)==null?void 0:W.docs,source:{originalSource:`{
  args: {
    environments: environments({
      modules: [...modules, embedded]
    })
  }
}`,...(z=(F=v.parameters)==null?void 0:F.docs)==null?void 0:z.source}}};var G,J,Q;g.parameters={...g.parameters,docs:{...(G=g.parameters)==null?void 0:G.docs,source:{originalSource:`{
  args: {
    environments: environments({
      list: [],
      configurations: [],
      operations: []
    })
  }
}`,...(Q=(J=g.parameters)==null?void 0:J.docs)==null?void 0:Q.source}}};var X,Y,nn;y.parameters={...y.parameters,docs:{...(X=y.parameters)==null?void 0:X.docs,source:{originalSource:`{
  args: {
    owner: false,
    onComposeCore: undefined
  }
}`,...(nn=(Y=y.parameters)==null?void 0:Y.docs)==null?void 0:nn.source}}};var en,an,sn;h.parameters={...h.parameters,docs:{...(en=h.parameters)==null?void 0:en.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(sn=(an=h.parameters)==null?void 0:an.docs)==null?void 0:sn.source}}};var tn,rn,on;f.parameters={...f.parameters,docs:{...(tn=f.parameters)==null?void 0:tn.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByRole('button', {
      name: 'Изменить версии'
    }));
    await userEvent.selectOptions(await canvas.findByLabelText('Выбрать версию Kanban'), \`0.1.3@\${sha('c')}\`);
  }
}`,...(on=(rn=f.parameters)==null?void 0:rn.docs)==null?void 0:on.source}}};var cn,mn,dn;i.parameters={...i.parameters,docs:{...(cn=i.parameters)==null?void 0:cn.docs,source:{originalSource:`{
  args: {
    environments: managedApi,
    api: projectApi
  }
}`,...(dn=(mn=i.parameters)==null?void 0:mn.docs)==null?void 0:dn.source}}};var pn,ln,un;k.parameters={...k.parameters,docs:{...(pn=k.parameters)==null?void 0:pn.docs,source:{originalSource:`{
  args: {
    environments: {
      ...managedApi,
      'environments:list': async () => [{
        ...managedEnvironment,
        state: 'ready',
        port: 17800
      }],
      'environments:configurations': async () => [{
        ...configurations[0]!,
        environmentId: managedEnvironment.id
      }]
    },
    api: projectApi
  }
}`,...(un=(ln=k.parameters)==null?void 0:ln.docs)==null?void 0:un.source}}};var vn,gn,yn;b.parameters={...b.parameters,docs:{...(vn=b.parameters)==null?void 0:vn.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Новое окружение'
    }));
  }
}`,...(yn=(gn=b.parameters)==null?void 0:gn.docs)==null?void 0:yn.source}}};var hn,fn,kn;w.parameters={...w.parameters,docs:{...(hn=w.parameters)==null?void 0:hn.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Проверить машину'
    }));
  }
}`,...(kn=(fn=w.parameters)==null?void 0:fn.docs)==null?void 0:kn.source}}};var bn,wn,In;I.parameters={...I.parameters,docs:{...(bn=I.parameters)==null?void 0:bn.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Настройки и секреты'
    }));
  }
}`,...(In=(wn=I.parameters)==null?void 0:wn.docs)==null?void 0:In.source}}};var An,En,Mn;A.parameters={...A.parameters,docs:{...(An=A.parameters)==null?void 0:An.docs,source:{originalSource:`{
  args: {
    environments: {
      ...managedApi,
      'environments:list': async () => [{
        ...managedEnvironment,
        state: 'ready',
        port: 17800,
        publicHost: 'stand.example.com',
        lanAccess: true
      }],
      'environments:configurations': async () => [{
        ...configurations[0]!,
        environmentId: managedEnvironment.id
      }],
      'environments:operations': async () => [{
        ...running,
        kind: 'migrate',
        id: 'migrate',
        status: 'preparing',
        steps: [{
          kind: 'stage',
          service: 'files',
          from: null,
          to: 'copied',
          status: 'running',
          log: ''
        }]
      }],
      'environments:migrate': async () => ({
        ...running,
        kind: 'migrate'
      }),
      'environments:cutover': async () => ({
        ...running,
        kind: 'cutover'
      }),
      'environments:cancel': async () => ({
        ...running,
        kind: 'migrate',
        status: 'failed',
        error: 'Cancelled'
      })
    }
  }
}`,...(Mn=(En=A.parameters)==null?void 0:En.docs)==null?void 0:Mn.source}}};const ce=["SwitchOneService","MultiMachineSnapshot","Applying","EmbeddedModules","NotObserved","ReadOnlyMember","Mobile","EditVersions","ManagedDraft","ManagedReady","CreateManaged","MachineReadiness","SettingsAndSecrets","ProductionMigrationReadOnly"];export{u as Applying,b as CreateManaged,f as EditVersions,v as EmbeddedModules,w as MachineReadiness,i as ManagedDraft,k as ManagedReady,h as Mobile,l as MultiMachineSnapshot,g as NotObserved,A as ProductionMigrationReadOnly,y as ReadOnlyMember,I as SettingsAndSecrets,p as SwitchOneService,ce as __namedExportsOrder,ie as default};
