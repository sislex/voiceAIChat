import { z } from 'zod'
import { makeStandOperationSchema, makeStandResultSchema, validateMakeStandResult, type MakeStandOperation, type MakeStandResult } from './projectMode.js'

/** Core's double-submit CSRF: cookie sessions must echo `vc_csrf` in `x-vc-csrf` on every mutation. */
export function sessionMutationHeaders(cookie = (globalThis as { document?: { cookie?: string } }).document?.cookie ?? ''): Record<string, string> {
  const match = /(?:^|;\s*)vc_csrf=([^;]+)/.exec(cookie)
  return { 'Content-Type': 'application/json', ...(match ? { 'x-vc-csrf': decodeURIComponent(match[1]!) } : {}) }
}

export interface MakeStandClient {
  state(conversationId: string): Promise<MakeStandResult>
  operation(conversationId: string, operation: MakeStandOperation): Promise<MakeStandResult>
}

/** Authenticated host transport; mutations are never retried. */
export function createStandHttpClient(fetchImpl: typeof fetch = globalThis.fetch): MakeStandClient {
  async function request(id: string, operation?: MakeStandOperation) {
    const response = await fetchImpl(`/api/make/${encodeURIComponent(id)}/stand`, {
      method: operation ? 'POST' : 'GET', credentials: 'include',
      ...(operation ? { headers: sessionMutationHeaders(), body: JSON.stringify(makeStandOperationSchema.parse(operation)) } : {}),
    })
    const body = await response.json()
    if (!response.ok) {
      const error = z.object({ error: z.string() }).safeParse(body)
      throw new Error(error.success ? error.data.error : `HTTP ${response.status}`)
    }
    const result = makeStandResultSchema.parse(body)
    if (operation) validateMakeStandResult(operation, result)
    return result
  }
  return { state: id => request(id), operation: (id, operation) => request(id, operation) }
}
import { createTransferTaskSchema, standPreviewOperationSchema, standPreviewResultSchema, makeProjectSchema, projectSubprojectSchema, projectDesignSchema, projectGitOperationSchema, projectGitResultSchema, projectPathSchema, transferTaskResultSchema, type MakeProjectCore, type ProjectDesign } from './projectMode.js'

export type ProjectInventory = { [K in 'listProjects' | 'projectStructure' | 'projectDesign' | 'projectGit' | 'createTransferTask' | 'standPreview']: MakeProjectCore[K] extends (user: string, ...args: infer A) => infer R ? (...args: A) => R : never }
export interface ProjectFiles {
  read(projectId: string, path: string): Promise<string>
  write(projectId: string, path: string, content: string): Promise<void>
}
export type MakeProjectClient = ProjectInventory & ProjectFiles

/** The host may supply its authenticated fetch implementation, including desktop transport. */
export function createProjectHttpClient(fetchImpl: typeof fetch = globalThis.fetch): ProjectInventory {
  async function call(method: string, args: unknown[]) {
    const response = await fetchImpl('/api/make/projects/operation', {
      method: 'POST', credentials: 'include', headers: sessionMutationHeaders(), body: JSON.stringify({ method, args }),
    })
    const body = await response.json()
    if (!response.ok) {
      const error = z.object({ error: z.string() }).safeParse(body)
      throw new Error(error.success ? error.data.error : `HTTP ${response.status}`)
    }
    return body
  }
  return {
    standPreview: async (id, operation) => {
      const result = standPreviewResultSchema.parse(await call('standPreview', [id, standPreviewOperationSchema.parse(operation)]))
      if ((operation.op === 'live_on' || operation.op === 'live_off') && result.live !== undefined && result.live !== (operation.op === 'live_on')) throw new Error(result.error || 'Core did not confirm live mode')
      return result
    },
    listProjects: async () => z.array(makeProjectSchema).parse(await call('listProjects', [])),
    projectStructure: async id => z.array(projectSubprojectSchema).parse(await call('projectStructure', [id])),
    projectDesign: async (id, path) => projectDesignSchema.parse(await call('projectDesign', [id, projectPathSchema.parse(path)])),
    projectGit: async (id, operation) => {
      const result = projectGitResultSchema.parse(await call('projectGit', [id, projectGitOperationSchema.parse(operation)]))
      if (result.op !== operation.op) throw new Error('Mismatched project Git result')
      return result
    },
    createTransferTask: async args => transferTaskResultSchema.parse(await call('createTransferTask', [createTransferTaskSchema.parse(args)])),
  }
}

/** A variant overrides discovered CSS variables without rewriting their source files. */
export function projectThemeFile(subproject: string, name: string, design: ProjectDesign, values: Record<string, string>, theme?: string) {
  projectPathSchema.parse(subproject)
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(name)) throw new Error('Invalid theme file name')
  const discovered = new Set(design.tokens.filter(token => token.theme === theme && /^--[\w-]+$/.test(token.name)).map(token => token.name))
  const declarations = Object.entries(values).map(([key, value]) => {
    if (!discovered.has(key) || !value.trim() || /[{};\x00-\x1f]|\/\*/.test(value)) throw new Error(`Invalid token override: ${key}`)
    return `  ${key}: ${value};`
  })
  if (!declarations.length) throw new Error('No CSS variable overrides')
  if (theme && !/^[\w-]+$/.test(theme)) throw new Error('Invalid theme selector')
  return { path: `${subproject === '.' ? '' : `${subproject}/`}themes/${name}.css`, content: `${theme ? `[data-theme="${theme}"]` : ':root'} {\n${declarations.join('\n')}\n}\n` }
}
