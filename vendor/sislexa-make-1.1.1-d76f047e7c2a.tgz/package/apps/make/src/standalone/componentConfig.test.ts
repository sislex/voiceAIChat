import { afterEach, describe, expect, it, vi } from 'vitest'
import { mkdtempSync, writeFileSync, rmSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import Fastify from 'fastify'
import { spawn, spawnSync } from 'node:child_process'
import { once } from 'node:events'
import { createComponentRuntime } from '@sislexa/component-runtime'
import { buildMakeServer } from './server.js'
const cleanups: (() => unknown | Promise<unknown>)[] = []
afterEach(async () => { for (const close of cleanups.splice(0).reverse()) await close(); vi.unstubAllEnvs() })

describe('managed standalone component configuration', () => {
  it('uses configured dependencies, separates user and component credentials, and rejects legacy RPC access', async () => {
    const root = mkdtempSync(join(tmpdir(), 'sislexa-make-')); cleanups.push(() => rmSync(root, { recursive: true, force: true }))
    const contractFile = fileURLToPath(new URL('../../component-contract.json', import.meta.url))
    const contract = JSON.parse(readFileSync(contractFile, 'utf8')) as { dependencies: { applicationId: string; scopes: string[] }[] }
    const configFile = join(root, 'component.json')
    const dependencies: { applicationId: string; url: string; tokenFile: string }[] = []
    let coreToken = ''
    for (const required of contract.dependencies) {
      const providerFile = join(root, required.applicationId + '.contract.json'), settingsFile = join(root, required.applicationId + '.config.json')
      writeFileSync(providerFile, JSON.stringify({ schemaVersion: 1, applicationId: required.applicationId, provides: required.scopes, legacyScopes: [], dependencies: [] }))
      writeFileSync(settingsFile, JSON.stringify({ schemaVersion: 1, environmentId: 'test', registryDirectory: join(root, required.applicationId), grants: [{ consumerId: 'make', scopes: required.scopes, maxTtlSeconds: 3600 }], legacyScopes: [], dependencies: [] }))
      const runtime = await createComponentRuntime({ contractFile: providerFile, configFile: settingsFile, metadata: { applicationId: required.applicationId, version: required.applicationId === 'core' ? '0.1.312' : '1.1.0', apiVersion: '1.1.0', dataVersion: '1.0.0', commit: 'a'.repeat(40) } })
      const provider = Fastify(); runtime.register(provider); cleanups.push(() => provider.close())
      provider.post<{ Body: { headers?: { authorization?: string } } }>('/internal/whoami', async (req, reply) => {
        const result = runtime.authorize(req.headers.authorization, 'identity.verify')
        if (!result.ok) return reply.code(result.status).send({ error: 'denied' })
        return req.body.headers?.authorization === 'Bearer user-session' ? { ok: true, user: { name: 'ann', role: 'developer' } } : { ok: false, status: 401, error: 'unauthorized' }
      })
      provider.post('/*', async () => ({ result: null }))
      const url = await provider.listen({ host: '127.0.0.1', port: 0 })
      const token = runtime.registry!.issue('make', required.scopes, 3600).token
      if (required.applicationId === 'core') coreToken = token
      const tokenFile = join(root, required.applicationId + '.token'); writeFileSync(tokenFile, token, { mode: 0o600 })
      dependencies.push({ applicationId: required.applicationId, url, tokenFile })
    }
    writeFileSync(configFile, JSON.stringify({ schemaVersion: 1, environmentId: 'test', registryDirectory: join(root, 'own-registry'), grants: [{ consumerId: 'core', scopes: ['make.service'], maxTtlSeconds: 3600 }], legacyScopes: [], dependencies }))
    for (const [key, value] of Object.entries({ VC_APPLICATION_VERSION: '1.1.0', VC_APPLICATION_API_VERSION: '1.1.0', VC_APPLICATION_COMMIT: 'b'.repeat(40) })) vi.stubEnv(key, value)
    const { app } = await buildMakeServer({ config: { host: '127.0.0.1', port: 0, dataDir: root, coreUrl: 'http://invalid', internalToken: 'legacy', mcpSecret: 'mcp', version: '1.1.0', componentConfigPath: configFile } })
    cleanups.push(() => app.close())
    expect((await app.inject({ url: '/v1/ready' })).statusCode).toBe(200)
    expect((await app.inject({ url: '/v1/component' })).json()).toMatchObject({ application: { applicationId: 'make', version: '1.1.0' }, environmentId: 'test' })
    expect((await app.inject({ url: '/api/make/missing', headers: { authorization: 'Bearer ' + coreToken } })).statusCode).toBe(401)
    const issuer = await createComponentRuntime({ contractFile, configFile, metadata: { applicationId: 'make', version: '1.1.0', apiVersion: '1.1.0', dataVersion: '1.0.0', commit: 'b'.repeat(40) } })
    cleanups.push(() => issuer.close())
    const issued = issuer.registry!.issue('core', ['make.service'], 60)
    const request = { method: 'POST' as const, url: '/v1/component/authorize', payload: { scopes: ['make.service'] } }
    expect((await app.inject({ ...request, headers: { authorization: 'Bearer legacy' } })).statusCode).toBe(401)
    expect((await app.inject({ ...request, headers: { authorization: 'Bearer ' + coreToken } })).statusCode).toBe(401)
    expect((await app.inject({ ...request, headers: { authorization: 'Bearer ' + issued.token } })).statusCode).toBe(200)
    expect((await app.inject({ method: 'POST', url: '/internal/service', headers: { authorization: 'Bearer legacy' }, payload: { method: 'unknown', args: [] } })).statusCode).toBe(401)
    // Exercise the real entry point: server-factory tests cannot catch legacy bootstrap guards.
    const entry = fileURLToPath(new URL('./index.ts', import.meta.url))
    const cwd = fileURLToPath(new URL('../../../../', import.meta.url))
    const env = { ...process.env, HOST: '127.0.0.1', PORT: '0', VC_MAKE_DATA_DIR: root,
      SISLEXA_COMPONENT_CONFIG: configFile, VC_INTERNAL_TOKEN: '', VC_MCP_SECRET: 'mcp' }
    const child = spawn(process.execPath, ['--import', 'tsx', entry], { cwd, env, stdio: ['ignore', 'pipe', 'pipe'] })
    let output = ''
    child.stdout.on('data', chunk => { output += String(chunk) })
    child.stderr.on('data', chunk => { output += String(chunk) })
    cleanups.push(async () => {
      if (child.exitCode === null) { const stopped = once(child, 'exit'); child.kill('SIGTERM'); await stopped }
    })
    let address = ''
    await vi.waitFor(() => {
      if (child.exitCode !== null) throw Error('Make exited before listening: ' + output)
      address = output.match(/Server listening at (http:\/\/127\.0\.0\.1:\d+)/)?.[1] ?? ''
      expect(address).not.toBe('')
    }, { timeout: 10000 })
    expect((await fetch(address + '/v1/ready')).status).toBe(200)
    expect((await fetch(address + '/internal/service', { method: 'POST', headers: { authorization: 'Bearer legacy', 'content-type': 'application/json' }, body: JSON.stringify({ method: 'unknown', args: [] }) })).status).toBe(401)
    const legacy = spawnSync(process.execPath, ['--import', 'tsx', entry], { cwd, env: { ...env, SISLEXA_COMPONENT_CONFIG: '' }, encoding: 'utf8', timeout: 10000 })
    expect(legacy.status).toBe(1)
    expect(legacy.stderr).toContain('VC_INTERNAL_TOKEN is required')
    issuer.registry!.revoke(issued.principal.tokenId)
    expect((await app.inject({ ...request, headers: { authorization: 'Bearer ' + issued.token } })).statusCode).toBe(401)
  }, 20000)
})
