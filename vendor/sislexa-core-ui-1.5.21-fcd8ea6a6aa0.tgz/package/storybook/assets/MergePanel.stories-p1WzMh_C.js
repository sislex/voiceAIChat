import{j as l}from"./jsx-runtime-BYYWji4R.js";import{M as X}from"./MergePanel-CqssyCMm.js";import{q as Y}from"./queuedMerge-C6LdcEEW.js";import{c as K}from"./fakeApi-DOzlA0mv.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./QueuedMergeMachine-3G6jJgNn.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Skeleton-42oMjovX.js";import"./ErrorState-CqsakWkx.js";import"./merge-CBY8VSWw.js";import"./dateFormat-Mm5g7L0f.js";import"./EmptyState-q579drYF.js";import"./StatusPill-Dn6iIbOr.js";import"./Badge-zWzzcJYU.js";import"./loadState-C9E-sPL9.js";import"./ciFormat-BG9i2Mqq.js";import"./ci-DFdZK10C.js";import"./types-DFdjDDUq.js";import"./ansi-DtpFsZ9v.js";import"./AnsiText-L5oy_LV7.js";import"./iframe-vd2lyGNM.js";import"./tools-D2dVYbOd.js";import"./agentProtocol-ChPLBt7B.js";import"./devProcess-DlbHViLE.js";import"./projects-DdDt-pC-.js";import"./projectTypes-C-9aONcK.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";const g=[{stage:"checking",status:"passed",startedAt:1,finishedAt:2,durationMs:700,exitCode:null,timedOut:!1,message:"Серверные проверки пройдены",log:""},{stage:"fetching",status:"passed",startedAt:2,finishedAt:3,durationMs:1800,exitCode:null,timedOut:!1,message:"Source 1a2b3c4d, main 9f8e7d6c",log:""},{stage:"merging",status:"passed",startedAt:3,finishedAt:4,durationMs:400,exitCode:null,timedOut:!1,message:"Создан merge 5e6f7a8b",log:""},{stage:"testing",status:"passed",startedAt:4,finishedAt:5,durationMs:48e4,exitCode:null,timedOut:!1,message:"Все обязательные проверки прошли",log:""},{stage:"pushing",status:"passed",startedAt:5,finishedAt:6,durationMs:2400,exitCode:null,timedOut:!1,message:"origin/main подтверждён",log:""}],e={id:"run-1",projectId:"p1",taskId:"t1",status:"success",triggeredBy:"admin",sourceBranch:"CHAT-180",targetBranch:"main",sourceSha:"1a2b3c4d".repeat(5),targetSha:"9f8e7d6c".repeat(5),mergeSha:"5e6f7a8b".repeat(5),revertSha:null,agentId:"m1",machineName:"MacBook",llmEngineId:null,llmProvider:"claude",llmModel:"",stage:"success",stages:g,conflicts:[],conflictDetails:[],checks:[{name:"Проверки проекта",command:"npm run typecheck",status:"passed",startedAt:4,finishedAt:5,durationMs:48e4,exitCode:0,timedOut:!1,output:`> typecheck
✓ ok`}],deployId:null,deployVersion:null,productionStatus:null,error:null,recommendedAction:null,log:`[12:00:00] merge requested by admin
[12:00:01] Серверные проверки пройдены
[12:08:02] origin/main подтверждён`,canCancel:!1,canRetry:!1,pushStartedAt:5,startedAt:1,finishedAt:6,createdAt:1},Z=[{id:"r1",projectId:"p1",taskId:"t1",agentId:"m1",machineName:"MacBook",path:"/Users/dev/chatAI/dev/chatai/CHAT-180",kind:"dev-workspace",state:"active",createdAt:1,deletedAt:null},{id:"r2",projectId:"p1",taskId:"t1",agentId:"m2",machineName:"Server",path:"/root/VoiceAIChatRepos/chatai/.merge",kind:"merge-clone",state:"deleted",createdAt:2,deletedAt:3}];function r(t,d=[t]){return function(L){return window.ci={...K(),getMerge:async()=>t,listMergeRuns:async()=>d,getTaskRepositories:async()=>Z,onMerge:()=>()=>{}},window.api={"projects:get":async()=>({machines:[{agentId:"m1",name:"MacBook",online:!0,path:"/w",reposRoot:"/repos"}]})},l.jsx("div",{style:{maxWidth:860},children:l.jsx(L,{})})}}const Be={title:"CI/MergePanel",component:X,args:{projectId:"p1",taskId:"t1",runId:"run-1",canStart:!1}},n={decorators:[r(e)]},c={decorators:[r({...e,targetBranch:"dev",stages:[],log:""})]},u={decorators:[r({...e,targetBranch:"dev",status:"testing",stage:"testing",finishedAt:null,stages:[],log:""})]},m={decorators:[r({...e,targetBranch:"dev",status:"failed",stage:"failed",error:"Проверки не прошли",stages:[],log:""})]},s={decorators:[t=>{const d={id:"temporary-1",projectId:"p1",taskId:"t1",runId:"run-1",userId:"admin",machineId:"m1",machineName:"MacBook",path:"/managed/merge-run-tests",root:"/managed",category:"merge-worktree",generation:"g1",identity:"1:2",gitCommonDir:null,gitRegistration:null,createdAt:1,state:"registered"};return window.ci={...K(),getTemporaryResources:async()=>({candidates:[{resource:d,eligible:!1,reasons:["machine_offline","git_changes"],retainUntil:null,bytes:null,sizeReason:"machine_offline"}],attempts:[{id:"attempt-1",resource:d,at:Date.now(),reason:"machine_offline",outcome:"deferred",freedBytes:null,error:null}]})},l.jsx(t,{})}]},a={args:{runId:"queued-475"},decorators:[t=>(window.ci=Y(),l.jsx(t,{}))]},o={decorators:[r({...e,id:"run-2",status:"testing",stage:"testing",mergeSha:null,finishedAt:null,canCancel:!0,stages:g.slice(0,3).concat([{...g[3],status:"running",finishedAt:null,durationMs:null,message:"Запускаю обязательные проверки до push"}])},[{...e,id:"run-2",status:"testing"}])],args:{runId:"run-2"}},i={decorators:[r({...e,id:"run-3",status:"decision_required",stage:"decision_required",mergeSha:null,error:"Конфликты требуют решения пользователя",recommendedAction:"Разрешите файлы в ветке задачи и повторите merge.",conflicts:["apps/server/src/index.ts"],canRetry:!0,stages:g.slice(0,2)},[{...e,id:"run-3",status:"decision_required"},e])],args:{runId:"run-3",canStart:!0}};var p,h,f,y,A;n.parameters={...n.parameters,docs:{...(p=n.parameters)==null?void 0:p.docs,source:{originalSource:`{
  decorators: [withCi(baseRun)]
}`,...(f=(h=n.parameters)==null?void 0:h.docs)==null?void 0:f.source},description:{story:"Успешный ран: зелёный бейдж, все стадии пройдены, деплой ещё не запускался.",...(A=(y=n.parameters)==null?void 0:y.docs)==null?void 0:A.description}}};var I,R,S;c.parameters={...c.parameters,docs:{...(I=c.parameters)==null?void 0:I.docs,source:{originalSource:`{
  decorators: [withCi({
    ...baseRun,
    targetBranch: 'dev',
    stages: [],
    log: ''
  })]
}`,...(S=(R=c.parameters)==null?void 0:R.docs)==null?void 0:S.source}}};var w,C,k;u.parameters={...u.parameters,docs:{...(w=u.parameters)==null?void 0:w.docs,source:{originalSource:`{
  decorators: [withCi({
    ...baseRun,
    targetBranch: 'dev',
    status: 'testing',
    stage: 'testing',
    finishedAt: null,
    stages: [],
    log: ''
  })]
}`,...(k=(C=u.parameters)==null?void 0:C.docs)==null?void 0:k.source}}};var v,M,b;m.parameters={...m.parameters,docs:{...(v=m.parameters)==null?void 0:v.docs,source:{originalSource:`{
  decorators: [withCi({
    ...baseRun,
    targetBranch: 'dev',
    status: 'failed',
    stage: 'failed',
    error: 'Проверки не прошли',
    stages: [],
    log: ''
  })]
}`,...(b=(M=m.parameters)==null?void 0:M.docs)==null?void 0:b.source}}};var x,D,B,_,q;s.parameters={...s.parameters,docs:{...(x=s.parameters)==null?void 0:x.docs,source:{originalSource:`{
  decorators: [Story => {
    const resource = {
      id: 'temporary-1',
      projectId: 'p1',
      taskId: 't1',
      runId: 'run-1',
      userId: 'admin',
      machineId: 'm1',
      machineName: 'MacBook',
      path: '/managed/merge-run-tests',
      root: '/managed',
      category: 'merge-worktree' as const,
      generation: 'g1',
      identity: '1:2',
      gitCommonDir: null,
      gitRegistration: null,
      createdAt: 1,
      state: 'registered' as const
    };
    window.ci = {
      ...createFakeCi(),
      getTemporaryResources: async () => ({
        candidates: [{
          resource,
          eligible: false,
          reasons: ['machine_offline', 'git_changes'],
          retainUntil: null,
          bytes: null,
          sizeReason: 'machine_offline'
        }],
        attempts: [{
          id: 'attempt-1',
          resource,
          at: Date.now(),
          reason: 'machine_offline',
          outcome: 'deferred',
          freedBytes: null,
          error: null
        }]
      })
    };
    return <Story />;
  }]
}`,...(B=(D=s.parameters)==null?void 0:D.docs)==null?void 0:B.source},description:{story:"Open the resource panel to review offline, unknown-size and retained-work states.",...(q=(_=s.parameters)==null?void 0:_.docs)==null?void 0:q.description}}};var j,O,T,N,F;a.parameters={...a.parameters,docs:{...(j=a.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    runId: 'queued-475'
  },
  decorators: [Story => {
    window.ci = queuedMergeCi();
    return <Story />;
  }]
}`,...(T=(O=a.parameters)==null?void 0:O.docs)==null?void 0:T.source},description:{story:"Shared fixtures exercise the queued action in DOM, Storybook and Chromium.",...(F=(N=a.parameters)==null?void 0:N.docs)==null?void 0:F.description}}};var z,E,P,U,H;o.parameters={...o.parameters,docs:{...(z=o.parameters)==null?void 0:z.docs,source:{originalSource:`{
  decorators: [withCi({
    ...baseRun,
    id: 'run-2',
    status: 'testing',
    stage: 'testing',
    mergeSha: null,
    finishedAt: null,
    canCancel: true,
    stages: stagesDone.slice(0, 3).concat([{
      ...stagesDone[3],
      status: 'running',
      finishedAt: null,
      durationMs: null,
      message: 'Запускаю обязательные проверки до push'
    }])
  }, [{
    ...baseRun,
    id: 'run-2',
    status: 'testing'
  }])],
  args: {
    runId: 'run-2'
  }
}`,...(P=(E=o.parameters)==null?void 0:E.docs)==null?void 0:P.source},description:{story:"Ран в работе: стадия testing выполняется, лог открыт, доступна отмена.",...(H=(U=o.parameters)==null?void 0:U.docs)==null?void 0:H.description}}};var Q,V,W,G,J;i.parameters={...i.parameters,docs:{...(Q=i.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  decorators: [withCi({
    ...baseRun,
    id: 'run-3',
    status: 'decision_required',
    stage: 'decision_required',
    mergeSha: null,
    error: 'Конфликты требуют решения пользователя',
    recommendedAction: 'Разрешите файлы в ветке задачи и повторите merge.',
    conflicts: ['apps/server/src/index.ts'],
    canRetry: true,
    stages: stagesDone.slice(0, 2)
  }, [{
    ...baseRun,
    id: 'run-3',
    status: 'decision_required'
  }, baseRun])],
  args: {
    runId: 'run-3',
    canStart: true
  }
}`,...(W=(V=i.parameters)==null?void 0:V.docs)==null?void 0:W.source},description:{story:"Конфликты: плашка ошибки с рекомендацией, список файлов, retry доступен.",...(J=(G=i.parameters)==null?void 0:G.docs)==null?void 0:J.description}}};const _e=["Success","DevSuccess","DevRunning","DevFailed","TemporaryResourceReview","Queued","Running","DecisionRequired"];export{i as DecisionRequired,m as DevFailed,u as DevRunning,c as DevSuccess,a as Queued,o as Running,n as Success,s as TemporaryResourceReview,_e as __namedExportsOrder,Be as default};
