/** @jsxRuntime automatic */
import { useEffect, useMemo, useRef } from 'react'
import type * as MonacoNs from 'monaco-editor/esm/vs/editor/editor.api'
import Editor, { type OnMount } from '@monaco-editor/react'
import { attachJsxAutoClose, setupMonaco, syncProjectModels, setModelSnippetTranslator } from './monacoSetup'
import { monacoLanguageFor } from './monacoLang'
import type { CodeEditorProps } from '../CodeEditor'

/** Редактор на Monaco — настоящий VS Code: подсветка TSX/JSX, автодополнение, поиск, сворачивание. */
export default function MonacoCodeEditor({ path, value, onChange, onSave, ariaLabel, markers, projectFiles, onSelectionChange, onInlineCommand, readOnly, changedLines, loadingLabel = 'Загружаю редактор…', translateUiText }: CodeEditorProps): JSX.Element {
  const monaco = useMemo(() => setupMonaco(), [])
  useEffect(() => { if (projectFiles) syncProjectModels(monaco, projectFiles) }, [monaco, projectFiles])
  const saveRef = useRef(onSave)
  saveRef.current = onSave
  const editorRef = useRef<MonacoNs.editor.IStandaloneCodeEditor | null>(null)
  const translateRef = useRef(translateUiText); translateRef.current = translateUiText
  const selRef = useRef(onSelectionChange); selRef.current = onSelectionChange
  const inlineRef = useRef(onInlineCommand); inlineRef.current = onInlineCommand
  // Маркеры ошибок компиляции: приходят из make_check после сохранения.
  useEffect(() => {
    const model = editorRef.current?.getModel()
    if (!model) return
    monaco.editor.setModelMarkers(model, 'make', (markers ?? []).map((mk) => ({
      severity: mk.severity === 'warning' ? monaco.MarkerSeverity.Warning : monaco.MarkerSeverity.Error,
      message: mk.message,
      startLineNumber: mk.line, startColumn: mk.column ?? 1,
      endLineNumber: mk.line, endColumn: model.getLineMaxColumn(Math.min(mk.line, model.getLineCount()))
    })))
  }, [markers, monaco, value])
  // Подсветка строк, изменённых ассистентом (roadmap-4 п.9): полоска в gutter + фон строки; снимается новым набором/пустым.
  const decorationsRef = useRef<MonacoNs.editor.IEditorDecorationsCollection | null>(null)
  useEffect(() => {
    const editor = editorRef.current
    if (!editor) return
    if (!decorationsRef.current) decorationsRef.current = editor.createDecorationsCollection([])
    decorationsRef.current.set((changedLines ?? []).map((line) => ({ range: { startLineNumber: line, startColumn: 1, endLineNumber: line, endColumn: 1 }, options: { isWholeLine: true, className: 'make-line-changed', linesDecorationsClassName: 'make-line-changed-gutter' } })))
    if (changedLines && changedLines.length) editor.revealLineInCenterIfOutsideViewport(changedLines[0]!)
  }, [changedLines, value])
  const onMount: OnMount = (editor, m) => {
    editorRef.current = editor
    const model = editor.getModel()
    if (model) setModelSnippetTranslator(model, (text) => translateRef.current?.(text) ?? text)
    // Редактор пересоздаётся при смене файла (key={path}) — коллекция декораций старого экземпляра мертва.
    decorationsRef.current = null
    editor.addCommand(m.KeyMod.CtrlCmd | m.KeyCode.KeyS, () => saveRef.current?.())
    editor.addCommand(m.KeyMod.CtrlCmd | m.KeyCode.KeyI, () => inlineRef.current?.())
    editor.onDidChangeCursorSelection((e) => {
      const model = editor.getModel()
      if (!model || !selRef.current) return
      const s = e.selection
      if (s.isEmpty()) { selRef.current(null); return }
      selRef.current({ startLine: s.startLineNumber, endLine: s.endLineNumber, text: model.getValueInRange(s) })
    })
    attachJsxAutoClose(editor, m)
    editor.focus()
  }
  return (
    <div className="make-monaco" data-testid="make-monaco" aria-label={ariaLabel} role="group">
      <Editor
        key={path}
        // Абсолютные пути машины начинаются с `/` (или `C:\`): убираем ведущие слэши, иначе URI получает `////` и Monaco падает.
        path={`file:///${path.replace(/^[\\/]+/, '')}`}
        language={monacoLanguageFor(path)}
        value={value}
        theme="vs-dark"
        onChange={(next) => onChange(next ?? '')}
        onMount={onMount}
        loading={<div className="make-monaco-loading">{loadingLabel}</div>}
        options={{
          readOnly: Boolean(readOnly),
          fontSize: 12.5,
          fontFamily: "'SF Mono', ui-monospace, Menlo, Consolas, monospace",
          tabSize: 2,
          insertSpaces: true,
          minimap: { enabled: false },
          automaticLayout: true,
          scrollBeyondLastLine: false,
          wordWrap: 'off',
          renderWhitespace: 'selection',
          bracketPairColorization: { enabled: true },
          autoClosingBrackets: 'languageDefined',
          autoClosingQuotes: 'languageDefined',
          formatOnPaste: true,
          smoothScrolling: true,
          padding: { top: 8 },
          ariaLabel
        }}
      />
      {/* monaco экспортируется через setupMonaco, чтобы loader не ходил в CDN */}
      {monaco ? null : null}
    </div>
  )
}
