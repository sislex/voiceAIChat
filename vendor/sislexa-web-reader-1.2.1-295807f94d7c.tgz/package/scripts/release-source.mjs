import {execFileSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
const root=new URL('../',import.meta.url)
const commit=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()
if(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim())throw Error('Release archives require a clean committed checkout')
const pkg=JSON.parse(readFileSync('package.json','utf8'))
writeFileSync('release-source.json',JSON.stringify({schemaVersion:1,repository:pkg.repository.url,version:pkg.version,commit},null,2)+'\n')
