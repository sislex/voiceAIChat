import{j as k}from"./jsx-runtime-BYYWji4R.js";import{within as z,userEvent as w}from"./index-DeN4tkzB.js";import{a as G}from"./fakeApi-CUcY9ytG.js";import{EnvironmentsPanel as A}from"./EnvironmentsPanel-B1hIWwVw.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-Cjoo2Y6X.js";import"./types-DFdjDDUq.js";import"./tools-D2dVYbOd.js";import"./agentProtocol-ChPLBt7B.js";import"./projects-B9njsDhM.js";import"./projectTypes-C-9aONcK.js";import"./ci-DFdZK10C.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./dateFormat-Mm5g7L0f.js";import"./environmentsBridge-CX_W_cmJ.js";const o=Date.UTC(2026,9,2,9,0),e=n=>n.repeat(40),p="https://github.com/sislex/sislexa-kanban",u="https://github.com/sislex/make",g="https://github.com/sislex/sielexa-ui",b={id:"production",projectId:"p1",name:"Production",machines:["prod-89.125.68.35"],checkoutPath:"/root/ChatAI/voiceAIChat",createdBy:"admin",createdAt:o,updatedAt:o},H={...b,id:"staging",name:"Staging",machines:["makbook-m1"],checkoutPath:"/Users/alex/stage"},J=[{id:"c2",environmentId:"production",revision:2,note:"Kanban 0.1.2 на проверку",createdBy:"admin",createdAt:o-6e5,modules:[{repository:p,version:"0.1.2",commit:e("b")},{repository:u,version:"1.3.1",commit:e("e")},{repository:g,version:"0.1.4",commit:e("d")}]},{id:"c1",environmentId:"production",revision:1,note:"Initial observation",createdBy:"admin",createdAt:o-864e5,modules:[{repository:p,version:"0.1.1",commit:e("a")},{repository:u,version:"1.3.1",commit:e("e")},{repository:g,version:"0.1.3",commit:e("3")}]}],F=[{repository:p,name:"Kanban",services:["kanban"],desired:{version:"0.1.2",commit:e("b")},actual:{version:"0.1.1",commit:e("a")},action:"switch",reason:null},{repository:u,name:"Make",services:["make-api","make-worker"],desired:{version:"1.3.1",commit:e("e")},actual:{version:"1.3.1",commit:e("e")},action:"none",reason:null}],Q={repository:g,name:"UI Kit",services:[],desired:{version:"0.1.4",commit:e("d")},actual:{version:"0.1.3",commit:e("3")},action:"needs_core_release",reason:"Module is embedded in Core"},l=(n,s="")=>({service:"kanban",from:`ghcr.io/sislex/kanban:${e("a")}`,to:`ghcr.io/sislex/kanban:${e("b")}`,status:n,log:s}),y={id:"op1",environmentId:"production",configurationId:"c2",previousConfigurationId:"c1",status:"succeeded",steps:[l("passed",`pulling
switching
healthy`)],startedBy:"admin",startedAt:o-3e5,finishedAt:o-24e4,error:null},h={...y,id:"op2",status:"health_check",steps:[l("running",`pulling
switching`)],startedAt:o-2e4,finishedAt:null},X={baseBranch:"main",applications:[{repository:p,name:"Kanban",applicationId:"kanban",current:null,releases:[{version:"0.1.3",commit:e("c"),publishedAt:"2026-10-02T08:00:00Z"},{version:"0.1.2",commit:e("b"),publishedAt:"2026-10-01T08:00:00Z"}]},{repository:u,name:"Make",applicationId:"make",current:null,releases:[{version:"1.3.2",commit:e("f"),publishedAt:"2026-10-01T09:30:00Z"},{version:"1.3.1",commit:e("e"),publishedAt:"2026-09-30T18:00:00Z"}]}]};function v(n={}){const s={observation:{environmentId:"production",machineId:b.machines[0],observedAt:o,core:{version:"0.1.360",commit:e("9")},services:[]},modules:n.modules??F},f=n.configurations??J;return{"environments:list":async()=>n.list??[b,H],"environments:configurations":async()=>f,"environments:saveConfiguration":async({modules:W,note:q})=>({...f[0],id:"c3",revision:3,modules:W,note:q}),"environments:observe":async()=>s.observation,"environments:diff":async()=>s,"environments:apply":async()=>({...h,status:"pending",steps:[l("pending")]}),"environments:operations":async()=>n.operations??[y],"environments:rollback":async()=>({...h,id:"op3",configurationId:"c1",status:"pending",steps:[l("pending")]})}}function Y(){const n=G();return n["releases:composition"]=async()=>X,n}const Ie={title:"Operations/Releases/EnvironmentsPanel",component:A,args:{projectId:"p1",baseBranch:"main",owner:!0,environments:v(),api:Y(),onComposeCore:()=>{}},render:n=>k.jsx("div",{style:{maxWidth:960,padding:16},children:k.jsx(A,{...n})})},r={},t={args:{environments:v({operations:[h,y]})}},i={args:{environments:v({modules:[...F,Q]})}},a={args:{environments:v({list:[],configurations:[],operations:[]})}},c={args:{owner:!1,onComposeCore:void 0}},m={parameters:{viewport:{defaultViewport:"mobile1"}}},d={play:async({canvasElement:n})=>{const s=z(n);await w.click(await s.findByRole("button",{name:"Изменить версии"})),await w.selectOptions(await s.findByLabelText("Выбрать версию Kanban"),`0.1.3@${e("c")}`)}};var I,x,E;r.parameters={...r.parameters,docs:{...(I=r.parameters)==null?void 0:I.docs,source:{originalSource:"{}",...(E=(x=r.parameters)==null?void 0:x.docs)==null?void 0:E.source}}};var C,S,B;t.parameters={...t.parameters,docs:{...(C=t.parameters)==null?void 0:C.docs,source:{originalSource:`{
  args: {
    environments: environments({
      operations: [running, succeeded]
    })
  }
}`,...(B=(S=t.parameters)==null?void 0:S.docs)==null?void 0:B.source}}};var M,O,K;i.parameters={...i.parameters,docs:{...(M=i.parameters)==null?void 0:M.docs,source:{originalSource:`{
  args: {
    environments: environments({
      modules: [...modules, embedded]
    })
  }
}`,...(K=(O=i.parameters)==null?void 0:O.docs)==null?void 0:K.source}}};var T,j,R;a.parameters={...a.parameters,docs:{...(T=a.parameters)==null?void 0:T.docs,source:{originalSource:`{
  args: {
    environments: environments({
      list: [],
      configurations: [],
      operations: []
    })
  }
}`,...(R=(j=a.parameters)==null?void 0:j.docs)==null?void 0:R.source}}};var _,P,N;c.parameters={...c.parameters,docs:{...(_=c.parameters)==null?void 0:_.docs,source:{originalSource:`{
  args: {
    owner: false,
    onComposeCore: undefined
  }
}`,...(N=(P=c.parameters)==null?void 0:P.docs)==null?void 0:N.source}}};var U,V,Z;m.parameters={...m.parameters,docs:{...(U=m.parameters)==null?void 0:U.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(Z=(V=m.parameters)==null?void 0:V.docs)==null?void 0:Z.source}}};var $,L,D;d.parameters={...d.parameters,docs:{...($=d.parameters)==null?void 0:$.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByRole('button', {
      name: 'Изменить версии'
    }));
    await userEvent.selectOptions(await canvas.findByLabelText('Выбрать версию Kanban'), \`0.1.3@\${sha('c')}\`);
  }
}`,...(D=(L=d.parameters)==null?void 0:L.docs)==null?void 0:D.source}}};const xe=["SwitchOneService","Applying","EmbeddedModules","NotObserved","ReadOnlyMember","Mobile","EditVersions"];export{t as Applying,d as EditVersions,i as EmbeddedModules,m as Mobile,a as NotObserved,c as ReadOnlyMember,r as SwitchOneService,xe as __namedExportsOrder,Ie as default};
