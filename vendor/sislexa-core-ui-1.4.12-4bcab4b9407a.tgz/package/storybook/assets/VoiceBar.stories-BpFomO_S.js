import{j as a}from"./jsx-runtime-BYYWji4R.js";import{r as y}from"./index-ClcD9ViR.js";import{fn as n,within as P,userEvent as l,expect as p}from"./index-DeN4tkzB.js";import{V as W}from"./VoiceBar-o9huicVE.js";import{q as U}from"./chat-COYZgq2j.js";import"./ci-DFdZK10C.js";import"./machines-mJ7_PUPS.js";import"./clarification-BhK1l2ki.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";import"./hotkeys-4oJJtujI.js";import"./types-DFdjDDUq.js";import"./autoGrow-CoBFBF9S.js";import"./view-0MbJGw9Y.js";import"./animations--P72MiAI.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./icons-M-fant0Z.js";import"./images-CH23vBlI.js";import"./tools-D2dVYbOd.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";const d=()=>{},rs={title:"Chat/VoiceBar",component:W,args:{state:"idle",draft:"",diarization:!0,detectedSpeakers:[],attachments:[],onDraftChange:n(),onSubmitText:n(),onStartVoice:n(),onStopVoice:n(),onStopSpeak:n(),onCancelRequest:n(),onAddFiles:n(),onRemoveAttachment:n(),defaultCollapsed:!1},decorators:[t=>a.jsx("div",{style:{maxWidth:860},children:a.jsx(t,{})})]},h={},z={args:{draft:"Сохранённый черновик беседы. Длинный текст остаётся доступным для редактирования."},decorators:[t=>a.jsx("div",{style:{width:390,maxWidth:"100%"},children:a.jsx(t,{})})]},F={args:{attachments:[{localId:"pasted",name:"clipboard.svg",status:"ready",previewUrl:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="80" height="60"%3E%3Crect width="80" height="60" fill="skyblue"/%3E%3C/svg%3E'}]}},v={args:{draft:"Разберись, почему упал шаг npm test в последнем ране."}},f={args:{state:"listening",detectedSpeakers:[1,2]}},w={args:{state:"listening",detectedSpeakers:[1],diarization:!1}},x={args:{state:"transcribing"}},Ia=`
  .waiting-in-feed-story { display: grid; min-height: 420px; grid-template-rows: 1fr auto; }
  .waiting-in-feed-story__timeline {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    gap: 10px;
    min-height: 260px;
    padding: 20px 14px;
    background: var(--bg);
  }
  .waiting-in-feed-story__message {
    align-self: flex-end;
    max-width: min(76%, 560px);
    padding: 9px 12px;
    border-radius: 14px 14px 4px 14px;
    background: var(--accent);
    color: white;
  }
  .waiting-in-feed-story__preparing {
    align-self: flex-start;
    display: flex;
    align-items: center;
    gap: 7px;
    min-height: 26px;
    color: var(--text-dim);
    font-size: 13px;
  }
  .waiting-in-feed-story__dots { letter-spacing: 2px; color: var(--accent); }
`,S={args:{state:"thinking",draft:"Следующее сообщение в очередь"},render:t=>a.jsxs("div",{className:"waiting-in-feed-story",children:[a.jsx("style",{children:Ia}),a.jsxs("div",{className:"waiting-in-feed-story__timeline",role:"log","aria-label":"Сообщения",children:[a.jsx("div",{className:"waiting-in-feed-story__message",children:"Проверь, почему последний тест падает только в CI"}),a.jsxs("div",{className:"waiting-in-feed-story__preparing",role:"status",children:[a.jsx("span",{className:"waiting-in-feed-story__dots","aria-hidden":"true",children:"•••"}),a.jsx("span",{children:"Готовим ответ…"})]})]}),a.jsx(W,{...t})]})},C={args:{state:"thinking",replyStarted:!0,draft:"А ещё проверь кэш npm"}},T={args:{state:"speaking"}},b={args:{voiceInputEnabled:!1}},Ba=`
  .attachment-preview-story .attchips { align-items: flex-end; }
  .attachment-preview-story .attpreview-image {
    background:
      linear-gradient(145deg, transparent 55%, rgba(255,255,255,.22) 56% 64%, transparent 65%),
      radial-gradient(circle at 72% 28%, #ffd166 0 7px, transparent 8px),
      linear-gradient(155deg, #7db7e8 0 48%, #4f8f6a 49% 67%, #315f49 68%);
  }
  .attachment-preview-story .attpreview-image > span { display: none; }
`,g={decorators:[t=>a.jsxs("div",{className:"attachment-preview-story",children:[a.jsx("style",{children:Ba}),a.jsx(t,{})]})],args:{draft:"Вот скриншот и лог рана",attachments:[U({name:"скриншот-падения.png"}),U({name:"ci-run-1934.log",mimeType:"text/plain"})]}},k={args:{layout:"centered",draft:"",userDisplayName:"Анна"}},E={args:{layout:"docked",draft:"Следующее сообщение"}},I={args:{draft:`Первая строка
Вторая строка
Третья строка`}},B={args:{draft:Array.from({length:10},(t,e)=>`Строка ${e+1}: детали задачи`).join(`
`)}},A={args:{draft:`Первая строка
Вторая строка
Третья строка`},play:async({canvasElement:t})=>{const e=P(t);await l.click(e.getByTestId("composer-size-toggle")),await p(e.getByLabelText("Поле ввода сообщения").closest(".voicebar")).toHaveClass("voicebar--expanded")}},M={args:{draft:"Посмотри изображение",attachments:[{localId:"processing-image",status:"processing",name:"большой-скриншот.png",mimeType:"image/png"}]}},j={decorators:g.decorators,args:{draft:"Посмотри изображение",attachments:[{localId:"ready-image",status:"ready",name:"готовый-скриншот.png",mimeType:"image/png"}]}},_={args:{draft:"Посмотри изображение",onRetryAttachment:n(),attachments:[{localId:"error-image",status:"error",name:"сломанный-скриншот.png",mimeType:"image/png",error:"Не удалось загрузить"}]}},R={args:{draft:"Три изображения",onRetryAttachment:n(),attachments:[{localId:"processing",status:"processing",name:"обработка.png",mimeType:"image/png"},{localId:"ready",status:"ready",name:"готово.png",mimeType:"image/png"},{localId:"error",status:"error",name:"ошибка.png",mimeType:"image/png",error:"Сеть недоступна"}]}},ka=Array.from({length:5},(t,e)=>({id:`queue-${e+1}`,conversationId:"storybook-chat",messageId:`message-${e+1}`,text:e===1?"Очень длинное ожидающее сообщение, проверяющее перенос текста и доступность действий при увеличенном размере шрифта.":`Ожидающее сообщение ${e+1}`,attachments:e===0?["image-upload","document-upload"]:[],...e===0?{attachmentDetails:[{uploadId:"image-upload",path:"/fixtures/image.png",name:"image.png",mimeType:"image/png",size:1024},{uploadId:"document-upload",path:"/fixtures/document.pdf",name:"document.pdf",mimeType:"application/pdf",size:2048}]}:{},position:e+1,status:"queued",createdAt:e+1}));function Aa(t){const[e,m]=y.useState(ka);return a.jsx(W,{...t,queuedTurns:e,onEditQueued:(s,r)=>{var i;m(c=>c.map(o=>o.id===s?{...o,text:r}:o)),(i=t.onEditQueued)==null||i.call(t,s,r)},onDeleteQueued:s=>{var r;m(i=>i.filter(c=>c.id!==s).map((c,o)=>({...c,position:o+1}))),(r=t.onDeleteQueued)==null||r.call(t,s)},onSendQueuedNow:s=>{var r;m(i=>{const c=i.find(o=>o.id===s);return c?[c,...i.filter(o=>o.id!==s)].map((o,Ea)=>({...o,position:Ea+1})):i}),(r=t.onSendQueuedNow)==null||r.call(t,s)}})}const u={render:t=>a.jsx(Aa,{...t}),args:{state:"thinking",queuedTurns:ka,onEditQueued:n(),onDeleteQueued:n(),onSendQueuedNow:n()},play:async({canvasElement:t})=>{const e=P(t);await p(e.getAllByTestId("turn-queue-item")).toHaveLength(3),await l.click(e.getByRole("button",{name:"Показать ещё 2"})),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(5),await l.click(e.getByRole("button",{name:"Отправить сейчас сообщение № 5"})),await p(e.getAllByTestId("turn-queue-item")[0]).toHaveTextContent("Ожидающее сообщение 5")}},D={args:{...u.args,defaultCollapsed:!0,allowCollapse:!0},parameters:{viewport:{defaultViewport:"mobile1"}},play:async({canvasElement:t})=>{const e=P(t);await p(e.queryByLabelText("Поле ввода сообщения")).not.toBeInTheDocument(),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(3),await l.click(e.getByRole("button",{name:"Показать ещё 2"})),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(5)}},q={args:{...u.args,queuePaused:!0,requestError:"Движок недоступен"}},L={args:{allowCollapse:!0,defaultCollapsed:!0,draft:"Проверь, почему шаг npm test падает только в CI"},parameters:{viewport:{defaultViewport:"mobile1"}}},Q={args:{allowCollapse:!0,defaultCollapsed:!0,state:"thinking"},parameters:{viewport:{defaultViewport:"mobile1"}}},N={args:{permissionMode:"acceptEdits",onChangePermissionMode:n()}};function Ma({initial:t="",state:e="idle"}){const[m,s]=y.useState(t),[r,i]=y.useState([]);return a.jsxs("div",{style:{maxWidth:860},children:[r.length>0&&a.jsx("ul",{className:"attchips","data-testid":"sent-messages",children:r.map((c,o)=>a.jsx("li",{className:"attchip",children:c},o))}),a.jsx(W,{defaultCollapsed:!1,state:e,draft:m,diarization:!0,detectedSpeakers:[],attachments:[],onDraftChange:s,onSubmitText:()=>{i(c=>[...c,m]),s("")},onStartVoice:d,onStopVoice:d,onStopSpeak:d,onCancelRequest:d,onAddFiles:d,onRemoveAttachment:d})]})}function ja(){const[t,e]=y.useState("Создай компонент"),[m,s]=y.useState("plan"),[r,i]=y.useState(null);return a.jsxs("div",{children:[r&&a.jsxs("p",{role:"status",children:["Первая отправка: ",r==="acceptEdits"?"Разработка":"План"]}),a.jsx(W,{defaultCollapsed:!1,state:"idle",draft:t,diarization:!0,detectedSpeakers:[],attachments:[],permissionMode:m,onChangePermissionMode:s,onDraftChange:e,onSubmitText:()=>i(m),onStartVoice:d,onStopVoice:d,onStopSpeak:d,onCancelRequest:d,onAddFiles:d,onRemoveAttachment:d})]})}const V={render:()=>a.jsx(ja,{}),play:async({canvasElement:t})=>{const e=P(t);await l.click(e.getByRole("button",{name:"Разработка"})),await l.click(e.getByLabelText("Отправить сообщение")),await p(e.getByRole("status")).toHaveTextContent("Первая отправка: Разработка")}},H={render:()=>a.jsx(Ma,{}),play:async({canvasElement:t})=>{const e=P(t);await l.type(e.getByLabelText("Поле ввода сообщения"),"Проверь гейт пакета ui"),await l.click(e.getByLabelText("Отправить сообщение")),await p(e.getByTestId("sent-messages")).toHaveTextContent("Проверь гейт пакета ui"),await p(e.getByLabelText("Поле ввода сообщения")).toHaveValue("")}};var $,O,G,J,K;h.parameters={...h.parameters,docs:{...($=h.parameters)==null?void 0:$.docs,source:{originalSource:"{}",...(G=(O=h.parameters)==null?void 0:O.docs)==null?void 0:G.source},description:{story:"Простой: композер пуст, кнопка справа — микрофон.",...(K=(J=h.parameters)==null?void 0:J.docs)==null?void 0:K.description}}};var X,Y,Z;z.parameters={...z.parameters,docs:{...(X=z.parameters)==null?void 0:X.docs,source:{originalSource:`{
  args: {
    draft: 'Сохранённый черновик беседы. Длинный текст остаётся доступным для редактирования.'
  },
  decorators: [Story => <div style={{
    width: 390,
    maxWidth: '100%'
  }}><Story /></div>]
}`,...(Z=(Y=z.parameters)==null?void 0:Y.docs)==null?void 0:Z.source}}};var ee,te,ae;F.parameters={...F.parameters,docs:{...(ee=F.parameters)==null?void 0:ee.docs,source:{originalSource:`{
  args: {
    attachments: [{
      localId: 'pasted',
      name: 'clipboard.svg',
      status: 'ready',
      previewUrl: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="80" height="60"%3E%3Crect width="80" height="60" fill="skyblue"/%3E%3C/svg%3E'
    }]
  }
}`,...(ae=(te=F.parameters)==null?void 0:te.docs)==null?void 0:ae.source}}};var se,re,ne,oe,ie;v.parameters={...v.parameters,docs:{...(se=v.parameters)==null?void 0:se.docs,source:{originalSource:`{
  args: {
    draft: 'Разберись, почему упал шаг npm test в последнем ране.'
  }
}`,...(ne=(re=v.parameters)==null?void 0:re.docs)==null?void 0:ne.source},description:{story:"Набранный черновик: микрофон сменился на «отправить».",...(ie=(oe=v.parameters)==null?void 0:oe.docs)==null?void 0:ie.description}}};var ce,de,pe,me,le;f.parameters={...f.parameters,docs:{...(ce=f.parameters)==null?void 0:ce.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    detectedSpeakers: [1, 2]
  }
}`,...(pe=(de=f.parameters)==null?void 0:de.docs)==null?void 0:pe.source},description:{story:"Запись: волна, «Готово» и строка обнаруженных говорящих.",...(le=(me=f.parameters)==null?void 0:me.docs)==null?void 0:le.description}}};var ue,ge,ye,he,ve;w.parameters={...w.parameters,docs:{...(ue=w.parameters)==null?void 0:ue.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    detectedSpeakers: [1],
    diarization: false
  }
}`,...(ye=(ge=w.parameters)==null?void 0:ge.docs)==null?void 0:ye.source},description:{story:"Запись без диаризации: чипы говорящих становятся общим «Вы».",...(ve=(he=w.parameters)==null?void 0:he.docs)==null?void 0:ve.description}}};var fe,we,xe,Se,Ce;x.parameters={...x.parameters,docs:{...(fe=x.parameters)==null?void 0:fe.docs,source:{originalSource:`{
  args: {
    state: 'transcribing'
  }
}`,...(xe=(we=x.parameters)==null?void 0:we.docs)==null?void 0:xe.source},description:{story:"Распознавание: транскрипт финализируется, композер ещё заблокирован.",...(Ce=(Se=x.parameters)==null?void 0:Se.docs)==null?void 0:Ce.description}}};var Te,be,ke,Ee,Ie;S.parameters={...S.parameters,docs:{...(Te=S.parameters)==null?void 0:Te.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    draft: 'Следующее сообщение в очередь'
  },
  render: args => <div className="waiting-in-feed-story">
      <style>{waitingInFeedStoryCss}</style>
      <div className="waiting-in-feed-story__timeline" role="log" aria-label="Сообщения">
        <div className="waiting-in-feed-story__message">Проверь, почему последний тест падает только в CI</div>
        <div className="waiting-in-feed-story__preparing" role="status">
          <span className="waiting-in-feed-story__dots" aria-hidden="true">•••</span>
          <span>Готовим ответ…</span>
        </div>
      </div>
      <VoiceBar {...args} />
    </div>
}`,...(ke=(be=S.parameters)==null?void 0:be.docs)==null?void 0:ke.source},description:{story:"До первого фрагмента подготовка видна в ленте, не увеличивая нижнюю панель.",...(Ie=(Ee=S.parameters)==null?void 0:Ee.docs)==null?void 0:Ie.description}}};var Be,Ae,Me,je,_e;C.parameters={...C.parameters,docs:{...(Be=C.parameters)==null?void 0:Be.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    replyStarted: true,
    draft: 'А ещё проверь кэш npm'
  }
}`,...(Me=(Ae=C.parameters)==null?void 0:Ae.docs)==null?void 0:Me.source},description:{story:"Пошёл стрим ответа: композер снова доступен под черновик, отправка — нет.",...(_e=(je=C.parameters)==null?void 0:je.docs)==null?void 0:_e.description}}};var Re,De,qe,Le,Qe;T.parameters={...T.parameters,docs:{...(Re=T.parameters)==null?void 0:Re.docs,source:{originalSource:`{
  args: {
    state: 'speaking'
  }
}`,...(qe=(De=T.parameters)==null?void 0:De.docs)==null?void 0:qe.source},description:{story:"Озвучка ответа: композер доступен, красная кнопка останавливает речь.",...(Qe=(Le=T.parameters)==null?void 0:Le.docs)==null?void 0:Qe.description}}};var Ne,Ve,He,Pe,We;b.parameters={...b.parameters,docs:{...(Ne=b.parameters)==null?void 0:Ne.docs,source:{originalSource:`{
  args: {
    voiceInputEnabled: false
  }
}`,...(He=(Ve=b.parameters)==null?void 0:Ve.docs)==null?void 0:He.source},description:{story:"Микрофон недоступен: движок распознавания не поднялся (нет модели, нет доступа\nк устройству) — голосовой ввод выключен целиком, кнопки микрофона нет, и в\nпростое панель молчит вместо подсказки про пробел. Текст самой ошибки живёт в\nбаннере ленты (`ChatColumn`, сториз `WithError`).",...(We=(Pe=b.parameters)==null?void 0:Pe.docs)==null?void 0:We.description}}};var ze,Fe,Ue,$e,Oe;g.parameters={...g.parameters,docs:{...(ze=g.parameters)==null?void 0:ze.docs,source:{originalSource:`{
  decorators: [Story => <div className="attachment-preview-story">
      <style>{attachmentPreviewStoryCss}</style>
      <Story />
    </div>],
  args: {
    draft: 'Вот скриншот и лог рана',
    attachments: [makeUpload({
      name: 'скриншот-падения.png'
    }), makeUpload({
      name: 'ci-run-1934.log',
      mimeType: 'text/plain'
    })]
  }
}`,...(Ue=(Fe=g.parameters)==null?void 0:Fe.docs)==null?void 0:Ue.source},description:{story:"Изображение показано миниатюрой с именем снизу; прочие файлы остаются чипами.",...(Oe=($e=g.parameters)==null?void 0:$e.docs)==null?void 0:Oe.description}}};var Ge,Je,Ke,Xe,Ye;k.parameters={...k.parameters,docs:{...(Ge=k.parameters)==null?void 0:Ge.docs,source:{originalSource:`{
  args: {
    layout: 'centered',
    draft: '',
    userDisplayName: 'Анна'
  }
}`,...(Ke=(Je=k.parameters)==null?void 0:Je.docs)==null?void 0:Ke.source},description:{story:"Пустой чат: композер по центру с приветствием.",...(Ye=(Xe=k.parameters)==null?void 0:Xe.docs)==null?void 0:Ye.description}}};var Ze,et,tt,at,st;E.parameters={...E.parameters,docs:{...(Ze=E.parameters)==null?void 0:Ze.docs,source:{originalSource:`{
  args: {
    layout: 'docked',
    draft: 'Следующее сообщение'
  }
}`,...(tt=(et=E.parameters)==null?void 0:et.docs)==null?void 0:tt.source},description:{story:"Разговор начат: композер закреплён внизу колонки.",...(st=(at=E.parameters)==null?void 0:at.docs)==null?void 0:st.description}}};var rt,nt,ot,it,ct;I.parameters={...I.parameters,docs:{...(rt=I.parameters)==null?void 0:rt.docs,source:{originalSource:`{
  args: {
    draft: 'Первая строка\\nВторая строка\\nТретья строка'
  }
}`,...(ot=(nt=I.parameters)==null?void 0:nt.docs)==null?void 0:ot.source},description:{story:"Поле начинается с одной строки и растёт на каждую новую строку текста.",...(ct=(it=I.parameters)==null?void 0:it.docs)==null?void 0:ct.description}}};var dt,pt,mt,lt,ut;B.parameters={...B.parameters,docs:{...(dt=B.parameters)==null?void 0:dt.docs,source:{originalSource:`{
  args: {
    draft: Array.from({
      length: 10
    }, (_, index) => \`Строка \${index + 1}: детали задачи\`).join('\\n')
  }
}`,...(mt=(pt=B.parameters)==null?void 0:pt.docs)==null?void 0:mt.source},description:{story:"После четырёх строк высота ограничена, текст прокручивается внутри поля.",...(ut=(lt=B.parameters)==null?void 0:lt.docs)==null?void 0:ut.description}}};var gt,yt,ht,vt,ft;A.parameters={...A.parameters,docs:{...(gt=A.parameters)==null?void 0:gt.docs,source:{originalSource:`{
  args: {
    draft: 'Первая строка\\nВторая строка\\nТретья строка'
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByTestId('composer-size-toggle'));
    await expect(canvas.getByLabelText('Поле ввода сообщения').closest('.voicebar')).toHaveClass('voicebar--expanded');
  }
}`,...(ht=(yt=A.parameters)==null?void 0:yt.docs)==null?void 0:ht.source},description:{story:"Редактор раскрыт вручную; play оставляет story в раскрытом состоянии.",...(ft=(vt=A.parameters)==null?void 0:vt.docs)==null?void 0:ft.description}}};var wt,xt,St,Ct,Tt;M.parameters={...M.parameters,docs:{...(wt=M.parameters)==null?void 0:wt.docs,source:{originalSource:`{
  args: {
    draft: 'Посмотри изображение',
    attachments: [{
      localId: 'processing-image',
      status: 'processing',
      name: 'большой-скриншот.png',
      mimeType: 'image/png'
    }]
  }
}`,...(St=(xt=M.parameters)==null?void 0:xt.docs)==null?void 0:St.source},description:{story:"Изображение обрабатывается: плитка зарезервирована, отправка заблокирована.",...(Tt=(Ct=M.parameters)==null?void 0:Ct.docs)==null?void 0:Tt.description}}};var bt,kt,Et,It,Bt;j.parameters={...j.parameters,docs:{...(bt=j.parameters)==null?void 0:bt.docs,source:{originalSource:`{
  decorators: WithAttachments.decorators,
  args: {
    draft: 'Посмотри изображение',
    attachments: [{
      localId: 'ready-image',
      status: 'ready',
      name: 'готовый-скриншот.png',
      mimeType: 'image/png'
    }]
  }
}`,...(Et=(kt=j.parameters)==null?void 0:kt.docs)==null?void 0:Et.source},description:{story:"Изображение готово и может быть отправлено.",...(Bt=(It=j.parameters)==null?void 0:It.docs)==null?void 0:Bt.description}}};var At,Mt,jt,_t,Rt;_.parameters={..._.parameters,docs:{...(At=_.parameters)==null?void 0:At.docs,source:{originalSource:`{
  args: {
    draft: 'Посмотри изображение',
    onRetryAttachment: fn(),
    attachments: [{
      localId: 'error-image',
      status: 'error',
      name: 'сломанный-скриншот.png',
      mimeType: 'image/png',
      error: 'Не удалось загрузить'
    }]
  }
}`,...(jt=(Mt=_.parameters)==null?void 0:Mt.docs)==null?void 0:jt.source},description:{story:"Ошибка изображения: плитка сохраняется, доступны повтор и удаление.",...(Rt=(_t=_.parameters)==null?void 0:_t.docs)==null?void 0:Rt.description}}};var Dt,qt,Lt,Qt,Nt;R.parameters={...R.parameters,docs:{...(Dt=R.parameters)==null?void 0:Dt.docs,source:{originalSource:`{
  args: {
    draft: 'Три изображения',
    onRetryAttachment: fn(),
    attachments: [{
      localId: 'processing',
      status: 'processing',
      name: 'обработка.png',
      mimeType: 'image/png'
    }, {
      localId: 'ready',
      status: 'ready',
      name: 'готово.png',
      mimeType: 'image/png'
    }, {
      localId: 'error',
      status: 'error',
      name: 'ошибка.png',
      mimeType: 'image/png',
      error: 'Сеть недоступна'
    }]
  }
}`,...(Lt=(qt=R.parameters)==null?void 0:qt.docs)==null?void 0:Lt.source},description:{story:"Смешанные статусы вложений явно блокируют отправку до устранения проблем.",...(Nt=(Qt=R.parameters)==null?void 0:Qt.docs)==null?void 0:Nt.description}}};var Vt,Ht,Pt,Wt,zt;u.parameters={...u.parameters,docs:{...(Vt=u.parameters)==null?void 0:Vt.docs,source:{originalSource:`{
  render: args => <MessageQueueDemo {...args} />,
  args: {
    state: 'thinking',
    queuedTurns,
    onEditQueued: fn(),
    onDeleteQueued: fn(),
    onSendQueuedNow: fn()
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(3);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать ещё 2'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(5);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Отправить сейчас сообщение № 5'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')[0]).toHaveTextContent('Ожидающее сообщение 5');
  }
}`,...(Pt=(Ht=u.parameters)==null?void 0:Ht.docs)==null?void 0:Pt.source},description:{story:"Свёрнутая очередь показывает первые три элемента и счётчик остальных.",...(zt=(Wt=u.parameters)==null?void 0:Wt.docs)==null?void 0:zt.description}}};var Ft,Ut,$t,Ot,Gt;D.parameters={...D.parameters,docs:{...(Ft=D.parameters)==null?void 0:Ft.docs,source:{originalSource:`{
  args: {
    ...MessageQueue.args,
    defaultCollapsed: true,
    allowCollapse: true
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await expect(canvas.queryByLabelText('Поле ввода сообщения')).not.toBeInTheDocument();
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(3);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать ещё 2'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(5);
  }
}`,...($t=(Ut=D.parameters)==null?void 0:Ut.docs)==null?void 0:$t.source},description:{story:"Мобильный дефолт: очередь доступна, хотя само поле ввода свёрнуто.",...(Gt=(Ot=D.parameters)==null?void 0:Ot.docs)==null?void 0:Gt.description}}};var Jt,Kt,Xt,Yt,Zt;q.parameters={...q.parameters,docs:{...(Jt=q.parameters)==null?void 0:Jt.docs,source:{originalSource:`{
  args: {
    ...MessageQueue.args,
    queuePaused: true,
    requestError: 'Движок недоступен'
  }
}`,...(Xt=(Kt=q.parameters)==null?void 0:Kt.docs)==null?void 0:Xt.source},description:{story:"Ошибка текущего хода оставляет ожидающие элементы на явной паузе.",...(Zt=(Yt=q.parameters)==null?void 0:Yt.docs)==null?void 0:Zt.description}}};var ea,ta,aa,sa,ra;L.parameters={...L.parameters,docs:{...(ea=L.parameters)==null?void 0:ea.docs,source:{originalSource:`{
  args: {
    allowCollapse: true,
    defaultCollapsed: true,
    draft: 'Проверь, почему шаг npm test падает только в CI'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(aa=(ta=L.parameters)==null?void 0:ta.docs)==null?void 0:aa.source},description:{story:`Свёрнутый композер — то, с чего чат открывается: поле убрано в строку, в ней
черновик (иначе вложения или состояние хода). Так под ленту сообщений
отдаётся вся высота колонки.`,...(ra=(sa=L.parameters)==null?void 0:sa.docs)==null?void 0:ra.description}}};var na,oa,ia,ca,da;Q.parameters={...Q.parameters,docs:{...(na=Q.parameters)==null?void 0:na.docs,source:{originalSource:`{
  args: {
    allowCollapse: true,
    defaultCollapsed: true,
    state: 'thinking'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(ia=(oa=Q.parameters)==null?void 0:oa.docs)==null?void 0:ia.source},description:{story:"Свёрнут во время хода: кнопка остановки остаётся в строке, а не прячется.",...(da=(ca=Q.parameters)==null?void 0:ca.docs)==null?void 0:da.description}}};var pa,ma,la,ua,ga;N.parameters={...N.parameters,docs:{...(pa=N.parameters)==null?void 0:pa.docs,source:{originalSource:`{
  args: {
    permissionMode: 'acceptEdits',
    onChangePermissionMode: fn()
  }
}`,...(la=(ma=N.parameters)==null?void 0:ma.docs)==null?void 0:la.source},description:{story:"Переключатель режима: план / разработка (в простое активен, в ходе заблокирован).",...(ga=(ua=N.parameters)==null?void 0:ua.docs)==null?void 0:ga.description}}};var ya,ha,va,fa,wa;V.parameters={...V.parameters,docs:{...(ya=V.parameters)==null?void 0:ya.docs,source:{originalSource:`{
  render: () => <PermissionModeFirstSendDemo />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Разработка'
    }));
    await userEvent.click(canvas.getByLabelText('Отправить сообщение'));
    await expect(canvas.getByRole('status')).toHaveTextContent('Первая отправка: Разработка');
  }
}`,...(va=(ha=V.parameters)==null?void 0:ha.docs)==null?void 0:va.source},description:{story:"Выбранный режим разработки применяется уже к первой отправке.",...(wa=(fa=V.parameters)==null?void 0:fa.docs)==null?void 0:wa.description}}};var xa,Sa,Ca,Ta,ba;H.parameters={...H.parameters,docs:{...(xa=H.parameters)==null?void 0:xa.docs,source:{originalSource:`{
  render: () => <ControlledVoiceBar />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByLabelText('Поле ввода сообщения'), 'Проверь гейт пакета ui');
    await userEvent.click(canvas.getByLabelText('Отправить сообщение'));
    await expect(canvas.getByTestId('sent-messages')).toHaveTextContent('Проверь гейт пакета ui');
    await expect(canvas.getByLabelText('Поле ввода сообщения')).toHaveValue('');
  }
}`,...(Ca=(Sa=H.parameters)==null?void 0:Sa.docs)==null?void 0:Ca.source},description:{story:`Отправка сообщения: набрать текст → кнопка микрофона сменилась на «отправить» →
клик отправляет и очищает поле. Enter делает то же (Shift+Enter — перенос).`,...(ba=(Ta=H.parameters)==null?void 0:Ta.docs)==null?void 0:ba.description}}};const ns=["Idle","RestoredDraft390","PastedImage","WithDraft","Listening","ListeningWithoutDiarization","Transcribing","WaitingForModel","ReplyStreaming","Speaking","MicUnavailable","WithAttachments","EmptyCentered","ConversationDocked","Multiline","CappedScroll","Expanded","AttachmentProcessing","AttachmentReady","AttachmentError","AttachmentMixedStatuses","MessageQueue","MessageQueueCollapsedComposer","MessageQueuePausedAfterError","Collapsed","CollapsedWhileThinking","ModeToggle","PermissionModeOnFirstSend","SendMessage"];export{_ as AttachmentError,R as AttachmentMixedStatuses,M as AttachmentProcessing,j as AttachmentReady,B as CappedScroll,L as Collapsed,Q as CollapsedWhileThinking,E as ConversationDocked,k as EmptyCentered,A as Expanded,h as Idle,f as Listening,w as ListeningWithoutDiarization,u as MessageQueue,D as MessageQueueCollapsedComposer,q as MessageQueuePausedAfterError,b as MicUnavailable,N as ModeToggle,I as Multiline,F as PastedImage,V as PermissionModeOnFirstSend,C as ReplyStreaming,z as RestoredDraft390,H as SendMessage,T as Speaking,x as Transcribing,S as WaitingForModel,g as WithAttachments,v as WithDraft,ns as __namedExportsOrder,rs as default};
