import { z } from 'zod'

const id = z.string().trim().min(1).max(256)
/** POSIX paths relative to the working copy; '.' identifies its root. */
export const projectPathSchema = z.string().min(1).max(4096).refine(value =>
  value === '.' || (!value.startsWith('/') && !value.includes('\\') && !/[:\x00-\x1f]/.test(value)
    && value.split('/').every(part => part !== '' && part !== '.' && part !== '..')), 'Expected a relative project path')
export const projectMachineSchema = z.object({
  agentId: id, name: z.string().optional(), online: z.boolean().optional(), canUse: z.boolean().optional(), path: z.string(),
})
export const makeProjectSchema = z.object({
  id, name: z.string(), type: id, gitUrl: z.string().nullable(), hasGit: z.boolean(),
  machines: z.array(projectMachineSchema), defaultAgentId: id.nullable(), role: z.enum(['owner', 'member']),
})
export const projectSubprojectSchema = z.object({
  path: projectPathSchema, name: z.string(), kind: z.enum(['app', 'library', 'storybook', 'other']),
  packageName: z.string().optional(), stories: z.number().int().nonnegative(), styleFiles: z.array(projectPathSchema),
})
export const projectDesignSchema = z.object({
  tokens: z.array(z.object({
    name: z.string().min(1), value: z.string(), file: projectPathSchema, line: z.number().int().positive(),
    theme: z.string().optional(), source: z.enum(['css', 'scss', 'typescript', 'json']),
  })),
  themes: z.array(z.string()),
  components: z.array(z.object({ name: z.string(), kind: z.enum(['story', 'component']), file: projectPathSchema })),
})
const branch = z.string().min(1).max(256).refine(value =>
  !value.startsWith('-') && !value.startsWith('/') && !value.endsWith('/') && !value.endsWith('.')
  && !/[\s~^:?*\[\\\x00-\x1f\x7f]/.test(value) && !value.includes('..') && !value.includes('@{')
  && value !== '@' && value.split('/').every(part => part && !part.startsWith('.') && !part.endsWith('.lock')), 'Invalid branch name')
export const projectGitOperationSchema = z.discriminatedUnion('op', [
  z.object({ op: z.literal('status') }).strict(),
  z.object({ op: z.literal('branches') }).strict(),
  z.object({ op: z.literal('pull') }).strict(),
  z.object({ op: z.literal('commit'), message: z.string().trim().min(1).max(10000), files: z.array(projectPathSchema).min(1) }).strict(),
  z.object({ op: z.literal('push') }).strict(),
  z.object({ op: z.literal('branch'), name: branch }).strict(),
])
export const projectGitResultSchema = z.discriminatedUnion('op', [
  z.object({ op: z.literal('status'), branch: z.string().nullable(), files: z.array(z.object({ path: projectPathSchema, index: z.string(), workingTree: z.string() })), ahead: z.number().int().nonnegative(), behind: z.number().int().nonnegative() }),
  z.object({ op: z.literal('branches'), branches: z.array(z.object({ name: z.string(), current: z.boolean(), remote: z.boolean() })) }),
  z.object({ op: z.literal('commit'), commit: z.string().min(1) }),
  z.object({ op: z.literal('pull'), output: z.string() }),
  z.object({ op: z.literal('push'), output: z.string() }),
  z.object({ op: z.literal('branch'), name: branch }),
])
export const standPreviewOperationSchema = z.discriminatedUnion('op', [
  z.object({ op: z.literal('start'), subprojectPath: projectPathSchema, agentId: id.optional() }).strict(),
  z.object({ op: z.literal('status'), subprojectPath: projectPathSchema }).strict(),
  z.object({ op: z.literal('url'), subprojectPath: projectPathSchema }).strict(),
])
export const standPreviewResultSchema = z.object({
  standId: id.nullable(), status: z.enum(['stopped', 'starting', 'running', 'failed']),
  url: z.url().refine(value => ['http:', 'https:'].includes(new URL(value).protocol)).nullable(), error: z.string().optional(),
})
export const createTransferTaskSchema = z.object({
  targetProjectId: id, targetRepository: z.enum(['core-ui', 'ui-kit']),
  title: z.string().trim().min(1).max(1000), files: z.array(projectPathSchema).min(1), designConversationId: id,
}).strict()
export const transferTaskResultSchema = z.object({ taskId: id, projectId: id })

export type MakeProject = z.infer<typeof makeProjectSchema>
export type ProjectSubproject = z.infer<typeof projectSubprojectSchema>
export type ProjectDesign = z.infer<typeof projectDesignSchema>
export type ProjectGitOperation = z.infer<typeof projectGitOperationSchema>
export type ProjectGitResult = z.infer<typeof projectGitResultSchema>
export type StandPreviewOperation = z.infer<typeof standPreviewOperationSchema>
export type StandPreviewResult = z.infer<typeof standPreviewResultSchema>
export type CreateTransferTaskArgs = z.infer<typeof createTransferTaskSchema>
export type TransferTaskResult = z.infer<typeof transferTaskResultSchema>

/** Core authorizes each call against current membership, machine access and command policy. */
export interface MakeProjectCore {
  listProjects(userId: string): Promise<MakeProject[]>
  projectStructure(userId: string, projectId: string): Promise<ProjectSubproject[]>
  projectDesign(userId: string, projectId: string, subprojectPath: string): Promise<ProjectDesign>
  projectGit(userId: string, projectId: string, operation: ProjectGitOperation): Promise<ProjectGitResult>
  standPreview(userId: string, projectId: string, operation: StandPreviewOperation): Promise<StandPreviewResult>
  createTransferTask(userId: string, args: CreateTransferTaskArgs): Promise<TransferTaskResult>
}

export const projectModeRpcSchemas = {
  listProjects: { args: z.tuple([id]), result: z.array(makeProjectSchema) },
  projectStructure: { args: z.tuple([id, id]), result: z.array(projectSubprojectSchema) },
  projectDesign: { args: z.tuple([id, id, projectPathSchema]), result: projectDesignSchema },
  projectGit: { args: z.tuple([id, id, projectGitOperationSchema]), result: projectGitResultSchema },
  standPreview: { args: z.tuple([id, id, standPreviewOperationSchema]), result: standPreviewResultSchema },
  createTransferTask: { args: z.tuple([id, createTransferTaskSchema]), result: transferTaskResultSchema },
} as const
export type ProjectModeRpcMethod = keyof typeof projectModeRpcSchemas
export function isProjectModeRpcMethod(method: string): method is ProjectModeRpcMethod {
  return Object.prototype.hasOwnProperty.call(projectModeRpcSchemas, method)
}
