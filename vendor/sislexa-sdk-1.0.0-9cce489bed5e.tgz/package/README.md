# Sislexa SDK

Portable operation attribution, normalized usage aggregation and billing contracts.
Run `npm ci` and `npm run gate`; build outputs have no runtime dependencies.

This initial extraction is staged from Core shared contracts. `source-origin.json`
records its immutable source commit and original file hashes. Core remains authoritative
until its adapters switch to this release; do not evolve the two copies separately.

The validators check data shape only. Service callers must derive user and tenant
identity from Identity, authenticate the calling application, and preserve the
origin module across nested calls. Micro-USD amounts use bounded safe integers.
Null policy limits mean unlimited; zero explicitly denies new consumption.
