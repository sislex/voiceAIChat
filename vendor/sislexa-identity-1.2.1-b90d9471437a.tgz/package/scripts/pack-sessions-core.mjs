// Pure session policies must not pull React or database drivers into API builds.
import {cpSync,mkdtempSync,readFileSync,writeFileSync,rmSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {join,resolve} from 'node:path'
import {execFileSync} from 'node:child_process'
const root=resolve(import.meta.dirname,'..'),directory=mkdtempSync(join(tmpdir(),'identity-sessions-'))
try{
 const workspace=join(root,'packages/sessions-core'),source=JSON.parse(readFileSync(join(root,'release-source.json'),'utf8'))
 if(execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()!==source.commit||execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim())throw Error('Pure archives require matching clean source provenance')
 const manifest=JSON.parse(readFileSync(join(workspace,'package.json'),'utf8'))
 cpSync(join(workspace,'src'),join(directory,'src'),{recursive:true})
 cpSync(join(workspace,'tsconfig.json'),join(directory,'tsconfig.json'))
 writeFileSync(join(directory,'vitest.config.ts'),"import {defineConfig} from 'vitest/config'\nexport default defineConfig({test:{include:['src/**/*.test.ts']}})\n")
 writeFileSync(join(directory,'release-source.json'),JSON.stringify(source,null,2)+'\n')
 writeFileSync(join(directory,'package.json'),JSON.stringify({...manifest,name:'@sislexa/identity-sessions-core',exports:{...manifest.exports,'./package.json':'./package.json','./*':'./src/*.ts'},scripts:{typecheck:'tsc --noEmit -p tsconfig.json',test:'vitest run',build:'tsc --noEmit -p tsconfig.json'}},null,2)+'\n')
 execFileSync('npm',['pack','--ignore-scripts','--pack-destination',resolve(process.argv[2]??root)],{cwd:directory,stdio:'inherit'})
}finally{rmSync(directory,{recursive:true,force:true})}
