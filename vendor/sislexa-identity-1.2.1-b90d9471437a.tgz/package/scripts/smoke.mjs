import {spawn} from 'node:child_process'
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs'
import {tmpdir} from 'node:os'
import {resolve,join} from 'node:path'
import {createServer} from 'node:net'
import {once} from 'node:events'
import assert from 'node:assert/strict'
const root=resolve(import.meta.dirname,'..'),data=mkdtempSync(join(tmpdir(),'identity-smoke-'))
const listener=createServer();listener.listen(0,'127.0.0.1');await once(listener,'listening');const port=listener.address().port;await new Promise(resolve=>listener.close(resolve))
const config=join(data,'components.json');writeFileSync(config,JSON.stringify({schemaVersion:1,environmentId:'smoke',registryDirectory:join(data,'provider'),grants:[],legacyScopes:[],dependencies:[]}),{mode:0o600})
const child=spawn(process.execPath,['--import','tsx','apps/server/src/index.ts'],{cwd:root,env:{...process.env,HOST:'127.0.0.1',PORT:String(port),IDENTITY_DATA_DIR:data,IDENTITY_DATABASE_URL:'',IDENTITY_SESSION_SECRET_FILE:'',IDENTITY_ADMIN_PASSWORD:'Smoke-password-937!',SISLEXA_COMPONENT_CONFIG:config},stdio:['ignore','ignore','pipe']})
const base='http://127.0.0.1:'+port;let failure='';child.stderr.on('data',chunk=>{failure+=chunk.toString()})
try{
 let ready=false
 for(let n=0;n<100;n++){
  if(child.exitCode!==null)throw Error('Identity exited before readiness: '+failure)
  try{if((await fetch(base+'/v1/health')).ok){ready=true;break}}catch{}
  await new Promise(resolve=>setTimeout(resolve,100))
 }
 assert.ok(ready,'Identity did not start')
 for(const route of ['/login/','/account/']){
  const response=await fetch(base+route);assert.equal(response.status,200)
  const html=await response.text();const asset=html.match(/src="([^"]+\.js)"/)?.[1];assert.ok(asset)
  const js=await fetch(base+asset);assert.equal(js.status,200);assert.match(js.headers.get('content-type'),/javascript/)
 }
 const login=await fetch(base+'/api/session/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:'admin',password:'Smoke-password-937!'})})
 assert.equal(login.status,200);const {token}=await login.json()
 const me=await fetch(base+'/api/session/me',{headers:{authorization:'Bearer '+token}});assert.equal((await me.json()).user.name,'admin')
 const denied=await fetch(base+'/v1/identity/store',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({method:'listUsers',args:[]})});assert.equal(denied.status,401)
 console.log('Standalone Identity process, assets, login and RPC protection passed')
}finally{
 child.kill('SIGTERM');await Promise.race([once(child,'exit'),new Promise(resolve=>setTimeout(resolve,5000))]);if(child.exitCode===null)child.kill('SIGKILL');rmSync(data,{recursive:true,force:true})
}
