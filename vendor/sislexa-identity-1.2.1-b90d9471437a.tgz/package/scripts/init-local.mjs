import {mkdirSync,writeFileSync} from 'node:fs'
import {resolve,join} from 'node:path'
const directory=resolve(process.argv[2]??'data')
mkdirSync(directory,{recursive:true,mode:0o700})
const config={schemaVersion:1,environmentId:'local-identity',registryDirectory:join(directory,'provider'),grants:[],legacyScopes:[],dependencies:[]}
const file=join(directory,'components.json')
writeFileSync(file,JSON.stringify(config,null,2)+'\n',{mode:0o600,flag:'wx'})
console.log('Created local Identity configuration: '+file)
