import type { ProjectFeature } from '@voicechat/shared'
import type { IdentityRepo } from './store/identity.js'
export type IdentityStore = Pick<IdentityRepo, keyof IdentityRepo>
export interface IdentityCore {
 settings: {
  getAppConfig(key: string): Promise<string | null>
  getSettings(user: string): Promise<{ loginNewDeviceEmails?: boolean }>
 }
 projects: {
  isProjectOwner(user: string, project: string): Promise<boolean>
  projectFeatures(project: string): Promise<Record<ProjectFeature, boolean>>
  attachInvitationsToNewUser(user: string, email: string): Promise<unknown>
 }
}
export interface AuthDatabase extends IdentityCore { identity: IdentityStore }
