import {afterEach,describe,expect,it} from 'vitest'
import {openIdentityStore} from './store/open.js'
import {buildIdentityServer} from './server.js'
import {IDENTITY_PATHS} from '@voicechat/identity-contracts'
import {createIdentityStoreClient} from '../../../packages/client/src/rpc.js'
const dispose:Array<()=>Promise<unknown>>=[]
afterEach(async()=>{for(const close of dispose.splice(0).reverse())await close()})
async function fixture(){
 const cleanup={chat:{deleteConversationsOfUser:async()=>{}},machines:{deleteAgentsOfUser:async()=>{}},settings:{deleteUserSettings:async()=>{}},tasks:{unassignUser:async()=>{}},projects:{detachDeletedUser:async()=>{}}}
 const storage=await openIdentityStore({filename:':memory:',cleanup});dispose.push(storage.close)
 await storage.store.ensureAdmin('Test-password-947!')
 const database={identity:storage.store,settings:{getAppConfig:async()=>null,getSettings:async()=>({})},projects:{isProjectOwner:async()=>false,projectFeatures:async()=>({} as never),attachInvitationsToNewUser:async()=>{}}}
 const {app}=await buildIdentityServer({database,secret:'identity-test-secret',authorize:(header,scope)=>header==='Bearer core-grant'?{ok:true}:header==='Bearer wrong-scope'?{ok:false,status:403}:{ok:false,status:401}})
 dispose.push(()=>app.close());return {app,storage}
}
async function login(app:Awaited<ReturnType<typeof fixture>>['app']){
 const r=await app.inject({method:'POST',url:'/api/session/login',payload:{name:'admin',password:'Test-password-947!'}})
 expect(r.statusCode).toBe(200);return r
}
describe('independent Identity boundary',()=>{
 it('preserves populated and empty session activity through JSON and the real client',async()=>{
  const {app,storage}=await fixture()
  const fetchImpl:typeof fetch=async(input,init)=>{
   const request=new Request(input,init)
   const response=await app.inject({method:'POST',url:new URL(request.url).pathname,headers:Object.fromEntries(request.headers),payload:await request.text()})
   return new Response(response.body,{status:response.statusCode})
  }
  const remote=createIdentityStoreClient({url:'http://identity.test',token:'core-grant',fetchImpl})
  expect(await remote.sessionActivity()).toEqual(new Map())
  await login(app)
  const at=Date.now(),expected=await storage.store.sessionActivity(at)
  expect(expected.get('admin')?.live).toBe(1)
  const actual=await remote.sessionActivity(at)
  expect(actual).toEqual(expected)
  expect(actual.get('admin')).toEqual(expected.get('admin'))
  expect(await remote.getUser('missing-user')).toBeNull()
  expect(await remote.listUsers()).toHaveLength(1)
 })
 it('refuses lossy or malformed activity responses from incompatible providers',async()=>{
  for(const result of [{},null,[['admin',{lastSeen:1,live:'1'}]],[['admin',{lastSeen:null,live:1}]]]){
   const remote=createIdentityStoreClient({url:'http://identity.test',token:'core-grant',fetchImpl:async()=>Response.json({result})})
   await expect(remote.sessionActivity()).rejects.toMatchObject({statusCode:503})
  }
 })
 it('owns its schema and rejects absent or insufficient component grants',async()=>{
  const {app,storage}=await fixture()
  const tables=await storage.sql.all<{name:string}>("SELECT name FROM sqlite_master WHERE type='table'")
  expect(tables.some(t=>t.name==='users')).toBe(true);expect(tables.some(t=>t.name==='conversations')).toBe(false)
  for(const [authorization,status]of [['',401],['Bearer wrong-scope',403]]as const){const r=await app.inject({method:'POST',url:IDENTITY_PATHS.store,headers:{authorization},payload:{method:'getUser',args:['admin']}});expect(r.statusCode).toBe(status)}
  const r=await app.inject({method:'POST',url:IDENTITY_PATHS.store,headers:{authorization:'Bearer core-grant'},payload:{method:'constructor',args:[]}});expect(r.statusCode).toBe(400)
 })
 it('proxies login cookies and keeps cookie mutations protected by CSRF',async()=>{
  const {app}=await fixture()
  const r=await app.inject({method:'POST',url:IDENTITY_PATHS.session,headers:{authorization:'Bearer core-grant'},payload:{method:'POST',url:'/api/session/login',corsAllowed:true,ip:'203.0.113.8',headers:{'content-type':'application/json',host:'identity.example','x-forwarded-proto':'https'},body:{name:'admin',password:'Test-password-947!'}}})
  expect(r.statusCode).toBe(200);const result=r.json();expect(result.status).toBe(200)
  const cookies=result.headers['set-cookie'] as string[];expect(cookies.some(c=>c.includes('HttpOnly'))).toBe(true)
  expect(cookies.some(c=>c.includes('SameSite=None'))).toBe(true)
  const publicLogin=await app.inject({method:'POST',url:'/api/session/login',headers:{'x-forwarded-proto':'https','x-identity-forwarded-request':'true'},payload:{name:'admin',password:'Test-password-947!'}})
  expect(([] as string[]).concat(publicLogin.headers['set-cookie'] as string[]).some(c=>c.includes('SameSite=None'))).toBe(false)
  const cookie=cookies.map(c=>c.split(';')[0]).join('; ')
  const denied=await app.inject({method:'POST',url:'/api/session/logout',headers:{cookie}});expect(denied.statusCode).toBe(403)
  const csrf=JSON.parse(result.body).csrf
  const allowed=await app.inject({method:'POST',url:'/api/session/logout',headers:{cookie,'x-vc-csrf':csrf}});expect(allowed.statusCode).toBe(200)
 })
 it('verifies every user request and rejects revoked sessions immediately',async()=>{
  const {app}=await fixture(),r=await login(app),token=r.json().token
  const verify=()=>app.inject({method:'POST',url:IDENTITY_PATHS.verify,headers:{authorization:'Bearer core-grant'},payload:{request:{method:'GET',url:'/api/conversations',headers:{authorization:'Bearer '+token}}}})
  expect((await verify()).json()).toMatchObject({ok:true,user:{name:'admin'}})
  expect((await app.inject({method:'POST',url:'/api/session/logout',headers:{authorization:'Bearer '+token}})).statusCode).toBe(200)
  expect((await verify()).json()).toMatchObject({ok:false,status:401})
  const events=await app.inject({url:IDENTITY_PATHS.events,headers:{authorization:'Bearer core-grant'}})
  expect(events.json().events.some((e:{revokedSid?:string})=>e.revokedSid)).toBe(true)
 })
 it('never injects arbitrary URLs through the session proxy',async()=>{
  const {app}=await fixture();for(const url of ['/api/admin/users','/v1/identity/store','https://evil.example/api/session/login']){const r=await app.inject({method:'POST',url:IDENTITY_PATHS.session,headers:{authorization:'Bearer core-grant'},payload:{method:'POST',url,ip:'127.0.0.1',headers:{}}});expect(r.statusCode).toBe(400)}
 })
})
