import { afterEach, expect, it } from 'vitest'
import { REST } from '@voicechat/shared'
import { buildIdentityServer } from '../server.js'
import { openIdentityStore } from '../store/open.js'
import { IDENTITY_PATHS } from '@voicechat/identity-contracts'

const disposers: Array<() => Promise<unknown>> = []
afterEach(async () => { for (const dispose of disposers.splice(0).reverse()) await dispose() })
async function fixture() {
  const storage = await openIdentityStore({ filename: ':memory:', cleanup: {
    chat: { deleteConversationsOfUser: async () => {} }, machines: { deleteAgentsOfUser: async () => {} },
    settings: { deleteUserSettings: async () => {} }, tasks: { unassignUser: async () => {} }, projects: { detachDeletedUser: async () => {} }
  } })
  disposers.push(storage.close)
  for (const [name, role] of [['admin', 'admin'], ['alice', 'observer'], ['bob', 'tester']] as const) await storage.store.createUser(name, 'Fixture-password-937!', role)
  const { app } = await buildIdentityServer({ secret: 'test-secret', database: {
    identity: storage.store, settings: { getAppConfig: async () => null, getSettings: async () => ({}) },
    projects: { isProjectOwner: async () => false, projectFeatures: async () => ({} as never), attachInvitationsToNewUser: async () => {} }
  }, authorize: header => header === 'Bearer core-grant' ? { ok: true } : { ok: false, status: 401 } })
  disposers.push(() => app.close())
  app.get('/api/make/work', async request => ({ user: request.user }))
  const login = async (name: string) => {
    const response = await app.inject({ method: 'POST', url: REST.sessionLogin, payload: { name, password: 'Fixture-password-937!' } })
    expect(response.statusCode).toBe(200)
    return { headers: { authorization: 'Bearer ' + response.json().token }, body: response.json(), cookie: ([] as string[]).concat(response.headers['set-cookie'] as string[]).map(value => value.split(';')[0]).join('; ') }
  }
  return { app, storage, admin: await login('admin'), alice: await login('alice'), bob: await login('bob') }
}

it('requires a user and system administrator for tariff mutations and protects cookies with CSRF', async () => {
  const { app, admin, alice } = await fixture()
  const plan = { id: 'chat', name: 'Chat', capabilities: ['chat.use'] }
  for (const [headers, status] of [[{}, 401], [{ authorization: 'Bearer core-grant' }, 401], [alice.headers, 403]] as const) {
    expect((await app.inject({ method: 'POST', url: REST.sessionTariffs, headers, payload: plan })).statusCode).toBe(status)
  }
  expect((await app.inject({ method: 'POST', url: REST.sessionTariffs, headers: { cookie: admin.cookie }, payload: plan })).statusCode).toBe(403)
  expect((await app.inject({ method: 'POST', url: REST.sessionTariffs, headers: { cookie: admin.cookie, 'x-vc-csrf': admin.body.csrf }, payload: plan })).statusCode).toBe(201)
  expect((await app.inject({ method: 'POST', url: REST.sessionTariffs, headers: admin.headers, payload: { ...plan, id: 'bad', role: 'admin' } })).statusCode).toBe(400)
  expect((await app.inject({ method: 'POST', url: REST.sessionTariffs, headers: admin.headers, payload: { ...plan, id: 'bad', capabilities: ['identity.store'] } })).statusCode).toBe(400)
})

it('derives the personal tenant from authentication and refuses a different tenant hint', async () => {
  const { app, alice, bob } = await fixture()
  const own = await app.inject({ url: REST.sessionAccountAccess + '?userName=bob', headers: alice.headers })
  expect(own.json()).toMatchObject({ userName: 'alice', systemRole: 'observer', tenant: { owner: 'alice', id: alice.body.user.account.tenantId } })
  expect(alice.body.user.account.tenantId).not.toBe(bob.body.user.account.tenantId)
  for (const url of [REST.sessionAccountAccess, '/api/make/work']) {
    const response = await app.inject({ url, headers: { ...alice.headers, 'x-sislexa-tenant-id': bob.body.user.account.tenantId } })
    expect(response.statusCode).toBe(403)
    expect(response.json().error).toBe('tenant_not_allowed')
  }
})

it('applies changed capabilities immediately to direct and delegated requests without changing roles or other users', async () => {
  const { app, storage, admin, alice, bob } = await fixture()
  await app.inject({ method: 'POST', url: REST.sessionTariffs, headers: admin.headers, payload: { id: 'chat', name: 'Chat', capabilities: ['chat.use'] } })
  const assignment = await app.inject({ method: 'PUT', url: REST.sessionTariffAssignment('alice'), headers: admin.headers, payload: { tariffId: 'chat' } })
  expect(assignment.statusCode).toBe(200)
  expect(assignment.json()).toMatchObject({ systemRole: 'observer', capabilities: ['chat.use'] })
  expect((await app.inject({ url: '/api/make/work', headers: alice.headers })).statusCode).toBe(403)
  expect((await app.inject({ url: '/api/make/work', headers: bob.headers })).statusCode).toBe(200)
  const delegated = await app.inject({ method: 'POST', url: IDENTITY_PATHS.verify, headers: { authorization: 'Bearer core-grant' }, payload: { request: { method: 'GET', url: '/api/make/work', headers: alice.headers } } })
  expect(delegated.json()).toMatchObject({ ok: false, status: 403, error: 'capability_unavailable' })
  const update = { id: 'chat', name: 'Make access', capabilities: ['make.use'], expectedRevision: 1 }
  expect((await app.inject({ method: 'PUT', url: REST.sessionTariff('chat'), headers: admin.headers, payload: update })).statusCode).toBe(200)
  expect((await app.inject({ method: 'PUT', url: REST.sessionTariff('chat'), headers: admin.headers, payload: update })).statusCode).toBe(409)
  const permitted = await app.inject({ url: '/api/make/work', headers: alice.headers })
  expect(permitted.statusCode).toBe(200)
  expect(permitted.json().user).toMatchObject({ role: 'observer', account: { tariffId: 'chat', tariffRevision: 2, capabilities: ['make.use'] } })
  expect(await storage.store.getUser('alice')).toMatchObject({ role: 'observer' })
  const events = await app.inject({ url: IDENTITY_PATHS.events, headers: { authorization: 'Bearer core-grant' } })
  expect(events.json().events.filter((event: { user: string }) => event.user === 'alice').length).toBeGreaterThanOrEqual(2)
})

it('keeps administration available on an empty tariff but never bypasses product restrictions for an admin', async () => {
  const { app, admin } = await fixture()
  await app.inject({ method: 'POST', url: REST.sessionTariffs, headers: admin.headers, payload: { id: 'empty', name: 'Empty', capabilities: [] } })
  await app.inject({ method: 'PUT', url: REST.sessionTariffAssignment('admin'), headers: admin.headers, payload: { tariffId: 'empty' } })
  expect((await app.inject({ url: '/api/make/work', headers: admin.headers })).statusCode).toBe(403)
  expect((await app.inject({ url: REST.sessionTariffs, headers: admin.headers })).statusCode).toBe(200)
  expect((await app.inject({ method: 'PUT', url: REST.sessionTariffAssignment('admin'), headers: admin.headers, payload: { tariffId: 'standard' } })).statusCode).toBe(200)
})
