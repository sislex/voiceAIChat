import type { Sql } from '@voicechat/storage-sql/types'
export interface IdentityContext {
 sql: Sql; newId: () => string; now: () => number; closed: boolean
 repos: {
  chat: { deleteConversationsOfUser(user: string): Promise<void> }
  machines: { deleteAgentsOfUser(user: string): Promise<void> }
  settings: { deleteUserSettings(user: string): Promise<void> }
  tasks: { unassignUser(user: string): Promise<void> }
  projects: { detachDeletedUser(user: string, email: string): Promise<void> }
 }
}
export abstract class BaseRepo {
 protected readonly sql: Sql; protected readonly newId: () => string; protected readonly now: () => number
 constructor(private readonly ctx: IdentityContext) { this.sql=ctx.sql; this.newId=ctx.newId; this.now=ctx.now }
 protected get closed() { return this.ctx.closed }
 protected get repos() { return this.ctx.repos }
}
