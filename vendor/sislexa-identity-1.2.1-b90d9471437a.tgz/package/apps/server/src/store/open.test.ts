import {expect,it,vi} from 'vitest'
import {openIdentityStore} from './open.js'
it('keeps an account quarantined when remote cleanup fails and allows a safe retry',async()=>{
 const fail=vi.fn().mockRejectedValueOnce(Error('Core is unavailable')).mockResolvedValue(undefined)
 const cleanup={chat:{deleteConversationsOfUser:fail},machines:{deleteAgentsOfUser:async()=>{}},settings:{deleteUserSettings:async()=>{}},tasks:{unassignUser:async()=>{}},projects:{detachDeletedUser:async()=>{}}}
 const storage=await openIdentityStore({filename:':memory:',cleanup})
 try{
  await storage.store.createUser('alice','Test-password-947!','developer')
  await expect(storage.store.deleteUserData('alice')).rejects.toThrow('Core is unavailable')
  expect(await storage.store.getUser('alice')).toMatchObject({blocked:true})
  await storage.store.deleteUserData('alice');expect(await storage.store.getUser('alice')).toBeNull()
 }finally{await storage.close()}
})
