import { DEFAULT_TARIFF_ID, PRODUCT_CAPABILITIES } from '@voicechat/shared'
import type { Sql } from '@voicechat/storage-sql/types'

export async function seedDefaultTariff(sql: Sql, now: number): Promise<void> {
  // Never replace an administrator's later edits when a process restarts.
  await sql.run(`INSERT OR IGNORE INTO tariff_plans
    (id, name, capabilities, revision, created_at, updated_at) VALUES (?, ?, ?, 1, ?, ?)`,
  [DEFAULT_TARIFF_ID, 'Стандартный', JSON.stringify(PRODUCT_CAPABILITIES), now, now])
}

/** The caller's transaction includes user creation and all account relationships. */
export async function ensurePersonalTenant(sql: Sql, user: string, createdAt: number, newId: () => string): Promise<string> {
  await sql.run(`INSERT OR IGNORE INTO identity_subjects (id, user_name, created_at)
    VALUES (?, ?, ?)`, [newId(), user, createdAt])
  await seedDefaultTariff(sql, createdAt)
  await sql.run(`INSERT OR IGNORE INTO tenants (id, kind, owner_user_name, name, created_at)
    VALUES (?, 'personal', ?, ?, ?)`, [newId(), user, user, createdAt])
  const tenant = await sql.get<{ id: string }>('SELECT id FROM tenants WHERE owner_user_name = ?', [user])
  if (!tenant) throw new Error('Personal tenant provisioning failed')
  await sql.run(`INSERT OR IGNORE INTO tenant_memberships (tenant_id, user_name, role, created_at)
    VALUES (?, ?, 'owner', ?)`, [tenant.id, user, createdAt])
  await sql.run(`INSERT OR IGNORE INTO tenant_tariffs (tenant_id, tariff_id, updated_at)
    VALUES (?, ?, ?)`, [tenant.id, DEFAULT_TARIFF_ID, createdAt])
  return tenant.id
}

/** Add missing relationships only; both SQLite and PostgreSQL use the same migration. */
export async function initializePersonalTenants(sql: Sql, now: () => number, newId: () => string): Promise<void> {
  await sql.transaction(async () => {
    await seedDefaultTariff(sql, now())
    // A stable lock order avoids competing initializers locking users in opposite order.
    const users = await sql.all<{ name: string; created_at: number }>('SELECT name, created_at FROM users ORDER BY name')
    for (const user of users) await ensurePersonalTenant(sql, user.name, user.created_at, newId)
  })
}
