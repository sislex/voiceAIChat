import { isProductCapability, validTariffPlanInput } from '@voicechat/shared'
import type { AccountAccess, ProductCapability, TariffAssignment, TariffPlan, TariffPlanInput, SystemRole } from '@voicechat/shared'
import type { Sql } from '@voicechat/storage-sql/types'

interface PlanRow {
  id: string; name: string; capabilities: string; revision: number; created_at: number; updated_at: number
}
const failure = (statusCode: number, message: string): Error => Object.assign(new Error(message), { statusCode })
function planOf(row: PlanRow): TariffPlan {
  const capabilities: unknown = JSON.parse(row.capabilities)
  if (!Array.isArray(capabilities) || !capabilities.every(isProductCapability) || new Set(capabilities).size !== capabilities.length) {
    throw new Error('Invalid stored tariff capabilities')
  }
  return { id: row.id, name: row.name, capabilities: capabilities as ProductCapability[], revision: row.revision, createdAt: row.created_at, updatedAt: row.updated_at }
}

/** Identity is the only writer; callers still need their own user/admin authentication. */
export class TariffStore {
  constructor(private readonly sql: Sql, private readonly now: () => number) {}

  async getAccess(userName: string): Promise<AccountAccess | null> {
    const row = await this.sql.get<PlanRow & {
      user_id: string; system_role: SystemRole; tenant_id: string; tenant_name: string; tenant_created_at: number
    }>(`SELECT p.*, s.id AS user_id, u.role AS system_role, t.id AS tenant_id, t.name AS tenant_name,
      t.created_at AS tenant_created_at FROM users u
      JOIN identity_subjects s ON s.user_name = u.name
      JOIN tenants t ON t.owner_user_name = u.name AND t.kind = 'personal'
      JOIN tenant_memberships m ON m.tenant_id = t.id AND m.user_name = u.name AND m.role = 'owner'
      JOIN tenant_tariffs a ON a.tenant_id = t.id
      JOIN tariff_plans p ON p.id = a.tariff_id WHERE u.name = ?`, [userName])
    if (!row) return null
    const tariff = planOf(row)
    return { userId: row.user_id, userName, systemRole: row.system_role,
      tenant: { id: row.tenant_id, kind: 'personal', name: row.tenant_name, owner: userName, createdAt: row.tenant_created_at },
      tariff, capabilities: [...tariff.capabilities] }
  }

  async listPlans(): Promise<TariffPlan[]> {
    return (await this.sql.all<PlanRow>('SELECT * FROM tariff_plans ORDER BY id')).map(planOf)
  }

  async savePlan(input: TariffPlanInput): Promise<TariffPlan> {
    if (!validTariffPlanInput(input)) throw failure(400, 'invalid_tariff')
    return this.sql.transaction(async () => {
      const now = this.now(), capabilities = JSON.stringify(input.capabilities)
      const result = input.expectedRevision === undefined
        ? await this.sql.run(`INSERT OR IGNORE INTO tariff_plans (id, name, capabilities, revision, created_at, updated_at)
          VALUES (?, ?, ?, 1, ?, ?)`, [input.id, input.name.trim(), capabilities, now, now])
        : await this.sql.run(`UPDATE tariff_plans SET name = ?, capabilities = ?, revision = revision + 1, updated_at = ?
          WHERE id = ? AND revision = ?`, [input.name.trim(), capabilities, now, input.id, input.expectedRevision])
      if (result.changes !== 1) throw failure(409, 'tariff_revision_conflict')
      return planOf((await this.sql.get<PlanRow>('SELECT * FROM tariff_plans WHERE id = ?', [input.id]))!)
    })
  }

  async listAssignments(): Promise<TariffAssignment[]> {
    const rows = await this.sql.all<{ user_name: string; role: SystemRole; tenant_id: string; tariff_id: string }>(
      `SELECT u.name AS user_name, u.role, t.id AS tenant_id, a.tariff_id FROM users u
       JOIN tenants t ON t.owner_user_name = u.name JOIN tenant_tariffs a ON a.tenant_id = t.id ORDER BY u.name`)
    return rows.map(row => ({ userName: row.user_name, systemRole: row.role, tenantId: row.tenant_id, tariffId: row.tariff_id }))
  }

  async assign(userName: string, tariffId: string): Promise<AccountAccess> {
    return this.sql.transaction(async () => {
      const current = await this.getAccess(userName)
      if (!current) throw failure(404, 'account_not_found')
      if (!await this.sql.get('SELECT id FROM tariff_plans WHERE id = ?', [tariffId])) throw failure(404, 'tariff_not_found')
      await this.sql.run('UPDATE tenant_tariffs SET tariff_id = ?, updated_at = ? WHERE tenant_id = ?', [tariffId, this.now(), current.tenant.id])
      // Role, membership and existing per-user spend limits are deliberately untouched.
      return (await this.getAccess(userName))!
    })
  }
}
