export const IDENTITY_TABLES = ["users", "identity_subjects", "email_verifications", "password_reset_tokens", "invites", "security_events", "login_device_emails", "sessions", "session_revocations", "user_llm_access", "tenants", "tenant_memberships", "tariff_plans", "tenant_tariffs"] as const
export const IDENTITY_SCHEMA = `
CREATE TABLE IF NOT EXISTS users (
  name          TEXT PRIMARY KEY,
  password_hash TEXT NOT NULL,
  role          TEXT NOT NULL,
  blocked       INTEGER NOT NULL DEFAULT 0,
  created_at    INTEGER NOT NULL,
  failed_logins INTEGER NOT NULL DEFAULT 0,
  locked_until INTEGER,
  lock_reason TEXT,
  totp_secret TEXT,
  reset_code_hash TEXT,
  reset_code_expires INTEGER,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  last_login INTEGER,
  notices_seen_at INTEGER NOT NULL DEFAULT 0,
  llm_limit_usd REAL,
  email TEXT
);
-- Stable accounting identity is independent of the legacy login-name primary key.
CREATE TABLE IF NOT EXISTS identity_subjects (
  id TEXT PRIMARY KEY,
  user_name TEXT NOT NULL UNIQUE,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (user_name) REFERENCES users(name) ON UPDATE CASCADE ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS email_verifications (
  token_hash TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_email_verifications_email ON email_verifications(email);
CREATE TABLE IF NOT EXISTS password_reset_tokens (
  token_hash TEXT PRIMARY KEY,
  user_name TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user ON password_reset_tokens(user_name);
CREATE TABLE IF NOT EXISTS invites (
  token TEXT PRIMARY KEY,
  role TEXT NOT NULL,
  created_by TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  max_uses INTEGER NOT NULL DEFAULT 1,
  uses INTEGER NOT NULL DEFAULT 0,
  note TEXT NOT NULL DEFAULT '',
  email TEXT,
  emailed_at INTEGER
);
CREATE TABLE IF NOT EXISTS security_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  at INTEGER NOT NULL,
  user_name TEXT NOT NULL,
  type TEXT NOT NULL,
  ip TEXT NOT NULL DEFAULT '',
  user_agent TEXT NOT NULL DEFAULT '',
  details TEXT NOT NULL DEFAULT '',
  -- Сессия, к которой относится событие. По ней строится история устройства:
  -- пара «User-Agent + адрес» рвётся при смене сети и склеивает разные входы.
  session_sid TEXT
);
CREATE INDEX IF NOT EXISTS idx_security_events_user ON security_events(user_name, at DESC);
CREATE TABLE IF NOT EXISTS login_device_emails (
  user_name TEXT NOT NULL,
  ip TEXT NOT NULL,
  user_agent TEXT NOT NULL,
  sent_at INTEGER NOT NULL,
  PRIMARY KEY (user_name, ip, user_agent)
);
CREATE TABLE IF NOT EXISTS sessions (
  sid TEXT PRIMARY KEY,
  user_name TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  ip TEXT NOT NULL DEFAULT '',
  user_agent TEXT NOT NULL DEFAULT '',
  revoked_at INTEGER,
  -- Метаданные устройства: имя от пользователя, ключ устройства (доверие и
  -- распознавание нового входа), место по адресу и грубая мера активности.
  label TEXT,
  device_key TEXT,
  trusted_at INTEGER,
  platform TEXT,
  client_version TEXT,
  geo TEXT,
  requests INTEGER NOT NULL DEFAULT 0,
  last_path TEXT,
  -- Почему сессия закончилась: revoked | evicted | panic | logout_all | admin | stale.
  end_reason TEXT,
  -- SHA-256 секрета устройства из cookie vc_device: доверие привязано к нему, а
  -- не к угадываемым свойствам запроса (User-Agent и подсеть подделываются).
  device_secret TEXT,
  -- Подтверждали ли этот вход вторым фактором. Доверять можно только такой
  -- сессии: иначе доверие выдаётся входу, который сам проверку не проходил.
  two_factor INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_name);
CREATE INDEX IF NOT EXISTS idx_sessions_live ON sessions(revoked_at, expires_at, user_name);
CREATE TABLE IF NOT EXISTS session_revocations (
  token_hash TEXT PRIMARY KEY,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user_llm_access (
  user_name TEXT NOT NULL,
  provider  TEXT NOT NULL,
  model_id  TEXT NOT NULL,
  PRIMARY KEY (user_name, provider, model_id),
  FOREIGN KEY (user_name) REFERENCES users(name) ON DELETE CASCADE
);

-- Product entitlements do not change users.role or provider token grants.
CREATE TABLE IF NOT EXISTS tariff_plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  capabilities TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1 CHECK(revision > 0),
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tenants (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK(kind = 'personal'),
  owner_user_name TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  FOREIGN KEY (owner_user_name) REFERENCES users(name) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS tenant_memberships (
  tenant_id TEXT NOT NULL,
  user_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role = 'owner'),
  created_at INTEGER NOT NULL,
  PRIMARY KEY (tenant_id, user_name),
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (user_name) REFERENCES users(name) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tenant_memberships_user ON tenant_memberships(user_name);
CREATE TABLE IF NOT EXISTS tenant_tariffs (
  tenant_id TEXT PRIMARY KEY,
  tariff_id TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
  FOREIGN KEY (tariff_id) REFERENCES tariff_plans(id)
);
CREATE INDEX IF NOT EXISTS idx_tenant_tariffs_plan ON tenant_tariffs(tariff_id);
`
