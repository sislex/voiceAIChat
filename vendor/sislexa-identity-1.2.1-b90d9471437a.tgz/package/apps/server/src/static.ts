import {readFile} from 'node:fs/promises'
import {resolve,extname,sep} from 'node:path'
import type {FastifyInstance} from 'fastify'
export function registerIdentityAssets(app:FastifyInstance,root:string){
 for(const name of ['login','account']){
  const directory=resolve(root,name,'dist')
  const serve=async(req:import('fastify').FastifyRequest,reply:import('fastify').FastifyReply)=>{
   let relative:string;try{relative=decodeURIComponent(req.url.split('?')[0]!.slice(name.length+2))}catch{return reply.code(400).send()}
   const path=resolve(directory,relative||'index.html')
   if(!path.startsWith(directory+sep))return reply.code(404).send()
   try{const data=await readFile(path);const type:Record<string,string>={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.svg':'image/svg+xml','.woff2':'font/woff2'};return reply.type(type[extname(path)]??'application/octet-stream').header('cache-control',extname(path)==='.html'?'no-cache':'public,max-age=86400').send(data)}catch{return reply.code(404).send()}
  }
  app.get('/'+name+'/',serve);app.get('/'+name+'/*',serve)
 }
}
