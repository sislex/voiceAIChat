import {defineConfig} from 'vitest/config'
import react from '@vitejs/plugin-react'
import {sharedSource} from '../../scripts/shared-path.mjs'
export default defineConfig({plugins:[react()],resolve:{alias:[{find:/^@shared\//,replacement:sharedSource()}]},test:{environment:'node',globals:true,include:['src/**/*.test.{ts,tsx}']}})
