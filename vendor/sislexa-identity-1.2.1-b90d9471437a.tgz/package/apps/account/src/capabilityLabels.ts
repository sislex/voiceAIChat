import type { ProductCapability, SystemRole } from '@voicechat/shared'

export const capabilityLabels: Record<ProductCapability, string> = {
  'chat.use': 'Чат', 'make.use': 'Make', 'web-reader.use': 'Web Reader',
  'playwright-reader.use': 'Playwright Reader', 'image-studio.use': 'Image Studio',
  'voice.stt': 'Распознавание речи', 'voice.tts': 'Озвучивание',
  'projects.use': 'Проекты', 'machines.use': 'Машины'
}
export const roleLabels: Record<SystemRole, string> = {
  admin: 'Администратор', developer: 'Разработчик', tester: 'Тестировщик', observer: 'Наблюдатель'
}
