import './tariffs.css'
import { useEffect, useState } from 'react'
import { Button, Dialog, ErrorState } from '@voicechat/ui-kit'
import { PRODUCT_CAPABILITIES, type AccountTariffClient, type TariffPlan, type TariffPlanInput, type TariffAssignment } from '@voicechat/shared'
import { capabilityLabels, roleLabels } from './capabilityLabels'

const emptyPlan = (): TariffPlanInput => ({ id: '', name: '', capabilities: [] })

export default function TariffAdminDialog({ client, onChanged, onClose }: { client: AccountTariffClient; onChanged: () => void; onClose: () => void }): JSX.Element {
  const [plans, setPlans] = useState<TariffPlan[]>([])
  const [assignments, setAssignments] = useState<TariffAssignment[]>([])
  const [draft, setDraft] = useState<TariffPlanInput>(emptyPlan)
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [status, setStatus] = useState('')
  const [reload, setReload] = useState(0)
  useEffect(() => {
    let disposed = false
    setLoading(true)
    void Promise.all([client.listPlans(), client.listAssignments()]).then(([nextPlans, nextAssignments]) => {
      if (!disposed) { setPlans(nextPlans); setAssignments(nextAssignments); setError('') }
    }).catch(reason => { if (!disposed) setError(reason instanceof Error ? reason.message : String(reason)) })
      .finally(() => { if (!disposed) setLoading(false) })
    return () => { disposed = true }
  }, [client, reload])
  const mutate = async (operation: () => Promise<void>, message: string) => {
    setBusy(true); setError(''); setStatus('')
    try { await operation(); setStatus(message); onChanged() }
    catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)) }
    finally { setBusy(false) }
  }
  const selectPlan = (id: string) => {
    const plan = plans.find(value => value.id === id)
    setDraft(plan ? { id: plan.id, name: plan.name, capabilities: [...plan.capabilities], expectedRevision: plan.revision } : emptyPlan())
    setStatus('')
  }
  return <Dialog title="Управление тарифами" size="lg" padded closeOnOverlay={false} onClose={busy ? undefined : onClose}>
    <div className="tariff-admin">
      <p>Тариф определяет доступные модули. Системная роль пользователя задаётся отдельно.</p>
      {error && <ErrorState message="Не удалось выполнить операцию" detail={error} onRetry={() => { setDraft(emptyPlan()); setReload(value => value + 1) }} />}
      {status && <p role="status">{status}</p>}
      {loading && <p role="status">Загружаю тарифы и пользователей…</p>}
      <fieldset disabled={loading || busy}>
        <legend>Тарифы</legend>
        <label>Редактируемый тариф<select value={draft.expectedRevision === undefined ? '' : draft.id} onChange={event => selectPlan(event.target.value)}><option value="">Новый тариф</option>{plans.map(plan => <option key={plan.id} value={plan.id}>{plan.name}</option>)}</select></label>
        <form onSubmit={event => { event.preventDefault(); void mutate(async () => {
          const saved = await client.savePlan({ ...draft, name: draft.name.trim() })
          setPlans(current => [...current.filter(plan => plan.id !== saved.id), saved])
          setDraft({ id: saved.id, name: saved.name, capabilities: [...saved.capabilities], expectedRevision: saved.revision })
        }, 'Тариф сохранён') }}>
          <label>Идентификатор<input required pattern="[a-z][a-z0-9-]{0,63}" maxLength={64} disabled={draft.expectedRevision !== undefined} value={draft.id} onChange={event => setDraft({ ...draft, id: event.target.value })} /></label>
          <label>Название<input required maxLength={80} value={draft.name} onChange={event => setDraft({ ...draft, name: event.target.value })} /></label>
          <fieldset className="tariff-admin__capabilities"><legend>Доступные модули</legend>{PRODUCT_CAPABILITIES.map(capability => <label key={capability}><input type="checkbox" checked={draft.capabilities.includes(capability)} onChange={event => setDraft({ ...draft, capabilities: event.target.checked ? [...draft.capabilities, capability] : draft.capabilities.filter(value => value !== capability) })} />{capabilityLabels[capability]}</label>)}</fieldset>
          <Button type="submit" disabled={!draft.name.trim()}>Сохранить тариф</Button>
        </form>
      </fieldset>
      <fieldset disabled={loading || busy}><legend>Тарифы пользователей</legend>
        {assignments.map(assignment => <label className="tariff-admin__assignment" key={assignment.userName}>
          <span>{assignment.userName} · {roleLabels[assignment.systemRole]}</span>
          <select aria-label={`Тариф пользователя ${assignment.userName}`} value={assignment.tariffId} onChange={event => {
            const tariffId = event.target.value
            void mutate(async () => {
              await client.assign(assignment.userName, tariffId)
              setAssignments(current => current.map(value => value.userName === assignment.userName ? { ...value, tariffId } : value))
            }, `Тариф пользователя ${assignment.userName} изменён`)
          }}>{plans.map(plan => <option key={plan.id} value={plan.id}>{plan.name}</option>)}</select>
        </label>)}
      </fieldset>
    </div>
  </Dialog>
}
