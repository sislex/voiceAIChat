import { lazy, Suspense, useEffect, useState } from 'react'
import { Button, ErrorState, PropertyRow, SectionHeader, Badge } from '@voicechat/ui-kit'
import type { AccountAccess, AccountTariffClient } from '@voicechat/shared'
import { capabilityLabels, roleLabels } from './capabilityLabels'

const TariffAdminDialog = lazy(() => import('./TariffAdminDialog'))

export function AccountEntitlements({ client }: { client: AccountTariffClient }): JSX.Element {
  const [access, setAccess] = useState<AccountAccess | null>(null)
  const [error, setError] = useState('')
  const [reload, setReload] = useState(0)
  const [editing, setEditing] = useState(false)
  useEffect(() => {
    let disposed = false
    const refresh = () => { void client.getAccess().then(value => {
      if (!disposed) { setAccess(value); setError('') }
    }).catch(reason => { if (!disposed) setError(reason instanceof Error ? reason.message : String(reason)) }) }
    refresh()
    const timer = setInterval(refresh, 30_000)
    return () => { disposed = true; clearInterval(timer) }
  }, [client, reload])
  return <section className="vcp account-page__fallback" aria-label="Тариф и рабочее пространство">
    <SectionHeader title="Тариф и рабочее пространство" level={2} />
    {error && <ErrorState message="Не удалось обновить тариф" detail={error} onRetry={() => setReload(value => value + 1)} />}
    {!access && !error && <p role="status">Загружаю тариф…</p>}
    {access && <>
      <PropertyRow label="Системная роль"><span>{roleLabels[access.systemRole]}</span></PropertyRow>
      <PropertyRow label="Личное пространство"><span style={{ overflowWrap: 'anywhere' }}>{access.tenant.name}</span></PropertyRow>
      <PropertyRow label="Тариф"><span>{access.tariff.name}</span></PropertyRow>
      <p className="vcp-head__sub">Возможности тарифа действуют в пределах ваших прав на проекты и ресурсы.</p>
      <PropertyRow label="Доступные модули" wide>
        {access.capabilities.length ? <div role="list" className="vc-chips">{access.capabilities.map(capability => <span role="listitem" key={capability}><Badge>{capabilityLabels[capability]}</Badge></span>)}</div> : <p>В тарифе пока нет доступных модулей.</p>}
      </PropertyRow>
      {access.systemRole === 'admin' && <div><Button onClick={() => setEditing(true)}>Управление тарифами</Button></div>}
    </>}
    {editing && <Suspense fallback={<p role="status">Загружаю управление тарифами…</p>}><TariffAdminDialog client={client} onChanged={() => setReload(value => value + 1)} onClose={() => setEditing(false)} /></Suspense>}
  </section>
}
