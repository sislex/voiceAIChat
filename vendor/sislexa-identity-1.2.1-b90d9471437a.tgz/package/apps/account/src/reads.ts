import type { RendererApi } from '@shared/ipc'
export interface AccountReads {
 api: RendererApi
 cache: { onInvalidated(listener: (family?: string) => void): () => void }
 periodNow(now: number): number
 peek<K extends keyof RendererApi>(channel: K, ...args: Parameters<RendererApi[K]>): Awaited<ReturnType<RendererApi[K]>> | undefined
 fresh(channel: keyof RendererApi, ...args: unknown[]): boolean
}
export function accountReads(api: RendererApi): AccountReads {
 return { api, cache: { onInvalidated: () => () => {} }, periodNow: now => now, peek: () => undefined, fresh: () => true }
}
