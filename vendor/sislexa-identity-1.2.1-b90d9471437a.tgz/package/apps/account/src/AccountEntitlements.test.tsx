import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import { expect, it, vi } from 'vitest'
import type { AccountAccess, AccountTariffClient, TariffPlan } from '@voicechat/shared'
import { AccountEntitlements } from './AccountEntitlements'
import TariffAdminDialog from './TariffAdminDialog'

const standard: TariffPlan = { id: 'standard', name: 'Стандартный', capabilities: ['chat.use', 'make.use'], revision: 3, createdAt: 1, updatedAt: 2 }
const chat: TariffPlan = { ...standard, id: 'chat', name: 'Только чат', capabilities: ['chat.use'] }
function fixture(role: AccountAccess['systemRole'] = 'observer') {
  const access: AccountAccess = { userName: 'alice', systemRole: role, tenant: { id: 'tenant-alice', kind: 'personal', name: 'alice', owner: 'alice', createdAt: 1 }, tariff: standard, capabilities: standard.capabilities }
  const client: AccountTariffClient = {
    getAccess: vi.fn(async () => access), listPlans: vi.fn(async () => [standard, chat]),
    listAssignments: vi.fn(async () => [{ userName: 'alice', systemRole: role, tenantId: 'tenant-alice', tariffId: 'standard' }]),
    savePlan: vi.fn(async input => ({ ...standard, ...input, revision: 4 })),
    assign: vi.fn(async () => ({ ...access, tariff: chat, capabilities: chat.capabilities }))
  }
  return { client, access }
}
it('shows role separately from tariff and never exposes administration to an observer', async () => {
  const { client } = fixture()
  render(<AccountEntitlements client={client} />)
  expect(await screen.findByText('Стандартный')).toBeInTheDocument()
  expect(screen.getByText('Наблюдатель')).toBeInTheDocument()
  expect(screen.getByText('Make')).toBeInTheDocument()
  expect(screen.queryByRole('button', { name: 'Управление тарифами' })).not.toBeInTheDocument()
  expect(client.listPlans).not.toHaveBeenCalled()
})
it('loads tariff management only when an administrator opens it', async () => {
  const { client } = fixture('admin')
  render(<AccountEntitlements client={client} />)
  fireEvent.click(await screen.findByRole('button', { name: 'Управление тарифами' }))
  expect(await screen.findByRole('dialog', { name: 'Управление тарифами' })).toBeInTheDocument()
  await waitFor(() => expect(client.listAssignments).toHaveBeenCalledTimes(1))
})
it('sends optimistic revisions and only capability fields when editing and assigning tariffs', async () => {
  const { client } = fixture('admin')
  const onChanged = vi.fn()
  render(<TariffAdminDialog client={client} onChanged={onChanged} onClose={() => {}} />)
  await waitFor(() => expect(screen.getByLabelText('Редактируемый тариф')).toBeEnabled())
  fireEvent.change(screen.getByLabelText('Редактируемый тариф'), { target: { value: 'standard' } })
  expect(screen.getByLabelText('Идентификатор')).toBeDisabled()
  fireEvent.click(screen.getByLabelText('Make'))
  fireEvent.click(screen.getByRole('button', { name: 'Сохранить тариф' }))
  await screen.findByText('Тариф сохранён')
  expect(client.savePlan).toHaveBeenCalledWith({ id: 'standard', name: 'Стандартный', capabilities: ['chat.use'], expectedRevision: 3 })
  fireEvent.change(screen.getByLabelText('Тариф пользователя alice'), { target: { value: 'chat' } })
  await screen.findByText('Тариф пользователя alice изменён')
  expect(client.assign).toHaveBeenCalledWith('alice', 'chat')
  expect(onChanged).toHaveBeenCalledTimes(2)
})
it('preserves the old assignment and shows the error when saving fails', async () => {
  const { client } = fixture('admin')
  vi.mocked(client.assign).mockRejectedValue(new Error('Сервер недоступен'))
  render(<TariffAdminDialog client={client} onChanged={() => {}} onClose={() => {}} />)
  await waitFor(() => expect(screen.getByLabelText('Тариф пользователя alice')).toBeEnabled())
  fireEvent.change(screen.getByLabelText('Тариф пользователя alice'), { target: { value: 'chat' } })
  expect(await screen.findByText('Сервер недоступен')).toBeInTheDocument()
  expect(screen.getByLabelText('Тариф пользователя alice')).toHaveValue('standard')
})
