import '@testing-library/jest-dom/vitest'
import {cleanup} from '@testing-library/react'
import {afterEach} from 'vitest'
afterEach(cleanup)
if(!globalThis.PointerEvent)globalThis.PointerEvent=MouseEvent as typeof PointerEvent
if(!globalThis.matchMedia)globalThis.matchMedia=((q:string)=>({matches:false,media:q,onchange:null,dispatchEvent(){return false},addListener(){},removeListener(){},addEventListener(){},removeEventListener(){}})) as typeof matchMedia
