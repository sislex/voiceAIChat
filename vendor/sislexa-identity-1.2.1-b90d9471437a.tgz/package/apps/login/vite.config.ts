import {defineConfig} from 'vite'
import react from '@vitejs/plugin-react'
import {sharedSource} from '../../scripts/shared-path.mjs'
export default defineConfig({base:'/'+'login'+'/',plugins:[react()],resolve:{alias:[{find:/^@shared\//,replacement:sharedSource()}]},server:{proxy:{'/api':process.env.IDENTITY_API_URL ?? 'http://127.0.0.1:8798'}}})
