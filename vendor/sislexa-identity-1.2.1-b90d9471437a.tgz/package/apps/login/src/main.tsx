import React, {useEffect, useState} from 'react'
import {createRoot} from 'react-dom/client'
import {LoginScreen, ResetPasswordScreen} from './LoginScreen'
import {SignupScreen, VerifyScreen} from './SignupScreen'
import {InviteRegister} from './InviteRegister'
import {makeSessionBridge} from '@voicechat/identity-client/sessionBridge'
import '@voicechat/ui-kit/styles.css'
import './styles.css'
import './login.css'
const session = makeSessionBridge('', {reconnect() {}, on() {return () => {}}})
function Login() {
 const [error,setError]=useState<string|null>(null), [ticket,setTicket]=useState<string|null>(null)
 const [route,setRoute]=useState(location.hash), [signup,setSignup]=useState(false)
 useEffect(()=>{const update=()=>setRoute(location.hash);addEventListener('hashchange',update);void session.signupEnabled!().then(setSignup);return()=>removeEventListener('hashchange',update)},[])
 const done=()=>location.assign('/account/'), back=()=>{location.hash='';setError(null)}
 const run=async(action:()=>Promise<unknown>)=>{setError(null);try{const result=await action();if(result&&typeof result==='object'&&'error'in result)throw Error(String(result.error));if(result&&typeof result==='object'&&'requires2fa'in result&&'ticket'in result){setTicket(String(result.ticket));return}if(result===null)throw Error('Неверный код подтверждения');done()}catch(e){setError(e instanceof Error?e.message:String(e))}}
 const token=decodeURIComponent(route.split('/')[2]??'')
 if(route.startsWith('#/reset/'))return <ResetPasswordScreen token={token} reset={session.resetPasswordByEmail!} onDone={back} onBack={back}/>
 if(route.startsWith('#/verify/'))return <VerifyScreen token={token} verify={session.verifyEmail!} onDone={done} onBack={back}/>
 if(route.startsWith('#/invite/'))return <InviteRegister token={token} api={{inviteInfo:session.inviteInfo!,register:session.register!}} onDone={done}/>
 if(route==='#/signup'&&signup)return <SignupScreen api={{signup:session.signup!,resend:session.signupResend!}} onBack={back}/>
 return <LoginScreen error={error} onLogin={(name,password,remember)=>void run(()=>session.login({name,password,remember}))} onForgotPassword={session.requestPasswordReset} onReset={(name,code,password)=>void run(()=>session.resetPassword!({name,code,password}))} {...(signup?{onSignup:()=>{location.hash='/signup'}}:{})} {...(ticket?{twoFactor:true,onCode:(code:string)=>void run(()=>session.login2fa!({ticket,code})),onCancelTwoFactor:()=>setTicket(null)}:{})}/>
}
createRoot(document.getElementById('root')!).render(<Login/>)
