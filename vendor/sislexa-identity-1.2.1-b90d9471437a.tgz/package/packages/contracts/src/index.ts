export const IDENTITY_API_VERSION = '1.1.0'
export const IDENTITY_PATHS = { verify:'/v1/identity/verify', store:'/v1/identity/store', session:'/v1/identity/session', events:'/v1/identity/events', core:'/internal/identity/core' } as const
export interface IdentityRequest { method: string; url: string; headers: Record<string,string|string[]|undefined> }
export interface IdentitySessionRequest extends IdentityRequest { body?: unknown; ip: string; corsAllowed?: boolean }
export interface IdentitySessionResponse { status: number; headers: Record<string,string|string[]|number|undefined>; body: string }
export interface IdentityEvent { sequence: number; user: string; revokedSid?: string }
/** JSON cannot preserve Map entries; the store RPC carries activity as tuples. */
export type IdentitySessionActivityWire = Array<[string, {lastSeen: number; live: number}]>
export const IDENTITY_CORE_METHODS = ['settings.getAppConfig','settings.getSettings','projects.isProjectOwner','projects.projectFeatures','projects.attachInvitationsToNewUser','chat.deleteConversationsOfUser','machines.deleteAgentsOfUser','settings.deleteUserSettings','tasks.unassignUser','projects.detachDeletedUser'] as const
