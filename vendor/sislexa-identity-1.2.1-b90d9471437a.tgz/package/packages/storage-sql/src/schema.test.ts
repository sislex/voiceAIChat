import { expect, it } from 'vitest'
import { postgresSchemaFrom } from './schema.js'

it('preserves both foreign-key actions in either order for table and inline references', () => {
  for (const actions of ['ON UPDATE CASCADE ON DELETE CASCADE', 'ON DELETE CASCADE ON UPDATE CASCADE']) {
    for (const body of [`user_name TEXT NOT NULL, FOREIGN KEY (user_name) REFERENCES users(name) ${actions}`, `user_name TEXT NOT NULL REFERENCES users(name) ${actions}`]) {
      const result = postgresSchemaFrom(`CREATE TABLE IF NOT EXISTS subjects (id TEXT PRIMARY KEY, ${body});`)
      expect(result.foreignKeys).toHaveLength(1)
      expect(result.foreignKeys[0]).toContain('ON DELETE CASCADE ON UPDATE CASCADE')
      expect(result.tables[0]).not.toContain('ON UPDATE')
      expect(result.tables[0]).not.toContain('REFERENCES')
    }
  }
})

it('does not silently accept duplicate or unsupported table-reference actions', () => {
  for (const actions of ['ON DELETE CASCADE ON DELETE RESTRICT', 'ON UPDATE INVALID']) {
    expect(() => postgresSchemaFrom(`CREATE TABLE IF NOT EXISTS subjects (id TEXT PRIMARY KEY, user_name TEXT, FOREIGN KEY (user_name) REFERENCES users(name) ${actions});`)).toThrow()
  }
})
