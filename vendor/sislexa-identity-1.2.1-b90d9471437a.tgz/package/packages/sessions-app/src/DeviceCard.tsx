// Карточка одного устройства. Всё, что она показывает, уже вычислено ядром
// (SessionView): здесь только раскладка, тексты и локальный режим переименования.
import { useEffect, useRef, useState } from 'react'
import { countryFlag, deviceIcon, type SessionView } from '@voicechat/sessions-core'
import { Button } from '@voicechat/ui-kit'
import { formatDuration, formatMoment } from './format'
import type { SessionsTexts } from './texts'

export interface DeviceCardProps {
  view: SessionView
  texts: SessionsTexts
  locale: string
  /** Момент, относительно которого считаются «назад» и «истекает через». */
  now: number
  /** По этой карточке идёт действие — кнопки заняты. */
  busy: boolean
  canRename: boolean
  canTrust: boolean
  /** История устройства: undefined — не запрашивали, null — грузится. */
  history?: import('./contracts').SessionHistoryEvent[] | null
  onHistory?(): void
  /** Завершить все сессии этого устройства; нет обработчика — нет кнопки. */
  onRevokeDevice?(): void
  /** Отметка для массового завершения; нет обработчика — нет чекбокса. */
  selected?: boolean
  onToggleSelected?(): void
  onRevoke(): void
  onRename(label: string | null): void
  onTrust(trusted: boolean): void
}

export function DeviceCard({ view, texts, locale, now, busy, canRename, canTrust, history, onHistory, onRevokeDevice, selected, onToggleSelected, onRevoke, onRename, onTrust }: DeviceCardProps): JSX.Element {
  const { session, profile, title, online, trusted, current } = view
  const [editing, setEditing] = useState(false)
  const [draft, setDraft] = useState(session.label ?? '')
  const inputRef = useRef<HTMLInputElement>(null)
  useEffect(() => {
    if (editing) inputRef.current?.focus()
  }, [editing])

  const save = (): void => {
    const next = draft.trim()
    setEditing(false)
    // Пустое имя — это не «стереть подпись», а «вернуть автоматическую».
    if (next !== (session.label ?? '')) onRename(next || null)
  }

  const flag = countryFlag(session.geo?.country)
  const place = `${flag ? `${flag} ` : ''}${view.place || session.ip || texts.unknownPlace}`
  const expiry = view.expiresInMs > 0 ? texts.expiresIn(formatDuration(view.expiresInMs)) : texts.expired

  return (
    <li className={current ? 'vcs-item vcs-item--current' : 'vcs-item'} data-testid={`session-${session.sid}`}>
      {onToggleSelected && !current && (
        <input
          type="checkbox"
          className="vcs-check"
          checked={Boolean(selected)}
          aria-label={`${texts.selectSession}: ${title}`}
          onChange={onToggleSelected}
        />
      )}
      <span className="vcs-ico" aria-hidden="true">{deviceIcon(profile.kind)}</span>
      <div className="vcs-main">
        {editing ? (
          <div className="vcs-rename">
            <label className="vcs-rename-label" htmlFor={`rename-${session.sid}`}>
              {texts.renameLabel}
              {view.siblings > 0 && <span className="vcs-note"> — {texts.renameScopeHint}</span>}
            </label>
            <input
              id={`rename-${session.sid}`}
              ref={inputRef}
              className="vcs-input"
              value={draft}
              maxLength={60}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') save()
                if (e.key === 'Escape') setEditing(false)
              }}
            />
            <Button size="sm" variant="primary" onClick={save}>{texts.renameSave}</Button>
            <Button size="sm" variant="ghost" onClick={() => setEditing(false)}>{texts.renameCancel}</Button>
          </div>
        ) : (
          <p className="vcs-head">
            <strong className="vcs-title">{title}</strong>
            {current && <span className="vcs-badge vcs-badge--current">{texts.currentBadge}</span>}
            {trusted && (
              <span className="vcs-badge vcs-badge--trusted" title={view.trustLeftMs > 0 ? texts.trustLeft(formatDuration(view.trustLeftMs)) : undefined}>
                {texts.trustedBadge}
              </span>
            )}
            {online && !current && <span className="vcs-badge vcs-badge--online">{texts.onlineBadge}</span>}
            {session.twoFactor && <span className="vcs-badge vcs-badge--2fa">{texts.twoFactorBadge}</span>}
            {view.expiringSoon && <span className="vcs-badge vcs-badge--soon">{texts.expiringSoon}</span>}
          </p>
        )}
        <small className="vcs-meta">
          {[place, texts.createdAt(formatMoment(session.createdAt, locale)), texts.lastSeen(online ? texts.onlineBadge : `${formatDuration(now - session.lastSeen)} назад`), expiry].join(' · ')}
        </small>
        {/* Активность собирается всё равно — показываем её вместо того, чтобы
            держать в базе «на всякий случай»: по разделу видно, чем занята сессия. */}
        {(session.requests ?? 0) > 0 && (
          <small className="vcs-meta vcs-meta--dim">{texts.activity(session.requests ?? 0, session.lastPath ?? '')}</small>
        )}
        {view.siblings > 0 && <small className="vcs-meta vcs-meta--dim">{texts.siblings(view.siblings)}</small>}
        {trusted && view.trustLeftMs > 0 && <small className="vcs-meta vcs-meta--dim">{texts.trustLeft(formatDuration(view.trustLeftMs))}</small>}
        {onHistory && (
          <details className="vcs-history" onToggle={(e) => { if ((e.currentTarget as HTMLDetailsElement).open) onHistory() }}>
            <summary>{texts.historyToggle}</summary>
            {history === undefined || history === null ? (
              <p className="vcs-note">{texts.loading}</p>
            ) : history.length === 0 ? (
              <p className="vcs-note">{texts.historyEmpty}</p>
            ) : (
              <ul className="vcs-history-list" role="list">
                {history.map((event) => (
                  <li key={event.id}>
                    <span>{formatMoment(event.at, locale)}</span> — {texts.historyEvent(event.type)}
                    {event.details && event.details !== texts.historyEvent(event.type) ? `: ${event.details}` : ''}
                  </li>
                ))}
              </ul>
            )}
          </details>
        )}
      </div>
      <div className="vcs-actions">
        {canRename && !editing && (
          <Button size="sm" variant="ghost" disabled={busy} onClick={() => { setDraft(session.label ?? ''); setEditing(true) }}>{texts.rename}</Button>
        )}
        {canTrust && (
          <Button size="sm" variant="ghost" disabled={busy} onClick={() => onTrust(!trusted)}>{trusted ? texts.untrust : texts.trust}</Button>
        )}
        {!current && (
          <Button size="sm" variant="danger" loading={busy} onClick={onRevoke}>{texts.revoke}</Button>
        )}
        {onRevokeDevice && view.siblings > 0 && (
          <Button size="sm" variant="ghost" disabled={busy} onClick={onRevokeDevice}>
            {current ? texts.revokeDeviceOthers(view.siblings) : texts.revokeDevice(view.siblings + 1)}
          </Button>
        )}
      </div>
    </li>
  )
}
