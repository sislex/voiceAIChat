import { afterEach, expect, it, vi } from 'vitest'
import { makeSessionBridge } from './sessionBridge.js'
import { setCsrf, setToken } from './browser.js'

afterEach(() => { vi.unstubAllGlobals(); setToken(null); setCsrf(null) })
it('preserves credentials and CSRF on tariff mutations and encodes user names', async () => {
  const fetch = vi.fn<typeof globalThis.fetch>(async () => Response.json({}))
  vi.stubGlobal('fetch', fetch)
  setToken('user-credential'); setCsrf('csrf-value')
  const tariffs = makeSessionBridge('https://identity.test', { reconnect() {}, on() { return () => {} } }).tariffs!
  await tariffs.assign('a/b', 'standard')
  expect(fetch).toHaveBeenCalledWith('https://identity.test/api/session/tariff-assignments/a%2Fb', {
    method: 'PUT', credentials: 'include', headers: { authorization: 'Bearer user-credential', 'x-vc-csrf': 'csrf-value', 'content-type': 'application/json' }, body: JSON.stringify({ tariffId: 'standard' })
  })
  await tariffs.savePlan({ id: 'chat', name: 'Chat', capabilities: [], expectedRevision: 2 })
  expect(fetch.mock.calls[1]?.[1]).toMatchObject({ method: 'PUT' })
})
it('reports concurrent tariff edits instead of treating the error body as a plan', async () => {
  vi.stubGlobal('fetch', vi.fn(async () => Response.json({ error: 'revision_conflict' }, { status: 409 })))
  const tariffs = makeSessionBridge('', { reconnect() {}, on() { return () => {} } }).tariffs!
  await expect(tariffs.savePlan({ id: 'chat', name: 'Chat', capabilities: [], expectedRevision: 1 })).rejects.toMatchObject({ status: 409, message: expect.stringContaining('уже изменён') })
})
