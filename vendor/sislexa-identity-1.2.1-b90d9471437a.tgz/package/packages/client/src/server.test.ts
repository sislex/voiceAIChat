import Fastify from 'fastify'
import {afterEach,expect,it,vi} from 'vitest'
import {registerRemoteIdentity} from './server.js'
import type {AuthDatabase} from '../../../apps/server/src/ports.js'
const cleanups:Array<()=>Promise<unknown>>=[]
afterEach(async()=>{for(const close of cleanups.splice(0))await close()})
const db={projects:{isProjectOwner:async()=>false,projectFeatures:async()=>({})}} as unknown as AuthDatabase
it('denies API work during an Identity outage and does not treat the component grant as a user',async()=>{
 const app=Fastify();cleanups.push(()=>app.close())
 await registerRemoteIdentity(app,db,{url:'http://identity.local',token:'component-grant',fetchImpl:async()=>{throw Error('unavailable')}},'secret')
 const work=vi.fn(()=>({ok:true}));app.get('/api/private',work)
 const result=await app.inject({url:'/api/private',headers:{authorization:'Bearer component-grant'}})
 expect(result.statusCode).toBeGreaterThanOrEqual(500);expect(work).not.toHaveBeenCalled()
})
it('forwards the user credential inside the request while authenticating RPC separately',async()=>{
 const app=Fastify();cleanups.push(()=>app.close());const received:Array<{url:string;headers:Headers;body:unknown}>=[]
 const fetchImpl:typeof fetch=async(input,init)=>{const req=new Request(input,init);const body=req.method==='POST'?await req.json():null;received.push({url:req.url,headers:req.headers,body});return Response.json(req.url.includes('/events')?{epoch:'test',sequence:0,events:[]}:{ok:true,user:{name:'alice',role:'developer',account:{tenantId:'alice',tariffId:'standard',tariffRevision:1,capabilities:['chat.use']}}})}
 await registerRemoteIdentity(app,db,{url:'http://identity.local',token:'component-grant',fetchImpl},'secret')
 app.get('/api/private',req=>({user:req.user?.name}))
 const r=await app.inject({url:'/api/private',headers:{authorization:'Bearer user-token'}})
 expect(r.json()).toEqual({user:'alice'})
 const request=received.find(r=>r.url.endsWith('/verify'))!
 expect(request.headers.get('authorization')).toBe('Bearer component-grant')
 expect(request.body).toMatchObject({request:{headers:{authorization:'Bearer user-token'}}})
})
