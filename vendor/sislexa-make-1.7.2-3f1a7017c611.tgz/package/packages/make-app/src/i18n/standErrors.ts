import { mt } from './index'

const codes = [
  'stand_fetch_failed', 'stand_git_timeout', 'stand_worktree_dirty', 'stand_agent_timeout',
  'machine_unavailable', 'machine_offline', 'stand_not_found', 'stand_proxy_unavailable',
  'storybook_no_free_port', 'storybook_exit_nonzero', 'storybook_exited_before_ready',
  'pty_error', 'storybook_port_busy',
] as const

/** Accept newer host error codes without changing the pinned shared archive. */
export function localizeStandError(error: unknown, fallback = error instanceof Error ? error.message : String(error)): string {
  const fields = error && typeof error === 'object' ? error as Record<string, unknown> : {}
  const code = codes.find(code => fields.errorCode === code || fields.code === code || fallback === code)
  return code ? mt(code) : fallback
}
