import{j as s}from"./jsx-runtime-BYYWji4R.js";import{within as y,waitFor as h,expect as t,userEvent as o}from"./index-DeN4tkzB.js";import{M as rt}from"./MessageMeta-Dv9RcPkx.js";import{f as r}from"./chat-COYZgq2j.js";import"./ci-DFdZK10C.js";import"./machines-Dwf6SHZ7.js";import"./clarification-g58U83f7.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./ErrorState-CqsakWkx.js";import"./kb-FQoQkx7T.js";import"./view-BrHz5xl6.js";import"./images-CH23vBlI.js";import"./tools-D2dVYbOd.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./types-DFdjDDUq.js";import"./agentProtocol-ChPLBt7B.js";import"./version-B-iWu5V0.js";import"./devProcess-BR7jm11E.js";const Mt={title:"Chat/MessageMeta",component:rt,args:{meta:r()},decorators:[(n,e)=>s.jsx("div",{className:"shared-chat","data-testid":"meta-chat-column",style:{width:e.parameters.chatColumnWidth??"100%",flex:"none"},children:s.jsx("div",{className:"msg ai",children:s.jsxs("div",{className:"mfoot",style:{paddingTop:120},children:[s.jsx("span",{className:"mtime",children:"10:01"}),s.jsx(n,{})]})})})]},i={},c={args:{meta:{durationMs:1200,inputTokens:800,outputTokens:90}}},m={args:{meta:r({costUsd:void 0,model:"gpt-5-codex",request:{...r().request,provider:"codex",model:"gpt-5-codex",resumed:!1}})}},d={args:{meta:r({interrupted:!0})}},p={args:{meta:r({request:{...r().request,attachments:["/tmp/скриншот-1.png","/tmp/лог-рана.txt"],kbContext:{confidence:"high",sections:[{documentId:"ui",title:"ui.md",heading:"Витрина Storybook",sourcePath:"docs/kb/ui.md",anchor:"#storybook"},{documentId:"testing",title:"testing-operations.md",heading:"Тестовая матрица",sourcePath:"docs/kb/testing-operations.md",anchor:"#матрица"}]}}})}},u={play:async({canvasElement:n})=>{const e=y(n);await o.hover(e.getByLabelText("Сведения об ответе").parentElement),await t(e.getByTestId("meta-tip")).toHaveTextContent("1.5k → 320")}},l={play:async({canvasElement:n})=>{await o.click(y(n).getByLabelText("Сведения об ответе"));const e=y(document.body);await t(await e.findByTestId("meta-overlay")).toBeInTheDocument(),await t(e.getByTestId("meta-prompt")).toHaveTextContent("Как дела?")}},g={parameters:{chatColumnWidth:699},play:async({canvasElement:n})=>{const e=y(n),a=e.getByRole("button",{name:"Сведения об ответе"}),x=e.getByTestId("meta-chat-column");await h(()=>t(a.textContent).toBe("ⓘ")),await o.hover(a),await t(await e.findByTestId("meta-tip")).toHaveTextContent("1.5k → 320"),await o.unhover(a),await o.tab(),await t(a).toHaveFocus(),await t(e.getByTestId("meta-tip")).toHaveTextContent("1.5k → 320"),await o.click(a);const w=y(document.body);await t(await w.findByTestId("meta-overlay")).toBeInTheDocument(),await t(w.getByTestId("meta-prompt")).toHaveTextContent("Как дела?"),await o.keyboard("{Escape}"),await h(()=>t(w.queryByTestId("meta-overlay")).not.toBeInTheDocument()),x.style.width="700px",await h(()=>t(a.querySelector(".msgact-usage")).not.toBeNull()),await t(a.textContent).not.toBe("ⓘ"),x.style.width="699px",await h(()=>t(a.textContent).toBe("ⓘ"))}};var v,T,B,k,I;i.parameters={...i.parameters,docs:{...(v=i.parameters)==null?void 0:v.docs,source:{originalSource:"{}",...(B=(T=i.parameters)==null?void 0:T.docs)==null?void 0:B.source},description:{story:"Обычный ход: иконка ⓘ. Сводка появляется по наведению, панель — по клику.",...(I=(k=i.parameters)==null?void 0:k.docs)==null?void 0:I.description}}};var C,b,E,f,M;c.parameters={...c.parameters,docs:{...(C=c.parameters)==null?void 0:C.docs,source:{originalSource:`{
  args: {
    meta: {
      durationMs: 1200,
      inputTokens: 800,
      outputTokens: 90
    }
  }
}`,...(E=(b=c.parameters)==null?void 0:b.docs)==null?void 0:E.source},description:{story:"Ход без деталей запроса (сохранён до появления `meta.request`): только метрики.",...(M=(f=c.parameters)==null?void 0:f.docs)==null?void 0:M.description}}};var H,q,S,D,F;m.parameters={...m.parameters,docs:{...(H=m.parameters)==null?void 0:H.docs,source:{originalSource:`{
  args: {
    meta: makeTurnMeta({
      costUsd: undefined,
      model: 'gpt-5-codex',
      request: {
        ...makeTurnMeta().request!,
        provider: 'codex',
        model: 'gpt-5-codex',
        resumed: false
      }
    })
  }
}`,...(S=(q=m.parameters)==null?void 0:q.docs)==null?void 0:S.source},description:{story:"Codex не сообщает стоимость хода — панель говорит об этом прямо.",...(F=(D=m.parameters)==null?void 0:D.docs)==null?void 0:F.description}}};var j,O,W,N,L;d.parameters={...d.parameters,docs:{...(j=d.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    meta: makeTurnMeta({
      interrupted: true
    })
  }
}`,...(W=(O=d.parameters)==null?void 0:O.docs)==null?void 0:W.source},description:{story:"Ход прерван перезапуском сервера — статус видно и в сводке, и в панели.",...(L=(N=d.parameters)==null?void 0:N.docs)==null?void 0:L.description}}};var A,P,R,K,U;p.parameters={...p.parameters,docs:{...(A=p.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    meta: makeTurnMeta({
      request: {
        ...makeTurnMeta().request!,
        attachments: ['/tmp/скриншот-1.png', '/tmp/лог-рана.txt'],
        kbContext: {
          confidence: 'high',
          sections: [{
            documentId: 'ui',
            title: 'ui.md',
            heading: 'Витрина Storybook',
            sourcePath: 'docs/kb/ui.md',
            anchor: '#storybook'
          }, {
            documentId: 'testing',
            title: 'testing-operations.md',
            heading: 'Тестовая матрица',
            sourcePath: 'docs/kb/testing-operations.md',
            anchor: '#матрица'
          }]
        }
      }
    })
  }
}`,...(R=(P=p.parameters)==null?void 0:P.docs)==null?void 0:R.source},description:{story:"Ход с автодобавленной базой знаний и вложениями.",...(U=(K=p.parameters)==null?void 0:K.docs)==null?void 0:U.description}}};var _,z,G,J,Q;u.parameters={...u.parameters,docs:{...(_=u.parameters)==null?void 0:_.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.hover(canvas.getByLabelText('Сведения об ответе').parentElement as HTMLElement);
    await expect(canvas.getByTestId('meta-tip')).toHaveTextContent('1.5k → 320');
  }
}`,...(G=(z=u.parameters)==null?void 0:z.docs)==null?void 0:G.source},description:{story:"Сводка по наведению: модель, токены, размер запроса, время и стоимость.",...(Q=(J=u.parameters)==null?void 0:J.docs)==null?void 0:Q.description}}};var V,X,Y,Z,$;l.parameters={...l.parameters,docs:{...(V=l.parameters)==null?void 0:V.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(within(canvasElement).getByLabelText('Сведения об ответе'));
    const dialog = within(document.body);
    await expect(await dialog.findByTestId('meta-overlay')).toBeInTheDocument();
    await expect(dialog.getByTestId('meta-prompt')).toHaveTextContent('Как дела?');
  }
}`,...(Y=(X=l.parameters)==null?void 0:X.docs)==null?void 0:Y.source},description:{story:"Панель «Что было отправлено модели»: промпт, контекст, окружение хода.",...($=(Z=l.parameters)==null?void 0:Z.docs)==null?void 0:$.description}}};var tt,et,at,nt,ot;g.parameters={...g.parameters,docs:{...(tt=g.parameters)==null?void 0:tt.docs,source:{originalSource:`{
  parameters: {
    chatColumnWidth: 699
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const trigger = canvas.getByRole('button', {
      name: 'Сведения об ответе'
    });
    const column = canvas.getByTestId('meta-chat-column');
    await waitFor(() => expect(trigger.textContent).toBe('ⓘ'));
    await userEvent.hover(trigger);
    await expect(await canvas.findByTestId('meta-tip')).toHaveTextContent('1.5k → 320');
    await userEvent.unhover(trigger);
    await userEvent.tab();
    await expect(trigger).toHaveFocus();
    await expect(canvas.getByTestId('meta-tip')).toHaveTextContent('1.5k → 320');
    await userEvent.click(trigger);
    const dialog = within(document.body);
    await expect(await dialog.findByTestId('meta-overlay')).toBeInTheDocument();
    await expect(dialog.getByTestId('meta-prompt')).toHaveTextContent('Как дела?');
    await userEvent.keyboard('{Escape}');
    await waitFor(() => expect(dialog.queryByTestId('meta-overlay')).not.toBeInTheDocument());
    column.style.width = '700px';
    await waitFor(() => expect(trigger.querySelector('.msgact-usage')).not.toBeNull());
    await expect(trigger.textContent).not.toBe('ⓘ');
    column.style.width = '699px';
    await waitFor(() => expect(trigger.textContent).toBe('ⓘ'));
  }
}`,...(at=(et=g.parameters)==null?void 0:et.docs)==null?void 0:at.source},description:{story:"The breakpoint follows the chat column, including resizing in split layouts.",...(ot=(nt=g.parameters)==null?void 0:nt.docs)==null?void 0:ot.description}}};const Ht=["Icon","OnlyMetrics","CodexWithoutCost","Interrupted","WithKbAndAttachments","TooltipOnHover","DetailsOpen","CompactColumn"];export{m as CodexWithoutCost,g as CompactColumn,l as DetailsOpen,i as Icon,d as Interrupted,c as OnlyMetrics,u as TooltipOnHover,p as WithKbAndAttachments,Ht as __namedExportsOrder,Mt as default};
