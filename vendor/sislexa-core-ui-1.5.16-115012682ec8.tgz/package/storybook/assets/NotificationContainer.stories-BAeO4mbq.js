import{within as k,userEvent as B,expect as M,fn as e}from"./index-DeN4tkzB.js";import"./tools-D2dVYbOd.js";import"./ci-DFdZK10C.js";import"./machines-Dwf6SHZ7.js";import{l as E,c as n}from"./clarification-g58U83f7.js";import{N as R}from"./ClarificationNotification-DYRRSkp4.js";import"./types-DFdjDDUq.js";import"./agentProtocol-ChPLBt7B.js";import"./version-B-iWu5V0.js";import"./devProcess-BR7jm11E.js";import"./time-CfyNS7J_.js";import"./kb-FQoQkx7T.js";import"./jsx-runtime-BYYWji4R.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";const K={id:"chatai-notification-container",title:"ChatAI/NotificationContainer",component:R,args:{notifications:[n],onOpen:e(),onDismiss:e()}},o={},a={args:{notifications:[n,E]}},i={args:{notifications:[]}},t={args:{errors:{[n.questionId]:"Не удалось открыть задачу. Повторите попытку."}},play:async({args:S,canvasElement:h})=>{const x=k(h);await B.click(x.getByRole("button",{name:"Закрыть"})),await M(S.onDismiss).toHaveBeenCalledWith(n)}},r={args:{notifications:[E]},parameters:{viewport:{defaultViewport:"mobile1"}}};var s,c,m;o.parameters={...o.parameters,docs:{...(s=o.parameters)==null?void 0:s.docs,source:{originalSource:"{}",...(m=(c=o.parameters)==null?void 0:c.docs)==null?void 0:m.source}}};var p,l,f;a.parameters={...a.parameters,docs:{...(p=a.parameters)==null?void 0:p.docs,source:{originalSource:`{
  args: {
    notifications: [clarificationNotification, longClarificationNotification]
  }
}`,...(f=(l=a.parameters)==null?void 0:l.docs)==null?void 0:f.source}}};var u,d,g;i.parameters={...i.parameters,docs:{...(u=i.parameters)==null?void 0:u.docs,source:{originalSource:`{
  args: {
    notifications: []
  }
}`,...(g=(d=i.parameters)==null?void 0:d.docs)==null?void 0:g.source}}};var v,N,w;t.parameters={...t.parameters,docs:{...(v=t.parameters)==null?void 0:v.docs,source:{originalSource:`{
  args: {
    errors: {
      [clarificationNotification.questionId]: 'Не удалось открыть задачу. Повторите попытку.'
    }
  },
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Закрыть'
    }));
    await expect(args.onDismiss).toHaveBeenCalledWith(clarificationNotification);
  }
}`,...(w=(N=t.parameters)==null?void 0:N.docs)==null?void 0:w.source}}};var C,b,y;r.parameters={...r.parameters,docs:{...(C=r.parameters)==null?void 0:C.docs,source:{originalSource:`{
  args: {
    notifications: [longClarificationNotification]
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(y=(b=r.parameters)==null?void 0:b.docs)==null?void 0:y.source}}};const P=["Single","MultipleTasks","Closed","RetryableNavigationError","MobileLongQuestion"];export{i as Closed,r as MobileLongQuestion,a as MultipleTasks,t as RetryableNavigationError,o as Single,P as __namedExportsOrder,K as default};
