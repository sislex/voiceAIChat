import{j as d}from"./jsx-runtime-BYYWji4R.js";import{within as R,userEvent as m,expect as p,fn as G}from"./index-DeN4tkzB.js";import{D as V}from"./agentProtocol-ChPLBt7B.js";import"./devProcess-BR7jm11E.js";import{A as Y}from"./AgentCard-1iw-faCA.js";import"./tools-D2dVYbOd.js";import"./ci-DFdZK10C.js";import{m as i,d as c,c as q,e as z}from"./machines-Dwf6SHZ7.js";import"./clarification-g58U83f7.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./ErrorState-CqsakWkx.js";import"./types-DFdjDDUq.js";import"./version-B-iWu5V0.js";import"./time-CfyNS7J_.js";import"./kb-FQoQkx7T.js";const de={title:"Machines/AgentCard",component:Y,args:{agent:i({id:"m1",name:"MacBook",policy:c()}),onSetPolicy:G()},decorators:[e=>d.jsx("div",{style:{maxWidth:640},children:d.jsx(e,{})})]},a={},o={args:{agent:i({version:"0.22.0"}),latestAgentVersion:"0.23.0",onUpdateAgent:G(async()=>null)}},n={args:{agent:q({id:"m2",name:"Домашний ПК",policy:c()})}},t={args:{agent:i({id:"m3",name:"Новая машина",policy:{...V}})}},r={args:{agent:z({name:"Pixel (только чтение)",policy:c({allowNetwork:!1,allowWrite:!1,allowPatterns:["^git ","^npm "],skills:[]})})},play:async({canvasElement:e})=>{await p(R(e).getByText("^git")).toBeInTheDocument()}},s={args:{agent:i({id:"m1",name:"MacBook",policy:c({skills:[]})})},play:async({args:e,canvasElement:H})=>{const l=R(H);await m.type(l.getByPlaceholderText("Имя (напр. сборка)"),"сборка"),await m.type(l.getByPlaceholderText("Команда (npm run build)"),"npm run build"),await m.click(l.getByLabelText("Добавить навык")),await p(e.onSetPolicy).toHaveBeenCalledWith("m1",p.objectContaining({skills:[{name:"сборка",command:"npm run build"}]}))}};var g,y,u,k,f;a.parameters={...a.parameters,docs:{...(g=a.parameters)==null?void 0:g.docs,source:{originalSource:"{}",...(u=(y=a.parameters)==null?void 0:y.docs)==null?void 0:u.source},description:{story:"Заполненная политика: разрешённый каталог, запреты и два навыка.",...(f=(k=a.parameters)==null?void 0:k.docs)==null?void 0:f.description}}};var A,P,x;o.parameters={...o.parameters,docs:{...(A=o.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    agent: makeAgent({
      version: '0.22.0'
    }),
    latestAgentVersion: '0.23.0',
    onUpdateAgent: fn(async () => null)
  }
}`,...(x=(P=o.parameters)==null?void 0:P.docs)==null?void 0:x.source}}};var w,v,B,E,h;n.parameters={...n.parameters,docs:{...(w=n.parameters)==null?void 0:w.docs,source:{originalSource:`{
  args: {
    agent: makeOfflineAgent({
      id: 'm2',
      name: 'Домашний ПК',
      policy: makePolicy()
    })
  }
}`,...(B=(v=n.parameters)==null?void 0:v.docs)==null?void 0:B.source},description:{story:"Офлайн: агент на машине не запущен, но политику править можно — она живёт на сервере.",...(h=(E=n.parameters)==null?void 0:E.docs)==null?void 0:h.description}}};var T,S,b,O,C;t.parameters={...t.parameters,docs:{...(T=t.parameters)==null?void 0:T.docs,source:{originalSource:`{
  args: {
    agent: makeAgent({
      id: 'm3',
      name: 'Новая машина',
      policy: {
        ...DEFAULT_AGENT_POLICY
      }
    })
  }
}`,...(b=(S=t.parameters)==null?void 0:S.docs)==null?void 0:b.source},description:{story:"Пустая политика (машина только добавлена): всё разрешено, списки пусты.",...(C=(O=t.parameters)==null?void 0:O.docs)==null?void 0:C.description}}};var D,j,L,_,W;r.parameters={...r.parameters,docs:{...(D=r.parameters)==null?void 0:D.docs,source:{originalSource:`{
  args: {
    agent: makeAndroidAgent({
      name: 'Pixel (только чтение)',
      policy: makePolicy({
        allowNetwork: false,
        allowWrite: false,
        allowPatterns: ['^git ', '^npm '],
        skills: []
      })
    })
  },
  play: async ({
    canvasElement
  }) => {
    await expect(within(canvasElement).getByText('^git')).toBeInTheDocument();
  }
}`,...(L=(j=r.parameters)==null?void 0:j.docs)==null?void 0:L.source},description:{story:"Жёсткая политика: разрешены только свои паттерны, навыков нет.",...(W=(_=r.parameters)==null?void 0:_.docs)==null?void 0:W.description}}};var F,I,M,N,U;s.parameters={...s.parameters,docs:{...(F=s.parameters)==null?void 0:F.docs,source:{originalSource:`{
  args: {
    agent: makeAgent({
      id: 'm1',
      name: 'MacBook',
      policy: makePolicy({
        skills: []
      })
    })
  },
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByPlaceholderText('Имя (напр. сборка)'), 'сборка');
    await userEvent.type(canvas.getByPlaceholderText('Команда (npm run build)'), 'npm run build');
    await userEvent.click(canvas.getByLabelText('Добавить навык'));
    await expect(args.onSetPolicy).toHaveBeenCalledWith('m1', expect.objectContaining({
      skills: [{
        name: 'сборка',
        command: 'npm run build'
      }]
    }));
  }
}`,...(M=(I=s.parameters)==null?void 0:I.docs)==null?void 0:M.source},description:{story:"Новый навык: имя, команда, «Добавить» — политика уходит сразу, без «Сохранить».",...(U=(N=s.parameters)==null?void 0:N.docs)==null?void 0:U.description}}};const ge=["FilledPolicy","Outdated","Offline","DefaultPolicy","RestrictedPolicy","AddSkill"];export{s as AddSkill,t as DefaultPolicy,a as FilledPolicy,n as Offline,o as Outdated,r as RestrictedPolicy,ge as __namedExportsOrder,de as default};
