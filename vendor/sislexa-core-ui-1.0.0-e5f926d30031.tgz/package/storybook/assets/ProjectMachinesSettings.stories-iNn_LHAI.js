import{j as m}from"./jsx-runtime-BYYWji4R.js";import{userEvent as l,within as A,expect as a,fn as p}from"./index-DeN4tkzB.js";import"./tools-iBbMKii-.js";import"./ci-awuetLx1.js";import{m as R,b as k}from"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import{P as O}from"./ProjectMachinesSettings-BTpl5VC_.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./time-CfyNS7J_.js";import"./kb-CjYTCLN0.js";import"./index-Brl4xq4Y.js";import"./Toast-CcZfB6x2.js";import"./projects-BdwKgk--.js";const V=[{agentId:"mine-online",name:"Мой Mac",owner:"alice",ownership:"mine",online:!0,sharedWithProject:!0,isMyDefault:!0,canUse:!0,load:1,path:"/Users/alice/project",reposRoot:"/Users/alice/VoiceAIChatRepos",sshHost:"mac.local",sshUser:"alice"},{agentId:"mine-offline",name:"Домашний ПК",owner:"alice",ownership:"mine",online:!1,sharedWithProject:!1,isMyDefault:!1,canUse:!0,load:0,path:"",reposRoot:"",sshHost:"",sshUser:""},{agentId:"shared",name:"CI — очень длинное название машины для проверки переноса",owner:"bob",ownership:"other",online:!0,sharedWithProject:!0,isMyDefault:!1,canUse:!0,load:3,path:"/srv/checkouts/project/with/a/very/long/path",reposRoot:"/srv/VoiceAIChatRepos",sshHost:"ci.internal.example.test",sshUser:"runner"},{agentId:"unavailable",name:"Недоступная",owner:"carol",ownership:"other",online:!1,sharedWithProject:!0,isMyDefault:!1,canUse:!1,unavailableReason:"владелец больше не участник",load:0,path:"/opt/project",reposRoot:"/opt/repos",sshHost:"10.0.0.8",sshUser:"deploy"}],ne={title:"Project Settings/Machines",component:O,parameters:{layout:"fullscreen"},decorators:[e=>m.jsx("div",{style:{padding:24},children:m.jsx(e,{})})],args:{projectId:"p1",machines:V,agents:[R({id:"mine-online",name:"Мой Mac"}),k({id:"mine-offline",name:"Домашний ПК"})],onShare:p(),onSave:p(async()=>{}),onSetDefault:p()}},t={},r={args:{machines:[],agents:[]}},n={render:()=>m.jsx("div",{role:"status",children:"Загрузка машин…"})},s={render:()=>m.jsx("div",{role:"alert",children:"Не удалось загрузить машины"})},o={args:{onSave:p(async()=>{throw new Error("HTTP 500")})}},i={play:async({args:e,canvasElement:d})=>{const h=A(d);await l.click(h.getByLabelText("Предоставить текущему проекту: Домашний ПК")),await a(e.onShare).toHaveBeenCalledWith("p1","mine-offline",!0);const u=h.getByLabelText("Папка проекта: Мой Mac");await l.clear(u),await l.type(u,"/new/project{Enter}"),await a(e.onSave).toHaveBeenCalledWith("p1","mine-online","path","/new/project",a.anything()),await a(h.getByLabelText("Папка проекта: CI — очень длинное название машины для проверки переноса")).toHaveAttribute("readonly")}},c={play:async({args:e,canvasElement:d})=>{await l.click(A(d).getByLabelText("По умолчанию: CI — очень длинное название машины для проверки переноса")),await a(e.onSetDefault).toHaveBeenCalledWith("p1","shared")}};var v,g,w;t.parameters={...t.parameters,docs:{...(v=t.parameters)==null?void 0:v.docs,source:{originalSource:"{}",...(w=(g=t.parameters)==null?void 0:g.docs)==null?void 0:w.source}}};var f,y,x;r.parameters={...r.parameters,docs:{...(f=r.parameters)==null?void 0:f.docs,source:{originalSource:`{
  args: {
    machines: [],
    agents: []
  }
}`,...(x=(y=r.parameters)==null?void 0:y.docs)==null?void 0:x.source}}};var E,S,j;n.parameters={...n.parameters,docs:{...(E=n.parameters)==null?void 0:E.docs,source:{originalSource:`{
  render: () => <div role="status">Загрузка машин…</div>
}`,...(j=(S=n.parameters)==null?void 0:S.docs)==null?void 0:j.source}}};var b,B,H;s.parameters={...s.parameters,docs:{...(b=s.parameters)==null?void 0:b.docs,source:{originalSource:`{
  render: () => <div role="alert">Не удалось загрузить машины</div>
}`,...(H=(B=s.parameters)==null?void 0:B.docs)==null?void 0:H.source}}};var T,C,I;o.parameters={...o.parameters,docs:{...(T=o.parameters)==null?void 0:T.docs,source:{originalSource:`{
  args: {
    onSave: fn(async () => {
      throw new Error('HTTP 500');
    })
  }
}`,...(I=(C=o.parameters)==null?void 0:C.docs)==null?void 0:I.source}}};var L,P,M;i.parameters={...i.parameters,docs:{...(L=i.parameters)==null?void 0:L.docs,source:{originalSource:`{
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByLabelText('Предоставить текущему проекту: Домашний ПК'));
    await expect(args.onShare).toHaveBeenCalledWith('p1', 'mine-offline', true);
    const path = canvas.getByLabelText('Папка проекта: Мой Mac');
    await userEvent.clear(path);
    await userEvent.type(path, '/new/project{Enter}');
    await expect(args.onSave).toHaveBeenCalledWith('p1', 'mine-online', 'path', '/new/project', expect.anything());
    await expect(canvas.getByLabelText('Папка проекта: CI — очень длинное название машины для проверки переноса')).toHaveAttribute('readonly');
  }
}`,...(M=(P=i.parameters)==null?void 0:P.docs)==null?void 0:M.source}}};var U,W,D;c.parameters={...c.parameters,docs:{...(U=c.parameters)==null?void 0:U.docs,source:{originalSource:`{
  play: async ({
    args,
    canvasElement
  }) => {
    await userEvent.click(within(canvasElement).getByLabelText('По умолчанию: CI — очень длинное название машины для проверки переноса'));
    await expect(args.onSetDefault).toHaveBeenCalledWith('p1', 'shared');
  }
}`,...(D=(W=c.parameters)==null?void 0:W.docs)==null?void 0:D.source}}};const se=["Overview","EmptyTables","Loading","LoadError","SaveError","ShareAndEdit","PersonalDefault"];export{r as EmptyTables,s as LoadError,n as Loading,t as Overview,c as PersonalDefault,o as SaveError,i as ShareAndEdit,se as __namedExportsOrder,ne as default};
