import{j as S}from"./jsx-runtime-BYYWji4R.js";import{T as Ea}from"./TaskCard-BuPlcnSm.js";import"./ProjectsApp-dH9TYZcw.js";import{m as e,e as t}from"./fixtures-CFkrQMEm.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./merge-CBY8VSWw.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./ciFormat-wlGR6KpA.js";import"./ansi-DtpFsZ9v.js";import"./kanbanMeta-CBiUCx3-.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Avatar-Ds_00F2y.js";import"./mediaQuery-CCkbYk-e.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./icons-MIP1fpxy.js";import"./projects-BdwKgk--.js";const Ba=e({id:"ep1",type:"epic",title:"Платёжная система"}),rt={title:"Kanban/TaskCard",component:Ea,args:{projectName:"Голос Чат",allTasks:[Ba],doneColumnIds:new Set(["done"]),dragging:!1,onOpen:()=>{},onUpdate:()=>{},onDelete:()=>{},onMoveTop:()=>{},onMoveBottom:()=>{}},decorators:[M=>S.jsx("div",{className:"jboard",style:{padding:16},children:S.jsx("div",{className:"jcol",style:{width:272},children:S.jsx("div",{className:"jcol-body",style:{padding:"8px 6px"},children:S.jsx(M,{})})})})]},r={args:{task:e({title:"Поправить отступ в шапке"})}},n={args:{task:e({title:"Интеграция платёжного шлюза",parentId:"ep1"})}},s={args:{task:e({title:"Срочно: падает прод",flagged:!0,priority:"urgent"})}},o={args:{task:e({id:"full",title:"Оплата картой: полный сценарий с 3-DS подтверждением",parentId:"ep1",labels:["payments","critical"],storyPoints:8,dueDate:Date.now()-24*60*60*1e3,flagged:!0,assignee:"bob",priority:"high",seq:42}),allTasks:[Ba,e({id:"ch1",parentId:"full",columnId:"done",title:"Форма"}),e({id:"ch2",parentId:"full",columnId:"wip",title:"Шлюз"})]}},i={args:{task:e({title:"Выпущено в прод",columnId:"done",assignee:"admin"})}},c={args:{task:e({title:"Спроектировать и реализовать сценарий обработки переполнения текста, включая перенос строк и обрезание СловаБезПробеловКотороеОченьДлинное"+"ещёдлиннее".repeat(8)})}},m={args:{task:e({title:"Меня тащат"}),dragging:!0}},p={args:{task:{id:"br",projectId:"p1",columnId:"x",type:"task",parentId:"ghost",title:"Битая задача",description:"",acceptanceCriteria:"",priority:"medium",assignee:null,labels:[],skills:[],storyPoints:null,dueDate:null,flagged:!1,seq:0,position:0,createdAt:1,updatedAt:1}}},d={args:{task:e({title:"Ран выполняется"}),ciSummary:t(),onStartCi:()=>{},onOpenCiRun:()=>{}}},u={args:{task:e({title:"Модель исправляет ошибку"}),ciSummary:t({slotProgress:{done:4,total:6,phase:"Модель исправляет ошибку",fixing:!0}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},l={args:{task:e({title:"Есть вопросы к пользователю"}),ciSummary:t({status:"awaiting_input",awaitingInput:!0,slotProgress:{done:3,total:6,phase:"Модель ждёт ответа"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},g={args:{task:e({title:"Ран упал"}),ciSummary:t({status:"failed",modelActive:!1,slotProgress:{done:4,total:6,phase:"Финальные команды (1/2)"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},k={args:{task:e({title:"Готово к пересборке прода"}),ciSummary:t({status:"success",modelActive:!1,slotProgress:{done:6,total:6,phase:"Резюме"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},a=(M,ja={})=>e({columnId:M,...ja}),y={args:{columnSemanticType:"backlog",task:a("backlog",{labels:["ui"],storyPoints:3}),onStartPreparation:()=>{}}},T={args:{columnSemanticType:"preparation",task:a("preparation",{taskPreparationStatus:"running"}),onStartPreparation:()=>{}}},C={args:{columnSemanticType:"preparation",task:a("preparation",{taskPreparationStatus:"failed",taskPreparationError:"Не заполнены критерии приёмки"}),onStartPreparation:()=>{}}},f={args:{columnSemanticType:"ready",task:a("ready",{skills:["storybook","a11y"],agentId:"prod-10e"}),onStartCi:()=>{}}},h={args:{columnSemanticType:"development",task:a("development"),ciSummary:t(),onOpenCiRun:()=>{}}},A={args:{columnSemanticType:"component_qa",task:a("component_qa",{latestRunResult:{id:"qa-1",kind:"component_qa",status:"success",outcome:"success",createdAt:1,finishedAt:2}})}},P={args:{columnSemanticType:"integration_tests",task:a("integration_tests")}},R={args:{columnSemanticType:"automated_qa",task:a("automated_qa",{latestRunResult:{id:"qa-2",kind:"automated_qa",status:"failed",outcome:"failure",createdAt:1,finishedAt:2}})}},I={args:{columnSemanticType:"manual_qa",task:a("manual_qa")}},_={args:{columnSemanticType:"awaiting_merge",task:a("awaiting_merge",{mergeSourceBranch:"feature/CHAT-375",mergePermitted:!0,mergeMachineBound:!0}),onStartMerge:()=>{}}},q={args:{columnSemanticType:"merge",task:a("merge",{mergeSourceBranch:"feature/CHAT-375",activeMergeRunId:"merge-1"})}},b={args:{columnSemanticType:"done",task:a("done",{mergeSourceBranch:"feature/CHAT-375",doneAt:Date.UTC(2026,7,29),latestRunResult:{id:"run-1",kind:"merge",status:"success",outcome:"success",createdAt:1,finishedAt:2}})}},w={args:{columnSemanticType:"cancelled",task:a("cancelled",{taskPreparationError:"Отменено пользователем"})}},v={args:{columnSemanticType:"decision_required",task:a("decision_required",{taskPreparationError:"Нужно выбрать стратегию миграции"})}},D={args:{columnSemanticType:"development",task:a("development",{title:"Длинный мобильный заголовок карточки задачи ".repeat(4)}),ciSummary:t(),onOpenCiRun:()=>{}},parameters:{viewport:{defaultViewport:"mobile1"}}};var x,O,B,j,E;r.parameters={...r.parameters,docs:{...(x=r.parameters)==null?void 0:x.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Поправить отступ в шапке'
    })
  }
}`,...(B=(O=r.parameters)==null?void 0:O.docs)==null?void 0:B.source},description:{story:"Минимальная задача: только заголовок, тип и приоритет по умолчанию.",...(E=(j=r.parameters)==null?void 0:j.docs)==null?void 0:E.description}}};var Q,F,H,L,N;n.parameters={...n.parameters,docs:{...(Q=n.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Интеграция платёжного шлюза',
      parentId: 'ep1'
    })
  }
}`,...(H=(F=n.parameters)==null?void 0:F.docs)==null?void 0:H.source},description:{story:"С чипом эпика-родителя.",...(N=(L=n.parameters)==null?void 0:L.docs)==null?void 0:N.description}}};var U,V,W,K,z;s.parameters={...s.parameters,docs:{...(U=s.parameters)==null?void 0:U.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Срочно: падает прод',
      flagged: true,
      priority: 'urgent'
    })
  }
}`,...(W=(V=s.parameters)==null?void 0:V.docs)==null?void 0:W.source},description:{story:"Помечена флагом — жёлтая карточка.",...(z=(K=s.parameters)==null?void 0:K.docs)==null?void 0:z.description}}};var G,J,X,Y,Z;o.parameters={...o.parameters,docs:{...(G=o.parameters)==null?void 0:G.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      id: 'full',
      title: 'Оплата картой: полный сценарий с 3-DS подтверждением',
      parentId: 'ep1',
      labels: ['payments', 'critical'],
      storyPoints: 8,
      dueDate: Date.now() - 24 * 60 * 60 * 1000,
      flagged: true,
      assignee: 'bob',
      priority: 'high',
      seq: 42
    }),
    allTasks: [epic, makeTask({
      id: 'ch1',
      parentId: 'full',
      columnId: 'done',
      title: 'Форма'
    }), makeTask({
      id: 'ch2',
      parentId: 'full',
      columnId: 'wip',
      title: 'Шлюз'
    })]
  }
}`,...(X=(J=o.parameters)==null?void 0:J.docs)==null?void 0:X.source},description:{story:"Все атрибуты сразу: эпик, метки, флаг, просроченный срок, поинты, аватар, подзадачи.",...(Z=(Y=o.parameters)==null?void 0:Y.docs)==null?void 0:Z.description}}};var $,ee,ae,te,re;i.parameters={...i.parameters,docs:{...($=i.parameters)==null?void 0:$.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Выпущено в прод',
      columnId: 'done',
      assignee: 'admin'
    })
  }
}`,...(ae=(ee=i.parameters)==null?void 0:ee.docs)==null?void 0:ae.source},description:{story:"В колонке «Готово» — ключ зачёркнут.",...(re=(te=i.parameters)==null?void 0:te.docs)==null?void 0:re.description}}};var ne,se,oe,ie,ce;c.parameters={...c.parameters,docs:{...(ne=c.parameters)==null?void 0:ne.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Спроектировать и реализовать сценарий обработки переполнения текста, включая перенос строк и обрезание СловаБезПробеловКотороеОченьДлинное' + 'ещёдлиннее'.repeat(8)
    })
  }
}`,...(oe=(se=c.parameters)==null?void 0:se.docs)==null?void 0:oe.source},description:{story:"Очень длинный заголовок и слово без пробелов.",...(ce=(ie=c.parameters)==null?void 0:ie.docs)==null?void 0:ce.description}}};var me,pe,de,ue,le;m.parameters={...m.parameters,docs:{...(me=m.parameters)==null?void 0:me.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Меня тащат'
    }),
    dragging: true
  }
}`,...(de=(pe=m.parameters)==null?void 0:pe.docs)==null?void 0:de.source},description:{story:"Состояние перетаскивания.",...(le=(ue=m.parameters)==null?void 0:ue.docs)==null?void 0:le.description}}};var ge,ke,Se,ye,Te;p.parameters={...p.parameters,docs:{...(ge=p.parameters)==null?void 0:ge.docs,source:{originalSource:`{
  args: {
    task: {
      id: 'br',
      projectId: 'p1',
      columnId: 'x',
      type: 'task',
      parentId: 'ghost',
      title: 'Битая задача',
      description: '',
      acceptanceCriteria: '',
      priority: 'medium',
      assignee: null,
      labels: [],
      skills: [],
      storyPoints: null,
      dueDate: null,
      flagged: false,
      seq: 0,
      position: 0,
      createdAt: 1,
      updatedAt: 1
    } as Task
  }
}`,...(Se=(ke=p.parameters)==null?void 0:ke.docs)==null?void 0:Se.source},description:{story:"Битые данные (через каст) — компонент не падает на уровне карточки.",...(Te=(ye=p.parameters)==null?void 0:ye.docs)==null?void 0:Te.description}}};var Ce,fe,he,Ae,Pe;d.parameters={...d.parameters,docs:{...(Ce=d.parameters)==null?void 0:Ce.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Ран выполняется'
    }),
    ciSummary: makeCiSummary(),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(he=(fe=d.parameters)==null?void 0:fe.docs)==null?void 0:he.source},description:{story:"Ран идёт: голубая рамка медленно «дышит», запуск недоступен — только лента.",...(Pe=(Ae=d.parameters)==null?void 0:Ae.docs)==null?void 0:Pe.description}}};var Re,Ie,_e,qe,be;u.parameters={...u.parameters,docs:{...(Re=u.parameters)==null?void 0:Re.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Модель исправляет ошибку'
    }),
    ciSummary: makeCiSummary({
      slotProgress: {
        done: 4,
        total: 6,
        phase: 'Модель исправляет ошибку',
        fixing: true
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(_e=(Ie=u.parameters)==null?void 0:Ie.docs)==null?void 0:_e.source},description:{story:"Шаг упал, модель разбирается: медленное красное мигание.",...(be=(qe=u.parameters)==null?void 0:qe.docs)==null?void 0:be.description}}};var we,ve,De,Me,xe;l.parameters={...l.parameters,docs:{...(we=l.parameters)==null?void 0:we.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Есть вопросы к пользователю'
    }),
    ciSummary: makeCiSummary({
      status: 'awaiting_input',
      awaitingInput: true,
      slotProgress: {
        done: 3,
        total: 6,
        phase: 'Модель ждёт ответа'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(De=(ve=l.parameters)==null?void 0:ve.docs)==null?void 0:De.source},description:{story:"Ран ждёт ответа пользователя: частое жёлтое мигание.",...(xe=(Me=l.parameters)==null?void 0:Me.docs)==null?void 0:xe.description}}};var Oe,Be,je,Ee,Qe;g.parameters={...g.parameters,docs:{...(Oe=g.parameters)==null?void 0:Oe.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Ран упал'
    }),
    ciSummary: makeCiSummary({
      status: 'failed',
      modelActive: false,
      slotProgress: {
        done: 4,
        total: 6,
        phase: 'Финальные команды (1/2)'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(je=(Be=g.parameters)==null?void 0:Be.docs)==null?void 0:je.source},description:{story:"Ран свалился окончательно: частое красное мигание.",...(Qe=(Ee=g.parameters)==null?void 0:Ee.docs)==null?void 0:Qe.description}}};var Fe,He,Le,Ne,Ue;k.parameters={...k.parameters,docs:{...(Fe=k.parameters)==null?void 0:Fe.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Готово к пересборке прода'
    }),
    ciSummary: makeCiSummary({
      status: 'success',
      modelActive: false,
      slotProgress: {
        done: 6,
        total: 6,
        phase: 'Резюме'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(Le=(He=k.parameters)==null?void 0:He.docs)==null?void 0:Le.source},description:{story:"Разработка закончена, ждёт пересборки прода: статичная зелёная рамка.",...(Ue=(Ne=k.parameters)==null?void 0:Ne.docs)==null?void 0:Ue.description}}};var Ve,We,Ke;y.parameters={...y.parameters,docs:{...(Ve=y.parameters)==null?void 0:Ve.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'backlog',
    task: stageTask('backlog', {
      labels: ['ui'],
      storyPoints: 3
    }),
    onStartPreparation: () => {}
  }
}`,...(Ke=(We=y.parameters)==null?void 0:We.docs)==null?void 0:Ke.source}}};var ze,Ge,Je;T.parameters={...T.parameters,docs:{...(ze=T.parameters)==null?void 0:ze.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'preparation',
    task: stageTask('preparation', {
      taskPreparationStatus: 'running'
    }),
    onStartPreparation: () => {}
  }
}`,...(Je=(Ge=T.parameters)==null?void 0:Ge.docs)==null?void 0:Je.source}}};var Xe,Ye,Ze;C.parameters={...C.parameters,docs:{...(Xe=C.parameters)==null?void 0:Xe.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'preparation',
    task: stageTask('preparation', {
      taskPreparationStatus: 'failed',
      taskPreparationError: 'Не заполнены критерии приёмки'
    }),
    onStartPreparation: () => {}
  }
}`,...(Ze=(Ye=C.parameters)==null?void 0:Ye.docs)==null?void 0:Ze.source}}};var $e,ea,aa;f.parameters={...f.parameters,docs:{...($e=f.parameters)==null?void 0:$e.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'ready',
    task: stageTask('ready', {
      skills: ['storybook', 'a11y'],
      agentId: 'prod-10e'
    }),
    onStartCi: () => {}
  }
}`,...(aa=(ea=f.parameters)==null?void 0:ea.docs)==null?void 0:aa.source}}};var ta,ra,na;h.parameters={...h.parameters,docs:{...(ta=h.parameters)==null?void 0:ta.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'development',
    task: stageTask('development'),
    ciSummary: makeCiSummary(),
    onOpenCiRun: () => {}
  }
}`,...(na=(ra=h.parameters)==null?void 0:ra.docs)==null?void 0:na.source}}};var sa,oa,ia;A.parameters={...A.parameters,docs:{...(sa=A.parameters)==null?void 0:sa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'component_qa',
    task: stageTask('component_qa', {
      latestRunResult: {
        id: 'qa-1',
        kind: 'component_qa',
        status: 'success',
        outcome: 'success',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(ia=(oa=A.parameters)==null?void 0:oa.docs)==null?void 0:ia.source}}};var ca,ma,pa;P.parameters={...P.parameters,docs:{...(ca=P.parameters)==null?void 0:ca.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'integration_tests',
    task: stageTask('integration_tests')
  }
}`,...(pa=(ma=P.parameters)==null?void 0:ma.docs)==null?void 0:pa.source}}};var da,ua,la;R.parameters={...R.parameters,docs:{...(da=R.parameters)==null?void 0:da.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'automated_qa',
    task: stageTask('automated_qa', {
      latestRunResult: {
        id: 'qa-2',
        kind: 'automated_qa',
        status: 'failed',
        outcome: 'failure',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(la=(ua=R.parameters)==null?void 0:ua.docs)==null?void 0:la.source}}};var ga,ka,Sa;I.parameters={...I.parameters,docs:{...(ga=I.parameters)==null?void 0:ga.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'manual_qa',
    task: stageTask('manual_qa')
  }
}`,...(Sa=(ka=I.parameters)==null?void 0:ka.docs)==null?void 0:Sa.source}}};var ya,Ta,Ca;_.parameters={..._.parameters,docs:{...(ya=_.parameters)==null?void 0:ya.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'awaiting_merge',
    task: stageTask('awaiting_merge', {
      mergeSourceBranch: 'feature/CHAT-375',
      mergePermitted: true,
      mergeMachineBound: true
    }),
    onStartMerge: () => {}
  }
}`,...(Ca=(Ta=_.parameters)==null?void 0:Ta.docs)==null?void 0:Ca.source}}};var fa,ha,Aa;q.parameters={...q.parameters,docs:{...(fa=q.parameters)==null?void 0:fa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'merge',
    task: stageTask('merge', {
      mergeSourceBranch: 'feature/CHAT-375',
      activeMergeRunId: 'merge-1'
    })
  }
}`,...(Aa=(ha=q.parameters)==null?void 0:ha.docs)==null?void 0:Aa.source}}};var Pa,Ra,Ia;b.parameters={...b.parameters,docs:{...(Pa=b.parameters)==null?void 0:Pa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'done',
    task: stageTask('done', {
      mergeSourceBranch: 'feature/CHAT-375',
      doneAt: Date.UTC(2026, 7, 29),
      latestRunResult: {
        id: 'run-1',
        kind: 'merge',
        status: 'success',
        outcome: 'success',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(Ia=(Ra=b.parameters)==null?void 0:Ra.docs)==null?void 0:Ia.source}}};var _a,qa,ba;w.parameters={...w.parameters,docs:{...(_a=w.parameters)==null?void 0:_a.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'cancelled',
    task: stageTask('cancelled', {
      taskPreparationError: 'Отменено пользователем'
    })
  }
}`,...(ba=(qa=w.parameters)==null?void 0:qa.docs)==null?void 0:ba.source}}};var wa,va,Da;v.parameters={...v.parameters,docs:{...(wa=v.parameters)==null?void 0:wa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'decision_required',
    task: stageTask('decision_required', {
      taskPreparationError: 'Нужно выбрать стратегию миграции'
    })
  }
}`,...(Da=(va=v.parameters)==null?void 0:va.docs)==null?void 0:Da.source}}};var Ma,xa,Oa;D.parameters={...D.parameters,docs:{...(Ma=D.parameters)==null?void 0:Ma.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'development',
    task: stageTask('development', {
      title: 'Длинный мобильный заголовок карточки задачи '.repeat(4)
    }),
    ciSummary: makeCiSummary(),
    onOpenCiRun: () => {}
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(Oa=(xa=D.parameters)==null?void 0:xa.docs)==null?void 0:Oa.source}}};const nt=["Minimal","WithEpicChip","Flagged","AllAttributes","DoneColumn","LongTitle","Dragging","BrokenData","CiRunning","CiFixing","CiAwaitingInput","CiFailed","CiSuccess","StageBacklog","StagePreparation","StagePreparationError","StageReady","StageInProgress","StageComponentQa","StageIntegrationQa","StageAutomatedQa","StageManualQa","StageAwaitingMerge","StageMerge","StageDone","StageCancelled","StageDecisionRequired","MobileLongTitle"];export{o as AllAttributes,p as BrokenData,l as CiAwaitingInput,g as CiFailed,u as CiFixing,d as CiRunning,k as CiSuccess,i as DoneColumn,m as Dragging,s as Flagged,c as LongTitle,r as Minimal,D as MobileLongTitle,R as StageAutomatedQa,_ as StageAwaitingMerge,y as StageBacklog,w as StageCancelled,A as StageComponentQa,v as StageDecisionRequired,b as StageDone,h as StageInProgress,P as StageIntegrationQa,I as StageManualQa,q as StageMerge,T as StagePreparation,C as StagePreparationError,f as StageReady,n as WithEpicChip,nt as __namedExportsOrder,rt as default};
