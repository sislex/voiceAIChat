import{j as d}from"./jsx-runtime-BYYWji4R.js";import{M as E}from"./MergePanel-Cjon5Arz.js";import{q as P}from"./queuedMerge-Br50QtzL.js";import{c as N}from"./fakeApi-Dd7dGTdR.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./QueuedMergeMachine-3G6jJgNn.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Skeleton-42oMjovX.js";import"./ErrorState-CqsakWkx.js";import"./merge-CBY8VSWw.js";import"./dateFormat-B8QlAdwY.js";import"./EmptyState-q579drYF.js";import"./StatusPill-Dn6iIbOr.js";import"./Badge-zWzzcJYU.js";import"./loadState-C9E-sPL9.js";import"./ciFormat-wlGR6KpA.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./ansi-DtpFsZ9v.js";import"./AnsiText-L5oy_LV7.js";import"./iframe-D-Q3L14w.js";import"./tools-iBbMKii-.js";import"./agentProtocol-ChPLBt7B.js";import"./projects-BdwKgk--.js";import"./projectTypes-C-9aONcK.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";const c=[{stage:"checking",status:"passed",startedAt:1,finishedAt:2,durationMs:700,exitCode:null,timedOut:!1,message:"Серверные проверки пройдены",log:""},{stage:"fetching",status:"passed",startedAt:2,finishedAt:3,durationMs:1800,exitCode:null,timedOut:!1,message:"Source 1a2b3c4d, main 9f8e7d6c",log:""},{stage:"merging",status:"passed",startedAt:3,finishedAt:4,durationMs:400,exitCode:null,timedOut:!1,message:"Создан merge 5e6f7a8b",log:""},{stage:"testing",status:"passed",startedAt:4,finishedAt:5,durationMs:48e4,exitCode:null,timedOut:!1,message:"Все обязательные проверки прошли",log:""},{stage:"pushing",status:"passed",startedAt:5,finishedAt:6,durationMs:2400,exitCode:null,timedOut:!1,message:"origin/main подтверждён",log:""}],t={id:"run-1",projectId:"p1",taskId:"t1",status:"success",triggeredBy:"admin",sourceBranch:"CHAT-180",targetBranch:"main",sourceSha:"1a2b3c4d".repeat(5),targetSha:"9f8e7d6c".repeat(5),mergeSha:"5e6f7a8b".repeat(5),revertSha:null,agentId:"m1",machineName:"MacBook",llmEngineId:null,llmProvider:"claude",llmModel:"",stage:"success",stages:c,conflicts:[],conflictDetails:[],checks:[{name:"Проверки проекта",command:"npm run typecheck",status:"passed",startedAt:4,finishedAt:5,durationMs:48e4,exitCode:0,timedOut:!1,output:`> typecheck
✓ ok`}],deployId:null,deployVersion:null,productionStatus:null,error:null,recommendedAction:null,log:`[12:00:00] merge requested by admin
[12:00:01] Серверные проверки пройдены
[12:08:02] origin/main подтверждён`,canCancel:!1,canRetry:!1,pushStartedAt:5,startedAt:1,finishedAt:6,createdAt:1},U=[{id:"r1",projectId:"p1",taskId:"t1",agentId:"m1",machineName:"MacBook",path:"/Users/dev/chatAI/dev/chatai/CHAT-180",kind:"dev-workspace",state:"active",createdAt:1,deletedAt:null},{id:"r2",projectId:"p1",taskId:"t1",agentId:"m2",machineName:"Server",path:"/root/VoiceAIChatRepos/chatai/.merge",kind:"merge-clone",state:"deleted",createdAt:2,deletedAt:3}];function u(e,i=[e]){return function(z){return window.ci={...N(),getMerge:async()=>e,listMergeRuns:async()=>i,getTaskRepositories:async()=>U,onMerge:()=>()=>{}},window.api={"projects:get":async()=>({machines:[{agentId:"m1",name:"MacBook",online:!0,path:"/w",reposRoot:"/repos"}]})},d.jsx("div",{style:{maxWidth:860},children:d.jsx(z,{})})}}const ye={title:"CI/MergePanel",component:E,args:{projectId:"p1",taskId:"t1",runId:"run-1",canStart:!1}},n={decorators:[u(t)]},r={decorators:[e=>{const i={id:"temporary-1",projectId:"p1",taskId:"t1",runId:"run-1",userId:"admin",machineId:"m1",machineName:"MacBook",path:"/managed/merge-run-tests",root:"/managed",category:"merge-worktree",generation:"g1",identity:"1:2",gitCommonDir:null,gitRegistration:null,createdAt:1,state:"registered"};return window.ci={...N(),getTemporaryResources:async()=>({candidates:[{resource:i,eligible:!1,reasons:["machine_offline","git_changes"],retainUntil:null,bytes:null,sizeReason:"machine_offline"}],attempts:[{id:"attempt-1",resource:i,at:Date.now(),reason:"machine_offline",outcome:"deferred",freedBytes:null,error:null}]})},d.jsx(e,{})}]},s={args:{runId:"queued-475"},decorators:[e=>(window.ci=P(),d.jsx(e,{}))]},a={decorators:[u({...t,id:"run-2",status:"testing",stage:"testing",mergeSha:null,finishedAt:null,canCancel:!0,stages:c.slice(0,3).concat([{...c[3],status:"running",finishedAt:null,durationMs:null,message:"Запускаю обязательные проверки до push"}])},[{...t,id:"run-2",status:"testing"}])],args:{runId:"run-2"}},o={decorators:[u({...t,id:"run-3",status:"decision_required",stage:"decision_required",mergeSha:null,error:"Конфликты требуют решения пользователя",recommendedAction:"Разрешите файлы в ветке задачи и повторите merge.",conflicts:["apps/server/src/index.ts"],canRetry:!0,stages:c.slice(0,2)},[{...t,id:"run-3",status:"decision_required"},t])],args:{runId:"run-3",canStart:!0}};var m,l,p,g,h;n.parameters={...n.parameters,docs:{...(m=n.parameters)==null?void 0:m.docs,source:{originalSource:`{
  decorators: [withCi(baseRun)]
}`,...(p=(l=n.parameters)==null?void 0:l.docs)==null?void 0:p.source},description:{story:"Успешный ран: зелёный бейдж, все стадии пройдены, деплой ещё не запускался.",...(h=(g=n.parameters)==null?void 0:g.docs)==null?void 0:h.description}}};var f,y,I,A,R;r.parameters={...r.parameters,docs:{...(f=r.parameters)==null?void 0:f.docs,source:{originalSource:`{
  decorators: [Story => {
    const resource = {
      id: 'temporary-1',
      projectId: 'p1',
      taskId: 't1',
      runId: 'run-1',
      userId: 'admin',
      machineId: 'm1',
      machineName: 'MacBook',
      path: '/managed/merge-run-tests',
      root: '/managed',
      category: 'merge-worktree' as const,
      generation: 'g1',
      identity: '1:2',
      gitCommonDir: null,
      gitRegistration: null,
      createdAt: 1,
      state: 'registered' as const
    };
    window.ci = {
      ...createFakeCi(),
      getTemporaryResources: async () => ({
        candidates: [{
          resource,
          eligible: false,
          reasons: ['machine_offline', 'git_changes'],
          retainUntil: null,
          bytes: null,
          sizeReason: 'machine_offline'
        }],
        attempts: [{
          id: 'attempt-1',
          resource,
          at: Date.now(),
          reason: 'machine_offline',
          outcome: 'deferred',
          freedBytes: null,
          error: null
        }]
      })
    };
    return <Story />;
  }]
}`,...(I=(y=r.parameters)==null?void 0:y.docs)==null?void 0:I.source},description:{story:"Open the resource panel to review offline, unknown-size and retained-work states.",...(R=(A=r.parameters)==null?void 0:A.docs)==null?void 0:R.description}}};var S,k,w,C,M;s.parameters={...s.parameters,docs:{...(S=s.parameters)==null?void 0:S.docs,source:{originalSource:`{
  args: {
    runId: 'queued-475'
  },
  decorators: [Story => {
    window.ci = queuedMergeCi();
    return <Story />;
  }]
}`,...(w=(k=s.parameters)==null?void 0:k.docs)==null?void 0:w.source},description:{story:"Shared fixtures exercise the queued action in DOM, Storybook and Chromium.",...(M=(C=s.parameters)==null?void 0:C.docs)==null?void 0:M.description}}};var x,b,_,q,j;a.parameters={...a.parameters,docs:{...(x=a.parameters)==null?void 0:x.docs,source:{originalSource:`{
  decorators: [withCi({
    ...baseRun,
    id: 'run-2',
    status: 'testing',
    stage: 'testing',
    mergeSha: null,
    finishedAt: null,
    canCancel: true,
    stages: stagesDone.slice(0, 3).concat([{
      ...stagesDone[3],
      status: 'running',
      finishedAt: null,
      durationMs: null,
      message: 'Запускаю обязательные проверки до push'
    }])
  }, [{
    ...baseRun,
    id: 'run-2',
    status: 'testing'
  }])],
  args: {
    runId: 'run-2'
  }
}`,...(_=(b=a.parameters)==null?void 0:b.docs)==null?void 0:_.source},description:{story:"Ран в работе: стадия testing выполняется, лог открыт, доступна отмена.",...(j=(q=a.parameters)==null?void 0:q.docs)==null?void 0:j.description}}};var v,D,B,O,T;o.parameters={...o.parameters,docs:{...(v=o.parameters)==null?void 0:v.docs,source:{originalSource:`{
  decorators: [withCi({
    ...baseRun,
    id: 'run-3',
    status: 'decision_required',
    stage: 'decision_required',
    mergeSha: null,
    error: 'Конфликты требуют решения пользователя',
    recommendedAction: 'Разрешите файлы в ветке задачи и повторите merge.',
    conflicts: ['apps/server/src/index.ts'],
    canRetry: true,
    stages: stagesDone.slice(0, 2)
  }, [{
    ...baseRun,
    id: 'run-3',
    status: 'decision_required'
  }, baseRun])],
  args: {
    runId: 'run-3',
    canStart: true
  }
}`,...(B=(D=o.parameters)==null?void 0:D.docs)==null?void 0:B.source},description:{story:"Конфликты: плашка ошибки с рекомендацией, список файлов, retry доступен.",...(T=(O=o.parameters)==null?void 0:O.docs)==null?void 0:T.description}}};const Ie=["Success","TemporaryResourceReview","Queued","Running","DecisionRequired"];export{o as DecisionRequired,s as Queued,a as Running,n as Success,r as TemporaryResourceReview,Ie as __namedExportsOrder,ye as default};
