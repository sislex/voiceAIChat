import{j as x}from"./jsx-runtime-BYYWji4R.js";import{r as Lo}from"./index-ClcD9ViR.js";import{within as q,userEvent as L}from"./index-DeN4tkzB.js";import{K as Mo}from"./KanbanBoard-W-ZVOsOO.js";import"./ProjectsApp-dH9TYZcw.js";import{m as e,a as i,b as a,c as _,n as jo,d as Ro}from"./fixtures-CFkrQMEm.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./mediaQuery-CCkbYk-e.js";import"./persistence-Y4P2JfJq.js";import"./projects-BdwKgk--.js";import"./TaskCard-BuPlcnSm.js";import"./merge-CBY8VSWw.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./ciFormat-wlGR6KpA.js";import"./ansi-DtpFsZ9v.js";import"./kanbanMeta-CBiUCx3-.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Avatar-Ds_00F2y.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./icons-MIP1fpxy.js";import"./projectTypes-C-9aONcK.js";import"./TaskModal-DG-cTVcU.js";import"./iframe-D-Q3L14w.js";import"./dateFormat-B8QlAdwY.js";import"./usePolling-okXCim0o.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./StatusPill-Dn6iIbOr.js";import"./Badge-zWzzcJYU.js";import"./PanelHeading-CyQiDTtn.js";import"./ProgressTrack-cilVHFpU.js";import"./Markdown-CXCb5Rql.js";import"./clipboard-BEgkkb6H.js";import"./core-BwXZ_Otv.js";import"./ChatColumn-nzqsxsmi.js";import"./machineHealth-E52qv8cU.js";import"./version-CuhpF6Tw.js";import"./questions-Bk4wc6lB.js";import"./tools-iBbMKii-.js";import"./images-CH23vBlI.js";import"./lazyScreen-CooZxeYV.js";import"./Skeleton-42oMjovX.js";import"./MessageImage-CtDLZeiJ.js";import"./animations--P72MiAI.js";import"./view-0MbJGw9Y.js";import"./ToolFrame-CqCmqPT9.js";import"./QuestionsForm-BIFaA7UX.js";import"./MessageMeta-DXRhU3rA.js";import"./kb-CjYTCLN0.js";import"./MessageTimeline-AcAPYvz7.js";import"./MessageActivity-DR8202wn.js";import"./autoGrow-CoBFBF9S.js";import"./uiPerformance-R53OMrUM.js";import"./useHotkeys-CjtRU-3i.js";import"./hotkeys-4oJJtujI.js";import"./useCommands-isko1sz4.js";import"./commands-BOmIcTa-.js";import"./VoiceBar-BSyoAAZC.js";import"./useAiAssist-CtGDklNp.js";import"./CiTaskSettings-B2RW3Tia.js";import"./llmAccess-BLY4i_O6.js";import"./CiSlotEditor-DglnL3dM.js";import"./FeaturePreviewSection-CJRBEHMh.js";import"./browserId-xQxZgjMo.js";import"./ManualQaPanel-Czvz411D.js";import"./ComponentQaPanel-Bfq_8f2I.js";import"./qa-B4ObmSZt.js";import"./MetricGrid-BvmJHgqt.js";import"./FeedItem-C_LU9yhH.js";import"./useQaStageUpdates-CqPw_UKl.js";import"./QaStageRunPanel-BPHuupvB.js";import"./RunFeed-gMpl9k0I.js";import"./AnsiText-L5oy_LV7.js";import"./CiConsole-Ovgqiy62.js";import"./loadState-C9E-sPL9.js";import"./kbUsageFormat-DuWbHUyl.js";import"./CiReport-O4v0dz3S.js";import"./MergePanel-Cjon5Arz.js";import"./QueuedMergeMachine-3G6jJgNn.js";import"./protocol-D2sHC_Sq.js";import"./AutomationProgressView-CuUxOFQT.js";import"./NewTaskCardView-CEPGBvKB.js";import"./NewTaskStages-DKk_2SXR.js";import"./NewTaskFeedPanel-BntD_IgA.js";import"./NewTaskMergePanel-C8-AVC9S.js";import"./shellPreferences-eSuxx32R.js";const fn={title:"Kanban/KanbanBoard",component:Mo,decorators:[o=>x.jsx("div",{className:"toolpage",style:{height:"calc(100vh - 32px)"},children:x.jsx(o,{})})],args:{projectName:"Голос Чат",loading:!1,members:Ro("admin","bob","carol"),currentUser:"admin",...jo()}},l={args:{board:a([],[])}},u={args:{board:a([i({id:"solo",name:"Бэклог",semanticType:"backlog"})],[])}},b={args:{board:(()=>{const o=Array.from({length:10},(r,s)=>i({id:`mc${s}`,name:`Этап ${s+1}`,position:(s+1)*1024})),n=o.flatMap((r,s)=>Array.from({length:s%3+1},()=>e({columnId:r.id})));return a(o,n)})()}},g={args:{board:(()=>{const o=i({id:"d0",name:"Пустая",position:1024}),n=i({id:"d1",name:"Одна",position:2048}),r=i({id:"d15",name:"Пятнадцать",position:3072});return a([o,n,r],[e({columnId:"d1"}),...Array.from({length:15},()=>e({columnId:"d15"}))])})()}},y={args:{projectName:"Очень длинное название проекта голосового чата с искусственным интеллектом",board:(()=>{const o=i({id:"long",name:"Колонка с чрезвычайно длинным названием, которое не помещается в шапку и должно обрезаться"});return a([o],[e({columnId:"long",title:"Задача с очень длинным названием: нужно спроектировать, реализовать и протестировать сценарий обработки переполнения текста в карточке канбан-доски, включая перенос строк и обрезание слишком длинных строк без пробелов"}),e({columnId:"long",title:"Слово-без-пробелов-"+"оченьдлинное".repeat(12)}),e({columnId:"long",title:"Восемь меток",labels:["frontend","backend","инфраструктура","дизайн-система","критично-для-релиза","техдолг","исследование","документация"]})])})()}},k={args:{board:null,loading:!0}},I={args:{board:null,error:"Не удалось загрузить доску: сервер недоступен",onRetry:()=>{}}},f={args:{board:a(_(),[e({columnId:"col-development"})]),loading:!0}},w={args:{board:a([i({id:"e1",name:"Бэклог"})],[e({columnId:"e1"})]),error:"Не удалось сохранить изменение: повторите попытку",onRetry:()=>{}}},S={args:{board:{columns:[{id:"b1",projectId:"p1",name:"",semanticType:"что-то",position:"наверх",hidden:0,wipLimit:-5,createdAt:1}],tasks:[{id:"bt1",projectId:"p1",columnId:"b1",type:"bug",parentId:"ghost",title:"",description:3,acceptanceCriteria:null,priority:"критический",assignee:42,labels:"ui",storyPoints:-1,dueDate:"завтра",flagged:"да",seq:void 0,position:null,createdAt:1,updatedAt:1},e({columnId:"b1",title:"Соседняя валидная задача",labels:["ok"]})]}}},$o=()=>{const o=_(),n=e({id:"ep-auth",type:"epic",title:"Авторизация",columnId:"col-backlog"}),r=e({id:"ep-voice",type:"epic",title:"Голосовой ввод",columnId:"col-backlog"});return a(o,[n,r,e({id:"st1",type:"story",parentId:"ep-auth",title:"Вход по паролю",columnId:"col-ready",assignee:"bob"}),e({parentId:"st1",title:"Форма входа",columnId:"col-development",assignee:"bob"}),e({parentId:"ep-voice",type:"story",title:"Запись с микрофона",columnId:"col-development",assignee:"carol"}),e({title:"Задача без эпика",columnId:"col-automated_qa"}),e({title:"Готовая задача",columnId:"col-done",assignee:"admin"})])},B={args:{board:$o(),defaultSwimlane:"epic"}},v={args:{board:$o(),defaultSwimlane:"assignee"}},h={args:{board:(()=>{const o=i({id:"wip",name:"Разработка",semanticType:"development",wipLimit:2});return a([o],Array.from({length:4},()=>e({columnId:"wip"})))})()}},C={args:{board:(()=>{const o=_(),n=e({id:"ep",type:"epic",title:"Платежи",columnId:"col-backlog"}),r=e({id:"st",type:"story",parentId:"ep",title:"Оплата картой: полный сценарий с 3-DS подтверждением",columnId:"col-development",assignee:"bob",labels:["payments","critical"],storyPoints:8,dueDate:Date.now()-3*24*60*60*1e3,flagged:!0});return a(o,[n,r,e({id:"sub1",parentId:"st",title:"Форма карты",columnId:"col-done"}),e({id:"sub2",parentId:"st",title:"Интеграция шлюза",columnId:"col-done"}),e({id:"sub3",parentId:"st",title:"Обработка отказов",columnId:"col-development"})])})()}},T={args:{board:a([i({id:"v1",name:"Видимая",position:1024}),i({id:"h1",name:"Скрытая",position:2048,hidden:!0})],[e({columnId:"v1"}),e({columnId:"h1",title:"Задача в скрытой колонке"})])}},P=()=>{const o=_();return a(o,[e({id:"dr1",title:"Починить авторизацию по токену",columnId:"col-backlog",assignee:"bob"}),e({id:"dr2",title:"Экран настроек: вкладка «Голос»",columnId:"col-backlog"}),e({id:"dr3",title:"Перенести карточку пальцем",columnId:"col-development",assignee:"admin",labels:["ui"]}),e({id:"dr4",title:"Скролл доски у края экрана",columnId:"col-development"}),e({id:"dr5",title:"Озвучить перенос в aria-live",columnId:"col-automated_qa",assignee:"carol"})])},p={args:{board:P()},play:async({canvasElement:o})=>{const n=q(o).getAllByTestId("task-card")[0];n==null||n.focus(),await L.keyboard(" "),await L.keyboard("{ArrowDown}")}},Vo=()=>{const o=Array.from({length:6},(n,r)=>i({id:`mobile-${r}`,name:r===1?"Development":`Колонка ${r+1}`,position:(r+1)*1024}));return a(o,o.flatMap((n,r)=>Array.from({length:r===0?15:3},(s,m)=>e({id:`mobile-task-${r}-${m}`,columnId:n.id,title:`Задача ${r+1}.${m+1}${r===0&&m===14?" — "+"LongUnbrokenTitle".repeat(12):""}`,position:(m+1)*1024,labels:["mobile","design","accessibility"],storyPoints:5,assignee:"admin"}))))},j={args:{board:Vo(),scrollScopeId:"mobile-scroll"},parameters:{viewport:{defaultViewport:"mobile1"}}},R={args:{board:Vo(),scrollScopeId:"mobile-filters"},parameters:{viewport:{defaultViewport:"mobile1"}},play:async({canvasElement:o})=>{const n=q(o).queryByRole("button",{name:/Фильтры \(/});n&&await L.click(n),await L.type(q(document.body).getByRole("searchbox",{name:"Поиск на доске"}),"no matching task")}},$={args:{board:P()},parameters:{viewport:{defaultViewport:"mobile2"}}},E={args:{board:P()},parameters:{viewport:{defaultViewport:"mobile2"}},play:p.play};function _o(){const[o,n]=Lo.useState(P),r=1024;return x.jsx(Mo,{projectName:"Голос Чат",loading:!1,members:Ro("admin","bob","carol"),currentUser:"admin",...jo(),board:o,onReorderColumns:s=>n(m=>({...m,columns:s.flatMap((A,D)=>{const c=m.columns.find(d=>d.id===A);return c?[{...c,position:(D+1)*r}]:[]})})),onMoveTask:(s,m,A,D)=>n(c=>{const d=A?c.tasks.find(t=>t.id===A):null,M=D?c.tasks.find(t=>t.id===D):null,xo=d&&M?(d.position+M.position)/2:d?d.position+r:M?M.position-r:Math.max(0,...c.tasks.filter(t=>t.columnId===m&&t.id!==s).map(t=>t.position))+r;return{...c,tasks:c.tasks.map(t=>t.id===s?{...t,columnId:m,position:xo}:t)}})})}const V={render:()=>x.jsx(_o,{})};var F,G,N,W,K;l.parameters={...l.parameters,docs:{...(F=l.parameters)==null?void 0:F.docs,source:{originalSource:`{
  args: {
    board: makeBoard([], [])
  }
}`,...(N=(G=l.parameters)==null?void 0:G.docs)==null?void 0:N.source},description:{story:"Пусто: ни колонок, ни задач — подсказка про колонки и бокс «+ колонка».",...(K=(W=l.parameters)==null?void 0:W.docs)==null?void 0:K.description}}};var H,U,O,z,J;u.parameters={...u.parameters,docs:{...(H=u.parameters)==null?void 0:H.docs,source:{originalSource:`{
  args: {
    board: makeBoard([makeColumn({
      id: 'solo',
      name: 'Бэклог',
      semanticType: 'backlog'
    })], [])
  }
}`,...(O=(U=u.parameters)==null?void 0:U.docs)==null?void 0:O.source},description:{story:"Одна колонка без задач: подсказка, чем её наполнить.",...(J=(z=u.parameters)==null?void 0:z.docs)==null?void 0:J.description}}};var Q,X,Y,Z,ee;b.parameters={...b.parameters,docs:{...(Q=b.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  args: {
    board: (() => {
      const cols = Array.from({
        length: 10
      }, (_, i) => makeColumn({
        id: \`mc\${i}\`,
        name: \`Этап \${i + 1}\`,
        position: (i + 1) * 1024
      }));
      const tasks = cols.flatMap((c, i) => Array.from({
        length: i % 3 + 1
      }, () => makeTask({
        columnId: c.id
      })));
      return makeBoard(cols, tasks);
    })()
  }
}`,...(Y=(X=b.parameters)==null?void 0:X.docs)==null?void 0:Y.source},description:{story:"Много колонок — горизонтальный скролл.",...(ee=(Z=b.parameters)==null?void 0:Z.docs)==null?void 0:ee.description}}};var oe,re,ne,ae,te;g.parameters={...g.parameters,docs:{...(oe=g.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  args: {
    board: (() => {
      const empty = makeColumn({
        id: 'd0',
        name: 'Пустая',
        position: 1024
      });
      const one = makeColumn({
        id: 'd1',
        name: 'Одна',
        position: 2048
      });
      const many = makeColumn({
        id: 'd15',
        name: 'Пятнадцать',
        position: 3072
      });
      return makeBoard([empty, one, many], [makeTask({
        columnId: 'd1'
      }), ...Array.from({
        length: 15
      }, () => makeTask({
        columnId: 'd15'
      }))]);
    })()
  }
}`,...(ne=(re=g.parameters)==null?void 0:re.docs)==null?void 0:ne.source},description:{story:"Плотность: колонки с 0, 1 и 15 карточками (вертикальный скролл).",...(te=(ae=g.parameters)==null?void 0:ae.docs)==null?void 0:te.description}}};var se,ie,me,ce,de;y.parameters={...y.parameters,docs:{...(se=y.parameters)==null?void 0:se.docs,source:{originalSource:`{
  args: {
    projectName: 'Очень длинное название проекта голосового чата с искусственным интеллектом',
    board: (() => {
      const col = makeColumn({
        id: 'long',
        name: 'Колонка с чрезвычайно длинным названием, которое не помещается в шапку и должно обрезаться'
      });
      return makeBoard([col], [makeTask({
        columnId: 'long',
        title: 'Задача с очень длинным названием: нужно спроектировать, реализовать и протестировать сценарий обработки переполнения текста в карточке канбан-доски, включая перенос строк и обрезание слишком длинных строк без пробелов'
      }), makeTask({
        columnId: 'long',
        title: 'Слово-без-пробелов-' + 'оченьдлинное'.repeat(12)
      }), makeTask({
        columnId: 'long',
        title: 'Восемь меток',
        labels: ['frontend', 'backend', 'инфраструктура', 'дизайн-система', 'критично-для-релиза', 'техдолг', 'исследование', 'документация']
      })]);
    })()
  }
}`,...(me=(ie=y.parameters)==null?void 0:ie.docs)==null?void 0:me.source},description:{story:"Длинные тексты: имя проекта, колонок, задач, слово без пробелов, 8 меток.",...(de=(ce=y.parameters)==null?void 0:ce.docs)==null?void 0:de.description}}};var pe,le,ue,be,ge;k.parameters={...k.parameters,docs:{...(pe=k.parameters)==null?void 0:pe.docs,source:{originalSource:`{
  args: {
    board: null,
    loading: true
  }
}`,...(ue=(le=k.parameters)==null?void 0:le.docs)==null?void 0:ue.source},description:{story:"Загрузка (первая): скелетон колонок и карточек, геометрия — как у доски.",...(ge=(be=k.parameters)==null?void 0:be.docs)==null?void 0:ge.description}}};var ye,ke,Ie,fe,we;I.parameters={...I.parameters,docs:{...(ye=I.parameters)==null?void 0:ye.docs,source:{originalSource:`{
  args: {
    board: null,
    error: 'Не удалось загрузить доску: сервер недоступен',
    onRetry: () => {}
  }
}`,...(Ie=(ke=I.parameters)==null?void 0:ke.docs)==null?void 0:Ie.source},description:{story:"Ошибка без доски: сообщение, деталь под «Подробнее», «Повторить».",...(we=(fe=I.parameters)==null?void 0:fe.docs)==null?void 0:we.description}}};var Se,Be,ve,he,Ce;f.parameters={...f.parameters,docs:{...(Se=f.parameters)==null?void 0:Se.docs,source:{originalSource:`{
  args: {
    board: makeBoard(makeDefaultColumns(), [makeTask({
      columnId: 'col-development'
    })]),
    loading: true
  }
}`,...(ve=(Be=f.parameters)==null?void 0:Be.docs)==null?void 0:ve.source},description:{story:"Повторная загрузка: доска остаётся на месте, сверху — индикатор обновления.",...(Ce=(he=f.parameters)==null?void 0:he.docs)==null?void 0:Ce.description}}};var Te,Ee,Ae,De,Me;w.parameters={...w.parameters,docs:{...(Te=w.parameters)==null?void 0:Te.docs,source:{originalSource:`{
  args: {
    board: makeBoard([makeColumn({
      id: 'e1',
      name: 'Бэклог'
    })], [makeTask({
      columnId: 'e1'
    })]),
    error: 'Не удалось сохранить изменение: повторите попытку',
    onRetry: () => {}
  }
}`,...(Ae=(Ee=w.parameters)==null?void 0:Ee.docs)==null?void 0:Ae.source},description:{story:"Ошибка поверх загруженной доски: данные остаются, ошибка — баннером.",...(Me=(De=w.parameters)==null?void 0:De.docs)==null?void 0:Me.description}}};var je,Re,$e,Ve,xe;S.parameters={...S.parameters,docs:{...(je=S.parameters)==null?void 0:je.docs,source:{originalSource:`{
  args: {
    board: {
      columns: [{
        id: 'b1',
        projectId: 'p1',
        name: '',
        semanticType: 'что-то',
        position: 'наверх',
        hidden: 0,
        wipLimit: -5,
        createdAt: 1
      }],
      tasks: [{
        id: 'bt1',
        projectId: 'p1',
        columnId: 'b1',
        type: 'bug',
        parentId: 'ghost',
        title: '',
        description: 3,
        acceptanceCriteria: null,
        priority: 'критический',
        assignee: 42,
        labels: 'ui',
        storyPoints: -1,
        dueDate: 'завтра',
        flagged: 'да',
        seq: undefined,
        position: null,
        createdAt: 1,
        updatedAt: 1
      }, makeTask({
        columnId: 'b1',
        title: 'Соседняя валидная задача',
        labels: ['ok']
      })]
    } as unknown as Board
  }
}`,...($e=(Re=S.parameters)==null?void 0:Re.docs)==null?void 0:$e.source},description:{story:"Битые данные: рендер без падения, все фолбэки нормализации.",...(xe=(Ve=S.parameters)==null?void 0:Ve.docs)==null?void 0:xe.description}}};var Le,_e,Pe,qe,Fe;B.parameters={...B.parameters,docs:{...(Le=B.parameters)==null?void 0:Le.docs,source:{originalSource:`{
  args: {
    board: epicBoard(),
    defaultSwimlane: 'epic'
  }
}`,...(Pe=(_e=B.parameters)==null?void 0:_e.docs)==null?void 0:Pe.source},description:{story:"Свимлейны по эпикам (карточки эпиков скрыты, последняя дорожка — «Без эпика»).",...(Fe=(qe=B.parameters)==null?void 0:qe.docs)==null?void 0:Fe.description}}};var Ge,Ne,We,Ke,He;v.parameters={...v.parameters,docs:{...(Ge=v.parameters)==null?void 0:Ge.docs,source:{originalSource:`{
  args: {
    board: epicBoard(),
    defaultSwimlane: 'assignee'
  }
}`,...(We=(Ne=v.parameters)==null?void 0:Ne.docs)==null?void 0:We.source},description:{story:"Свимлейны по исполнителям («Не назначено» — последняя дорожка).",...(He=(Ke=v.parameters)==null?void 0:Ke.docs)==null?void 0:He.description}}};var Ue,Oe,ze,Je,Qe;h.parameters={...h.parameters,docs:{...(Ue=h.parameters)==null?void 0:Ue.docs,source:{originalSource:`{
  args: {
    board: (() => {
      const col = makeColumn({
        id: 'wip',
        name: 'Разработка',
        semanticType: 'development',
        wipLimit: 2
      });
      return makeBoard([col], Array.from({
        length: 4
      }, () => makeTask({
        columnId: 'wip'
      })));
    })()
  }
}`,...(ze=(Oe=h.parameters)==null?void 0:Oe.docs)==null?void 0:ze.source},description:{story:"Превышенный WIP-лимит: подсветка шапки и счётчика 4/2.",...(Qe=(Je=h.parameters)==null?void 0:Je.docs)==null?void 0:Qe.description}}};var Xe,Ye,Ze,eo,oo;C.parameters={...C.parameters,docs:{...(Xe=C.parameters)==null?void 0:Xe.docs,source:{originalSource:`{
  args: {
    board: (() => {
      const cols = makeDefaultColumns();
      const epic = makeTask({
        id: 'ep',
        type: 'epic',
        title: 'Платежи',
        columnId: 'col-backlog'
      });
      const story = makeTask({
        id: 'st',
        type: 'story',
        parentId: 'ep',
        title: 'Оплата картой: полный сценарий с 3-DS подтверждением',
        columnId: 'col-development',
        assignee: 'bob',
        labels: ['payments', 'critical'],
        storyPoints: 8,
        dueDate: Date.now() - 3 * 24 * 60 * 60 * 1000,
        flagged: true
      });
      return makeBoard(cols, [epic, story, makeTask({
        id: 'sub1',
        parentId: 'st',
        title: 'Форма карты',
        columnId: 'col-done'
      }), makeTask({
        id: 'sub2',
        parentId: 'st',
        title: 'Интеграция шлюза',
        columnId: 'col-done'
      }), makeTask({
        id: 'sub3',
        parentId: 'st',
        title: 'Обработка отказов',
        columnId: 'col-development'
      })]);
    })()
  }
}`,...(Ze=(Ye=C.parameters)==null?void 0:Ye.docs)==null?void 0:Ze.source},description:{story:"Карточка со всеми атрибутами + запущенная фича.",...(oo=(eo=C.parameters)==null?void 0:eo.docs)==null?void 0:oo.description}}};var ro,no,ao,to,so;T.parameters={...T.parameters,docs:{...(ro=T.parameters)==null?void 0:ro.docs,source:{originalSource:`{
  args: {
    board: makeBoard([makeColumn({
      id: 'v1',
      name: 'Видимая',
      position: 1024
    }), makeColumn({
      id: 'h1',
      name: 'Скрытая',
      position: 2048,
      hidden: true
    })], [makeTask({
      columnId: 'v1'
    }), makeTask({
      columnId: 'h1',
      title: 'Задача в скрытой колонке'
    })])
  }
}`,...(ao=(no=T.parameters)==null?void 0:no.docs)==null?void 0:ao.source},description:{story:"Скрытые колонки: чекбокс «скрытые» в панели фильтров.",...(so=(to=T.parameters)==null?void 0:to.docs)==null?void 0:so.description}}};var io,mo,co,po,lo;p.parameters={...p.parameters,docs:{...(io=p.parameters)==null?void 0:io.docs,source:{originalSource:`{
  args: {
    board: dragBoard()
  },
  play: async ({
    canvasElement
  }) => {
    const card = within(canvasElement).getAllByTestId('task-card')[0];
    card?.focus();
    await userEvent.keyboard(' ');
    await userEvent.keyboard('{ArrowDown}');
  }
}`,...(co=(mo=p.parameters)==null?void 0:mo.docs)==null?void 0:co.source},description:{story:`Карточка захвачена: так доска выглядит в середине переноса. Взято с
клавиатуры (Space) и сдвинуто стрелкой — карточка подсвечена и остаётся на
месте (иначе слетел бы фокус), а плейсхолдер показывает выбранное место.
Тот же плейсхолдер видно и при переносе пальцем — только там карточка уезжает
в приподнятую копию под пальцем, которую скриншотом не поймать.`,...(lo=(po=p.parameters)==null?void 0:po.docs)==null?void 0:lo.description}}};var uo,bo,go;j.parameters={...j.parameters,docs:{...(uo=j.parameters)==null?void 0:uo.docs,source:{originalSource:`{
  args: {
    board: mobileScrollBoard(),
    scrollScopeId: 'mobile-scroll'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(go=(bo=j.parameters)==null?void 0:bo.docs)==null?void 0:go.source}}};var yo,ko,Io;R.parameters={...R.parameters,docs:{...(yo=R.parameters)==null?void 0:yo.docs,source:{originalSource:`{
  args: {
    board: mobileScrollBoard(),
    scrollScopeId: 'mobile-filters'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  },
  play: async ({
    canvasElement
  }) => {
    const button = within(canvasElement).queryByRole('button', {
      name: /Фильтры \\(/
    });
    if (button) await userEvent.click(button);
    await userEvent.type(within(document.body).getByRole('searchbox', {
      name: 'Поиск на доске'
    }), 'no matching task');
  }
}`,...(Io=(ko=R.parameters)==null?void 0:ko.docs)==null?void 0:Io.source}}};var fo,wo,So;$.parameters={...$.parameters,docs:{...(fo=$.parameters)==null?void 0:fo.docs,source:{originalSource:`{
  args: {
    board: dragBoard()
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile2'
    }
  }
}`,...(So=(wo=$.parameters)==null?void 0:wo.docs)==null?void 0:So.source}}};var Bo,vo,ho,Co,To;E.parameters={...E.parameters,docs:{...(Bo=E.parameters)==null?void 0:Bo.docs,source:{originalSource:`{
  args: {
    board: dragBoard()
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile2'
    }
  },
  play: GrabbedCard.play
}`,...(ho=(vo=E.parameters)==null?void 0:vo.docs)==null?void 0:ho.source},description:{story:"Телефон в середине переноса: плейсхолдер и подсвеченная карточка на узком экране.",...(To=(Co=E.parameters)==null?void 0:Co.docs)==null?void 0:To.description}}};var Eo,Ao,Do;V.parameters={...V.parameters,docs:{...(Eo=V.parameters)==null?void 0:Eo.docs,source:{originalSource:`{
  render: () => <InteractiveBoard />
}`,...(Do=(Ao=V.parameters)==null?void 0:Ao.docs)==null?void 0:Do.source}}};const wn=["EmptyBoard","SingleColumn","ManyColumns","ColumnDensity","LongTitles","Loading","ErrorState","Refreshing","ErrorWithBoard","BrokenData","SwimlanesByEpic","SwimlanesByAssignee","WipExceeded","FullFeaturedCard","HiddenColumns","GrabbedCard","MobileScroll","MobileFilters","MobileViewport","MobileGrabbedCard","Interactive"];export{S as BrokenData,g as ColumnDensity,l as EmptyBoard,I as ErrorState,w as ErrorWithBoard,C as FullFeaturedCard,p as GrabbedCard,T as HiddenColumns,V as Interactive,k as Loading,y as LongTitles,b as ManyColumns,R as MobileFilters,E as MobileGrabbedCard,j as MobileScroll,$ as MobileViewport,f as Refreshing,u as SingleColumn,v as SwimlanesByAssignee,B as SwimlanesByEpic,h as WipExceeded,wn as __namedExportsOrder,fn as default};
