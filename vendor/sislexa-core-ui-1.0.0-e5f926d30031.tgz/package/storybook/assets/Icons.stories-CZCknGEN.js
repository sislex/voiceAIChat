import{j as e}from"./jsx-runtime-BYYWji4R.js";import{r as p}from"./index-ClcD9ViR.js";import{i as E}from"./icons-MIP1fpxy.js";import{I as M,B as C,a as O}from"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import{P as k,S as P,M as l,T}from"./parts-C1UcRfGq.js";import"./_commonjsHelpers-Cpj98o6Y.js";const R={title:"Foundations/Icons",parameters:{layout:"padded"}},d=Object.entries(E).filter(([t])=>t.endsWith("Icon")).sort(([t],[n])=>t.localeCompare(n)),m=[16,20,24],N=m.map(t=>`.fnd-ic-${t} svg { width: ${t}px; height: ${t}px; }`).join(`
`);function b(t){const n=new Set;for(const r of Array.from(t.querySelectorAll("[fill], [stroke]")))for(const o of["fill","stroke"]){const s=r.getAttribute(o);s&&s!=="currentColor"&&s!=="none"&&n.add(s)}return[...n]}async function w(t){try{return await navigator.clipboard.writeText(t),!0}catch{const n=document.createElement("textarea");n.value=t,n.style.position="fixed",n.style.opacity="0",document.body.appendChild(n),n.select();const r=document.execCommand("copy");return n.remove(),r}}function $({name:t,Icon:n}){const r=O(),o=p.useRef(null),[s,B]=p.useState([]);return p.useEffect(()=>{o.current&&B(b(o.current))},[]),e.jsxs(C,{variant:"secondary",title:"Скопировать имя",onClick:()=>{w(t).then(a=>a?r.success(`Скопировано: ${t}`):r.error("Не удалось скопировать имя"))},style:{display:"grid",gap:8,justifyItems:"center",height:"auto",padding:"var(--space-150)",textAlign:"center"},children:[e.jsx("span",{ref:o,style:{display:"inline-flex",alignItems:"flex-end",gap:12},"aria-hidden":"true",children:m.map(a=>e.jsx("span",{className:`fnd-ic-${a}`,style:{display:"inline-flex"},children:e.jsx(n,{})},a))}),e.jsx("span",{style:{display:"flex",gap:12,fontSize:10,color:"var(--text-dim)"},"aria-hidden":"true",children:m.map(a=>e.jsx("span",{style:{width:a,textAlign:"center"},children:a},a))}),e.jsx(l,{children:t}),s.length>0&&e.jsxs("span",{className:"ci-lozenge ci-lozenge--progress",style:{textTransform:"none"},children:["цвет прошит: ",s.join(", ")]})]})}const i={name:"Сетка",render:()=>e.jsxs(k,{title:"Icons",lead:e.jsxs(e.Fragment,{children:["Все экспорты ",e.jsx(l,{children:"components/icons.tsx"}),", чьё имя кончается на ",e.jsx(l,{children:"Icon"}),". Клик по карточке копирует имя компонента. Иконка должна рисоваться ",e.jsx(l,{children:"currentColor"})," — тогда она сама следует теме и варианту кнопки."]}),children:[e.jsx("style",{children:N}),e.jsx(P,{title:`Иконки (${d.length})`,hint:"Размеры 16 / 20 / 24 — те же, что встречаются в шапках, композере и тулбарах.",children:e.jsx("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fill, minmax(180px, 1fr))",gap:"var(--space-150)"},children:d.map(([t,n])=>e.jsx($,{name:t,Icon:n},t))})})]})},c={name:"В кнопках",render:()=>e.jsxs(k,{title:"Icons — в кнопках",lead:"Иконка на currentColor меняет цвет вместе с вариантом кнопки и темой. Если в обеих темах она осталась одинаково серой — цвет прошит в SVG.",children:[e.jsx("style",{children:N}),e.jsx("div",{style:{display:"grid",gap:"var(--space-150)"},children:["light","dark"].map(t=>e.jsx(T,{theme:t,children:e.jsxs("div",{style:{display:"flex",gap:"var(--space-100)",flexWrap:"wrap",alignItems:"center"},children:[d.map(([n,r])=>e.jsx(M,{variant:"ghost","aria-label":n,title:n,children:e.jsx("span",{className:"fnd-ic-20",style:{display:"inline-flex"},children:e.jsx(r,{})})},n)),d.slice(0,2).map(([n,r])=>e.jsx(C,{variant:"primary",iconLeft:e.jsx(r,{}),children:n},n))]})},t))})]})};var x,u,y,h,f;i.parameters={...i.parameters,docs:{...(x=i.parameters)==null?void 0:x.docs,source:{originalSource:`{
  name: 'Сетка',
  render: () => <Page title="Icons" lead={<>
          Все экспорты <Mono>components/icons.tsx</Mono>, чьё имя кончается на <Mono>Icon</Mono>. Клик по карточке копирует имя
          компонента. Иконка должна рисоваться <Mono>currentColor</Mono> — тогда она сама следует теме и варианту кнопки.
        </>}>
      <style>{SIZE_CSS}</style>
      <Section title={\`Иконки (\${ICONS.length})\`} hint="Размеры 16 / 20 / 24 — те же, что встречаются в шапках, композере и тулбарах.">
        <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
        gap: 'var(--space-150)'
      }}>
          {ICONS.map(([name, Icon]) => <IconCard name={name} Icon={Icon} key={name} />)}
        </div>
      </Section>
    </Page>
}`,...(y=(u=i.parameters)==null?void 0:u.docs)==null?void 0:y.source},description:{story:"Сетка всех иконок в текущей теме тулбара.",...(f=(h=i.parameters)==null?void 0:h.docs)==null?void 0:f.description}}};var g,I,j,v,S;c.parameters={...c.parameters,docs:{...(g=c.parameters)==null?void 0:g.docs,source:{originalSource:`{
  name: 'В кнопках',
  render: () => <Page title="Icons — в кнопках" lead="Иконка на currentColor меняет цвет вместе с вариантом кнопки и темой. Если в обеих темах она осталась одинаково серой — цвет прошит в SVG.">
      <style>{SIZE_CSS}</style>
      <div style={{
      display: 'grid',
      gap: 'var(--space-150)'
    }}>
        {(['light', 'dark'] as const).map(theme => <ThemePane theme={theme} key={theme}>
            <div style={{
          display: 'flex',
          gap: 'var(--space-100)',
          flexWrap: 'wrap',
          alignItems: 'center'
        }}>
              {ICONS.map(([name, Icon]) => <IconButton variant="ghost" aria-label={name} title={name} key={name}>
                  <span className="fnd-ic-20" style={{
              display: 'inline-flex'
            }}>
                    <Icon />
                  </span>
                </IconButton>)}
              {ICONS.slice(0, 2).map(([name, Icon]) => <Button variant="primary" key={name} iconLeft={<Icon />}>
                  {name}
                </Button>)}
            </div>
          </ThemePane>)}
      </div>
    </Page>
}`,...(j=(I=c.parameters)==null?void 0:I.docs)==null?void 0:j.source},description:{story:"Иконки внутри кнопок в обеих темах: видно, кто следует currentColor, а кто нет.",...(S=(v=c.parameters)==null?void 0:v.docs)==null?void 0:S.description}}};const V=["Grid","OnButtons"];export{i as Grid,c as OnButtons,V as __namedExportsOrder,R as default};
