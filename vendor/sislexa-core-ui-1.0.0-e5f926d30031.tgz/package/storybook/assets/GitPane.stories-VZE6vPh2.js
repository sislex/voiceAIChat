import{within as R,userEvent as n}from"./index-DeN4tkzB.js";import{m as s,a as G,b as pa,c as da,d as ma,e as la}from"./git-p1B0wyA1.js";import{GitPane as ua}from"./GitPane-CrutkSUc.js";import"./time-CfyNS7J_.js";import"./jsx-runtime-BYYWji4R.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./StatusPill-Dn6iIbOr.js";import"./Badge-zWzzcJYU.js";import"./loadState-C9E-sPL9.js";import"./CodeDiff-eD9pwj9B.js";import"./iframe-D-Q3L14w.js";import"./codeHighlight-COY3V3up.js";import"./core-BwXZ_Otv.js";import"./mediaQuery-CCkbYk-e.js";import"./gitLabels-C1YTJXFU.js";import"./dateFormat-B8QlAdwY.js";const t=(e,r={})=>({"projects:gitStatus":async()=>e,"projects:gitBranches":async()=>la(),"projects:gitDiff":async({path:a})=>ma({path:a}),"projects:gitTree":async({dir:a})=>({...da(),dir:a}),"projects:gitFile":async({path:a})=>pa({path:a}),"projects:gitSaveFile":async({path:a,content:j})=>({file:{path:a,ref:null,content:j,size:j.length,truncated:!1,binary:!1},status:e}),"projects:gitCheckout":async()=>({status:e,createdLocal:!1}),"projects:gitCreateBranch":async()=>({status:e,createdLocal:!0}),"projects:gitCommit":async()=>({status:{...e,changes:[]},sha:"d".repeat(40),staged:1}),"projects:gitPush":async()=>({status:e,branch:e.branch??"CHAT-42",sha:"d".repeat(40)}),"projects:gitPull":async()=>({status:e,mode:"rebase",pulled:2}),"projects:gitDiscard":async()=>({status:e,reverted:1,removed:0}),"projects:gitBranchChanges":async()=>({base:"e".repeat(40),changes:[{path:"apps/server/src/git/scripts.ts",oldPath:null,state:"added",staged:!0,worktree:!1},{path:"packages/shared/src/gitWorkspace.ts",oldPath:null,state:"added",staged:!0,worktree:!1},{path:"docs/kb/ui.md",oldPath:null,state:"modified",staged:!0,worktree:!1}],truncated:!1}),"projects:gitStage":async()=>e,"projects:gitLog":async()=>({commits:e.commitsAhead}),"projects:gitCommitDetail":async({sha:a})=>({sha:a,subject:"feat(git): панель кода",author:"bob",at:1788172791,files:[{path:"apps/server/src/index.ts",oldPath:null,state:"modified"}],truncated:!1}),"projects:gitGrep":async({query:a})=>({query:a,matches:[{path:"apps/server/src/index.ts",line:3,text:"const app = await buildServer()"},{path:"packages/ui/src/App.tsx",line:128,text:"const GitPane = lazy(async () => {"}],truncated:!1}),"projects:gitFileBytes":async({path:a})=>({path:a,dataBase64:"YQ==",size:1}),"projects:gitConflict":async({path:a})=>({path:a,base:{path:a,ref:":1:",content:`общий предок
строка два
`,size:24,truncated:!1,binary:!1},ours:{path:a,ref:":2:",content:`наша версия
строка два
`,size:22,truncated:!1,binary:!1},theirs:{path:a,ref:":3:",content:`их версия
строка два
`,size:20,truncated:!1,binary:!1}}),"projects:gitResolveConflict":async()=>e,...r}),Ma={title:"Git/GitPane",component:ua,parameters:{layout:"fullscreen"},args:{projectId:"p1",workspaceId:"ws:ws-1",api:t(s())}},c={},i={args:{api:t(s({changes:[],ahead:1}))}},o={args:{api:t(s({ref:G({busy:{kind:"ci",runId:"run-7",status:"running"}})})),onOpenRun:()=>{}}},p={args:{api:t(s({ref:G({kind:"merge-clone",writable:!1})}))}},d={args:{api:t(s({branch:"main",ahead:2}))}},m={args:{api:t(s({branch:null,detached:!0,ahead:0}))}},l={args:{api:t(s({problem:"workspace_released",changes:[],ref:G({released:!0})}))}},u={args:{api:t(s({problem:"machine_offline",changes:[],ref:G({online:!1})}))}},g={args:{api:t(s({changesTruncated:!0,changes:Array.from({length:12},(e,r)=>({path:`packages/ui/src/components/file-${r}.tsx`,oldPath:null,state:r%4===0?"untracked":r%5===0?"conflict":"modified",staged:r%3===0,worktree:!0}))}))}},h={args:{api:t(s(),{"projects:gitStatus":async()=>{throw new Error("Машина не в сети")}})}},f={args:{api:t(s({ref:G({writable:!1,readOnlyReason:"Ваша роль не позволяет менять рабочую копию"})}))}},y={args:{api:t(s({behind:3,ahead:1}))}},k={args:{api:t(s({behind:3,ahead:0,changes:[]}))}},w={play:async({canvasElement:e})=>{const r=R(e);await n.click(await r.findByRole("tab",{name:"Ветка"}))}},b={play:async({canvasElement:e})=>{const r=R(e);await n.click(await r.findByRole("tab",{name:"Поиск"})),await n.type(await r.findByLabelText("Поиск по файлам и содержимому"),"buildServer"),await n.click(r.getByRole("button",{name:"Искать"}))}},v={args:{api:t(s({changes:[{path:"apps/server/src/git/scripts.ts",oldPath:null,state:"conflict",staged:!1,worktree:!0}]}))},play:async({canvasElement:e})=>{const r=R(e);await n.click(await r.findByText("apps/server/src/git/scripts.ts")),await n.click(await r.findByRole("tab",{name:"Конфликт"}))}},S={parameters:{viewport:{defaultViewport:"mobile1"}}},B={args:{api:t(s({changesTruncated:!0,changes:Array.from({length:8},(e,r)=>({path:`packages/ui/src/components/file-${r}.tsx`,oldPath:null,state:"modified",staged:!1,worktree:!0}))}))}};var C,E,x,P,T;c.parameters={...c.parameters,docs:{...(C=c.parameters)==null?void 0:C.docs,source:{originalSource:"{}",...(x=(E=c.parameters)==null?void 0:E.docs)==null?void 0:x.source},description:{story:"Обычная работа: ветка задачи, три изменения, есть что коммитить.",...(T=(P=c.parameters)==null?void 0:P.docs)==null?void 0:T.description}}};var O,W,_,A,D;i.parameters={...i.parameters,docs:{...(O=i.parameters)==null?void 0:O.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      changes: [],
      ahead: 1
    }))
  }
}`,...(_=(W=i.parameters)==null?void 0:W.docs)==null?void 0:_.source},description:{story:"Всё закоммичено — следующий CI-ран пройдёт проверку чистого дерева.",...(D=(A=i.parameters)==null?void 0:A.docs)==null?void 0:D.description}}};var M,z,F,I,H;o.parameters={...o.parameters,docs:{...(M=o.parameters)==null?void 0:M.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      ref: makeGitWorkspace({
        busy: {
          kind: 'ci',
          runId: 'run-7',
          status: 'running'
        }
      })
    })),
    onOpenRun: () => {}
  }
}`,...(F=(z=o.parameters)==null?void 0:z.docs)==null?void 0:F.source},description:{story:"Каталог занят раном: смотреть можно, менять нельзя.",...(H=(I=o.parameters)==null?void 0:I.docs)==null?void 0:H.description}}};var L,$,Q,V,Y;p.parameters={...p.parameters,docs:{...(L=p.parameters)==null?void 0:L.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      ref: makeGitWorkspace({
        kind: 'merge-clone',
        writable: false
      })
    }))
  }
}`,...(Q=($=p.parameters)==null?void 0:$.docs)==null?void 0:Q.source},description:{story:"Merge-клон: им управляет merge-ран, правки запрещены.",...(Y=(V=p.parameters)==null?void 0:V.docs)==null?void 0:Y.description}}};var N,U,q,J,K;d.parameters={...d.parameters,docs:{...(N=d.parameters)==null?void 0:N.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      branch: 'main',
      ahead: 2
    }))
  }
}`,...(q=(U=d.parameters)==null?void 0:U.docs)==null?void 0:q.source},description:{story:"На main панель не пушит: туда ведут merge-ран и релизы.",...(K=(J=d.parameters)==null?void 0:J.docs)==null?void 0:K.description}}};var X,Z,ee,ae,re;m.parameters={...m.parameters,docs:{...(X=m.parameters)==null?void 0:X.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      branch: null,
      detached: true,
      ahead: 0
    }))
  }
}`,...(ee=(Z=m.parameters)==null?void 0:Z.docs)==null?void 0:ee.source},description:{story:"Detached HEAD: коммитить можно, но видно, что ветки нет.",...(re=(ae=m.parameters)==null?void 0:ae.docs)==null?void 0:re.description}}};var se,te,ne,ce,ie;l.parameters={...l.parameters,docs:{...(se=l.parameters)==null?void 0:se.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      problem: 'workspace_released',
      changes: [],
      ref: makeGitWorkspace({
        released: true
      })
    }))
  }
}`,...(ne=(te=l.parameters)==null?void 0:te.docs)==null?void 0:ne.source},description:{story:"Каталог снесён cleanup-шагом рана — объяснение и следующий шаг.",...(ie=(ce=l.parameters)==null?void 0:ce.docs)==null?void 0:ie.description}}};var oe,pe,de,me,le;u.parameters={...u.parameters,docs:{...(oe=u.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      problem: 'machine_offline',
      changes: [],
      ref: makeGitWorkspace({
        online: false
      })
    }))
  }
}`,...(de=(pe=u.parameters)==null?void 0:pe.docs)==null?void 0:de.source},description:{story:"Машина офлайн: состояние читается прямо с неё, поэтому его просто нет.",...(le=(me=u.parameters)==null?void 0:me.docs)==null?void 0:le.description}}};var ue,ge,he,fe,ye;g.parameters={...g.parameters,docs:{...(ue=g.parameters)==null?void 0:ue.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      changesTruncated: true,
      changes: Array.from({
        length: 12
      }, (_, index) => ({
        path: \`packages/ui/src/components/file-\${index}.tsx\`,
        oldPath: null,
        state: index % 4 === 0 ? 'untracked' as const : index % 5 === 0 ? 'conflict' as const : 'modified' as const,
        staged: index % 3 === 0,
        worktree: true
      }))
    }))
  }
}`,...(he=(ge=g.parameters)==null?void 0:ge.docs)==null?void 0:he.source},description:{story:"Много изменений: список обрезан сервером, и панель об этом говорит.",...(ye=(fe=g.parameters)==null?void 0:fe.docs)==null?void 0:ye.description}}};var ke,we,be,ve,Se;h.parameters={...h.parameters,docs:{...(ke=h.parameters)==null?void 0:ke.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus(), {
      'projects:gitStatus': (async () => {
        throw new Error('Машина не в сети');
      }) as never
    })
  }
}`,...(be=(we=h.parameters)==null?void 0:we.docs)==null?void 0:be.source},description:{story:"Ошибка чтения состояния: экран не пустой, а с «Повторить».",...(Se=(ve=h.parameters)==null?void 0:ve.docs)==null?void 0:Se.description}}};var Be,Ge,Re,je,Ce;f.parameters={...f.parameters,docs:{...(Be=f.parameters)==null?void 0:Be.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      ref: makeGitWorkspace({
        writable: false,
        readOnlyReason: 'Ваша роль не позволяет менять рабочую копию'
      })
    }))
  }
}`,...(Re=(Ge=f.parameters)==null?void 0:Ge.docs)==null?void 0:Re.source},description:{story:"Роль без `repository:write`: смотреть можно, кнопки записи объясняют отказ.",...(Ce=(je=f.parameters)==null?void 0:je.docs)==null?void 0:Ce.description}}};var Ee,xe,Pe,Te,Oe;y.parameters={...y.parameters,docs:{...(Ee=y.parameters)==null?void 0:Ee.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      behind: 3,
      ahead: 1
    }))
  }
}`,...(Pe=(xe=y.parameters)==null?void 0:xe.docs)==null?void 0:Pe.source},description:{story:"Ветка отстала от origin: появляется «Подтянуть», на грязном дереве — выключенная.",...(Oe=(Te=y.parameters)==null?void 0:Te.docs)==null?void 0:Oe.description}}};var We,_e,Ae,De,Me;k.parameters={...k.parameters,docs:{...(We=k.parameters)==null?void 0:We.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      behind: 3,
      ahead: 0,
      changes: []
    }))
  }
}`,...(Ae=(_e=k.parameters)==null?void 0:_e.docs)==null?void 0:Ae.source},description:{story:"Отстала и дерево чистое — подтянуть можно сразу.",...(Me=(De=k.parameters)==null?void 0:De.docs)==null?void 0:Me.description}}};var ze,Fe,Ie,He,Le;w.parameters={...w.parameters,docs:{...(ze=w.parameters)==null?void 0:ze.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByRole('tab', {
      name: 'Ветка'
    }));
  }
}`,...(Ie=(Fe=w.parameters)==null?void 0:Fe.docs)==null?void 0:Ie.source},description:{story:"Изменения ветки против общего предка: главный вид, когда ревьюют работу модели.",...(Le=(He=w.parameters)==null?void 0:He.docs)==null?void 0:Le.description}}};var $e,Qe,Ve,Ye,Ne;b.parameters={...b.parameters,docs:{...($e=b.parameters)==null?void 0:$e.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByRole('tab', {
      name: 'Поиск'
    }));
    await userEvent.type(await canvas.findByLabelText('Поиск по файлам и содержимому'), 'buildServer');
    await userEvent.click(canvas.getByRole('button', {
      name: 'Искать'
    }));
  }
}`,...(Ve=(Qe=b.parameters)==null?void 0:Qe.docs)==null?void 0:Ve.source},description:{story:"Поиск: имя фильтруется на месте, содержимое ищет git grep.",...(Ne=(Ye=b.parameters)==null?void 0:Ye.docs)==null?void 0:Ne.description}}};var Ue,qe,Je,Ke,Xe;v.parameters={...v.parameters,docs:{...(Ue=v.parameters)==null?void 0:Ue.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      changes: [{
        path: 'apps/server/src/git/scripts.ts',
        oldPath: null,
        state: 'conflict',
        staged: false,
        worktree: true
      }]
    }))
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByText('apps/server/src/git/scripts.ts'));
    await userEvent.click(await canvas.findByRole('tab', {
      name: 'Конфликт'
    }));
  }
}`,...(Je=(qe=v.parameters)==null?void 0:qe.docs)==null?void 0:Je.source},description:{story:"Конфликт слияния: наша версия против их, общий предок — по требованию.",...(Xe=(Ke=v.parameters)==null?void 0:Ke.docs)==null?void 0:Xe.description}}};var Ze,ea,aa,ra,sa;S.parameters={...S.parameters,docs:{...(Ze=S.parameters)==null?void 0:Ze.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(aa=(ea=S.parameters)==null?void 0:ea.docs)==null?void 0:aa.source},description:{story:"Телефон: одна колонка, редактор деградирует до textarea (PHONE_EDITOR_QUERY).",...(sa=(ra=S.parameters)==null?void 0:ra.docs)==null?void 0:sa.description}}};var ta,na,ca,ia,oa;B.parameters={...B.parameters,docs:{...(ta=B.parameters)==null?void 0:ta.docs,source:{originalSource:`{
  args: {
    api: api(makeGitStatus({
      changesTruncated: true,
      changes: Array.from({
        length: 8
      }, (_, index) => ({
        path: \`packages/ui/src/components/file-\${index}.tsx\`,
        oldPath: null,
        state: 'modified' as const,
        staged: false,
        worktree: true
      }))
    }))
  }
}`,...(ca=(na=B.parameters)==null?void 0:na.docs)==null?void 0:ca.source},description:{story:"Список изменений обрезан сервером — есть чем его продолжить.",...(oa=(ia=B.parameters)==null?void 0:ia.docs)==null?void 0:oa.description}}};const za=["Changes","Clean","BusyByRun","MergeCloneReadOnly","ProtectedBranch","DetachedHead","WorkspaceReleased","MachineOffline","TruncatedChanges","ReadFailed","RoleWithoutWriteAccess","BehindOrigin","BehindOriginClean","BranchChanges","Search","Conflict","Mobile","TruncatedWithMore"];export{y as BehindOrigin,k as BehindOriginClean,w as BranchChanges,o as BusyByRun,c as Changes,i as Clean,v as Conflict,m as DetachedHead,u as MachineOffline,p as MergeCloneReadOnly,S as Mobile,d as ProtectedBranch,h as ReadFailed,f as RoleWithoutWriteAccess,b as Search,g as TruncatedChanges,B as TruncatedWithMore,l as WorkspaceReleased,za as __namedExportsOrder,Ma as default};
