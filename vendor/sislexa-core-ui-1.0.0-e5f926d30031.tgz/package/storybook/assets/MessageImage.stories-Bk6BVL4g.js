import{j as p}from"./jsx-runtime-BYYWji4R.js";import{within as $,userEvent as ee,expect as ae}from"./index-DeN4tkzB.js";import{M as re}from"./MessageImage-CtDLZeiJ.js";import"./tools-iBbMKii-.js";import"./ci-awuetLx1.js";import{P as se,d as m,m as oe}from"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./images-CH23vBlI.js";import"./clipboard-BEgkkb6H.js";import"./animations--P72MiAI.js";import"./view-0MbJGw9Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./ToolFrame-CqCmqPT9.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./time-CfyNS7J_.js";import"./kb-CjYTCLN0.js";const Z=m({read:()=>new Promise(()=>{})}),te=m({read:async()=>{throw new Error("Файл пустой или недоступен")}}),Te={title:"Chat/MessageImage",component:re,args:{image:{path:"/home/dev/out/plot.svg",agentId:"m1"},ops:m(),agents:[oe({id:"m1",name:"MacBook"})]},decorators:[e=>p.jsx("div",{className:"msg ai",children:p.jsx("div",{className:"bub",style:{maxWidth:720},children:p.jsx(e,{})})})]},a={},r={args:{image:{path:"/home/dev/out/plot.svg",agentId:"m1",caption:"Ходов модели в день за последнюю неделю"}}},s={args:{ops:Z}},o={args:{ops:Z,live:!0}},t={args:{ops:te}},n={args:{image:{path:"/var/lib/voicechat/users/admin/plot.svg"},agents:[],readServerFile:async e=>({name:e.split("/").pop()??e,dataBase64:se})}},i={args:{variant:"modal",onClose:()=>{}}},c={play:async({canvasElement:e})=>{const d=$(e);await ee.click(await d.findByLabelText("Открыть картинку на весь экран")),await ae(d.getByTestId("image-surface")).toBeInTheDocument()}};var g,l,u,v,h;a.parameters={...a.parameters,docs:{...(g=a.parameters)==null?void 0:g.docs,source:{originalSource:"{}",...(u=(l=a.parameters)==null?void 0:l.docs)==null?void 0:u.source},description:{story:"Готовая картинка: превью в рамке тула, клик разворачивает на весь экран.",...(h=(v=a.parameters)==null?void 0:v.docs)==null?void 0:h.description}}};var y,S,w,x,E;r.parameters={...r.parameters,docs:{...(y=r.parameters)==null?void 0:y.docs,source:{originalSource:`{
  args: {
    image: {
      path: '/home/dev/out/plot.svg',
      agentId: 'm1',
      caption: 'Ходов модели в день за последнюю неделю'
    }
  }
}`,...(w=(S=r.parameters)==null?void 0:S.docs)==null?void 0:w.source},description:{story:"С подписью модели — она живёт под картинкой, а не в шапке рамки.",...(E=(x=r.parameters)==null?void 0:x.docs)==null?void 0:E.description}}};var f,B,I,L,O;s.parameters={...s.parameters,docs:{...(f=s.parameters)==null?void 0:f.docs,source:{originalSource:`{
  args: {
    ops: pendingOps
  }
}`,...(I=(B=s.parameters)==null?void 0:B.docs)==null?void 0:I.source},description:{story:"Файла ещё нет, ход завершён: плитка-заглушка «Загрузка картинки…».",...(O=(L=s.parameters)==null?void 0:L.docs)==null?void 0:O.description}}};var T,M,b,C,F;o.parameters={...o.parameters,docs:{...(T=o.parameters)==null?void 0:T.docs,source:{originalSource:`{
  args: {
    ops: pendingOps,
    live: true
  }
}`,...(b=(M=o.parameters)==null?void 0:M.docs)==null?void 0:b.source},description:{story:"Ход идёт: та же плитка, но подпись честнее — «Рисую картинку…».",...(F=(C=o.parameters)==null?void 0:C.docs)==null?void 0:F.description}}};var _,j,k,A,R;t.parameters={...t.parameters,docs:{...(_=t.parameters)==null?void 0:_.docs,source:{originalSource:`{
  args: {
    ops: failingOps
  }
}`,...(k=(j=t.parameters)==null?void 0:j.docs)==null?void 0:k.source},description:{story:"Ход закончился, а файла нет: сообщение об ошибке и путь, по которому искали.",...(R=(A=t.parameters)==null?void 0:A.docs)==null?void 0:R.description}}};var D,P,W,G,N;n.parameters={...n.parameters,docs:{...(D=n.parameters)==null?void 0:D.docs,source:{originalSource:`{
  args: {
    image: {
      path: '/var/lib/voicechat/users/admin/plot.svg'
    },
    agents: [],
    readServerFile: async path => ({
      name: path.split('/').pop() ?? path,
      dataBase64: PLOT_SVG_BASE64
    })
  }
}`,...(W=(P=n.parameters)==null?void 0:P.docs)==null?void 0:W.source},description:{story:"Картинку создал сам CLI — она лежит на СЕРВЕРЕ, машина ни при чём.",...(N=(G=n.parameters)==null?void 0:G.docs)==null?void 0:N.description}}};var V,q,z,H,J;i.parameters={...i.parameters,docs:{...(V=i.parameters)==null?void 0:V.docs,source:{originalSource:`{
  args: {
    variant: 'modal',
    onClose: () => {}
  }
}`,...(z=(q=i.parameters)==null?void 0:q.docs)==null?void 0:z.source},description:{story:'Открыта из меню (`variant="modal"`): та же рамка, но как окно с крестиком.',...(J=(H=i.parameters)==null?void 0:H.docs)==null?void 0:J.description}}};var K,Q,U,X,Y;c.parameters={...c.parameters,docs:{...(K=c.parameters)==null?void 0:K.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByLabelText('Открыть картинку на весь экран'));
    await expect(canvas.getByTestId('image-surface')).toBeInTheDocument();
  }
}`,...(U=(Q=c.parameters)==null?void 0:Q.docs)==null?void 0:U.source},description:{story:`Развёрнутая картинка: в этом виде работают зум колесом, перетаскивание и сброс
двойным кликом — руками это самый неудобный для проверки экран.`,...(Y=(X=c.parameters)==null?void 0:X.docs)==null?void 0:Y.description}}};const Me=["Ready","WithCaption","Loading","LiveDrawing","ReadError","FromServer","AsModal","Fullscreen"];export{i as AsModal,n as FromServer,c as Fullscreen,o as LiveDrawing,s as Loading,t as ReadError,a as Ready,r as WithCaption,Me as __namedExportsOrder,Te as default};
