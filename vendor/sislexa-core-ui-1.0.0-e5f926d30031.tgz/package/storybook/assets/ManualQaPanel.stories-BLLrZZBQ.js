import{j as D}from"./jsx-runtime-BYYWji4R.js";import{M as F}from"./ManualQaPanel-Czvz411D.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./StatusPill-Dn6iIbOr.js";import"./Badge-zWzzcJYU.js";import"./ComponentQaPanel-Bfq_8f2I.js";import"./qa-B4ObmSZt.js";import"./PanelHeading-CyQiDTtn.js";import"./MetricGrid-BvmJHgqt.js";import"./FeedItem-C_LU9yhH.js";import"./ProgressTrack-cilVHFpU.js";import"./useQaStageUpdates-CqPw_UKl.js";import"./useHotkeys-CjtRU-3i.js";import"./hotkeys-4oJJtujI.js";function r(e){const t={id:"c1",taskId:"t1",order:1,title:"Пользователь может отменить ран",description:"Проверка отмены",preconditions:"Ран выполняется",steps:`1. Открыть ран
2. Нажать Отмена`,testData:"qa-seed-v3",expectedResult:"Ран остановлен, токены больше не расходуются",required:!0,testType:"manual",currentVersion:2,active:!0,author:"owner",createdAt:1,updatedAt:2};if(e===null)return{criteria:[t],versions:[],sessions:[],activeSession:null};const B={id:"r1",sessionId:"s1",criterionId:"c1",criterionVersion:2,status:e,draft:!1,testerId:"qa",assigneeId:null,startedAt:1,finishedAt:null,branch:"feature/164",commitSha:"abcdef123456",previewId:"preview-1",previewSha:"abcdef123456",appUrl:"https://preview.example",storybookUrl:"https://storybook.example",testDataScenario:"qa-seed-v3",executedSteps:"Открыт ран",expectedResult:t.expectedResult,actualResult:e==="failed"?"Ран продолжился":"",comment:"",environment:"Chrome / macOS",blockerReason:e==="blocked"?"Preview недоступен":"",blockerType:e==="blocked"?"environment":null,blockerOwner:e==="blocked"?"ops":null,notApplicableReason:e==="not_applicable"?"Сценарий CLI-only":"",revision:1,attachments:[],issue:null,updatedAt:2},m={id:"s1",taskId:"t1",projectId:"p1",branch:"feature/164",commitSha:"abcdef123456",testRunId:"tests-1",previewId:"preview-1",previewSha:"abcdef123456",appUrl:"https://preview.example",storybookUrl:"https://storybook.example",testDataScenario:"qa-seed-v3",criteriaSnapshot:[{criterionId:"c1",version:2,required:!0}],status:e==="stale"?"stale":"active",testerId:"qa",initiatedBy:"qa",startedAt:1,finishedAt:null,staleReason:e==="stale"?"commit_sha_changed":null,summary:"",results:[B]};return{criteria:[t],versions:[],sessions:[m],activeSession:m.status==="active"?m:null}}const ne={title:"QA/Manual QA",component:F,args:{projectId:"p1",taskId:"t1"},decorators:[(e,t)=>(window.qa={get:async()=>t.parameters.qaState,saveResult:async()=>{throw new Error("Story only")},addAttachment:async()=>{throw new Error("Story only")},complete:async()=>{throw new Error("Story only")},completePreparation:async()=>{throw new Error("Story only")},createCriterion:async()=>{throw new Error("Story only")},reviseCriterion:async()=>{throw new Error("Story only")},startSession:async()=>{throw new Error("Story only")},requestFix:async()=>{throw new Error("Story only")}},D.jsx(e,{}))]},a={parameters:{qaState:r(null)}},s={parameters:{qaState:r("in_progress")}},o={parameters:{qaState:r("failed")}},n={parameters:{qaState:r("blocked")}},i={parameters:{qaState:r("stale")}},c={parameters:{qaState:r("failed")}},p={parameters:{qaState:r("passed")}},l={parameters:{qaState:r("not_tested"),viewport:{defaultViewport:"mobile1"}}};var d,u,S;a.parameters={...a.parameters,docs:{...(d=a.parameters)==null?void 0:d.docs,source:{originalSource:`{
  parameters: {
    qaState: state(null)
  }
}`,...(S=(u=a.parameters)==null?void 0:u.docs)==null?void 0:S.source}}};var y,w,h;s.parameters={...s.parameters,docs:{...(y=s.parameters)==null?void 0:y.docs,source:{originalSource:`{
  parameters: {
    qaState: state('in_progress')
  }
}`,...(h=(w=s.parameters)==null?void 0:w.docs)==null?void 0:h.source}}};var q,v,b;o.parameters={...o.parameters,docs:{...(q=o.parameters)==null?void 0:q.docs,source:{originalSource:`{
  parameters: {
    qaState: state('failed')
  }
}`,...(b=(v=o.parameters)==null?void 0:v.docs)==null?void 0:b.source}}};var f,k,g;n.parameters={...n.parameters,docs:{...(f=n.parameters)==null?void 0:f.docs,source:{originalSource:`{
  parameters: {
    qaState: state('blocked')
  }
}`,...(g=(k=n.parameters)==null?void 0:k.docs)==null?void 0:g.source}}};var I,x,E;i.parameters={...i.parameters,docs:{...(I=i.parameters)==null?void 0:I.docs,source:{originalSource:`{
  parameters: {
    qaState: state('stale')
  }
}`,...(E=(x=i.parameters)==null?void 0:x.docs)==null?void 0:E.source}}};var R,A,_;c.parameters={...c.parameters,docs:{...(R=c.parameters)==null?void 0:R.docs,source:{originalSource:`{
  parameters: {
    qaState: state('failed')
  }
}`,...(_=(A=c.parameters)==null?void 0:A.docs)==null?void 0:_.source}}};var C,j,M;p.parameters={...p.parameters,docs:{...(C=p.parameters)==null?void 0:C.docs,source:{originalSource:`{
  parameters: {
    qaState: state('passed')
  }
}`,...(M=(j=p.parameters)==null?void 0:j.docs)==null?void 0:M.source}}};var P,U,V;l.parameters={...l.parameters,docs:{...(P=l.parameters)==null?void 0:P.docs,source:{originalSource:`{
  parameters: {
    qaState: state('not_tested'),
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(V=(U=l.parameters)==null?void 0:U.docs)==null?void 0:V.source}}};const ie=["Empty","Partial","Failed","Blocked","Stale","RequirementChange","Successful","MobileChecklist"];export{n as Blocked,a as Empty,o as Failed,l as MobileChecklist,s as Partial,c as RequirementChange,i as Stale,p as Successful,ie as __namedExportsOrder,ne as default};
