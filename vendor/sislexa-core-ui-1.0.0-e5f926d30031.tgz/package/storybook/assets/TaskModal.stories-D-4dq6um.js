import{j as P}from"./jsx-runtime-BYYWji4R.js";import{userEvent as gt,within as yt}from"./index-DeN4tkzB.js";import{T as wt}from"./TaskModal-DG-cTVcU.js";import{B}from"./Toast-CcZfB6x2.js";import"./index-ClcD9ViR.js";import"./index-Brl4xq4Y.js";import{w as v}from"./storyBridges-cQngtz-K.js";import"./ProjectsApp-dH9TYZcw.js";import{m as a,b as S,e as It,d as bt,c as ht}from"./fixtures-CFkrQMEm.js";import"./iframe-D-Q3L14w.js";import"./dateFormat-B8QlAdwY.js";import"./projectTypes-C-9aONcK.js";import"./projects-BdwKgk--.js";import"./usePolling-okXCim0o.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./Avatar-Ds_00F2y.js";import"./StatusPill-Dn6iIbOr.js";import"./Badge-zWzzcJYU.js";import"./PanelHeading-CyQiDTtn.js";import"./ProgressTrack-cilVHFpU.js";import"./Markdown-CXCb5Rql.js";import"./clipboard-BEgkkb6H.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./core-BwXZ_Otv.js";import"./icons-MIP1fpxy.js";import"./ChatColumn-nzqsxsmi.js";import"./machineHealth-E52qv8cU.js";import"./version-CuhpF6Tw.js";import"./questions-Bk4wc6lB.js";import"./tools-iBbMKii-.js";import"./images-CH23vBlI.js";import"./lazyScreen-CooZxeYV.js";import"./Skeleton-42oMjovX.js";import"./MessageImage-CtDLZeiJ.js";import"./animations--P72MiAI.js";import"./view-0MbJGw9Y.js";import"./ToolFrame-CqCmqPT9.js";import"./QuestionsForm-BIFaA7UX.js";import"./MessageMeta-DXRhU3rA.js";import"./kb-CjYTCLN0.js";import"./MessageTimeline-AcAPYvz7.js";import"./MessageActivity-DR8202wn.js";import"./autoGrow-CoBFBF9S.js";import"./uiPerformance-R53OMrUM.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./useHotkeys-CjtRU-3i.js";import"./hotkeys-4oJJtujI.js";import"./useCommands-isko1sz4.js";import"./commands-BOmIcTa-.js";import"./persistence-Y4P2JfJq.js";import"./mediaQuery-CCkbYk-e.js";import"./VoiceBar-BSyoAAZC.js";import"./useAiAssist-CtGDklNp.js";import"./kanbanMeta-CBiUCx3-.js";import"./CiTaskSettings-B2RW3Tia.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./ciFormat-wlGR6KpA.js";import"./ansi-DtpFsZ9v.js";import"./llmAccess-BLY4i_O6.js";import"./CiSlotEditor-DglnL3dM.js";import"./FeaturePreviewSection-CJRBEHMh.js";import"./browserId-xQxZgjMo.js";import"./ManualQaPanel-Czvz411D.js";import"./ComponentQaPanel-Bfq_8f2I.js";import"./qa-B4ObmSZt.js";import"./MetricGrid-BvmJHgqt.js";import"./FeedItem-C_LU9yhH.js";import"./useQaStageUpdates-CqPw_UKl.js";import"./QaStageRunPanel-BPHuupvB.js";import"./RunFeed-gMpl9k0I.js";import"./AnsiText-L5oy_LV7.js";import"./CiConsole-Ovgqiy62.js";import"./loadState-C9E-sPL9.js";import"./kbUsageFormat-DuWbHUyl.js";import"./CiReport-O4v0dz3S.js";import"./MergePanel-Cjon5Arz.js";import"./QueuedMergeMachine-3G6jJgNn.js";import"./merge-CBY8VSWw.js";import"./protocol-D2sHC_Sq.js";import"./AutomationProgressView-CuUxOFQT.js";import"./fakeApi-Dd7dGTdR.js";import"./agentProtocol-ChPLBt7B.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./machines-jWuoyc9K.js";const D=ht(),R=D[2],kt=a({id:"ep1",type:"epic",title:"Платёжная система",columnId:R.id}),t=a({id:"task-1",title:"Оплата картой: провести через 3-DS и показать результат пользователю",description:`Пользователь платит картой, банк требует подтверждение — надо показать
экран 3-DS и вернуться в чек-аут с результатом.`,acceptanceCriteria:`— успешная оплата ведёт на экран «Спасибо»
— отказ банка показывает причину`,columnId:R.id,parentId:kt.id,assignee:"bob",labels:["payments","critical"],skills:["react","fastify"],storyPoints:5,dueDate:17006e8,priority:"high",seq:42}),ft=a({...t,description:["## Зачем","","Оплата картой падает на 3-DS: пользователь возвращается в чек-аут без результата.","","## Что сделать","","- показать экран 3-DS в модалке","- вернуть результат в `checkout` и показать его пользователю","- при отказе банка показать причину","","```ts","const result = await pay({ card, threeDs: 'required' })","```"].join(`
`)}),At=a({id:"child-1",parentId:t.id,columnId:D[5].id,title:"Форма ввода карты"}),sa={title:"Kanban/TaskModal",component:wt,decorators:[v()],args:{task:t,board:S(D,[kt,t,At]),projectName:"Голос Чат",members:bt("admin","bob"),onUpdate:()=>{},onDelete:()=>{},onMoveToColumn:()=>{},onOpenTask:()=>{},onOpenChat:()=>{},onClose:()=>{},ciSummary:It(),onStartCi:()=>{},onOpenCiRun:()=>{}}},x={viewport:{viewports:{phone:{name:"Телефон 390×844",styles:{width:"390px",height:"844px"},type:"mobile"}},defaultViewport:"phone"}},Dt={viewport:{viewports:{tablet:{name:"Планшет 820×1180",styles:{width:"820px",height:"1180px"},type:"tablet"}},defaultViewport:"tablet"}},n={},o={args:{task:ft}},i={args:{task:ft,generateAiAssist:async()=>[{id:"s1",text:"Черновик описания"}]},play:async()=>{await gt.click(await yt(document.body).findByTestId("task-desc-edit"))}},p={parameters:Dt},c={parameters:x},d={args:{task:a({id:"plain",title:"Поправить отступ в шапке",columnId:R.id}),board:S(D,[]),ciSummary:void 0},parameters:x},e=s=>new Date(Date.UTC(2024,0,1,9)+s).toISOString(),Pt={version:1,taskId:t.id,generatedAt:e(60*6e4),summary:{createdAt:e(0),firstStartedAt:e(6e4),finishedAt:null,calendarDuration:60*6e4,activeDuration:15*6e4,queueDuration:2*6e4,awaitingInputDuration:6e4,lastChangedAt:e(59*6e4)},stages:[{id:"stage:development",type:"development",title:"Разработка",status:"succeeded",queuedAt:e(0),startedAt:e(6e4),finishedAt:e(15*6e4),queueDuration:6e4,activeDuration:14*6e4,awaitingInputDuration:0,calendarDuration:14*6e4,attemptCount:2,successfulDuration:10*6e4,unsuccessfulDuration:4*6e4,executor:"bob",machine:"mac-01",model:"claude-opus-5",reason:null,workflowPosition:20,dataComplete:!0,runs:[{id:"run-2",kind:"ci"}],attempts:[{id:"ci:run-1",number:1,status:"failed",queuedAt:e(0),startedAt:e(6e4),finishedAt:e(5*6e4),queueIntervals:[],activeIntervals:[],awaitingInputIntervals:[],queueDuration:6e4,activeDuration:4*6e4,awaitingInputDuration:0,calendarDuration:4*6e4,executor:"bob",machine:"mac-01",model:"claude-opus-5",reason:{code:"tests_failed",message:"Тесты упали"},runs:[{id:"run-1",kind:"ci"}],dataComplete:!0}]},{id:"stage:manual_qa",type:"manual_qa",title:"Ручное QA",status:"running",queuedAt:e(15*6e4),startedAt:e(15*6e4),finishedAt:null,queueDuration:0,activeDuration:6e4,awaitingInputDuration:6e4,calendarDuration:null,attemptCount:1,successfulDuration:0,unsuccessfulDuration:0,executor:null,machine:null,model:null,reason:null,workflowPosition:70,dataComplete:!0,runs:[],attempts:[]},{id:"stage:merge",type:"merge",title:"Merge",status:"failed",queuedAt:e(25*6e4),startedAt:e(25*6e4),finishedAt:e(27*6e4),queueDuration:0,activeDuration:2*6e4,awaitingInputDuration:0,calendarDuration:2*6e4,attemptCount:1,successfulDuration:0,unsuccessfulDuration:2*6e4,executor:null,machine:null,model:null,reason:{code:"conflict",message:"Конфликт в app.css"},workflowPosition:90,dataComplete:!0,runs:[],attempts:[]}]},C={id:"prep-1",projectId:t.projectId,taskId:t.id,status:"success",stage:"brief_generation",phase:"brief_generation",attempt:2,log:`$ git checkout -b task/CHAT-248
✓ workspace ready
✓ implementation plan saved`,events:[],questions:[],readiness:null,gateResults:[],gateReasons:[],machineId:"mac-01",machineName:"MacBook",provider:"codex",model:"gpt-5",durationMs:258e3,canCancel:!1,canRetry:!0,maxAttempts:3,error:null,finishedAt:259e3,createdBy:"admin",createdAt:1,updatedAt:1},T=s=>({id:"imp",taskId:t.id,projectId:t.projectId,runId:"run-2",stepId:null,source:"development",status:"new",title:"Улучшение",description:"Подробности",acceptanceCriteria:"",createdTaskId:null,fingerprint:"fp",evidence:[],files:[],occurrences:1,suggestedAction:"create_chatai_task",isNew:!0,createdAt:1,updatedAt:1,...s}),r=s=>async()=>{await gt.click(await yt(document.body).findByRole("tab",{name:s}))},m={decorators:[v(s=>{s.ci.getTaskTimeline=async()=>Pt})],play:r("Временная шкала")},u={play:r(/Улучшения/),decorators:[v(s=>{s.ci.listTaskImprovements=async()=>[T({id:"i1",title:"Кэшировать установку зависимостей",description:"Каждый ран ставит зависимости с нуля — это две минуты на запуск.",stepId:"install"}),T({id:"i2",title:"Уточнить команду тестов",status:"accepted",isNew:!1,source:"system",runId:null,suggestedAction:"reconfigure_commands"}),T({id:"i3",title:"Понизить таймаут merge-рана",status:"rejected",isNew:!1,source:"merge",suggestedAction:"support_ticket"})]})]},l={play:r(/Улучшения/)},g={args:{task:a({...t,taskPreparationRunId:"prep-1",taskPreparationStatus:"success"}),loadPreparationRuns:async()=>[C],onRetryPreparation:async()=>{},onExportPreparation:async()=>{}},play:r("Подготовка к разработке")},y={args:{task:a({...t,taskPreparationRunId:"prep-1",taskPreparationStatus:"waiting_for_answer"}),loadPreparationRuns:async()=>[{...C,status:"waiting_for_answer",phase:"clarification",questions:[{questionId:"q1",attemptId:"prep-1",text:"Какой лимит попыток 3-DS считаем нормой?",material:!0,status:"open",answer:null,askedAt:1,answeredAt:null,answeredBy:null}]}],onAnswerPreparation:async()=>{}},play:r("Подготовка к разработке")},k={play:r("Ход выполнения")},f={play:r("Настройки")},w={play:r("Ручное QA")},I={args:{task:a({...t,mergeSourceBranch:"task/CHAT-248",activeMergeRunId:"merge-1"}),onStartMerge:()=>{}},play:r("Merge")},b={play:r("Лента рана")},h={args:{task:a({...t,taskPreparationRunId:"prep-1",taskPreparationStatus:"success"}),loadPreparationRuns:async()=>[C]},parameters:x,play:r("Подготовка к разработке")},A={args:{draft:!0,task:a({id:"draft",title:"",description:"",acceptanceCriteria:"",columnId:"",assignee:null,labels:[],skills:[],storyPoints:null,dueDate:null}),board:S(D,[]),ciSummary:void 0,footer:P.jsxs(P.Fragment,{children:[P.jsx(B,{children:"Отмена"}),P.jsx(B,{variant:"primary",children:"Создать задачу"})]})}};var M,q,_,E,j;n.parameters={...n.parameters,docs:{...(M=n.parameters)==null?void 0:M.docs,source:{originalSource:"{}",...(_=(q=n.parameters)==null?void 0:q.docs)==null?void 0:_.source},description:{story:"Десктоп: основная колонка и правая панель деталей.",...(j=(E=n.parameters)==null?void 0:E.docs)==null?void 0:j.description}}};var N,O,H,Q,L;o.parameters={...o.parameters,docs:{...(N=o.parameters)==null?void 0:N.docs,source:{originalSource:`{
  args: {
    task: markdownTask
  }
}`,...(H=(O=o.parameters)==null?void 0:O.docs)==null?void 0:H.source},description:{story:"Описание в просмотре: маркдаун отрисован (заголовки, списки, `code`, блок кода),\nа не показан сырым текстом в поле — так карточку читают, а не расшифровывают.",...(L=(Q=o.parameters)==null?void 0:Q.docs)==null?void 0:L.description}}};var F,U,V,W,K;i.parameters={...i.parameters,docs:{...(F=i.parameters)==null?void 0:F.docs,source:{originalSource:`{
  args: {
    task: markdownTask,
    generateAiAssist: async () => [{
      id: 's1',
      text: 'Черновик описания'
    }]
  },
  // Карточка уходит порталом в document.body — canvasElement тут пуст.
  play: async () => {
    await userEvent.click(await within(document.body).findByTestId('task-desc-edit'));
  }
}`,...(V=(U=i.parameters)==null?void 0:U.docs)==null?void 0:V.source},description:{story:`Описание в правке: та же карточка после кнопки «Изменить» — поле ровно на 10
строк, палочка AI-помощника и пара «Сохранить»/«Отмена».`,...(K=(W=i.parameters)==null?void 0:W.docs)==null?void 0:K.description}}};var $,z,G,J,X;p.parameters={...p.parameters,docs:{...($=p.parameters)==null?void 0:$.docs,source:{originalSource:`{
  parameters: TABLET
}`,...(G=(z=p.parameters)==null?void 0:z.docs)==null?void 0:G.source},description:{story:"Планшет: две колонки на 820px — самая узкая десктопная раскладка.",...(X=(J=p.parameters)==null?void 0:J.docs)==null?void 0:X.description}}};var Y,Z,ee,te,re;c.parameters={...c.parameters,docs:{...(Y=c.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  parameters: PHONE
}`,...(ee=(Z=c.parameters)==null?void 0:Z.docs)==null?void 0:ee.source},description:{story:"Телефон: во весь экран, статус и исполнитель сверху, «Подробности» свёрнуты.",...(re=(te=c.parameters)==null?void 0:te.docs)==null?void 0:re.description}}};var ae,se,ne,oe,ie;d.parameters={...d.parameters,docs:{...(ae=d.parameters)==null?void 0:ae.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      id: 'plain',
      title: 'Поправить отступ в шапке',
      columnId: dev.id
    }),
    board: makeBoard(columns, []),
    ciSummary: undefined
  },
  parameters: PHONE
}`,...(ne=(se=d.parameters)==null?void 0:se.docs)==null?void 0:ne.source},description:{story:"Телефон без родителя и подзадач — минимальная карточка.",...(ie=(oe=d.parameters)==null?void 0:oe.docs)==null?void 0:ie.description}}};var pe,ce,de,me,ue;m.parameters={...m.parameters,docs:{...(pe=m.parameters)==null?void 0:pe.docs,source:{originalSource:`{
  decorators: [withBridges(bridges => {
    bridges.ci.getTaskTimeline = async () => timeline;
  })],
  play: openTab('Временная шкала')
}`,...(de=(ce=m.parameters)==null?void 0:ce.docs)==null?void 0:de.source},description:{story:"Временная шкала: точки статуса, шеврон раскрытия и русские даты.",...(ue=(me=m.parameters)==null?void 0:me.docs)==null?void 0:ue.description}}};var le,ge,ye,ke,fe;u.parameters={...u.parameters,docs:{...(le=u.parameters)==null?void 0:le.docs,source:{originalSource:`{
  play: openTab(/Улучшения/),
  decorators: [withBridges(bridges => {
    bridges.ci.listTaskImprovements = async () => [improvement({
      id: 'i1',
      title: 'Кэшировать установку зависимостей',
      description: 'Каждый ран ставит зависимости с нуля — это две минуты на запуск.',
      stepId: 'install'
    }), improvement({
      id: 'i2',
      title: 'Уточнить команду тестов',
      status: 'accepted',
      isNew: false,
      source: 'system',
      runId: null,
      suggestedAction: 'reconfigure_commands'
    }), improvement({
      id: 'i3',
      title: 'Понизить таймаут merge-рана',
      status: 'rejected',
      isNew: false,
      source: 'merge',
      suggestedAction: 'support_ticket'
    })];
  })]
}`,...(ye=(ge=u.parameters)==null?void 0:ge.docs)==null?void 0:ye.source},description:{story:"Улучшения: та же лента — статус точкой и словом, источник по-русски.",...(fe=(ke=u.parameters)==null?void 0:ke.docs)==null?void 0:fe.description}}};var we,Ie,be,he,Ae;l.parameters={...l.parameters,docs:{...(we=l.parameters)==null?void 0:we.docs,source:{originalSource:`{
  play: openTab(/Улучшения/)
}`,...(be=(Ie=l.parameters)==null?void 0:Ie.docs)==null?void 0:be.source},description:{story:"Пустая лента улучшений — общий пустой экран, а не голый заголовок.",...(Ae=(he=l.parameters)==null?void 0:he.docs)==null?void 0:Ae.description}}};var De,Pe,Te,ve,Se;g.parameters={...g.parameters,docs:{...(De=g.parameters)==null?void 0:De.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      ...task,
      taskPreparationRunId: 'prep-1',
      taskPreparationStatus: 'success'
    }),
    loadPreparationRuns: async () => [preparationRun],
    onRetryPreparation: async () => {},
    onExportPreparation: async () => {}
  },
  play: openTab('Подготовка к разработке')
}`,...(Te=(Pe=g.parameters)==null?void 0:Pe.docs)==null?void 0:Te.source},description:{story:"Подготовка к разработке: шапка попытки, сводка рана и его шаги.",...(Se=(ve=g.parameters)==null?void 0:ve.docs)==null?void 0:Se.description}}};var Re,xe,Ce,Be,Me;y.parameters={...y.parameters,docs:{...(Re=y.parameters)==null?void 0:Re.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      ...task,
      taskPreparationRunId: 'prep-1',
      taskPreparationStatus: 'waiting_for_answer'
    }),
    loadPreparationRuns: async () => [{
      ...preparationRun,
      status: 'waiting_for_answer',
      phase: 'clarification',
      questions: [{
        questionId: 'q1',
        attemptId: 'prep-1',
        text: 'Какой лимит попыток 3-DS считаем нормой?',
        material: true,
        status: 'open',
        answer: null,
        askedAt: 1,
        answeredAt: null,
        answeredBy: null
      }]
    }],
    onAnswerPreparation: async () => {}
  },
  play: openTab('Подготовка к разработке')
}`,...(Ce=(xe=y.parameters)==null?void 0:xe.docs)==null?void 0:Ce.source},description:{story:"Подготовка, которая ждёт ответа: тон лозенги отличается от успеха и от ошибки.",...(Me=(Be=y.parameters)==null?void 0:Be.docs)==null?void 0:Me.description}}};var qe,_e,Ee,je,Ne;k.parameters={...k.parameters,docs:{...(qe=k.parameters)==null?void 0:qe.docs,source:{originalSource:`{
  play: openTab('Ход выполнения')
}`,...(Ee=(_e=k.parameters)==null?void 0:_e.docs)==null?void 0:Ee.source},description:{story:"Ход выполнения: шапка рана с лозенгой и Live, дальше работа модели и отчёт.",...(Ne=(je=k.parameters)==null?void 0:je.docs)==null?void 0:Ne.description}}};var Oe,He,Qe,Le,Fe;f.parameters={...f.parameters,docs:{...(Oe=f.parameters)==null?void 0:Oe.docs,source:{originalSource:`{
  play: openTab('Настройки')
}`,...(Qe=(He=f.parameters)==null?void 0:He.docs)==null?void 0:Qe.source},description:{story:"Настройки выполнения: машина, модель и команды одной колонкой.",...(Fe=(Le=f.parameters)==null?void 0:Le.docs)==null?void 0:Fe.description}}};var Ue,Ve,We,Ke,$e;w.parameters={...w.parameters,docs:{...(Ue=w.parameters)==null?void 0:Ue.docs,source:{originalSource:`{
  play: openTab('Ручное QA')
}`,...(We=(Ve=w.parameters)==null?void 0:Ve.docs)==null?void 0:We.source},description:{story:"Ручное QA: превью и сценарии проверки.",...($e=(Ke=w.parameters)==null?void 0:Ke.docs)==null?void 0:$e.description}}};var ze,Ge,Je,Xe,Ye;I.parameters={...I.parameters,docs:{...(ze=I.parameters)==null?void 0:ze.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      ...task,
      mergeSourceBranch: 'task/CHAT-248',
      activeMergeRunId: 'merge-1'
    }),
    onStartMerge: () => {}
  },
  play: openTab('Merge')
}`,...(Je=(Ge=I.parameters)==null?void 0:Ge.docs)==null?void 0:Je.source},description:{story:"Merge: ветка задачи и её слияние в main.",...(Ye=(Xe=I.parameters)==null?void 0:Xe.docs)==null?void 0:Ye.description}}};var Ze,et,tt,rt,at;b.parameters={...b.parameters,docs:{...(Ze=b.parameters)==null?void 0:Ze.docs,source:{originalSource:`{
  play: openTab('Лента рана')
}`,...(tt=(et=b.parameters)==null?void 0:et.docs)==null?void 0:tt.source},description:{story:"Лента рана: технические события запуска с индикатором Live.",...(at=(rt=b.parameters)==null?void 0:rt.docs)==null?void 0:at.description}}};var st,nt,ot,it,pt;h.parameters={...h.parameters,docs:{...(st=h.parameters)==null?void 0:st.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      ...task,
      taskPreparationRunId: 'prep-1',
      taskPreparationStatus: 'success'
    }),
    loadPreparationRuns: async () => [preparationRun]
  },
  parameters: PHONE,
  play: openTab('Подготовка к разработке')
}`,...(ot=(nt=h.parameters)==null?void 0:nt.docs)==null?void 0:ot.source},description:{story:"Телефон: та же панель рана в одну колонку — сводка и шаги не разъезжаются.",...(pt=(it=h.parameters)==null?void 0:it.docs)==null?void 0:pt.description}}};var ct,dt,mt,ut,lt;A.parameters={...A.parameters,docs:{...(ct=A.parameters)==null?void 0:ct.docs,source:{originalSource:`{
  args: {
    draft: true,
    task: makeTask({
      id: 'draft',
      title: '',
      description: '',
      acceptanceCriteria: '',
      columnId: '',
      assignee: null,
      labels: [],
      skills: [],
      storyPoints: null,
      dueDate: null
    }),
    board: makeBoard(columns, []),
    ciSummary: undefined,
    footer: <>
      <Button>Отмена</Button>
      <Button variant="primary">Создать задачу</Button>
    </>
  }
}`,...(mt=(dt=A.parameters)==null?void 0:dt.docs)==null?void 0:mt.source},description:{story:`Черновик новой задачи: карточка ничего не сохраняет до подтверждения, вкладок
нет, а действия создания живут в стандартном подвале окна.`,...(lt=(ut=A.parameters)==null?void 0:ut.docs)==null?void 0:lt.description}}};const na=["Desktop","DescriptionMarkdown","DescriptionEditing","Tablet","Phone","PhoneMinimal","Timeline","Improvements","ImprovementsEmpty","Preparation","PreparationWaiting","Progress","Settings","ManualQa","Merge","RunFeed","PreparationPhone","Draft"];export{i as DescriptionEditing,o as DescriptionMarkdown,n as Desktop,A as Draft,u as Improvements,l as ImprovementsEmpty,w as ManualQa,I as Merge,c as Phone,d as PhoneMinimal,g as Preparation,h as PreparationPhone,y as PreparationWaiting,k as Progress,b as RunFeed,f as Settings,p as Tablet,m as Timeline,na as __namedExportsOrder,sa as default};
