import{j as c}from"./jsx-runtime-BYYWji4R.js";import{r as wt}from"./index-ClcD9ViR.js";import{within as i,userEvent as n,expect as o,fn as a}from"./index-DeN4tkzB.js";import{C as ut}from"./ChatColumn-nzqsxsmi.js";import{V as xt}from"./VoiceBar-BSyoAAZC.js";import{A as gt,S as Et,m as p,a as d,b as j,c as Mt,d as bt,e as vt,f as yt,g as kt,h as Tt,T as ft,i as St,M as O}from"./chat-DXuxoGTT.js";import"./ci-awuetLx1.js";import{m as ht,d as Bt,b as It}from"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import{T as Ct}from"./time-CfyNS7J_.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-D-Q3L14w.js";import"./clipboard-BEgkkb6H.js";import"./machineHealth-E52qv8cU.js";import"./version-CuhpF6Tw.js";import"./questions-Bk4wc6lB.js";import"./tools-iBbMKii-.js";import"./images-CH23vBlI.js";import"./lazyScreen-CooZxeYV.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Skeleton-42oMjovX.js";import"./ErrorState-CqsakWkx.js";import"./MessageImage-CtDLZeiJ.js";import"./animations--P72MiAI.js";import"./view-0MbJGw9Y.js";import"./ToolFrame-CqCmqPT9.js";import"./QuestionsForm-BIFaA7UX.js";import"./MessageMeta-DXRhU3rA.js";import"./kb-CjYTCLN0.js";import"./MessageTimeline-AcAPYvz7.js";import"./Markdown-CXCb5Rql.js";import"./core-BwXZ_Otv.js";import"./MessageActivity-DR8202wn.js";import"./autoGrow-CoBFBF9S.js";import"./uiPerformance-R53OMrUM.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./useHotkeys-CjtRU-3i.js";import"./hotkeys-4oJJtujI.js";import"./useCommands-isko1sz4.js";import"./commands-BOmIcTa-.js";import"./persistence-Y4P2JfJq.js";import"./mediaQuery-CCkbYk-e.js";import"./icons-MIP1fpxy.js";import"./useAiAssist-CtGDklNp.js";import"./EmptyState-q579drYF.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";const m=()=>{};function V(e="idle"){return c.jsx(xt,{defaultCollapsed:!1,state:e,draft:"",diarization:!0,detectedSpeakers:e==="listening"?[1,2]:[],attachments:[],onDraftChange:m,onSubmitText:m,onStartVoice:m,onStopVoice:m,onStopSpeak:m,onCancelRequest:m,onAddFiles:m,onRemoveAttachment:m})}const At=[ht({id:"m1",name:"MacBook"}),It({id:"m2",name:"Сборочный сервер"})];function Lt(){return[p({id:"u1",text:"Почему на последнем ране упал шаг с тестами?",execTarget:"m1"}),d({id:"a1",text:ft,execTarget:"m1",createdAt:Ct+45e3,meta:j({activity:St,durationMs:45e3,costUsd:.183,inputTokens:82400,outputTokens:1240})})]}const Sa={title:"Chat/ChatColumn",component:ut,parameters:{layout:"fullscreen"},args:{title:"Разбор упавшего рана",state:"idle",messages:Lt(),liveSegments:[],diarization:!0,agents:At,execTarget:"m1",aiLabel:"Claude",canSpeak:!0,permissionMode:"acceptEdits",voiceBar:V(),onSpeakMessage:a(),onDeleteMessage:a(),onEditMessage:a(),onExport:a(),onRenameTitle:a(),onOpenConversationSettings:a(),onChangeExecTarget:a()},decorators:[e=>c.jsx("div",{className:"app",style:{height:"90vh",display:"grid"},children:c.jsx(e,{})})]},_={render:e=>{const[s,t]=wt.useState(!1);return c.jsxs("div",{style:{height:700,display:"flex",flexDirection:"column",minWidth:0},children:[c.jsx("button",{onClick:()=>t(!0),children:"Получить новый ответ"}),c.jsx(ut,{...e,conversationId:"story-unread",messages:[...bt(),...s?[d({id:"new-story-reply",text:"Новый ответ"})]:[]]})]})},play:async({canvasElement:e})=>{const s=i(e),t=s.getByTestId("scroll");t.dispatchEvent(new Event("wheel",{bubbles:!0})),t.scrollTop=0,t.dispatchEvent(new Event("scroll",{bubbles:!0})),await n.click(s.getByText("Получить новый ответ")),await o(s.findByText("↓ Новые сообщения (1)")).resolves.toBeTruthy()}},W={args:{messages:[d({text:O})]},play:async({canvasElement:e})=>{const s=i(e);await n.click(s.getByText("Поиск")),await n.type(s.getByLabelText("Найти в беседе"),"код"),await n.click(s.getByLabelText("Меню беседы")),await n.click(s.getByText("Компактная лента"))}},N={args:{conversationId:"failed",failedSubmits:[{operationId:"op",conversationId:"failed",text:"Сообщение с вложением",attachmentIds:["upload"],error:"Нет соединения",retrying:!1}],onRetryFailedSubmit:a(),onDeleteFailedSubmit:a()}},F={decorators:[e=>c.jsx("div",{style:{width:"100%",maxWidth:390,minWidth:0,height:750},children:c.jsx(e,{})})],args:{messages:[d({text:O})]}},l={play:async({canvasElement:e})=>{const s=i(e).getByRole("button",{name:"Копировать вопрос"});await o(s).toHaveClass("copymsg"),await o(s).not.toHaveClass("copymsg--copied")}},u={play:async({canvasElement:e})=>{const t=i(e).getByRole("button",{name:"Копировать вопрос"}),r=t.closest(".me .bub");if(!r)throw new Error("User message bubble not found");await n.hover(r),await o(t).toHaveClass("copymsg")}},g={play:async({canvasElement:e})=>{const s=i(e).getByRole("button",{name:"Копировать вопрос"});s.focus(),await o(s).toHaveFocus()}},b={decorators:[e=>c.jsx("div",{"data-theme":"dark",style:{height:"100%"},children:c.jsx(e,{})})],play:async({canvasElement:e})=>{const r=i(e).getByRole("button",{name:"Копировать вопрос"}).closest(".me .bub");if(!r)throw new Error("User message bubble not found");await n.hover(r)}},v={play:async({canvasElement:e})=>{const t=i(e).getByRole("button",{name:"Копировать ответ"}),r=t.closest(".ai .bub");if(!r)throw new Error("Model message bubble not found");await n.hover(r),t.focus(),await o(t).toHaveFocus()}},y={play:async({canvasElement:e})=>{const t=i(e).getByRole("button",{name:"Копировать вопрос"});await n.click(t),await o(t).toHaveClass("copymsg--copied")}},h={args:{messages:[],onExport:void 0}},w={args:{messages:[],loadingMessages:!0}},x={args:{loadingMessages:!0}},E={args:{state:"thinking",streamingReply:Et,liveActivity:gt,liveUsage:vt(),voiceBar:V("thinking")}},M={args:{state:"thinking",liveActivity:gt,liveUsage:vt(),voiceBar:V("thinking")}},k={args:{state:"listening",liveSegments:Mt(),voiceBar:V("listening")}},T={args:{error:"Микрофон недоступен: браузер не дал доступ к устройству записи",onDismissError:a()}},f={args:{modelMissing:!0,modelLabel:"large-v3-turbo",onDownloadModel:a()}},S={args:{modelMissing:!0,modelLabel:"large-v3-turbo",downloading:!0,downloadPercent:42}},B={args:{messages:[p({text:"Сделай CI-шаг для витрины"}),yt()],onAnswerQuestions:a()}},I={args:{messages:[p({text:"старт"}),yt({id:"a-ci",meta:{ciInteraction:{runId:"run-1",interactionId:"it-1"}}}),p({id:"u-after",text:"а пока посмотрю лог"})],onAnswerCiInteraction:a()}},C={args:{messages:[p({text:"Построй график и открой консоль"}),kt(),Tt("console")],machineOps:Bt(),agents:[ht({id:"m1",name:"MacBook"})],onSwitchUtility:a(),onOpenMachines:a(),onOpenImageInExplorer:a()}},A={args:{permissionMode:"plan",messages:[p({text:"Составь план"}),d({id:"a-plan",text:O,meta:j({request:{...j().request,permissionMode:"plan"}})})],onExecutePlan:a(),voiceBar:V()}},L={args:{messages:[p({text:"Опиши архитектуру"}),d({id:"a-int",text:"Начал описывать, но не успел закон",meta:j({interrupted:!0})})]}},U={args:{messages:bt()}},R={args:{onToggleSidebar:a(),messages:[p({id:"u-mobile-copy",text:"Проверь перенос длинной ссылки: https://example.test/very/long/unbroken/path/that/must/not/escape/the/message/bubble?query=mobile-copy-button"}),d({id:"a-mobile-copy",text:"Кнопка остаётся внутри пузыря, а текст переносится."})]},parameters:{viewport:{defaultViewport:"mobile2"}},play:async({canvasElement:e})=>{const r=i(e).getByRole("button",{name:"Копировать вопрос"}).closest(".me .bub");if(!r)throw new Error("User message bubble not found");await n.hover(r)}},H={play:async({canvasElement:e})=>{const s=i(e);await n.click(s.getByLabelText("Изменить сообщение"));const t=s.getByLabelText("Редактирование сообщения");await n.clear(t),await n.type(t,"Почему упал шаг npm test и как это починить?"),await o(t).toHaveValue("Почему упал шаг npm test и как это починить?"),await o(s.getByRole("button",{name:"Отправить"})).toBeEnabled()}},D={play:async({canvasElement:e})=>{const s=i(e),t=s.getByLabelText("Переключить вид действий");await n.click(t),await o(s.getAllByTestId("activity-brief")).toHaveLength(2),await n.click(t),await o(s.getAllByTestId("activity-section").length).toBeGreaterThan(1)}};var Q,K,q;_.parameters={..._.parameters,docs:{...(Q=_.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  render: args => {
    const [extra, setExtra] = useState(false);
    return <div style={{
      height: 700,
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0
    }}>
      <button onClick={() => setExtra(true)}>Получить новый ответ</button>
      <ChatColumn {...args} conversationId="story-unread" messages={[...makeLongThread(), ...(extra ? [makeAiMessage({
        id: 'new-story-reply',
        text: 'Новый ответ'
      })] : [])]} />
    </div>;
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const scroll = canvas.getByTestId('scroll');
    scroll.dispatchEvent(new Event('wheel', {
      bubbles: true
    }));
    scroll.scrollTop = 0;
    scroll.dispatchEvent(new Event('scroll', {
      bubbles: true
    }));
    await userEvent.click(canvas.getByText('Получить новый ответ'));
    await expect(canvas.findByText('↓ Новые сообщения (1)')).resolves.toBeTruthy();
  }
}`,...(q=(K=_.parameters)==null?void 0:K.docs)==null?void 0:q.source}}};var P,Y,G;W.parameters={...W.parameters,docs:{...(P=W.parameters)==null?void 0:P.docs,source:{originalSource:`{
  args: {
    messages: [makeAiMessage({
      text: MD_KITCHEN_SINK
    })]
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByText('Поиск'));
    await userEvent.type(canvas.getByLabelText('Найти в беседе'), 'код');
    await userEvent.click(canvas.getByLabelText('Меню беседы'));
    await userEvent.click(canvas.getByText('Компактная лента'));
  }
}`,...(G=(Y=W.parameters)==null?void 0:Y.docs)==null?void 0:G.source}}};var X,z,J;N.parameters={...N.parameters,docs:{...(X=N.parameters)==null?void 0:X.docs,source:{originalSource:`{
  args: {
    conversationId: 'failed',
    failedSubmits: [{
      operationId: 'op',
      conversationId: 'failed',
      text: 'Сообщение с вложением',
      attachmentIds: ['upload'],
      error: 'Нет соединения',
      retrying: false
    }],
    onRetryFailedSubmit: fn(),
    onDeleteFailedSubmit: fn()
  }
}`,...(J=(z=N.parameters)==null?void 0:z.docs)==null?void 0:J.source}}};var Z,$,ee;F.parameters={...F.parameters,docs:{...(Z=F.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  decorators: [Story => <div style={{
    width: '100%',
    maxWidth: 390,
    minWidth: 0,
    height: 750
  }}><Story /></div>],
  args: {
    messages: [makeAiMessage({
      text: MD_KITCHEN_SINK
    })]
  }
}`,...(ee=($=F.parameters)==null?void 0:$.docs)==null?void 0:ee.source}}};var se,te,ae,ne,re;l.parameters={...l.parameters,docs:{...(se=l.parameters)==null?void 0:se.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const button = within(canvasElement).getByRole('button', {
      name: 'Копировать вопрос'
    });
    await expect(button).toHaveClass('copymsg');
    await expect(button).not.toHaveClass('copymsg--copied');
  }
}`,...(ae=(te=l.parameters)==null?void 0:te.docs)==null?void 0:ae.source},description:{story:"Обычная беседа: кнопка вопроса есть в DOM, но в покое визуально скрыта.",...(re=(ne=l.parameters)==null?void 0:ne.docs)==null?void 0:re.description}}};var oe,ie,ce,me,pe;u.parameters={...u.parameters,docs:{...(oe=u.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
    await expect(button).toHaveClass('copymsg');
  }
}`,...(ce=(ie=u.parameters)==null?void 0:ie.docs)==null?void 0:ce.source},description:{story:"Наведение на пользовательский пузырь раскрывает кнопку вопроса.",...(pe=(me=u.parameters)==null?void 0:me.docs)==null?void 0:pe.description}}};var de,le,ue,ge,be;g.parameters={...g.parameters,docs:{...(de=g.parameters)==null?void 0:de.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const button = within(canvasElement).getByRole('button', {
      name: 'Копировать вопрос'
    });
    button.focus();
    await expect(button).toHaveFocus();
  }
}`,...(ue=(le=g.parameters)==null?void 0:le.docs)==null?void 0:ue.source},description:{story:"Клавиатурный фокус раскрывает кнопку и сохраняет нативную активацию.",...(be=(ge=g.parameters)==null?void 0:ge.docs)==null?void 0:be.description}}};var ve,ye,he,we,xe;b.parameters={...b.parameters,docs:{...(ve=b.parameters)==null?void 0:ve.docs,source:{originalSource:`{
  decorators: [Story => <div data-theme="dark" style={{
    height: '100%'
  }}><Story /></div>],
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
  }
}`,...(he=(ye=b.parameters)==null?void 0:ye.docs)==null?void 0:he.source},description:{story:"Тёмная тема сохраняет контраст пользовательской кнопки в видимом состоянии.",...(xe=(we=b.parameters)==null?void 0:we.docs)==null?void 0:xe.description}}};var Ee,Me,ke,Te,fe;v.parameters={...v.parameters,docs:{...(Ee=v.parameters)==null?void 0:Ee.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать ответ'
    });
    const bubble = button.closest('.ai .bub');
    if (!bubble) throw new Error('Model message bubble not found');
    await userEvent.hover(bubble);
    button.focus();
    await expect(button).toHaveFocus();
  }
}`,...(ke=(Me=v.parameters)==null?void 0:Me.docs)==null?void 0:ke.source},description:{story:"Ответ модели сохраняет прежнее раскрытие при наведении и фокусе.",...(fe=(Te=v.parameters)==null?void 0:Te.docs)==null?void 0:fe.description}}};var Se,Be,Ie,Ce,Ae;y.parameters={...y.parameters,docs:{...(Se=y.parameters)==null?void 0:Se.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    await userEvent.click(button);
    await expect(button).toHaveClass('copymsg--copied');
  }
}`,...(Ie=(Be=y.parameters)==null?void 0:Be.docs)==null?void 0:Ie.source},description:{story:"Успешное копирование вопроса: видимое подтверждение закреплено для visual-check.",...(Ae=(Ce=y.parameters)==null?void 0:Ce.docs)==null?void 0:Ae.description}}};var Le,Ue,Re,He,De;h.parameters={...h.parameters,docs:{...(Le=h.parameters)==null?void 0:Le.docs,source:{originalSource:`{
  args: {
    messages: [],
    onExport: undefined
  }
}`,...(Re=(Ue=h.parameters)==null?void 0:Ue.docs)==null?void 0:Re.source},description:{story:"Пустая беседа: подсказка объясняет следующий шаг, а не констатирует пустоту.",...(De=(He=h.parameters)==null?void 0:He.docs)==null?void 0:De.description}}};var Ve,_e,We,Ne,Fe;w.parameters={...w.parameters,docs:{...(Ve=w.parameters)==null?void 0:Ve.docs,source:{originalSource:`{
  args: {
    messages: [],
    loadingMessages: true
  }
}`,...(We=(_e=w.parameters)==null?void 0:_e.docs)==null?void 0:We.source},description:{story:"Первая загрузка истории: скелетон реплик той же геометрии, что у сообщений.",...(Fe=(Ne=w.parameters)==null?void 0:Ne.docs)==null?void 0:Fe.description}}};var je,Oe,Qe,Ke,qe;x.parameters={...x.parameters,docs:{...(je=x.parameters)==null?void 0:je.docs,source:{originalSource:`{
  args: {
    loadingMessages: true
  }
}`,...(Qe=(Oe=x.parameters)==null?void 0:Oe.docs)==null?void 0:Qe.source},description:{story:"Повторная загрузка: лента остаётся на месте, сверху — индикатор обновления.",...(qe=(Ke=x.parameters)==null?void 0:Ke.docs)==null?void 0:qe.description}}};var Pe,Ye,Ge,Xe,ze;E.parameters={...E.parameters,docs:{...(Pe=E.parameters)==null?void 0:Pe.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    streamingReply: STREAMING_TEXT,
    liveActivity: ACTIVITY_LIVE,
    liveUsage: makeUsage(),
    voiceBar: bar('thinking')
  }
}`,...(Ge=(Ye=E.parameters)==null?void 0:Ye.docs)==null?void 0:Ge.source},description:{story:`Стриминг ответа: токены идут, действия чередуются с текстом, внизу пузыря
дубль статуса — при длинном ответе верхняя строка уезжает из вида.`,...(ze=(Xe=E.parameters)==null?void 0:Xe.docs)==null?void 0:ze.description}}};var Je,Ze,$e,es,ss;M.parameters={...M.parameters,docs:{...(Je=M.parameters)==null?void 0:Je.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    liveActivity: ACTIVITY_LIVE,
    liveUsage: makeUsage(),
    voiceBar: bar('thinking')
  }
}`,...($e=(Ze=M.parameters)==null?void 0:Ze.docs)==null?void 0:$e.source},description:{story:"Запрос ушёл, токенов ещё нет: блок «обрабатывает запрос» с живой активностью.",...(ss=(es=M.parameters)==null?void 0:es.docs)==null?void 0:ss.description}}};var ts,as,ns,rs,os;k.parameters={...k.parameters,docs:{...(ts=k.parameters)==null?void 0:ts.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    liveSegments: makeLiveSegments(),
    voiceBar: bar('listening')
  }
}`,...(ns=(as=k.parameters)==null?void 0:as.docs)==null?void 0:ns.source},description:{story:"Запись голоса: живой транскрипт по говорящим над композером.",...(os=(rs=k.parameters)==null?void 0:rs.docs)==null?void 0:os.description}}};var is,cs,ms,ps,ds;T.parameters={...T.parameters,docs:{...(is=T.parameters)==null?void 0:is.docs,source:{originalSource:`{
  args: {
    error: 'Микрофон недоступен: браузер не дал доступ к устройству записи',
    onDismissError: fn()
  }
}`,...(ms=(cs=T.parameters)==null?void 0:cs.docs)==null?void 0:ms.source},description:{story:"Ошибка движка баннером над лентой (закрывается крестиком).",...(ds=(ps=T.parameters)==null?void 0:ps.docs)==null?void 0:ds.description}}};var ls,us,gs,bs,vs;f.parameters={...f.parameters,docs:{...(ls=f.parameters)==null?void 0:ls.docs,source:{originalSource:`{
  args: {
    modelMissing: true,
    modelLabel: 'large-v3-turbo',
    onDownloadModel: fn()
  }
}`,...(gs=(us=f.parameters)==null?void 0:us.docs)==null?void 0:gs.source},description:{story:"Модель распознавания не скачана — баннер первого запуска с кнопкой.",...(vs=(bs=f.parameters)==null?void 0:bs.docs)==null?void 0:vs.description}}};var ys,hs,ws,xs,Es;S.parameters={...S.parameters,docs:{...(ys=S.parameters)==null?void 0:ys.docs,source:{originalSource:`{
  args: {
    modelMissing: true,
    modelLabel: 'large-v3-turbo',
    downloading: true,
    downloadPercent: 42
  }
}`,...(ws=(hs=S.parameters)==null?void 0:hs.docs)==null?void 0:ws.source},description:{story:"Скачивание модели идёт: вместо кнопки — процент.",...(Es=(xs=S.parameters)==null?void 0:xs.docs)==null?void 0:Es.description}}};var Ms,ks,Ts,fs,Ss;B.parameters={...B.parameters,docs:{...(Ms=B.parameters)==null?void 0:Ms.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Сделай CI-шаг для витрины'
    }), makeQuestionsMessage()],
    onAnswerQuestions: fn()
  }
}`,...(Ts=(ks=B.parameters)==null?void 0:ks.docs)==null?void 0:Ts.source},description:{story:"Уточняющие вопросы модели: форма ответов под последним сообщением.",...(Ss=(fs=B.parameters)==null?void 0:fs.docs)==null?void 0:Ss.description}}};var Bs,Is,Cs,As,Ls;I.parameters={...I.parameters,docs:{...(Bs=I.parameters)==null?void 0:Bs.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'старт'
    }), makeQuestionsMessage({
      id: 'a-ci',
      meta: {
        ciInteraction: {
          runId: 'run-1',
          interactionId: 'it-1'
        }
      }
    }), makeUserMessage({
      id: 'u-after',
      text: 'а пока посмотрю лог'
    })],
    onAnswerCiInteraction: fn()
  }
}`,...(Cs=(Is=I.parameters)==null?void 0:Is.docs)==null?void 0:Cs.source},description:{story:"Вопрос CI-рана, продублированный в чат: ответ уйдёт в ран, а не новым ходом.",...(Ls=(As=I.parameters)==null?void 0:As.docs)==null?void 0:Ls.description}}};var Us,Rs,Hs,Ds,Vs;C.parameters={...C.parameters,docs:{...(Us=C.parameters)==null?void 0:Us.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Построй график и открой консоль'
    }), makeImageMessage(), makeToolMessage('console')],
    machineOps: makeMachineOps(),
    // Машина нужна самой карточке: её шапка называет, где выполняются команды.
    agents: [makeAgent({
      id: 'm1',
      name: 'MacBook'
    })],
    onSwitchUtility: fn(),
    onOpenMachines: fn(),
    onOpenImageInExplorer: fn()
  }
}`,...(Hs=(Rs=C.parameters)==null?void 0:Rs.docs)==null?void 0:Hs.source},description:{story:"Ответ с картинкой и встроенной консолью машины (оба блока вырезаны из текста).",...(Vs=(Ds=C.parameters)==null?void 0:Ds.docs)==null?void 0:Vs.description}}};var _s,Ws,Ns,Fs,js;A.parameters={...A.parameters,docs:{...(_s=A.parameters)==null?void 0:_s.docs,source:{originalSource:`{
  args: {
    permissionMode: 'plan',
    messages: [makeUserMessage({
      text: 'Составь план'
    }), makeAiMessage({
      id: 'a-plan',
      text: MD_KITCHEN_SINK,
      meta: makeTurnMeta({
        request: {
          ...makeTurnMeta().request!,
          permissionMode: 'plan'
        }
      })
    })],
    onExecutePlan: fn(),
    voiceBar: bar()
  }
}`,...(Ns=(Ws=A.parameters)==null?void 0:Ws.docs)==null?void 0:Ns.source},description:{story:"Плановый ответ: под ним предложение выполнить тот же запрос в разработке.",...(js=(Fs=A.parameters)==null?void 0:Fs.docs)==null?void 0:js.description}}};var Os,Qs,Ks,qs,Ps;L.parameters={...L.parameters,docs:{...(Os=L.parameters)==null?void 0:Os.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Опиши архитектуру'
    }), makeAiMessage({
      id: 'a-int',
      text: 'Начал описывать, но не успел закон',
      meta: makeTurnMeta({
        interrupted: true
      })
    })]
  }
}`,...(Ks=(Qs=L.parameters)==null?void 0:Qs.docs)==null?void 0:Ks.source},description:{story:"Ход прерван перезапуском сервера: сохранена набранная часть, есть пометка.",...(Ps=(qs=L.parameters)==null?void 0:qs.docs)==null?void 0:Ps.description}}};var Ys,Gs,Xs,zs,Js;U.parameters={...U.parameters,docs:{...(Ys=U.parameters)==null?void 0:Ys.docs,source:{originalSource:`{
  args: {
    messages: makeLongThread()
  }
}`,...(Xs=(Gs=U.parameters)==null?void 0:Gs.docs)==null?void 0:Xs.source},description:{story:"Длинная переписка: 24 сообщения — скролл и автоскролл вниз.",...(Js=(zs=U.parameters)==null?void 0:zs.docs)==null?void 0:Js.description}}};var Zs,$s,et,st,tt;R.parameters={...R.parameters,docs:{...(Zs=R.parameters)==null?void 0:Zs.docs,source:{originalSource:`{
  args: {
    onToggleSidebar: fn(),
    messages: [makeUserMessage({
      id: 'u-mobile-copy',
      text: 'Проверь перенос длинной ссылки: https://example.test/very/long/unbroken/path/that/must/not/escape/the/message/bubble?query=mobile-copy-button'
    }), makeAiMessage({
      id: 'a-mobile-copy',
      text: 'Кнопка остаётся внутри пузыря, а текст переносится.'
    })]
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile2'
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
  }
}`,...(et=($s=R.parameters)==null?void 0:$s.docs)==null?void 0:et.source},description:{story:"Телефон: сайдбар выдвижной, поэтому в шапке появляется ☰.",...(tt=(st=R.parameters)==null?void 0:st.docs)==null?void 0:tt.description}}};var at,nt,rt,ot,it;H.parameters={...H.parameters,docs:{...(at=H.parameters)==null?void 0:at.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByLabelText('Изменить сообщение'));
    const area = canvas.getByLabelText('Редактирование сообщения');
    await userEvent.clear(area);
    await userEvent.type(area, 'Почему упал шаг npm test и как это починить?');
    await expect(area).toHaveValue('Почему упал шаг npm test и как это починить?');
    await expect(canvas.getByRole('button', {
      name: 'Отправить'
    })).toBeEnabled();
  }
}`,...(rt=(nt=H.parameters)==null?void 0:nt.docs)==null?void 0:rt.source},description:{story:`Правка своей реплики: ✏️ открывает поле на месте пузыря (2–4 строки),
«Отправить» перезапускает ход с новым текстом.`,...(it=(ot=H.parameters)==null?void 0:ot.docs)==null?void 0:it.description}}};var ct,mt,pt,dt,lt;D.parameters={...D.parameters,docs:{...(ct=D.parameters)==null?void 0:ct.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByLabelText('Переключить вид действий');
    await userEvent.click(button);
    // Секций действий в ответе две (по обе стороны абзацев) — обе сворачиваются
    // в свою строку-сводку, поэтому здесь \`getAllBy\`, а не \`getBy\`.
    await expect(canvas.getAllByTestId('activity-brief')).toHaveLength(2);
    await userEvent.click(button);
    await expect(canvas.getAllByTestId('activity-section').length).toBeGreaterThan(1);
  }
}`,...(pt=(mt=D.parameters)==null?void 0:mt.docs)==null?void 0:pt.source},description:{story:"Переключение вида действий у ответа: минимально → кратко → подробно.",...(lt=(dt=D.parameters)==null?void 0:dt.docs)==null?void 0:lt.description}}};const Ba=["NewMessages","SearchAndCompact","FailedSubmission","MobileComposer390","Conversation","UserMessageHovered","UserMessageFocused","UserMessageHoveredDark","ModelMessageHovered","UserMessageCopied","EmptyConversation","LoadingMessages","RefreshingMessages","Streaming","Thinking","Listening","WithError","ModelMissing","ModelDownloading","WithQuestions","WithCiQuestion","WithMachineWidgets","PlanReady","InterruptedAnswer","LongThread","MobileViewport","EditingMessage","ActivityModeSwitch"];export{D as ActivityModeSwitch,l as Conversation,H as EditingMessage,h as EmptyConversation,N as FailedSubmission,L as InterruptedAnswer,k as Listening,w as LoadingMessages,U as LongThread,F as MobileComposer390,R as MobileViewport,S as ModelDownloading,v as ModelMessageHovered,f as ModelMissing,_ as NewMessages,A as PlanReady,x as RefreshingMessages,W as SearchAndCompact,E as Streaming,M as Thinking,y as UserMessageCopied,g as UserMessageFocused,u as UserMessageHovered,b as UserMessageHoveredDark,I as WithCiQuestion,T as WithError,C as WithMachineWidgets,B as WithQuestions,Ba as __namedExportsOrder,Sa as default};
