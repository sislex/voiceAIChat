import{j as a}from"./jsx-runtime-BYYWji4R.js";import{r as h}from"./index-ClcD9ViR.js";import{fn as r,within as F,userEvent as l,expect as p}from"./index-DeN4tkzB.js";import{V as U}from"./VoiceBar-BSyoAAZC.js";import{q as G}from"./chat-DXuxoGTT.js";import"./ci-awuetLx1.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./useCommands-isko1sz4.js";import"./commands-BOmIcTa-.js";import"./hotkeys-4oJJtujI.js";import"./autoGrow-CoBFBF9S.js";import"./view-0MbJGw9Y.js";import"./animations--P72MiAI.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./icons-MIP1fpxy.js";import"./useAiAssist-CtGDklNp.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./clipboard-BEgkkb6H.js";import"./images-CH23vBlI.js";import"./tools-iBbMKii-.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";const d=()=>{},Ir={title:"Chat/VoiceBar",component:U,args:{state:"idle",draft:"",diarization:!0,detectedSpeakers:[],attachments:[],onDraftChange:r(),onSubmitText:r(),onStartVoice:r(),onStopVoice:r(),onStopSpeak:r(),onCancelRequest:r(),onAddFiles:r(),onRemoveAttachment:r(),defaultCollapsed:!1},decorators:[t=>a.jsx("div",{style:{maxWidth:860},children:a.jsx(t,{})})]},f={},$={args:{draft:"Сохранённый черновик беседы. Длинный текст остаётся доступным для редактирования."},decorators:[t=>a.jsx("div",{style:{width:390,maxWidth:"100%"},children:a.jsx(t,{})})]},O={args:{attachments:[{localId:"pasted",name:"clipboard.svg",status:"ready",previewUrl:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="80" height="60"%3E%3Crect width="80" height="60" fill="skyblue"/%3E%3C/svg%3E'}]}},v={args:{draft:"Разберись, почему упал шаг npm test в последнем ране."}},w={args:{state:"listening",detectedSpeakers:[1,2]}},x={args:{state:"listening",detectedSpeakers:[1],diarization:!1}},S={args:{state:"transcribing"}},Ua=`
  .waiting-in-feed-story { display: grid; min-height: 420px; grid-template-rows: 1fr auto; }
  .waiting-in-feed-story__timeline {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    gap: 10px;
    min-height: 260px;
    padding: 20px 14px;
    background: var(--bg);
  }
  .waiting-in-feed-story__message {
    align-self: flex-end;
    max-width: min(76%, 560px);
    padding: 9px 12px;
    border-radius: 14px 14px 4px 14px;
    background: var(--accent);
    color: white;
  }
  .waiting-in-feed-story__preparing {
    align-self: flex-start;
    display: flex;
    align-items: center;
    gap: 7px;
    min-height: 26px;
    color: var(--text-dim);
    font-size: 13px;
  }
  .waiting-in-feed-story__dots { letter-spacing: 2px; color: var(--accent); }
`,C={args:{state:"thinking",draft:"Следующее сообщение в очередь"},render:t=>a.jsxs("div",{className:"waiting-in-feed-story",children:[a.jsx("style",{children:Ua}),a.jsxs("div",{className:"waiting-in-feed-story__timeline",role:"log","aria-label":"Сообщения",children:[a.jsx("div",{className:"waiting-in-feed-story__message",children:"Проверь, почему последний тест падает только в CI"}),a.jsxs("div",{className:"waiting-in-feed-story__preparing",role:"status",children:[a.jsx("span",{className:"waiting-in-feed-story__dots","aria-hidden":"true",children:"•••"}),a.jsx("span",{children:"Готовим ответ…"})]})]}),a.jsx(U,{...t})]})},T={args:{state:"thinking",replyStarted:!0,draft:"А ещё проверь кэш npm"}},b={args:{state:"speaking"}},k={args:{voiceInputEnabled:!1}},$a=`
  .attachment-preview-story .attchips { align-items: flex-end; }
  .attachment-preview-story .attpreview-image {
    background:
      linear-gradient(145deg, transparent 55%, rgba(255,255,255,.22) 56% 64%, transparent 65%),
      radial-gradient(circle at 72% 28%, #ffd166 0 7px, transparent 8px),
      linear-gradient(155deg, #7db7e8 0 48%, #4f8f6a 49% 67%, #315f49 68%);
  }
  .attachment-preview-story .attpreview-image > span { display: none; }
`,y={decorators:[t=>a.jsxs("div",{className:"attachment-preview-story",children:[a.jsx("style",{children:$a}),a.jsx(t,{})]})],args:{draft:"Вот скриншот и лог рана",attachments:[G({name:"скриншот-падения.png"}),G({name:"ci-run-1934.log",mimeType:"text/plain"})]}},E={args:{layout:"centered",draft:"",userDisplayName:"Анна"}},I={args:{layout:"docked",draft:"Следующее сообщение"}},B={args:{draft:`Первая строка
Вторая строка
Третья строка`}},A={args:{draft:Array.from({length:10},(t,e)=>`Строка ${e+1}: детали задачи`).join(`
`)}},M={args:{draft:`Первая строка
Вторая строка
Третья строка`},play:async({canvasElement:t})=>{const e=F(t);await l.click(e.getByTestId("composer-size-toggle")),await p(e.getByLabelText("Поле ввода сообщения").closest(".voicebar")).toHaveClass("voicebar--expanded")}},H={args:{draft:"Посмотри изображение",attachments:[{localId:"processing-image",status:"processing",name:"большой-скриншот.png",mimeType:"image/png"}]}},j={decorators:y.decorators,args:{draft:"Посмотри изображение",attachments:[{localId:"ready-image",status:"ready",name:"готовый-скриншот.png",mimeType:"image/png"}]}},P={args:{draft:"Посмотри изображение",onRetryAttachment:r(),attachments:[{localId:"error-image",status:"error",name:"сломанный-скриншот.png",mimeType:"image/png",error:"Не удалось загрузить"}]}},R={args:{draft:"Три изображения",onRetryAttachment:r(),attachments:[{localId:"processing",status:"processing",name:"обработка.png",mimeType:"image/png"},{localId:"ready",status:"ready",name:"готово.png",mimeType:"image/png"},{localId:"error",status:"error",name:"ошибка.png",mimeType:"image/png",error:"Сеть недоступна"}]}},za=Array.from({length:5},(t,e)=>({id:`queue-${e+1}`,conversationId:"storybook-chat",messageId:`message-${e+1}`,text:e===1?"Очень длинное ожидающее сообщение, проверяющее перенос текста и доступность действий при увеличенном размере шрифта.":`Ожидающее сообщение ${e+1}`,attachments:e===0?["image-upload","document-upload"]:[],...e===0?{attachmentDetails:[{uploadId:"image-upload",path:"/fixtures/image.png",name:"image.png",mimeType:"image/png",size:1024},{uploadId:"document-upload",path:"/fixtures/document.pdf",name:"document.pdf",mimeType:"application/pdf",size:2048}]}:{},position:e+1,status:"queued",createdAt:e+1}));function Oa(t){const[e,m]=h.useState(za);return a.jsx(U,{...t,queuedTurns:e,onEditQueued:(s,n)=>{var i;m(c=>c.map(o=>o.id===s?{...o,text:n}:o)),(i=t.onEditQueued)==null||i.call(t,s,n)},onDeleteQueued:s=>{var n;m(i=>i.filter(c=>c.id!==s).map((c,o)=>({...c,position:o+1}))),(n=t.onDeleteQueued)==null||n.call(t,s)},onSendQueuedNow:s=>{var n;m(i=>{const c=i.find(o=>o.id===s);return c?[c,...i.filter(o=>o.id!==s)].map((o,Fa)=>({...o,position:Fa+1})):i}),(n=t.onSendQueuedNow)==null||n.call(t,s)}})}const u={render:t=>a.jsx(Oa,{...t}),args:{state:"thinking",queuedTurns:za,onEditQueued:r(),onDeleteQueued:r(),onSendQueuedNow:r()},play:async({canvasElement:t})=>{const e=F(t);await p(e.getAllByTestId("turn-queue-item")).toHaveLength(3),await l.click(e.getByRole("button",{name:"Показать ещё 2"})),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(5),await l.click(e.getByRole("button",{name:"Отправить сейчас сообщение № 5"})),await p(e.getAllByTestId("turn-queue-item")[0]).toHaveTextContent("Ожидающее сообщение 5")}},_={args:{...u.args,defaultCollapsed:!0,allowCollapse:!0},parameters:{viewport:{defaultViewport:"mobile1"}},play:async({canvasElement:t})=>{const e=F(t);await p(e.queryByLabelText("Поле ввода сообщения")).not.toBeInTheDocument(),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(3),await l.click(e.getByRole("button",{name:"Показать ещё 2"})),await p(e.getAllByTestId("turn-queue-item")).toHaveLength(5)}},D={args:{...u.args,queuePaused:!0,requestError:"Движок недоступен"}},L={args:{allowCollapse:!0,defaultCollapsed:!0,draft:"Проверь, почему шаг npm test падает только в CI"},parameters:{viewport:{defaultViewport:"mobile1"}}},q={args:{allowCollapse:!0,defaultCollapsed:!0,state:"thinking"},parameters:{viewport:{defaultViewport:"mobile1"}}},Q={args:{permissionMode:"acceptEdits",onChangePermissionMode:r()}},g={args:{draft:"сделай сториз",onSuggestPrompts:r(),onApplyPromptSuggestion:r(),onClosePromptSuggestions:r(),promptHelper:{open:!0,loading:!1,error:null,variants:["Покрой сториз виджеты чата и CI-панели, вынеся общие фикстуры.","Добавь Storybook-состояния для ленты чата и панели CI-рана.","Опиши сториз редкие состояния чата: пустая лента, стрим, ошибка движка."]}}},N={args:{...g.args,promptHelper:{open:!0,loading:!0,error:null,variants:[]}}},V={args:{...g.args,promptHelper:{open:!0,loading:!1,error:"Движок не ответил: истёк таймаут",variants:[]}}};function Ga({initial:t="",state:e="idle"}){const[m,s]=h.useState(t),[n,i]=h.useState([]);return a.jsxs("div",{style:{maxWidth:860},children:[n.length>0&&a.jsx("ul",{className:"attchips","data-testid":"sent-messages",children:n.map((c,o)=>a.jsx("li",{className:"attchip",children:c},o))}),a.jsx(U,{defaultCollapsed:!1,state:e,draft:m,diarization:!0,detectedSpeakers:[],attachments:[],onDraftChange:s,onSubmitText:()=>{i(c=>[...c,m]),s("")},onStartVoice:d,onStopVoice:d,onStopSpeak:d,onCancelRequest:d,onAddFiles:d,onRemoveAttachment:d})]})}function Ja(){const[t,e]=h.useState("Создай компонент"),[m,s]=h.useState("plan"),[n,i]=h.useState(null);return a.jsxs("div",{children:[n&&a.jsxs("p",{role:"status",children:["Первая отправка: ",n==="acceptEdits"?"Разработка":"План"]}),a.jsx(U,{defaultCollapsed:!1,state:"idle",draft:t,diarization:!0,detectedSpeakers:[],attachments:[],permissionMode:m,onChangePermissionMode:s,onDraftChange:e,onSubmitText:()=>i(m),onStartVoice:d,onStopVoice:d,onStopSpeak:d,onCancelRequest:d,onAddFiles:d,onRemoveAttachment:d})]})}const W={render:()=>a.jsx(Ja,{}),play:async({canvasElement:t})=>{const e=F(t);await l.click(e.getByRole("button",{name:"Разработка"})),await l.click(e.getByLabelText("Отправить сообщение")),await p(e.getByRole("status")).toHaveTextContent("Первая отправка: Разработка")}},z={render:()=>a.jsx(Ga,{}),play:async({canvasElement:t})=>{const e=F(t);await l.type(e.getByLabelText("Поле ввода сообщения"),"Проверь гейт пакета ui"),await l.click(e.getByLabelText("Отправить сообщение")),await p(e.getByTestId("sent-messages")).toHaveTextContent("Проверь гейт пакета ui"),await p(e.getByLabelText("Поле ввода сообщения")).toHaveValue("")}};var J,K,X,Y,Z;f.parameters={...f.parameters,docs:{...(J=f.parameters)==null?void 0:J.docs,source:{originalSource:"{}",...(X=(K=f.parameters)==null?void 0:K.docs)==null?void 0:X.source},description:{story:"Простой: композер пуст, кнопка справа — микрофон.",...(Z=(Y=f.parameters)==null?void 0:Y.docs)==null?void 0:Z.description}}};var ee,te,ae;$.parameters={...$.parameters,docs:{...(ee=$.parameters)==null?void 0:ee.docs,source:{originalSource:`{
  args: {
    draft: 'Сохранённый черновик беседы. Длинный текст остаётся доступным для редактирования.'
  },
  decorators: [Story => <div style={{
    width: 390,
    maxWidth: '100%'
  }}><Story /></div>]
}`,...(ae=(te=$.parameters)==null?void 0:te.docs)==null?void 0:ae.source}}};var re,se,ne;O.parameters={...O.parameters,docs:{...(re=O.parameters)==null?void 0:re.docs,source:{originalSource:`{
  args: {
    attachments: [{
      localId: 'pasted',
      name: 'clipboard.svg',
      status: 'ready',
      previewUrl: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="80" height="60"%3E%3Crect width="80" height="60" fill="skyblue"/%3E%3C/svg%3E'
    }]
  }
}`,...(ne=(se=O.parameters)==null?void 0:se.docs)==null?void 0:ne.source}}};var oe,ie,ce,de,pe;v.parameters={...v.parameters,docs:{...(oe=v.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  args: {
    draft: 'Разберись, почему упал шаг npm test в последнем ране.'
  }
}`,...(ce=(ie=v.parameters)==null?void 0:ie.docs)==null?void 0:ce.source},description:{story:"Набранный черновик: микрофон сменился на «отправить».",...(pe=(de=v.parameters)==null?void 0:de.docs)==null?void 0:pe.description}}};var me,le,ue,ge,ye;w.parameters={...w.parameters,docs:{...(me=w.parameters)==null?void 0:me.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    detectedSpeakers: [1, 2]
  }
}`,...(ue=(le=w.parameters)==null?void 0:le.docs)==null?void 0:ue.source},description:{story:"Запись: волна, «Готово» и строка обнаруженных говорящих.",...(ye=(ge=w.parameters)==null?void 0:ge.docs)==null?void 0:ye.description}}};var he,fe,ve,we,xe;x.parameters={...x.parameters,docs:{...(he=x.parameters)==null?void 0:he.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    detectedSpeakers: [1],
    diarization: false
  }
}`,...(ve=(fe=x.parameters)==null?void 0:fe.docs)==null?void 0:ve.source},description:{story:"Запись без диаризации: чипы говорящих становятся общим «Вы».",...(xe=(we=x.parameters)==null?void 0:we.docs)==null?void 0:xe.description}}};var Se,Ce,Te,be,ke;S.parameters={...S.parameters,docs:{...(Se=S.parameters)==null?void 0:Se.docs,source:{originalSource:`{
  args: {
    state: 'transcribing'
  }
}`,...(Te=(Ce=S.parameters)==null?void 0:Ce.docs)==null?void 0:Te.source},description:{story:"Распознавание: транскрипт финализируется, композер ещё заблокирован.",...(ke=(be=S.parameters)==null?void 0:be.docs)==null?void 0:ke.description}}};var Ee,Ie,Be,Ae,Me;C.parameters={...C.parameters,docs:{...(Ee=C.parameters)==null?void 0:Ee.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    draft: 'Следующее сообщение в очередь'
  },
  render: args => <div className="waiting-in-feed-story">
      <style>{waitingInFeedStoryCss}</style>
      <div className="waiting-in-feed-story__timeline" role="log" aria-label="Сообщения">
        <div className="waiting-in-feed-story__message">Проверь, почему последний тест падает только в CI</div>
        <div className="waiting-in-feed-story__preparing" role="status">
          <span className="waiting-in-feed-story__dots" aria-hidden="true">•••</span>
          <span>Готовим ответ…</span>
        </div>
      </div>
      <VoiceBar {...args} />
    </div>
}`,...(Be=(Ie=C.parameters)==null?void 0:Ie.docs)==null?void 0:Be.source},description:{story:"До первого фрагмента подготовка видна в ленте, не увеличивая нижнюю панель.",...(Me=(Ae=C.parameters)==null?void 0:Ae.docs)==null?void 0:Me.description}}};var He,je,Pe,Re,_e;T.parameters={...T.parameters,docs:{...(He=T.parameters)==null?void 0:He.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    replyStarted: true,
    draft: 'А ещё проверь кэш npm'
  }
}`,...(Pe=(je=T.parameters)==null?void 0:je.docs)==null?void 0:Pe.source},description:{story:"Пошёл стрим ответа: композер снова доступен под черновик, отправка — нет.",...(_e=(Re=T.parameters)==null?void 0:Re.docs)==null?void 0:_e.description}}};var De,Le,qe,Qe,Ne;b.parameters={...b.parameters,docs:{...(De=b.parameters)==null?void 0:De.docs,source:{originalSource:`{
  args: {
    state: 'speaking'
  }
}`,...(qe=(Le=b.parameters)==null?void 0:Le.docs)==null?void 0:qe.source},description:{story:"Озвучка ответа: композер доступен, красная кнопка останавливает речь.",...(Ne=(Qe=b.parameters)==null?void 0:Qe.docs)==null?void 0:Ne.description}}};var Ve,We,ze,Fe,Ue;k.parameters={...k.parameters,docs:{...(Ve=k.parameters)==null?void 0:Ve.docs,source:{originalSource:`{
  args: {
    voiceInputEnabled: false
  }
}`,...(ze=(We=k.parameters)==null?void 0:We.docs)==null?void 0:ze.source},description:{story:"Микрофон недоступен: движок распознавания не поднялся (нет модели, нет доступа\nк устройству) — голосовой ввод выключен целиком, кнопки микрофона нет, и в\nпростое панель молчит вместо подсказки про пробел. Текст самой ошибки живёт в\nбаннере ленты (`ChatColumn`, сториз `WithError`).",...(Ue=(Fe=k.parameters)==null?void 0:Fe.docs)==null?void 0:Ue.description}}};var $e,Oe,Ge,Je,Ke;y.parameters={...y.parameters,docs:{...($e=y.parameters)==null?void 0:$e.docs,source:{originalSource:`{
  decorators: [Story => <div className="attachment-preview-story">
      <style>{attachmentPreviewStoryCss}</style>
      <Story />
    </div>],
  args: {
    draft: 'Вот скриншот и лог рана',
    attachments: [makeUpload({
      name: 'скриншот-падения.png'
    }), makeUpload({
      name: 'ci-run-1934.log',
      mimeType: 'text/plain'
    })]
  }
}`,...(Ge=(Oe=y.parameters)==null?void 0:Oe.docs)==null?void 0:Ge.source},description:{story:"Изображение показано миниатюрой с именем снизу; прочие файлы остаются чипами.",...(Ke=(Je=y.parameters)==null?void 0:Je.docs)==null?void 0:Ke.description}}};var Xe,Ye,Ze,et,tt;E.parameters={...E.parameters,docs:{...(Xe=E.parameters)==null?void 0:Xe.docs,source:{originalSource:`{
  args: {
    layout: 'centered',
    draft: '',
    userDisplayName: 'Анна'
  }
}`,...(Ze=(Ye=E.parameters)==null?void 0:Ye.docs)==null?void 0:Ze.source},description:{story:"Пустой чат: композер по центру с приветствием.",...(tt=(et=E.parameters)==null?void 0:et.docs)==null?void 0:tt.description}}};var at,rt,st,nt,ot;I.parameters={...I.parameters,docs:{...(at=I.parameters)==null?void 0:at.docs,source:{originalSource:`{
  args: {
    layout: 'docked',
    draft: 'Следующее сообщение'
  }
}`,...(st=(rt=I.parameters)==null?void 0:rt.docs)==null?void 0:st.source},description:{story:"Разговор начат: композер закреплён внизу колонки.",...(ot=(nt=I.parameters)==null?void 0:nt.docs)==null?void 0:ot.description}}};var it,ct,dt,pt,mt;B.parameters={...B.parameters,docs:{...(it=B.parameters)==null?void 0:it.docs,source:{originalSource:`{
  args: {
    draft: 'Первая строка\\nВторая строка\\nТретья строка'
  }
}`,...(dt=(ct=B.parameters)==null?void 0:ct.docs)==null?void 0:dt.source},description:{story:"Поле начинается с одной строки и растёт на каждую новую строку текста.",...(mt=(pt=B.parameters)==null?void 0:pt.docs)==null?void 0:mt.description}}};var lt,ut,gt,yt,ht;A.parameters={...A.parameters,docs:{...(lt=A.parameters)==null?void 0:lt.docs,source:{originalSource:`{
  args: {
    draft: Array.from({
      length: 10
    }, (_, index) => \`Строка \${index + 1}: детали задачи\`).join('\\n')
  }
}`,...(gt=(ut=A.parameters)==null?void 0:ut.docs)==null?void 0:gt.source},description:{story:"После четырёх строк высота ограничена, текст прокручивается внутри поля.",...(ht=(yt=A.parameters)==null?void 0:yt.docs)==null?void 0:ht.description}}};var ft,vt,wt,xt,St;M.parameters={...M.parameters,docs:{...(ft=M.parameters)==null?void 0:ft.docs,source:{originalSource:`{
  args: {
    draft: 'Первая строка\\nВторая строка\\nТретья строка'
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByTestId('composer-size-toggle'));
    await expect(canvas.getByLabelText('Поле ввода сообщения').closest('.voicebar')).toHaveClass('voicebar--expanded');
  }
}`,...(wt=(vt=M.parameters)==null?void 0:vt.docs)==null?void 0:wt.source},description:{story:"Редактор раскрыт вручную; play оставляет story в раскрытом состоянии.",...(St=(xt=M.parameters)==null?void 0:xt.docs)==null?void 0:St.description}}};var Ct,Tt,bt,kt,Et;H.parameters={...H.parameters,docs:{...(Ct=H.parameters)==null?void 0:Ct.docs,source:{originalSource:`{
  args: {
    draft: 'Посмотри изображение',
    attachments: [{
      localId: 'processing-image',
      status: 'processing',
      name: 'большой-скриншот.png',
      mimeType: 'image/png'
    }]
  }
}`,...(bt=(Tt=H.parameters)==null?void 0:Tt.docs)==null?void 0:bt.source},description:{story:"Изображение обрабатывается: плитка зарезервирована, отправка заблокирована.",...(Et=(kt=H.parameters)==null?void 0:kt.docs)==null?void 0:Et.description}}};var It,Bt,At,Mt,Ht;j.parameters={...j.parameters,docs:{...(It=j.parameters)==null?void 0:It.docs,source:{originalSource:`{
  decorators: WithAttachments.decorators,
  args: {
    draft: 'Посмотри изображение',
    attachments: [{
      localId: 'ready-image',
      status: 'ready',
      name: 'готовый-скриншот.png',
      mimeType: 'image/png'
    }]
  }
}`,...(At=(Bt=j.parameters)==null?void 0:Bt.docs)==null?void 0:At.source},description:{story:"Изображение готово и может быть отправлено.",...(Ht=(Mt=j.parameters)==null?void 0:Mt.docs)==null?void 0:Ht.description}}};var jt,Pt,Rt,_t,Dt;P.parameters={...P.parameters,docs:{...(jt=P.parameters)==null?void 0:jt.docs,source:{originalSource:`{
  args: {
    draft: 'Посмотри изображение',
    onRetryAttachment: fn(),
    attachments: [{
      localId: 'error-image',
      status: 'error',
      name: 'сломанный-скриншот.png',
      mimeType: 'image/png',
      error: 'Не удалось загрузить'
    }]
  }
}`,...(Rt=(Pt=P.parameters)==null?void 0:Pt.docs)==null?void 0:Rt.source},description:{story:"Ошибка изображения: плитка сохраняется, доступны повтор и удаление.",...(Dt=(_t=P.parameters)==null?void 0:_t.docs)==null?void 0:Dt.description}}};var Lt,qt,Qt,Nt,Vt;R.parameters={...R.parameters,docs:{...(Lt=R.parameters)==null?void 0:Lt.docs,source:{originalSource:`{
  args: {
    draft: 'Три изображения',
    onRetryAttachment: fn(),
    attachments: [{
      localId: 'processing',
      status: 'processing',
      name: 'обработка.png',
      mimeType: 'image/png'
    }, {
      localId: 'ready',
      status: 'ready',
      name: 'готово.png',
      mimeType: 'image/png'
    }, {
      localId: 'error',
      status: 'error',
      name: 'ошибка.png',
      mimeType: 'image/png',
      error: 'Сеть недоступна'
    }]
  }
}`,...(Qt=(qt=R.parameters)==null?void 0:qt.docs)==null?void 0:Qt.source},description:{story:"Смешанные статусы вложений явно блокируют отправку до устранения проблем.",...(Vt=(Nt=R.parameters)==null?void 0:Nt.docs)==null?void 0:Vt.description}}};var Wt,zt,Ft,Ut,$t;u.parameters={...u.parameters,docs:{...(Wt=u.parameters)==null?void 0:Wt.docs,source:{originalSource:`{
  render: args => <MessageQueueDemo {...args} />,
  args: {
    state: 'thinking',
    queuedTurns,
    onEditQueued: fn(),
    onDeleteQueued: fn(),
    onSendQueuedNow: fn()
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(3);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать ещё 2'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(5);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Отправить сейчас сообщение № 5'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')[0]).toHaveTextContent('Ожидающее сообщение 5');
  }
}`,...(Ft=(zt=u.parameters)==null?void 0:zt.docs)==null?void 0:Ft.source},description:{story:"Свёрнутая очередь показывает первые три элемента и счётчик остальных.",...($t=(Ut=u.parameters)==null?void 0:Ut.docs)==null?void 0:$t.description}}};var Ot,Gt,Jt,Kt,Xt;_.parameters={..._.parameters,docs:{...(Ot=_.parameters)==null?void 0:Ot.docs,source:{originalSource:`{
  args: {
    ...MessageQueue.args,
    defaultCollapsed: true,
    allowCollapse: true
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await expect(canvas.queryByLabelText('Поле ввода сообщения')).not.toBeInTheDocument();
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(3);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать ещё 2'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(5);
  }
}`,...(Jt=(Gt=_.parameters)==null?void 0:Gt.docs)==null?void 0:Jt.source},description:{story:"Мобильный дефолт: очередь доступна, хотя само поле ввода свёрнуто.",...(Xt=(Kt=_.parameters)==null?void 0:Kt.docs)==null?void 0:Xt.description}}};var Yt,Zt,ea,ta,aa;D.parameters={...D.parameters,docs:{...(Yt=D.parameters)==null?void 0:Yt.docs,source:{originalSource:`{
  args: {
    ...MessageQueue.args,
    queuePaused: true,
    requestError: 'Движок недоступен'
  }
}`,...(ea=(Zt=D.parameters)==null?void 0:Zt.docs)==null?void 0:ea.source},description:{story:"Ошибка текущего хода оставляет ожидающие элементы на явной паузе.",...(aa=(ta=D.parameters)==null?void 0:ta.docs)==null?void 0:aa.description}}};var ra,sa,na,oa,ia;L.parameters={...L.parameters,docs:{...(ra=L.parameters)==null?void 0:ra.docs,source:{originalSource:`{
  args: {
    allowCollapse: true,
    defaultCollapsed: true,
    draft: 'Проверь, почему шаг npm test падает только в CI'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(na=(sa=L.parameters)==null?void 0:sa.docs)==null?void 0:na.source},description:{story:`Свёрнутый композер — то, с чего чат открывается: поле убрано в строку, в ней
черновик (иначе вложения или состояние хода). Так под ленту сообщений
отдаётся вся высота колонки.`,...(ia=(oa=L.parameters)==null?void 0:oa.docs)==null?void 0:ia.description}}};var ca,da,pa,ma,la;q.parameters={...q.parameters,docs:{...(ca=q.parameters)==null?void 0:ca.docs,source:{originalSource:`{
  args: {
    allowCollapse: true,
    defaultCollapsed: true,
    state: 'thinking'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(pa=(da=q.parameters)==null?void 0:da.docs)==null?void 0:pa.source},description:{story:"Свёрнут во время хода: кнопка остановки остаётся в строке, а не прячется.",...(la=(ma=q.parameters)==null?void 0:ma.docs)==null?void 0:la.description}}};var ua,ga,ya,ha,fa;Q.parameters={...Q.parameters,docs:{...(ua=Q.parameters)==null?void 0:ua.docs,source:{originalSource:`{
  args: {
    permissionMode: 'acceptEdits',
    onChangePermissionMode: fn()
  }
}`,...(ya=(ga=Q.parameters)==null?void 0:ga.docs)==null?void 0:ya.source},description:{story:"Переключатель режима: план / разработка (в простое активен, в ходе заблокирован).",...(fa=(ha=Q.parameters)==null?void 0:ha.docs)==null?void 0:fa.description}}};var va,wa,xa,Sa,Ca;g.parameters={...g.parameters,docs:{...(va=g.parameters)==null?void 0:va.docs,source:{originalSource:`{
  args: {
    draft: 'сделай сториз',
    onSuggestPrompts: fn(),
    onApplyPromptSuggestion: fn(),
    onClosePromptSuggestions: fn(),
    promptHelper: {
      open: true,
      loading: false,
      error: null,
      variants: ['Покрой сториз виджеты чата и CI-панели, вынеся общие фикстуры.', 'Добавь Storybook-состояния для ленты чата и панели CI-рана.', 'Опиши сториз редкие состояния чата: пустая лента, стрим, ошибка движка.']
    }
  }
}`,...(xa=(wa=g.parameters)==null?void 0:wa.docs)==null?void 0:xa.source},description:{story:"Помощник формулировки: варианты подобраны.",...(Ca=(Sa=g.parameters)==null?void 0:Sa.docs)==null?void 0:Ca.description}}};var Ta,ba,ka,Ea,Ia;N.parameters={...N.parameters,docs:{...(Ta=N.parameters)==null?void 0:Ta.docs,source:{originalSource:`{
  args: {
    ...PromptHelperReady.args,
    promptHelper: {
      open: true,
      loading: true,
      error: null,
      variants: []
    }
  }
}`,...(ka=(ba=N.parameters)==null?void 0:ba.docs)==null?void 0:ka.source},description:{story:"Помощник думает: спиннер вместо списка.",...(Ia=(Ea=N.parameters)==null?void 0:Ea.docs)==null?void 0:Ia.description}}};var Ba,Aa,Ma,Ha,ja;V.parameters={...V.parameters,docs:{...(Ba=V.parameters)==null?void 0:Ba.docs,source:{originalSource:`{
  args: {
    ...PromptHelperReady.args,
    promptHelper: {
      open: true,
      loading: false,
      error: 'Движок не ответил: истёк таймаут',
      variants: []
    }
  }
}`,...(Ma=(Aa=V.parameters)==null?void 0:Aa.docs)==null?void 0:Ma.source},description:{story:"Помощник не смог: текст ошибки вместо вариантов.",...(ja=(Ha=V.parameters)==null?void 0:Ha.docs)==null?void 0:ja.description}}};var Pa,Ra,_a,Da,La;W.parameters={...W.parameters,docs:{...(Pa=W.parameters)==null?void 0:Pa.docs,source:{originalSource:`{
  render: () => <PermissionModeFirstSendDemo />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Разработка'
    }));
    await userEvent.click(canvas.getByLabelText('Отправить сообщение'));
    await expect(canvas.getByRole('status')).toHaveTextContent('Первая отправка: Разработка');
  }
}`,...(_a=(Ra=W.parameters)==null?void 0:Ra.docs)==null?void 0:_a.source},description:{story:"Выбранный режим разработки применяется уже к первой отправке.",...(La=(Da=W.parameters)==null?void 0:Da.docs)==null?void 0:La.description}}};var qa,Qa,Na,Va,Wa;z.parameters={...z.parameters,docs:{...(qa=z.parameters)==null?void 0:qa.docs,source:{originalSource:`{
  render: () => <ControlledVoiceBar />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByLabelText('Поле ввода сообщения'), 'Проверь гейт пакета ui');
    await userEvent.click(canvas.getByLabelText('Отправить сообщение'));
    await expect(canvas.getByTestId('sent-messages')).toHaveTextContent('Проверь гейт пакета ui');
    await expect(canvas.getByLabelText('Поле ввода сообщения')).toHaveValue('');
  }
}`,...(Na=(Qa=z.parameters)==null?void 0:Qa.docs)==null?void 0:Na.source},description:{story:`Отправка сообщения: набрать текст → кнопка микрофона сменилась на «отправить» →
клик отправляет и очищает поле. Enter делает то же (Shift+Enter — перенос).`,...(Wa=(Va=z.parameters)==null?void 0:Va.docs)==null?void 0:Wa.description}}};const Br=["Idle","RestoredDraft390","PastedImage","WithDraft","Listening","ListeningWithoutDiarization","Transcribing","WaitingForModel","ReplyStreaming","Speaking","MicUnavailable","WithAttachments","EmptyCentered","ConversationDocked","Multiline","CappedScroll","Expanded","AttachmentProcessing","AttachmentReady","AttachmentError","AttachmentMixedStatuses","MessageQueue","MessageQueueCollapsedComposer","MessageQueuePausedAfterError","Collapsed","CollapsedWhileThinking","ModeToggle","PromptHelperReady","PromptHelperLoading","PromptHelperError","PermissionModeOnFirstSend","SendMessage"];export{P as AttachmentError,R as AttachmentMixedStatuses,H as AttachmentProcessing,j as AttachmentReady,A as CappedScroll,L as Collapsed,q as CollapsedWhileThinking,I as ConversationDocked,E as EmptyCentered,M as Expanded,f as Idle,w as Listening,x as ListeningWithoutDiarization,u as MessageQueue,_ as MessageQueueCollapsedComposer,D as MessageQueuePausedAfterError,k as MicUnavailable,Q as ModeToggle,B as Multiline,O as PastedImage,W as PermissionModeOnFirstSend,V as PromptHelperError,N as PromptHelperLoading,g as PromptHelperReady,T as ReplyStreaming,$ as RestoredDraft390,z as SendMessage,b as Speaking,S as Transcribing,C as WaitingForModel,y as WithAttachments,v as WithDraft,Br as __namedExportsOrder,Ir as default};
