import{j as d}from"./jsx-runtime-BYYWji4R.js";import{F as D}from"./FeaturePreviewSection-CJRBEHMh.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./browserId-xQxZgjMo.js";import"./clipboard-BEgkkb6H.js";const r=(e,B={})=>({id:"preview-163",projectId:"p1",taskId:"t1",agentId:"MacBook",workspacePath:"/repos/chat/163",branch:"feature/163",expectedCommitSha:"a1b2c3d4e5f6",builtCommitSha:"a1b2c3d4e5f6",currentCommitSha:"a1b2c3d4e5f6",gitStatus:"verified",state:e,staleReason:null,composeProject:"vc-preview-p1-t1",appUrl:"https://preview.example.test/app",storybookUrl:"https://preview.example.test/storybook/",storybookStatus:"ready",storybookCommitSha:"a1b2c3d4e5f6",selectedSeedScenario:"basic-user",seedVersion:"v1",dataReady:!0,healthStatus:e==="running"||e==="stale"?"healthy":"unknown",services:[],runs:[{id:"run1",environmentId:"preview-163",operation:"start",status:"succeeded",initiator:"alexey",createdAt:Date.now()-3e4,startedAt:Date.now()-3e4,finishedAt:Date.now(),agentId:"MacBook",workspacePath:"/repos/chat/163",configurationKey:"start:MacBook:/repos/chat/163:a1b2c3d4e5f6",commitSha:"a1b2c3d4e5f6",version:2,currentStepId:null,steps:[],events:[],errorType:null,errorMessage:null,exitCode:0,log:`build complete
health check passed
`,result:null}],createdBy:"alexey",createdAt:Date.now()-6e4,updatedAt:Date.now(),startedAt:Date.now(),stoppedAt:null,lastError:null,...B});function U({environment:e}){return window.featurePreview={get:async()=>e,operate:async()=>e??r("building"),cancel:async()=>!0,open:async()=>({connectionType:"direct",state:"connected",url:(e==null?void 0:e.appUrl)??null,tunnelId:null,manualCommand:null,internalUrl:(e==null?void 0:e.appUrl)??"",localAgentId:null,error:null}),closeTunnel:async()=>!0},d.jsx("div",{style:{width:420},children:d.jsx(D,{projectId:"p1",taskId:"t1"})})}const z={title:"Kanban/FeaturePreview",component:U},t={args:{environment:null}},a={args:{environment:r("building")}},n={args:{environment:r("running")}},o={args:{environment:r("stale",{currentCommitSha:"ffffffffffff",staleReason:"commit_changed"})}},s={args:{environment:r("failed",{storybookStatus:"failed",lastError:{type:"storybook",message:"Storybook build failed"}})}},c={args:{environment:r("seeding",{selectedSeedScenario:"project-with-tasks"})}},i={args:{environment:r("cleaning")}};var l,m,p;t.parameters={...t.parameters,docs:{...(l=t.parameters)==null?void 0:l.docs,source:{originalSource:`{
  args: {
    environment: null
  }
}`,...(p=(m=t.parameters)==null?void 0:m.docs)==null?void 0:p.source}}};var u,g,f;a.parameters={...a.parameters,docs:{...(u=a.parameters)==null?void 0:u.docs,source:{originalSource:`{
  args: {
    environment: makeEnvironment('building')
  }
}`,...(f=(g=a.parameters)==null?void 0:g.docs)==null?void 0:f.source}}};var S,k,y;n.parameters={...n.parameters,docs:{...(S=n.parameters)==null?void 0:S.docs,source:{originalSource:`{
  args: {
    environment: makeEnvironment('running')
  }
}`,...(y=(k=n.parameters)==null?void 0:k.docs)==null?void 0:y.source}}};var h,b,v;o.parameters={...o.parameters,docs:{...(h=o.parameters)==null?void 0:h.docs,source:{originalSource:`{
  args: {
    environment: makeEnvironment('stale', {
      currentCommitSha: 'ffffffffffff',
      staleReason: 'commit_changed'
    })
  }
}`,...(v=(b=o.parameters)==null?void 0:b.docs)==null?void 0:v.source}}};var w,E,x;s.parameters={...s.parameters,docs:{...(w=s.parameters)==null?void 0:w.docs,source:{originalSource:`{
  args: {
    environment: makeEnvironment('failed', {
      storybookStatus: 'failed',
      lastError: {
        type: 'storybook',
        message: 'Storybook build failed'
      }
    })
  }
}`,...(x=(E=s.parameters)==null?void 0:E.docs)==null?void 0:x.source}}};var C,I,j;c.parameters={...c.parameters,docs:{...(C=c.parameters)==null?void 0:C.docs,source:{originalSource:`{
  args: {
    environment: makeEnvironment('seeding', {
      selectedSeedScenario: 'project-with-tasks'
    })
  }
}`,...(j=(I=c.parameters)==null?void 0:I.docs)==null?void 0:j.source}}};var A,P,R;i.parameters={...i.parameters,docs:{...(A=i.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    environment: makeEnvironment('cleaning')
  }
}`,...(R=(P=i.parameters)==null?void 0:P.docs)==null?void 0:R.source}}};const G=["NotCreated","Building","Running","Stale","StorybookError","Seed","Cleanup"];export{a as Building,i as Cleanup,t as NotCreated,n as Running,c as Seed,o as Stale,s as StorybookError,G as __namedExportsOrder,z as default};
