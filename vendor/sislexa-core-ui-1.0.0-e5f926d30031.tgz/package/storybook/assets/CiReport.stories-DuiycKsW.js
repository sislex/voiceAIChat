import{j as g}from"./jsx-runtime-BYYWji4R.js";import{within as ne,userEvent as pe,expect as ce,fn as ie}from"./index-DeN4tkzB.js";import{C as me}from"./CiReport-O4v0dz3S.js";import{E as de}from"./ci-awuetLx1.js";import"./tools-iBbMKii-.js";import{b as r,c as e,d as u}from"./ci-C1-DRnym.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./ciFormat-wlGR6KpA.js";import"./ansi-DtpFsZ9v.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./time-CfyNS7J_.js";import"./kb-CjYTCLN0.js";const Pe={title:"CI/CiReport",component:me,args:{report:r(),onOpenRun:ie()},decorators:[t=>g.jsx("div",{style:{maxWidth:620},children:g.jsx(t,{})})]},s={},o={args:{report:r([e({totals:u({costUsd:2.07,costEstimated:!0})})])}},a={args:{report:r([e({runId:"run-2",durationMs:42e4,totals:u({requests:2,tokens:9e4,costUsd:.74})}),e({runId:"run-1",status:"failed",fixAttempts:3})])},play:async({canvasElement:t})=>{const l=ne(t);await pe.click(l.getByRole("button",{name:"Итог по задаче"})),await ce(l.getByTestId("ci-report-runs")).toBeInTheDocument()}},n={args:{report:r([e({totals:{...de},stages:[],steps:e().steps.map(t=>({...t,usage:null})),fixAttempts:0})])}},p={args:{report:r([e({totals:u({costUsd:.62,costEstimated:!0,costUnderstated:!0,inputNormalized:!0})})])}},c={args:{report:r([e({toolCalls:null,toolChars:null,toolResponses:[]})])}},i={args:{report:r([e({provider:"codex",totals:u({apiRequests:0,maxContextPerRequest:0})})])}},m={args:{report:null,error:"HTTP 500"}},d={args:{report:null,loading:!0}};var R,k,T,x,C;s.parameters={...s.parameters,docs:{...(R=s.parameters)==null?void 0:R.docs,source:{originalSource:"{}",...(T=(k=s.parameters)==null?void 0:k.docs)==null?void 0:T.source},description:{story:"Один успешный ран: плитки итогов и шаги со статусом, попыткой и временем.",...(C=(x=s.parameters)==null?void 0:x.docs)==null?void 0:C.description}}};var U,y,E,I,S;o.parameters={...o.parameters,docs:{...(U=o.parameters)==null?void 0:U.docs,source:{originalSource:`{
  args: {
    report: makeTaskReport([makeRunReport({
      totals: makeUsageTotals({
        costUsd: 2.07,
        costEstimated: true
      })
    })])
  }
}`,...(E=(y=o.parameters)==null?void 0:y.docs)==null?void 0:E.source},description:{story:"Стоимость посчитана по прайсу (CLI её не отдал) — везде «≈».",...(S=(I=o.parameters)==null?void 0:I.docs)==null?void 0:S.description}}};var f,v,_,A,P;a.parameters={...a.parameters,docs:{...(f=a.parameters)==null?void 0:f.docs,source:{originalSource:`{
  args: {
    report: makeTaskReport([makeRunReport({
      runId: 'run-2',
      durationMs: 420_000,
      totals: makeUsageTotals({
        requests: 2,
        tokens: 90_000,
        costUsd: 0.74
      })
    }), makeRunReport({
      runId: 'run-1',
      status: 'failed',
      fixAttempts: 3
    })])
  },
  play: async ({
    canvasElement
  }) => {
    const c = within(canvasElement);
    await userEvent.click(c.getByRole('button', {
      name: 'Итог по задаче'
    }));
    await expect(c.getByTestId('ci-report-runs')).toBeInTheDocument();
  }
}`,...(_=(v=a.parameters)==null?void 0:v.docs)==null?void 0:_.source},description:{story:"Несколько ранов: переключатель и итог по задаче (повторы складываются).",...(P=(A=a.parameters)==null?void 0:A.docs)==null?void 0:P.description}}};var h,q,N,L,w;n.parameters={...n.parameters,docs:{...(h=n.parameters)==null?void 0:h.docs,source:{originalSource:`{
  args: {
    report: makeTaskReport([makeRunReport({
      totals: {
        ...EMPTY_CI_USAGE_TOTALS
      },
      // Стадии считаются по строкам расхода — у такого рана их нет вовсе.
      stages: [],
      steps: makeRunReport().steps.map(s => ({
        ...s,
        usage: null
      })),
      fixAttempts: 0
    })])
  }
}`,...(N=(q=n.parameters)==null?void 0:q.docs)==null?void 0:N.source},description:{story:"Старый ран: строк расхода нет — шаги и время есть, деньги и токены прочерками.",...(w=(L=n.parameters)==null?void 0:L.docs)==null?void 0:w.description}}};var B,O,j,M,b;p.parameters={...p.parameters,docs:{...(B=p.parameters)==null?void 0:B.docs,source:{originalSource:`{
  args: {
    report: makeTaskReport([makeRunReport({
      totals: makeUsageTotals({
        costUsd: 0.62,
        costEstimated: true,
        costUnderstated: true,
        inputNormalized: true
      })
    })])
  }
}`,...(j=(O=p.parameters)==null?void 0:O.docs)==null?void 0:j.source},description:{story:`Ран через исполнителя: стоимости от CLI нет, а у части ходов неизвестна и
модель — итог помечен и оценкой, и заниженным.`,...(b=(M=p.parameters)==null?void 0:M.docs)==null?void 0:b.description}}};var z,D,F,G,H;c.parameters={...c.parameters,docs:{...(z=c.parameters)==null?void 0:z.docs,source:{originalSource:`{
  args: {
    report: makeTaskReport([makeRunReport({
      toolCalls: null,
      toolChars: null,
      toolResponses: []
    })])
  }
}`,...(F=(D=c.parameters)==null?void 0:D.docs)==null?void 0:F.source},description:{story:"Ран до появления счётчика вызовов: строки «Инструменты» нет вовсе, не «0».",...(H=(G=c.parameters)==null?void 0:G.docs)==null?void 0:H.description}}};var Y,W,J,K,Q;i.parameters={...i.parameters,docs:{...(Y=i.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  args: {
    report: makeTaskReport([makeRunReport({
      provider: 'codex',
      totals: makeUsageTotals({
        apiRequests: 0,
        maxContextPerRequest: 0
      })
    })])
  }
}`,...(J=(W=i.parameters)==null?void 0:W.docs)==null?void 0:J.source},description:{story:`Ран codex: числа запросов к API CLI не сообщает, поэтому контекст на запрос —
прочерк с объяснением, а не ноль.`,...(Q=(K=i.parameters)==null?void 0:K.docs)==null?void 0:Q.description}}};var V,X,Z,$,ee;m.parameters={...m.parameters,docs:{...(V=m.parameters)==null?void 0:V.docs,source:{originalSource:`{
  args: {
    report: null,
    error: 'HTTP 500'
  }
}`,...(Z=(X=m.parameters)==null?void 0:X.docs)==null?void 0:Z.source},description:{story:"Отчёт не прочитался: сообщение вместо чисел — карточку это не ломает.",...(ee=($=m.parameters)==null?void 0:$.docs)==null?void 0:ee.description}}};var re,te,se,oe,ae;d.parameters={...d.parameters,docs:{...(re=d.parameters)==null?void 0:re.docs,source:{originalSource:`{
  args: {
    report: null,
    loading: true
  }
}`,...(se=(te=d.parameters)==null?void 0:te.docs)==null?void 0:se.source},description:{story:"Пока грузится — короткая строка вместо пустоты.",...(ae=(oe=d.parameters)==null?void 0:oe.docs)==null?void 0:ae.description}}};const he=["OneRun","EstimatedCost","SeveralRuns","NoUsage","UnderstatedCost","NoToolCalls","NoContextPerRequest","Failed","Loading"];export{o as EstimatedCost,m as Failed,d as Loading,i as NoContextPerRequest,c as NoToolCalls,n as NoUsage,s as OneRun,a as SeveralRuns,p as UnderstatedCost,he as __namedExportsOrder,Pe as default};
