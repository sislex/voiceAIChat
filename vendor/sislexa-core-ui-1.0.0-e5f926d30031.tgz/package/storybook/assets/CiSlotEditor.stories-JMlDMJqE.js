import{j as r}from"./jsx-runtime-BYYWji4R.js";import{r as z}from"./index-ClcD9ViR.js";import{within as F,userEvent as G,expect as H}from"./index-DeN4tkzB.js";import{C as N}from"./CiSlotEditor-DglnL3dM.js";import"./tools-iBbMKii-.js";import{e as J}from"./ci-C1-DRnym.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./time-CfyNS7J_.js";import"./kb-CjYTCLN0.js";const V=J(),de={title:"CI/CiSlotEditor",component:N,args:{label:"До работы модели",commands:V,value:[],onChange:()=>{}},decorators:[e=>r.jsx("div",{style:{maxWidth:520},children:r.jsx(e,{})})]},s={},a={args:{value:["cmd-1","cmd-2","cmd-3"]}},t={args:{value:["cmd-1","cmd-3","cmd-2","cmd-3"]}},c={args:{value:["cmd-1","cmd-404"]}},o={args:{value:["cmd-1","cmd-5"],disabled:!0}};function K(){const[e,m]=z.useState(["cmd-1","cmd-2","cmd-3"]);return r.jsxs("div",{style:{maxWidth:520},children:[r.jsx(N,{label:"До работы модели",commands:V,value:e,onChange:m}),r.jsxs("p",{className:"ci-task-hint",children:["Порядок: ",e.join(" → ")]})]})}const n={render:()=>r.jsx(K,{}),play:async({canvasElement:e})=>{const m=F(e),[,,q]=m.getAllByLabelText("Выше");await G.click(q),await H(m.getByText("Порядок: cmd-1 → cmd-3 → cmd-2")).toBeInTheDocument()}};var d,i,p,l,u;s.parameters={...s.parameters,docs:{...(d=s.parameters)==null?void 0:d.docs,source:{originalSource:"{}",...(p=(i=s.parameters)==null?void 0:i.docs)==null?void 0:p.source},description:{story:"Ничего не выбрано: подсказка и селект «+ Добавить команду…».",...(u=(l=s.parameters)==null?void 0:l.docs)==null?void 0:u.description}}};var v,g,x,y,h;a.parameters={...a.parameters,docs:{...(v=a.parameters)==null?void 0:v.docs,source:{originalSource:`{
  args: {
    value: ['cmd-1', 'cmd-2', 'cmd-3']
  }
}`,...(x=(g=a.parameters)==null?void 0:g.docs)==null?void 0:x.source},description:{story:"Порядок = порядок выполнения; стрелки крайних элементов заблокированы.",...(h=(y=a.parameters)==null?void 0:y.docs)==null?void 0:h.description}}};var E,S,j,C,b;t.parameters={...t.parameters,docs:{...(E=t.parameters)==null?void 0:E.docs,source:{originalSource:`{
  args: {
    value: ['cmd-1', 'cmd-3', 'cmd-2', 'cmd-3']
  }
}`,...(j=(S=t.parameters)==null?void 0:S.docs)==null?void 0:j.source},description:{story:"Команда может повторяться: два прогона тестов вокруг сборки — это норма.",...(b=(C=t.parameters)==null?void 0:C.docs)==null?void 0:b.description}}};var f,w,B,D,T;c.parameters={...c.parameters,docs:{...(f=c.parameters)==null?void 0:f.docs,source:{originalSource:`{
  args: {
    value: ['cmd-1', 'cmd-404']
  }
}`,...(B=(w=c.parameters)==null?void 0:w.docs)==null?void 0:B.source},description:{story:"Команду удалили из справочника: слот честно говорит «— удалена —».",...(T=(D=c.parameters)==null?void 0:D.docs)==null?void 0:T.description}}};var I,k,L,O,R;o.parameters={...o.parameters,docs:{...(I=o.parameters)==null?void 0:I.docs,source:{originalSource:`{
  args: {
    value: ['cmd-1', 'cmd-5'],
    disabled: true
  }
}`,...(L=(k=o.parameters)==null?void 0:k.docs)==null?void 0:L.source},description:{story:"Только чтение (унаследованный слот): ни стрелок, ни селекта добавления.",...(R=(O=o.parameters)==null?void 0:O.docs)==null?void 0:R.description}}};var A,W,_;n.parameters={...n.parameters,docs:{...(A=n.parameters)==null?void 0:A.docs,source:{originalSource:`{
  render: () => <LiveSlot />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    // Поднимаем «test» на строку выше: порядок под списком меняется сразу.
    const [,, up] = canvas.getAllByLabelText('Выше');
    await userEvent.click(up);
    await expect(canvas.getByText('Порядок: cmd-1 → cmd-3 → cmd-2')).toBeInTheDocument();
  }
}`,...(_=(W=n.parameters)==null?void 0:W.docs)==null?void 0:_.source}}};const ie=["Empty","Ordered","Repeated","DeletedCommand","Disabled","Interactive"];export{c as DeletedCommand,o as Disabled,s as Empty,n as Interactive,a as Ordered,t as Repeated,ie as __namedExportsOrder,de as default};
