import{j as e}from"./jsx-runtime-BYYWji4R.js";import{r as m}from"./index-ClcD9ViR.js";import{s as w,P as M,S as p,M as n,a as x,b as o,c as l}from"./parts-C1UcRfGq.js";import"./_commonjsHelpers-Cpj98o6Y.js";const E=6;function y(s,t,r){const h=new Map;for(const u of w(s)){const c=u.style[t].trim();if(!c||!r(c))continue;const a=h.get(c)??{value:c,count:0,selectors:[]};a.count+=1,a.selectors.length<E&&a.selectors.push(u.selectorText),h.set(c,a)}return[...h.values()]}function W(s=document){return y(s,"fontSize",t=>t.endsWith("px")).sort((t,r)=>Number.parseFloat(r.value)-Number.parseFloat(t.value))}function H(s=document){return y(s,"fontWeight",t=>/^\d+$/.test(t)).sort((t,r)=>Number.parseFloat(r.value)-Number.parseFloat(t.value))}function A(s=document){return y(s,"fontFamily",t=>t!=="inherit").sort((t,r)=>r.count-t.count)}const k={title:"Foundations/Typography",parameters:{layout:"padded"}};function F(){const[s,t]=m.useState(null);return m.useEffect(()=>{t({sizes:W(),weights:H(),families:A(),bodyFont:getComputedStyle(document.body).fontFamily})},[]),s}const I={"24px":"крупный числовой акцент (счётчик на экране логина) — больше нигде","22px":"заголовок пустого экрана и большая цифра статистики","20px":"заголовок страницы или модального окна","18px":"подзаголовок раздела — редкий, можно свести к 16px","17px":"единичный случай — приводить к 16px","16px":"логотип, заголовок окна, крупная подпись в шапке","15px":"текст сообщения в чате — самый читаемый размер контента","14px":"заголовок блока настроек, подзаголовок карточки","13.5px":"единичный случай — приводить к 13px","13px":"основной размер интерфейса: пункты списков, поля, кнопки","12.5px":"единичный случай — приводить к 12px или 13px","12px":"плотные таблицы, вторичные подписи, содержимое консолей","11px":"лозенги, мета под заголовком, подписи иконок — минимум для текста","10px":"счётчики и индексы поверх иконок; для текста уже мелко"},L={800:"логотип и заголовок пустого экрана",750:"след прототипа — приводить к 700",700:"заголовки карточек, названия задач, акценты в строке",600:"рабочий полужирный: кнопки, лозенги, шапки таблиц",500:"редкий средний вес — обычно заменяется на 600",400:"обычный текст (сброс жирности внутри заголовков)"},g=new Set(["12.5px","13.5px","17px","750"]),d={name:"Шкала",render:()=>{const s=F();return s?e.jsxs(M,{title:"Typography",lead:e.jsxs(e.Fragment,{children:["Отдельных токенов у шрифта нет: кегль и вес стоят прямо в правилах ",e.jsx(n,{children:"styles/app.css"}),". Таблицы ниже собраны обходом подключённых стилей — счётчик показывает, насколько размер прижился, а помеченные «привести к шкале» значения стоит вычистить, а не размножать."]}),children:[e.jsxs(p,{title:"Семейства",hint:e.jsxs(e.Fragment,{children:["Интерфейсный шрифт приходит из ",e.jsx(n,{children:"global.css"})," (",e.jsx(n,{children:"body"}),"), моно — из правил кода и консолей."]}),children:[e.jsxs("p",{style:{margin:0,fontSize:13},children:[e.jsx(n,{children:"body"})," → ",e.jsx(n,{children:s.bodyFont})]}),e.jsxs("table",{style:x,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:o,scope:"col",children:"семейство"}),e.jsx("th",{style:o,scope:"col",children:"правил"}),e.jsx("th",{style:o,scope:"col",children:"образец"})]})}),e.jsx("tbody",{children:s.families.map(t=>e.jsxs("tr",{children:[e.jsx("th",{style:{...l,textAlign:"left",fontWeight:400},scope:"row",children:e.jsx(n,{children:t.value})}),e.jsx("td",{style:l,children:t.count}),e.jsx("td",{style:{...l,fontFamily:t.value,fontSize:13},children:"Голос чата — 0123456789"})]},t.value))})]})]}),e.jsx(p,{title:`Кегли (${s.sizes.length})`,children:e.jsxs("table",{style:x,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:o,scope:"col",children:"размер"}),e.jsx("th",{style:o,scope:"col",children:"образец"}),e.jsx("th",{style:o,scope:"col",children:"правил"}),e.jsx("th",{style:o,scope:"col",children:"для чего"}),e.jsx("th",{style:o,scope:"col",children:"примеры селекторов"})]})}),e.jsx("tbody",{children:s.sizes.map(t=>e.jsxs("tr",{children:[e.jsxs("th",{style:{...l,textAlign:"left",fontWeight:400,whiteSpace:"nowrap"},scope:"row",children:[e.jsx(n,{children:t.value}),g.has(t.value)&&e.jsx("span",{className:"ci-lozenge ci-lozenge--progress",style:{marginLeft:6},children:"привести к шкале"})]}),e.jsx("td",{style:{...l,fontSize:t.value},children:"Живой пример текста"}),e.jsx("td",{style:l,children:t.count}),e.jsx("td",{style:{...l,color:"var(--text-dim)"},children:I[t.value]??"нет рекомендации — проверь, нужен ли размер"}),e.jsx("td",{style:{...l,color:"var(--text-dim)"},children:e.jsx(n,{children:t.selectors.join(", ")})})]},t.value))})]})}),e.jsx(p,{title:`Веса (${s.weights.length})`,children:e.jsxs("table",{style:x,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:o,scope:"col",children:"вес"}),e.jsx("th",{style:o,scope:"col",children:"образец"}),e.jsx("th",{style:o,scope:"col",children:"правил"}),e.jsx("th",{style:o,scope:"col",children:"для чего"}),e.jsx("th",{style:o,scope:"col",children:"примеры селекторов"})]})}),e.jsx("tbody",{children:s.weights.map(t=>e.jsxs("tr",{children:[e.jsxs("th",{style:{...l,textAlign:"left",fontWeight:400,whiteSpace:"nowrap"},scope:"row",children:[e.jsx(n,{children:t.value}),g.has(t.value)&&e.jsx("span",{className:"ci-lozenge ci-lozenge--progress",style:{marginLeft:6},children:"привести к шкале"})]}),e.jsx("td",{style:{...l,fontWeight:Number(t.value),fontSize:15},children:"Голос чата"}),e.jsx("td",{style:l,children:t.count}),e.jsx("td",{style:{...l,color:"var(--text-dim)"},children:L[t.value]??"нет рекомендации — проверь, нужен ли вес"}),e.jsx("td",{style:{...l,color:"var(--text-dim)"},children:e.jsx(n,{children:t.selectors.join(", ")})})]},t.value))})]})})]}):e.jsx("p",{style:{fontSize:13,color:"var(--text-dim)"},children:"Читаем правила из app.css…"})}},i={name:"В деле",render:()=>e.jsx(M,{title:"Typography — иерархия",lead:"Три уровня подряд: заголовок 20px/800, содержимое 15px/400, мета 11px/600 приглушённым цветом.",children:e.jsx(p,{title:"Экран",children:e.jsxs("div",{style:{background:"var(--surface)",border:"1px solid var(--border)",borderRadius:"var(--radius-medium)",padding:"var(--space-150)",display:"grid",gap:"var(--space-100)",maxWidth:520},children:[e.jsx("h4",{style:{margin:0,fontSize:20,fontWeight:800,letterSpacing:"-0.2px"},children:"Заголовок окна"}),e.jsx("p",{style:{margin:0,fontSize:15},children:"Текст сообщения набирается 15px — это единственное место, где размер выбран под чтение, а не под плотность."}),e.jsx("p",{style:{margin:0,fontSize:13},children:"Интерфейсный размер 13px: пункты списков, подписи полей, кнопки."}),e.jsx("span",{style:{fontSize:11,fontWeight:600,textTransform:"uppercase",letterSpacing:"0.4px",color:"var(--text-dim)"},children:"мета · 11px · 600"})]})})})};var f,j,v;d.parameters={...d.parameters,docs:{...(f=d.parameters)==null?void 0:f.docs,source:{originalSource:`{
  name: 'Шкала',
  render: () => {
    const scan = useScan();
    if (!scan) return <p style={{
      fontSize: 13,
      color: 'var(--text-dim)'
    }}>Читаем правила из app.css…</p>;
    return <Page title="Typography" lead={<>
            Отдельных токенов у шрифта нет: кегль и вес стоят прямо в правилах <Mono>styles/app.css</Mono>. Таблицы ниже собраны
            обходом подключённых стилей — счётчик показывает, насколько размер прижился, а помеченные «привести к шкале» значения
            стоит вычистить, а не размножать.
          </>}>
        <Section title="Семейства" hint={<>Интерфейсный шрифт приходит из <Mono>global.css</Mono> (<Mono>body</Mono>), моно — из правил кода и консолей.</>}>
          <p style={{
          margin: 0,
          fontSize: 13
        }}>
            <Mono>body</Mono> → <Mono>{scan.bodyFont}</Mono>
          </p>
          <table style={TABLE}>
            <thead>
              <tr>
                <th style={TH} scope="col">
                  семейство
                </th>
                <th style={TH} scope="col">
                  правил
                </th>
                <th style={TH} scope="col">
                  образец
                </th>
              </tr>
            </thead>
            <tbody>
              {scan.families.map(family => <tr key={family.value}>
                  <th style={{
                ...TD,
                textAlign: 'left',
                fontWeight: 400
              }} scope="row">
                    <Mono>{family.value}</Mono>
                  </th>
                  <td style={TD}>{family.count}</td>
                  <td style={{
                ...TD,
                fontFamily: family.value,
                fontSize: 13
              }}>Голос чата — 0123456789</td>
                </tr>)}
            </tbody>
          </table>
        </Section>

        <Section title={\`Кегли (\${scan.sizes.length})\`}>
          <table style={TABLE}>
            <thead>
              <tr>
                <th style={TH} scope="col">
                  размер
                </th>
                <th style={TH} scope="col">
                  образец
                </th>
                <th style={TH} scope="col">
                  правил
                </th>
                <th style={TH} scope="col">
                  для чего
                </th>
                <th style={TH} scope="col">
                  примеры селекторов
                </th>
              </tr>
            </thead>
            <tbody>
              {scan.sizes.map(size => <tr key={size.value}>
                  <th style={{
                ...TD,
                textAlign: 'left',
                fontWeight: 400,
                whiteSpace: 'nowrap'
              }} scope="row">
                    <Mono>{size.value}</Mono>
                    {ODD.has(size.value) && <span className="ci-lozenge ci-lozenge--progress" style={{
                  marginLeft: 6
                }}>привести к шкале</span>}
                  </th>
                  <td style={{
                ...TD,
                fontSize: size.value
              }}>Живой пример текста</td>
                  <td style={TD}>{size.count}</td>
                  <td style={{
                ...TD,
                color: 'var(--text-dim)'
              }}>{SIZE_ADVICE[size.value] ?? 'нет рекомендации — проверь, нужен ли размер'}</td>
                  <td style={{
                ...TD,
                color: 'var(--text-dim)'
              }}>
                    <Mono>{size.selectors.join(', ')}</Mono>
                  </td>
                </tr>)}
            </tbody>
          </table>
        </Section>

        <Section title={\`Веса (\${scan.weights.length})\`}>
          <table style={TABLE}>
            <thead>
              <tr>
                <th style={TH} scope="col">
                  вес
                </th>
                <th style={TH} scope="col">
                  образец
                </th>
                <th style={TH} scope="col">
                  правил
                </th>
                <th style={TH} scope="col">
                  для чего
                </th>
                <th style={TH} scope="col">
                  примеры селекторов
                </th>
              </tr>
            </thead>
            <tbody>
              {scan.weights.map(weight => <tr key={weight.value}>
                  <th style={{
                ...TD,
                textAlign: 'left',
                fontWeight: 400,
                whiteSpace: 'nowrap'
              }} scope="row">
                    <Mono>{weight.value}</Mono>
                    {ODD.has(weight.value) && <span className="ci-lozenge ci-lozenge--progress" style={{
                  marginLeft: 6
                }}>привести к шкале</span>}
                  </th>
                  <td style={{
                ...TD,
                fontWeight: Number(weight.value),
                fontSize: 15
              }}>Голос чата</td>
                  <td style={TD}>{weight.count}</td>
                  <td style={{
                ...TD,
                color: 'var(--text-dim)'
              }}>{WEIGHT_ADVICE[weight.value] ?? 'нет рекомендации — проверь, нужен ли вес'}</td>
                  <td style={{
                ...TD,
                color: 'var(--text-dim)'
              }}>
                    <Mono>{weight.selectors.join(', ')}</Mono>
                  </td>
                </tr>)}
            </tbody>
          </table>
        </Section>
      </Page>;
  }
}`,...(v=(j=d.parameters)==null?void 0:j.docs)==null?void 0:v.source}}};var S,b,T,z,D;i.parameters={...i.parameters,docs:{...(S=i.parameters)==null?void 0:S.docs,source:{originalSource:`{
  name: 'В деле',
  render: () => <Page title="Typography — иерархия" lead="Три уровня подряд: заголовок 20px/800, содержимое 15px/400, мета 11px/600 приглушённым цветом.">
      <Section title="Экран">
        <div style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-medium)',
        padding: 'var(--space-150)',
        display: 'grid',
        gap: 'var(--space-100)',
        maxWidth: 520
      }}>
          <h4 style={{
          margin: 0,
          fontSize: 20,
          fontWeight: 800,
          letterSpacing: '-0.2px'
        }}>Заголовок окна</h4>
          <p style={{
          margin: 0,
          fontSize: 15
        }}>
            Текст сообщения набирается 15px — это единственное место, где размер выбран под чтение, а не под плотность.
          </p>
          <p style={{
          margin: 0,
          fontSize: 13
        }}>Интерфейсный размер 13px: пункты списков, подписи полей, кнопки.</p>
          <span style={{
          fontSize: 11,
          fontWeight: 600,
          textTransform: 'uppercase',
          letterSpacing: '0.4px',
          color: 'var(--text-dim)'
        }}>
            мета · 11px · 600
          </span>
        </div>
      </Section>
    </Page>
}`,...(T=(b=i.parameters)==null?void 0:b.docs)==null?void 0:T.source},description:{story:"Как размеры складываются в реальный блок: заголовок → текст → мета.",...(D=(z=i.parameters)==null?void 0:z.docs)==null?void 0:D.description}}};const O=["Scale","InUse"];export{i as InUse,d as Scale,O as __namedExportsOrder,k as default};
