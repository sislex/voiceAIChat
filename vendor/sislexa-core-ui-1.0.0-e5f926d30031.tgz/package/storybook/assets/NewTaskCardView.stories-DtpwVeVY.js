import{j as t}from"./jsx-runtime-BYYWji4R.js";import{r as f}from"./index-ClcD9ViR.js";import{S as pe,a as le,b as ue}from"./NewTaskStages-DKk_2SXR.js";import{fn as e}from"./index-DeN4tkzB.js";import{N as ne}from"./NewTaskCardView-CEPGBvKB.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./index-Brl4xq4Y.js";import"./Toast-CcZfB6x2.js";import"./Badge-zWzzcJYU.js";import"./dateFormat-B8QlAdwY.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./autoGrow-CoBFBF9S.js";import"./mediaQuery-CCkbYk-e.js";import"./ciFormat-wlGR6KpA.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./ansi-DtpFsZ9v.js";const a={taskId:"task-19",taskKey:"CHAT-408",projectName:"Голос Чат",title:"Новая карточка задачи по Make «Проект 19»",stage:{semanticType:"component_qa",label:"Component QA",fallback:!1},priority:"Высокий",assignee:"alexey",labels:["frontend","workflow"],description:"Карточка отображает задачу, раны, файлы и историю циклов.",acceptanceCriteria:"1. Новая и старая версии доступны без потери контекста.",source:{description:"Реализовать новую карточку по живому Make-проекту.",acceptanceCriteria:"1. Соответствует макету.",attachments:[{id:"brief",name:"brief.pdf",mimeType:"application/pdf",status:"ready"}]},workflow:[{id:"preparation",semanticType:"preparation",label:"Подготовка",state:"passed"},{id:"development",semanticType:"development",label:"Разработка",state:"passed",startedAt:Date.UTC(2026,8,4),finishedAt:Date.UTC(2026,8,4,0,12),durationMs:72e4},{id:"component_qa",semanticType:"component_qa",label:"Component QA",state:"current"},{id:"integration_tests",semanticType:"integration_tests",label:"Интеграционные тесты",state:"upcoming"}],runs:[{id:"run-19",title:"Development",status:"success",outcome:"success",createdAt:Date.UTC(2026,8,4),finishedAt:Date.UTC(2026,8,4,0,12),canOpen:!0,canCancel:!1,canAnswer:!1}],makeSources:[{id:"make",title:"Проект 19",conversationId:"e7b501e7-a0b5-4c00-bb20-e8743e25011f",mode:"files",paths:[{path:"src/App.jsx",available:!0},{path:"src/removed.jsx",available:!1,error:"Файл удалён"}]}],cycles:[],drafts:[],loadState:"ready",cycleNumber:1,nextCycleNumber:2,branch:null,commit:null,tabs:[{id:"overview",label:"Общее"},{id:"reworks",label:"Доработки"}],actions:{canRework:!0,hasActiveRun:!1,canStopRun:!1,safeActiveRunActions:[]}},Ue={title:"Kanban/NewTaskCard",component:ne,parameters:{componentQa:{componentId:"new-task-card-view",primaryStoryId:"kanban-newtaskcard--desktop"}},args:{model:a,activeTab:"overview",version:"new",reworkOpen:!1,reworkDraft:{description:"",criteria:[],makeMode:"whole_project",makePaths:[],attachments:[]},onVersionChange:e(),callbacks:{onClose:e(),onChangeTab:e(),onOpenRun:e(),onOpenMake:e(),onStartRework:e(),onChangeReworkDraft:e(),onAddReworkFiles:e(),onRemoveReworkFile:e(),onRetryReworkFile:e(),onRetryHistory:e(),onSubmitRework:e(),onCancelRework:e()}}};function oe(r){const[k,se]=f.useState(r.model),[ce,ie]=f.useState(r.activeTab);return t.jsx(ne,{...r,model:k,activeTab:ce,callbacks:{...r.callbacks,onChangeTab:ie,onUpdate:async me=>{se(de=>({...de,...me}))}}})}function be(){const[r,k]=f.useState(!0);return t.jsxs(t.Fragment,{children:[t.jsx(pe,{eyebrow:"Component QA",title:"Проверка компонентов"}),t.jsx(le,{children:t.jsx(ue,{number:1,status:r?"failed":"queued",eyebrow:"Этап 1",title:"Проверка компонентов",error:`Не удалось открыть страницу
Подробности в ленте`,onRetry:()=>k(!1),children:t.jsx("p",{children:"Результат последнего рана этого этапа."})})})]})}const o={name:"Редактирование постановки",render:r=>t.jsx(oe,{...r})},n={name:"Этап с ошибкой",args:{activeTab:"component_qa",model:{...a,tabs:[...a.tabs,{id:"component_qa",label:"Component QA"}]},renderPanel:()=>t.jsx(be,{})}},s={name:"Мобильная рейка",parameters:{viewport:{defaultViewport:"chat449mobile",viewports:{chat449mobile:{name:"390px",styles:{width:"390px",height:"844px"}}}}},args:{...n.args,model:{...a,title:"Очень длинное название задачи ".repeat(8),tabs:[...a.tabs,{id:"component_qa",label:"Component QA"}]}},render:r=>t.jsx(oe,{...r})},c={},i={parameters:{viewport:{defaultViewport:"tablet"}}},m={parameters:{viewport:{defaultViewport:"mobile1"}}},d={globals:{theme:"dark"}},p={args:{model:{...a,loadState:"loading"}}},l={args:{model:{...a,loadState:"empty"}}},u={args:{model:{...a,loadState:"error",error:"Сеть недоступна"}}},b={args:{model:{...a,runs:[{...a.runs[0],status:"waiting_for_answer",outcome:"active",canAnswer:!0}]},activeTab:"overview"}},w={args:{reworkOpen:!0,reworkDraft:{description:"Уточнить мобильное поведение",criteria:["Нет горизонтального скролла"],makeMode:"files",makePaths:["src/App.jsx"],attachments:[]}}},g={args:{activeTab:"reworks",model:{...a,tabs:[{id:"overview",label:"Общее"},{id:"reworks",label:"Доработки",count:1}],drafts:[{id:"draft-1",sequence:2,description:"Компактный статус синхронизации",criteria:["Статус рядом с сообщением"],makeSources:[],attachments:[],createdBy:"alex",createdAt:Date.UTC(2026,8,7,12),preparationRunId:null,status:"draft"}],cycles:[{id:"cycle-1",sequence:1,description:"Первый вариант индикатора записи",criteria:["Индикатор виден"],makeSources:[],attachments:[],createdBy:"alex",createdAt:Date.UTC(2026,8,1,12),preparationRunId:null,status:"submitted",merged:!0}]}}};var v,h,S;o.parameters={...o.parameters,docs:{...(v=o.parameters)==null?void 0:v.docs,source:{originalSource:`{
  name: 'Редактирование постановки',
  render: args => <InteractiveCard {...args} />
}`,...(S=(h=o.parameters)==null?void 0:h.docs)==null?void 0:S.source}}};var y,C,T;n.parameters={...n.parameters,docs:{...(y=n.parameters)==null?void 0:y.docs,source:{originalSource:`{
  name: 'Этап с ошибкой',
  args: {
    activeTab: 'component_qa',
    model: {
      ...model,
      tabs: [...model.tabs, {
        id: 'component_qa',
        label: 'Component QA'
      }]
    },
    renderPanel: () => <ErrorRail />
  }
}`,...(T=(C=n.parameters)==null?void 0:C.docs)==null?void 0:T.source}}};var x,R,A;s.parameters={...s.parameters,docs:{...(x=s.parameters)==null?void 0:x.docs,source:{originalSource:`{
  name: 'Мобильная рейка',
  parameters: {
    viewport: {
      defaultViewport: 'chat449mobile',
      viewports: {
        chat449mobile: {
          name: '390px',
          styles: {
            width: '390px',
            height: '844px'
          }
        }
      }
    }
  },
  args: {
    ...StageWithError.args,
    model: {
      ...model,
      title: 'Очень длинное название задачи '.repeat(8),
      tabs: [...model.tabs, {
        id: 'component_qa',
        label: 'Component QA'
      }]
    }
  },
  render: args => <InteractiveCard {...args} />
}`,...(A=(R=s.parameters)==null?void 0:R.docs)==null?void 0:A.source}}};var _,j,D;c.parameters={...c.parameters,docs:{...(_=c.parameters)==null?void 0:_.docs,source:{originalSource:"{}",...(D=(j=c.parameters)==null?void 0:j.docs)==null?void 0:D.source}}};var q,E,I;i.parameters={...i.parameters,docs:{...(q=i.parameters)==null?void 0:q.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'tablet'
    }
  }
}`,...(I=(E=i.parameters)==null?void 0:E.docs)==null?void 0:I.source}}};var M,U,Q;m.parameters={...m.parameters,docs:{...(M=m.parameters)==null?void 0:M.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(Q=(U=m.parameters)==null?void 0:U.docs)==null?void 0:Q.source}}};var V,F,O;d.parameters={...d.parameters,docs:{...(V=d.parameters)==null?void 0:V.docs,source:{originalSource:`{
  globals: {
    theme: 'dark'
  }
}`,...(O=(F=d.parameters)==null?void 0:F.docs)==null?void 0:O.source}}};var N,P,W;p.parameters={...p.parameters,docs:{...(N=p.parameters)==null?void 0:N.docs,source:{originalSource:`{
  args: {
    model: {
      ...model,
      loadState: 'loading'
    }
  }
}`,...(W=(P=p.parameters)==null?void 0:P.docs)==null?void 0:W.source}}};var B,H,K;l.parameters={...l.parameters,docs:{...(B=l.parameters)==null?void 0:B.docs,source:{originalSource:`{
  args: {
    model: {
      ...model,
      loadState: 'empty'
    }
  }
}`,...(K=(H=l.parameters)==null?void 0:H.docs)==null?void 0:K.source}}};var L,z,G;u.parameters={...u.parameters,docs:{...(L=u.parameters)==null?void 0:L.docs,source:{originalSource:`{
  args: {
    model: {
      ...model,
      loadState: 'error',
      error: 'Сеть недоступна'
    }
  }
}`,...(G=(z=u.parameters)==null?void 0:z.docs)==null?void 0:G.source}}};var J,X,Y;b.parameters={...b.parameters,docs:{...(J=b.parameters)==null?void 0:J.docs,source:{originalSource:`{
  args: {
    model: {
      ...model,
      runs: [{
        ...model.runs[0]!,
        status: 'waiting_for_answer',
        outcome: 'active',
        canAnswer: true
      }]
    },
    activeTab: 'overview'
  }
}`,...(Y=(X=b.parameters)==null?void 0:X.docs)==null?void 0:Y.source}}};var Z,$,ee;w.parameters={...w.parameters,docs:{...(Z=w.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    reworkOpen: true,
    reworkDraft: {
      description: 'Уточнить мобильное поведение',
      criteria: ['Нет горизонтального скролла'],
      makeMode: 'files',
      makePaths: ['src/App.jsx'],
      attachments: []
    }
  }
}`,...(ee=($=w.parameters)==null?void 0:$.docs)==null?void 0:ee.source}}};var ae,re,te;g.parameters={...g.parameters,docs:{...(ae=g.parameters)==null?void 0:ae.docs,source:{originalSource:`{
  args: {
    activeTab: 'reworks',
    model: {
      ...model,
      tabs: [{
        id: 'overview',
        label: 'Общее'
      }, {
        id: 'reworks',
        label: 'Доработки',
        count: 1
      }],
      drafts: [{
        id: 'draft-1',
        sequence: 2,
        description: 'Компактный статус синхронизации',
        criteria: ['Статус рядом с сообщением'],
        makeSources: [],
        attachments: [],
        createdBy: 'alex',
        createdAt: Date.UTC(2026, 8, 7, 12),
        preparationRunId: null,
        status: 'draft'
      }],
      cycles: [{
        id: 'cycle-1',
        sequence: 1,
        description: 'Первый вариант индикатора записи',
        criteria: ['Индикатор виден'],
        makeSources: [],
        attachments: [],
        createdBy: 'alex',
        createdAt: Date.UTC(2026, 8, 1, 12),
        preparationRunId: null,
        status: 'submitted',
        merged: true
      }]
    }
  }
}`,...(te=(re=g.parameters)==null?void 0:re.docs)==null?void 0:te.source}}};const Qe=["StatementEditing","StageWithError","MobileRail","Desktop","Tablet","Mobile","Dark","Loading","Empty","Error","WaitingForAnswer","Rework","Reworks"];export{d as Dark,c as Desktop,l as Empty,u as Error,p as Loading,m as Mobile,s as MobileRail,w as Rework,g as Reworks,n as StageWithError,o as StatementEditing,i as Tablet,b as WaitingForAnswer,Qe as __namedExportsOrder,Ue as default};
