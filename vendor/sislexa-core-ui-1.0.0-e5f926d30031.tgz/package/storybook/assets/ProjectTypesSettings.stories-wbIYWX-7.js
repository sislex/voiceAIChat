import{P as ye}from"./ProjectTypesSettings-BHCMjwRH.js";import{B as be}from"./projectTypes-C-9aONcK.js";import"./jsx-runtime-BYYWji4R.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./loadState-C9E-sPL9.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";const e=be.map(l=>({...l,builtin:!0,ownerId:null,status:"published",reviewNote:"",createdBy:"system",createdAt:0,updatedAt:0,usageCount:l.id==="type-software"?3:0})),r=(l={})=>({id:"own1",parentId:"type-software",name:"Бэкенд-сервис",description:"Из проекта «API»",features:{preview:!1},defaults:{},builtin:!1,ownerId:"bob",status:"private",reviewNote:"",createdBy:"bob",createdAt:0,updatedAt:0,usageCount:0,...l}),Ve={title:"Projects/ProjectTypesSettings",component:ye,args:{types:[...e,r()],currentUsername:"bob",onCreate:()=>{},onDelete:()=>{},onPublish:()=>{},onUnpublish:()=>{}}},s={},t={args:{types:[...e,r({status:"pending"})]}},o={args:{types:[...e,r({status:"rejected",reviewNote:"Дублирует «Веб-приложение»"})]}},a={args:{types:[...e,r({status:"published",usageCount:4})]}},n={args:{types:[...e,r({ownerId:"carol",status:"published"})]}},i={args:{types:[]}},p={parameters:{viewport:{defaultViewport:"mobile2"}}},c={args:{types:[...e,r({status:"pending"})]},parameters:{viewport:{defaultViewport:"mobile2"}}},d={args:{types:[],status:"loading"}},u={args:{types:[],status:"error",error:"Сеть недоступна",onRetry:()=>{}}},m={args:{status:"error",error:"Сеть недоступна",onRetry:()=>{}}};var g,y,b,w,S;s.parameters={...s.parameters,docs:{...(g=s.parameters)==null?void 0:g.docs,source:{originalSource:"{}",...(b=(y=s.parameters)==null?void 0:y.docs)==null?void 0:b.source},description:{story:"Обычный вид: встроенное дерево плюс личный подтип автора.",...(S=(w=s.parameters)==null?void 0:w.docs)==null?void 0:S.description}}};var f,P,v,I,h;t.parameters={...t.parameters,docs:{...(f=t.parameters)==null?void 0:f.docs,source:{originalSource:`{
  args: {
    types: [...builtin, own({
      status: 'pending'
    })]
  }
}`,...(v=(P=t.parameters)==null?void 0:P.docs)==null?void 0:v.source},description:{story:"Отправлен на утверждение: править нельзя, отзывать нечего.",...(h=(I=t.parameters)==null?void 0:I.docs)==null?void 0:h.description}}};var E,j,R,C,V;o.parameters={...o.parameters,docs:{...(E=o.parameters)==null?void 0:E.docs,source:{originalSource:`{
  args: {
    types: [...builtin, own({
      status: 'rejected',
      reviewNote: 'Дублирует «Веб-приложение»'
    })]
  }
}`,...(R=(j=o.parameters)==null?void 0:j.docs)==null?void 0:R.source},description:{story:"Отклонён: автор видит причину и может исправить.",...(V=(C=o.parameters)==null?void 0:C.docs)==null?void 0:V.description}}};var A,L,N,T,U;a.parameters={...a.parameters,docs:{...(A=a.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    types: [...builtin, own({
      status: 'published',
      usageCount: 4
    })]
  }
}`,...(N=(L=a.parameters)==null?void 0:L.docs)==null?void 0:N.source},description:{story:"Опубликован и уже используется: удаление заблокировано с объяснением.",...(U=(T=a.parameters)==null?void 0:T.docs)==null?void 0:U.description}}};var B,M,O,_,D;n.parameters={...n.parameters,docs:{...(B=n.parameters)==null?void 0:B.docs,source:{originalSource:`{
  args: {
    types: [...builtin, own({
      ownerId: 'carol',
      status: 'published'
    })]
  }
}`,...(O=(M=n.parameters)==null?void 0:M.docs)==null?void 0:O.source},description:{story:"Чужие узлы — без кнопок управления.",...(D=(_=n.parameters)==null?void 0:_.docs)==null?void 0:D.description}}};var x,F,J,Y,k;i.parameters={...i.parameters,docs:{...(x=i.parameters)==null?void 0:x.docs,source:{originalSource:`{
  args: {
    types: []
  }
}`,...(J=(F=i.parameters)==null?void 0:F.docs)==null?void 0:J.source},description:{story:"Пусто: каталог без единого узла объясняет следующий шаг.",...(k=(Y=i.parameters)==null?void 0:Y.docs)==null?void 0:k.description}}};var q,z,G,H,K;p.parameters={...p.parameters,docs:{...(q=p.parameters)==null?void 0:q.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile2'
    }
  }
}`,...(G=(z=p.parameters)==null?void 0:z.docs)==null?void 0:G.source},description:{story:"Телефон: дерево, чипы и форма создания в одну колонку.",...(K=(H=p.parameters)==null?void 0:H.docs)==null?void 0:K.description}}};var Q,W,X,Z,$;c.parameters={...c.parameters,docs:{...(Q=c.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  args: {
    types: [...builtin, own({
      status: 'pending'
    })]
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile2'
    }
  }
}`,...(X=(W=c.parameters)==null?void 0:W.docs)==null?void 0:X.source},description:{story:`Телефон + узел «на утверждении»: у него нет основного действия, и в строке
остаётся один крестик. Раньше он растягивался во всю ширину и глиф вставал по
центру пустой полосы — сочетание, которого не было ни в одной сториз.`,...($=(Z=c.parameters)==null?void 0:Z.docs)==null?void 0:$.description}}};var ee,re,se,te,oe;d.parameters={...d.parameters,docs:{...(ee=d.parameters)==null?void 0:ee.docs,source:{originalSource:`{
  args: {
    types: [],
    status: 'loading'
  }
}`,...(se=(re=d.parameters)==null?void 0:re.docs)==null?void 0:se.source},description:{story:"Первая загрузка: скелетоны вместо мигающей пустоты.",...(oe=(te=d.parameters)==null?void 0:te.docs)==null?void 0:oe.description}}};var ae,ne,ie,pe,ce;u.parameters={...u.parameters,docs:{...(ae=u.parameters)==null?void 0:ae.docs,source:{originalSource:`{
  args: {
    types: [],
    status: 'error',
    error: 'Сеть недоступна',
    onRetry: () => {}
  }
}`,...(ie=(ne=u.parameters)==null?void 0:ne.docs)==null?void 0:ie.source},description:{story:"Сбой чтения: экран объясняет причину и даёт «Повторить».",...(ce=(pe=u.parameters)==null?void 0:pe.docs)==null?void 0:ce.description}}};var de,ue,me,le,ge;m.parameters={...m.parameters,docs:{...(de=m.parameters)==null?void 0:de.docs,source:{originalSource:`{
  args: {
    status: 'error',
    error: 'Сеть недоступна',
    onRetry: () => {}
  }
}`,...(me=(ue=m.parameters)==null?void 0:ue.docs)==null?void 0:me.source},description:{story:"Сбой при уже показанном дереве: баннер над данными, а не вместо них.",...(ge=(le=m.parameters)==null?void 0:le.docs)==null?void 0:ge.description}}};const Ae=["Default","Pending","Rejected","PublishedInUse","ForeignOnly","Empty","MobileViewport","MobilePending","Loading","LoadError","StaleError"];export{s as Default,i as Empty,n as ForeignOnly,u as LoadError,d as Loading,c as MobilePending,p as MobileViewport,t as Pending,a as PublishedInUse,o as Rejected,m as StaleError,Ae as __namedExportsOrder,Ve as default};
