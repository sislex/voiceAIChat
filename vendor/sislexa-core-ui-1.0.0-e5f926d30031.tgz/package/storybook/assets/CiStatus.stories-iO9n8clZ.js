import{j as e}from"./jsx-runtime-BYYWji4R.js";import{r as y}from"./index-ClcD9ViR.js";import{m as p}from"./ci-awuetLx1.js";import{c as m,a as D,g as H}from"./ciFormat-wlGR6KpA.js";import{P as C,T as _,M as s,S as L,a as N,b as r,c as l,r as O,d as w,D as F,V as U,e as W}from"./parts-C1UcRfGq.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./types-CmoD7ERW.js";import"./ansi-DtpFsZ9v.js";const Q={title:"Foundations/CI Status",parameters:{layout:"padded"}},x=["light","dark"];function P(t){return{fg:`--ci-${t}`,bg:`--ci-${t}-bg`}}const u={neutral:"ничего не происходит: ран ждёт слот или шаг пропущен",progress:"ран занят: идёт шаг или модель ждёт ответа человека",success:"ран закончился успехом",removed:"ран закончился неудачей: ошибка, таймаут или отмена"};function z({status:t}){return e.jsxs("span",{className:`ci-lozenge ci-lozenge--${m(t)}`,children:[e.jsx("span",{"aria-hidden":"true",children:H(t)}),D(t)]})}const c={name:"Бейджи",render:()=>e.jsxs(C,{title:"CI Status",lead:e.jsxs(e.Fragment,{children:["Лозенг рисуется классом ",e.jsx(s,{children:".ci-lozenge--<тон>"}),", тон статусу выдаёт ",e.jsx(s,{children:"ciTone()"}),". Своих цветов у статуса нет — только четыре пары токенов ",e.jsx(s,{children:"--ci-*"})," / ",e.jsx(s,{children:"--ci-*-bg"}),"."]}),children:[e.jsx("div",{style:{display:"grid",gap:"var(--space-150)"},children:x.map(t=>e.jsx(_,{theme:t,children:e.jsx("div",{style:{display:"flex",gap:"var(--space-150)",flexWrap:"wrap",alignItems:"center"},children:p.map(n=>e.jsxs("span",{style:{display:"grid",gap:4,justifyItems:"start"},children:[e.jsx(z,{status:n}),e.jsx(s,{children:n})]},n))})},t))}),e.jsx(L,{title:"Тон и его смысл",children:e.jsxs("table",{style:N,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:r,scope:"col",children:"тон"}),e.jsx("th",{style:r,scope:"col",children:"токены"}),e.jsx("th",{style:r,scope:"col",children:"статусы"}),e.jsx("th",{style:r,scope:"col",children:"когда"})]})}),e.jsx("tbody",{children:Object.keys(u).map(t=>{const n=P(t);return e.jsxs("tr",{children:[e.jsx("th",{style:{...l,textAlign:"left",fontWeight:400},scope:"row",children:e.jsx("span",{className:`ci-lozenge ci-lozenge--${t}`,children:t})}),e.jsx("td",{style:l,children:e.jsxs(s,{children:[n.fg," / ",n.bg]})}),e.jsx("td",{style:l,children:e.jsx(s,{children:p.filter(o=>m(o)===t).join(", ")||"—"})}),e.jsx("td",{style:{...l,color:"var(--text-dim)"},children:u[t]})]},t)})})]})})]})},i={name:"Источник правды",render:()=>{const[t,n]=y.useState(null);return y.useEffect(()=>{n(O())},[]),e.jsx(C,{title:"CI Status — источник правды",lead:e.jsxs(e.Fragment,{children:["Таблица целиком вычислена: статусы — ",e.jsx(s,{children:"CI_STATUSES"})," из ",e.jsx(s,{children:"@voicechat/shared/ci"}),", подпись и глиф —"," ",e.jsx(s,{children:"ciStatusLabel()"})," и ",e.jsx(s,{children:"ciStatusIcon()"}),", тон — ",e.jsx(s,{children:"ciTone()"})," из"," ",e.jsx(s,{children:"components/ci/ciFormat.ts"}),". Контраст лозенга считается по вычисленным токенам: подпись в нём 11px, значит нужен полный AA 4.5:1."]}),children:e.jsxs("table",{style:N,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:r,scope:"col",children:"статус"}),e.jsx("th",{style:r,scope:"col",children:"подпись"}),e.jsx("th",{style:r,scope:"col",children:"глиф"}),e.jsx("th",{style:r,scope:"col",children:"тон"}),x.map(o=>e.jsx("th",{style:r,scope:"col",children:o==="light"?"светлая":"тёмная"},o))]})}),e.jsx("tbody",{children:p.map(o=>{const a=m(o),d=P(a);return e.jsxs("tr",{children:[e.jsx("th",{style:{...l,textAlign:"left",fontWeight:400},scope:"row",children:e.jsx(s,{children:o})}),e.jsx("td",{style:l,children:D(o)}),e.jsx("td",{style:{...l,textAlign:"center"},children:H(o)}),e.jsx("td",{style:l,children:e.jsx(s,{children:a})}),x.map(h=>{const g=t?w(j(t,d.fg,h),j(t,d.bg,h)):null;return e.jsx("td",{style:{...l,background:"var(--bg)"},"data-theme":h,children:e.jsxs("span",{style:{display:"inline-flex",flexDirection:"column",gap:4,alignItems:"flex-start"},children:[e.jsx(z,{status:o}),g==null?e.jsx(F,{}):e.jsx(U,{ratio:g})]})},h)})]},o)})})]})})}};function j(t,n,o){const a=t.find(d=>d.name===n);return a?W(o==="light"?a.light:a.dark,o):null}var T,f,S,M,b;c.parameters={...c.parameters,docs:{...(T=c.parameters)==null?void 0:T.docs,source:{originalSource:`{
  name: 'Бейджи',
  render: () => <Page title="CI Status" lead={<>
          Лозенг рисуется классом <Mono>.ci-lozenge--&lt;тон&gt;</Mono>, тон статусу выдаёт <Mono>ciTone()</Mono>. Своих цветов у
          статуса нет — только четыре пары токенов <Mono>--ci-*</Mono> / <Mono>--ci-*-bg</Mono>.
        </>}>
      <div style={{
      display: 'grid',
      gap: 'var(--space-150)'
    }}>
        {THEMES.map(theme => <ThemePane theme={theme} key={theme}>
            <div style={{
          display: 'flex',
          gap: 'var(--space-150)',
          flexWrap: 'wrap',
          alignItems: 'center'
        }}>
              {CI_STATUSES.map(status => <span key={status} style={{
            display: 'grid',
            gap: 4,
            justifyItems: 'start'
          }}>
                  <Lozenge status={status} />
                  <Mono>{status}</Mono>
                </span>)}
            </div>
          </ThemePane>)}
      </div>

      <Section title="Тон и его смысл">
        <table style={TABLE}>
          <thead>
            <tr>
              <th style={TH} scope="col">
                тон
              </th>
              <th style={TH} scope="col">
                токены
              </th>
              <th style={TH} scope="col">
                статусы
              </th>
              <th style={TH} scope="col">
                когда
              </th>
            </tr>
          </thead>
          <tbody>
            {(Object.keys(TONE_MEANING) as CiTone[]).map(tone => {
            const pair = tonePair(tone);
            return <tr key={tone}>
                  <th style={{
                ...TD,
                textAlign: 'left',
                fontWeight: 400
              }} scope="row">
                    <span className={\`ci-lozenge ci-lozenge--\${tone}\`}>{tone}</span>
                  </th>
                  <td style={TD}>
                    <Mono>
                      {pair.fg} / {pair.bg}
                    </Mono>
                  </td>
                  <td style={TD}>
                    <Mono>{CI_STATUSES.filter(status => ciTone(status) === tone).join(', ') || '—'}</Mono>
                  </td>
                  <td style={{
                ...TD,
                color: 'var(--text-dim)'
              }}>{TONE_MEANING[tone]}</td>
                </tr>;
          })}
          </tbody>
        </table>
      </Section>
    </Page>
}`,...(S=(f=c.parameters)==null?void 0:f.docs)==null?void 0:S.source},description:{story:"Бейджи всех статусов в обеих темах.",...(b=(M=c.parameters)==null?void 0:M.docs)==null?void 0:b.description}}};var E,k,I,A,v;i.parameters={...i.parameters,docs:{...(E=i.parameters)==null?void 0:E.docs,source:{originalSource:`{
  name: 'Источник правды',
  render: () => {
    const [tokens, setTokens] = useState<Token[] | null>(null);
    useEffect(() => {
      setTokens(readTokens());
    }, []);
    return <Page title="CI Status — источник правды" lead={<>
            Таблица целиком вычислена: статусы — <Mono>CI_STATUSES</Mono> из <Mono>@voicechat/shared/ci</Mono>, подпись и глиф —{' '}
            <Mono>ciStatusLabel()</Mono> и <Mono>ciStatusIcon()</Mono>, тон — <Mono>ciTone()</Mono> из{' '}
            <Mono>components/ci/ciFormat.ts</Mono>. Контраст лозенга считается по вычисленным токенам: подпись в нём 11px, значит
            нужен полный AA 4.5:1.
          </>}>
        <table style={TABLE}>
          <thead>
            <tr>
              <th style={TH} scope="col">
                статус
              </th>
              <th style={TH} scope="col">
                подпись
              </th>
              <th style={TH} scope="col">
                глиф
              </th>
              <th style={TH} scope="col">
                тон
              </th>
              {THEMES.map(theme => <th style={TH} scope="col" key={theme}>
                  {theme === 'light' ? 'светлая' : 'тёмная'}
                </th>)}
            </tr>
          </thead>
          <tbody>
            {CI_STATUSES.map(status => {
            const tone = ciTone(status);
            const pair = tonePair(tone);
            return <tr key={status}>
                  <th style={{
                ...TD,
                textAlign: 'left',
                fontWeight: 400
              }} scope="row">
                    <Mono>{status}</Mono>
                  </th>
                  <td style={TD}>{ciStatusLabel(status)}</td>
                  <td style={{
                ...TD,
                textAlign: 'center'
              }}>{ciStatusIcon(status)}</td>
                  <td style={TD}>
                    <Mono>{tone}</Mono>
                  </td>
                  {THEMES.map(theme => {
                const ratio = tokens ? ratioOf(tokenRgb(tokens, pair.fg, theme), tokenRgb(tokens, pair.bg, theme)) : null;
                return <td style={{
                  ...TD,
                  background: 'var(--bg)'
                }} data-theme={theme} key={theme}>
                        <span style={{
                    display: 'inline-flex',
                    flexDirection: 'column',
                    gap: 4,
                    alignItems: 'flex-start'
                  }}>
                          <Lozenge status={status} />
                          {ratio == null ? <Dash /> : <Verdict ratio={ratio} />}
                        </span>
                      </td>;
              })}
                </tr>;
          })}
          </tbody>
        </table>
      </Page>;
  }
}`,...(I=(k=i.parameters)==null?void 0:k.docs)==null?void 0:I.source},description:{story:"Источник правды: что именно возвращает ciFormat.ts для каждого статуса.",...(v=(A=i.parameters)==null?void 0:A.docs)==null?void 0:v.description}}};const X=["Badges","SourceOfTruth"];export{c as Badges,i as SourceOfTruth,X as __namedExportsOrder,Q as default};
