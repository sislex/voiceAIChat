import{j as c}from"./jsx-runtime-BYYWji4R.js";import{M as q}from"./MessageTimeline-AcAPYvz7.js";import{o as z,A as w,M as F,i as J,T as P}from"./chat-DXuxoGTT.js";import"./ci-awuetLx1.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import{T as Q}from"./time-CfyNS7J_.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./view-0MbJGw9Y.js";import"./animations--P72MiAI.js";import"./Markdown-CXCb5Rql.js";import"./clipboard-BEgkkb6H.js";import"./core-BwXZ_Otv.js";import"./MessageActivity-DR8202wn.js";import"./images-CH23vBlI.js";import"./tools-iBbMKii-.js";import"./questions-Bk4wc6lB.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";const xe={title:"Chat/MessageTimeline",component:q,args:{text:P,activity:J,mode:"brief",endMs:Q+45e3,execTarget:"MacBook"},decorators:[X=>c.jsx("div",{className:"msg ai",children:c.jsx("div",{className:"bub",style:{maxWidth:720},children:c.jsx(X,{})})})]},e={args:{mode:"minimal"}},r={},t={args:{mode:"detailed"}},s={args:{live:!0,voice:"thinking",text:"Проверяю гейт пакета…",activity:w,endMs:void 0}},i={args:{live:!0,voice:"thinking",mode:"minimal",text:"",activity:w}},a={args:{mode:"detailed",activity:z,text:"Ответ, сохранённый до появления смещений."}},o={args:{activity:[],text:F}};var n,m,d,p,l;e.parameters={...e.parameters,docs:{...(n=e.parameters)==null?void 0:n.docs,source:{originalSource:`{
  args: {
    mode: 'minimal'
  }
}`,...(d=(m=e.parameters)==null?void 0:m.docs)==null?void 0:d.source},description:{story:"Минимально: только текст ответа — действия спрятаны совсем.",...(l=(p=e.parameters)==null?void 0:p.docs)==null?void 0:l.description}}};var g,u,v,T,I;r.parameters={...r.parameters,docs:{...(g=r.parameters)==null?void 0:g.docs,source:{originalSource:"{}",...(v=(u=r.parameters)==null?void 0:u.docs)==null?void 0:v.source},description:{story:"Кратко: секция действий сворачивается в строку «что · сколько · последнее».",...(I=(T=r.parameters)==null?void 0:T.docs)==null?void 0:I.description}}};var y,x,f,M,A;t.parameters={...t.parameters,docs:{...(y=t.parameters)==null?void 0:y.docs,source:{originalSource:`{
  args: {
    mode: 'detailed'
  }
}`,...(f=(x=t.parameters)==null?void 0:x.docs)==null?void 0:f.source},description:{story:"Подробно: каждое действие строкой между абзацами текста.",...(A=(M=t.parameters)==null?void 0:M.docs)==null?void 0:A.description}}};var _,E,C,L,V;s.parameters={...s.parameters,docs:{...(_=s.parameters)==null?void 0:_.docs,source:{originalSource:`{
  args: {
    live: true,
    voice: 'thinking',
    text: 'Проверяю гейт пакета…',
    activity: ACTIVITY_LIVE,
    endMs: undefined
  }
}`,...(C=(E=s.parameters)==null?void 0:E.docs)==null?void 0:C.source},description:{story:`Живой ход: сверху статус со спиннером и счётчиком, в кратком виде время
последнего действия тикает раз в секунду (единственная сториз, где это видно).`,...(V=(L=s.parameters)==null?void 0:L.docs)==null?void 0:V.description}}};var h,N,S,Y,k;i.parameters={...i.parameters,docs:{...(h=i.parameters)==null?void 0:h.docs,source:{originalSource:`{
  args: {
    live: true,
    voice: 'thinking',
    mode: 'minimal',
    text: '',
    activity: ACTIVITY_LIVE
  }
}`,...(S=(N=i.parameters)==null?void 0:N.docs)==null?void 0:S.source},description:{story:"Живой ход без текста в минимальном виде — остаётся строка статуса.",...(k=(Y=i.parameters)==null?void 0:Y.docs)==null?void 0:k.description}}};var j,B,D,K,W;a.parameters={...a.parameters,docs:{...(j=a.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    mode: 'detailed',
    activity: ACTIVITY_LEGACY,
    text: 'Ответ, сохранённый до появления смещений.'
  }
}`,...(D=(B=a.parameters)==null?void 0:B.docs)==null?void 0:D.source},description:{story:"Старое сообщение: у действий нет смещений `at`, чередовать нечего — вид\nоткатывается к `MessageActivity` (секции после текста).",...(W=(K=a.parameters)==null?void 0:K.docs)==null?void 0:W.description}}};var b,H,O,G,R;o.parameters={...o.parameters,docs:{...(b=o.parameters)==null?void 0:b.docs,source:{originalSource:`{
  args: {
    activity: [],
    text: MD_KITCHEN_SINK
  }
}`,...(O=(H=o.parameters)==null?void 0:H.docs)==null?void 0:O.source},description:{story:"Ход без действий: обычный markdown-ответ во всю ширину пузыря.",...(R=(G=o.parameters)==null?void 0:G.docs)==null?void 0:R.description}}};const fe=["Minimal","Brief","Detailed","LiveBrief","LiveMinimal","LegacyWithoutOffsets","NoActivity"];export{r as Brief,t as Detailed,a as LegacyWithoutOffsets,s as LiveBrief,i as LiveMinimal,e as Minimal,o as NoActivity,fe as __namedExportsOrder,xe as default};
