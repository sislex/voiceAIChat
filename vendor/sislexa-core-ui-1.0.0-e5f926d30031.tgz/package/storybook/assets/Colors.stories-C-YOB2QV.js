import{j as e}from"./jsx-runtime-BYYWji4R.js";import{r as x}from"./index-ClcD9ViR.js";import{P as E,S as g,a as z,b as l,c as i,M as n,f as m,C as w,d as u,A as L,D as P,V as O,r as I,e as B}from"./parts-C1UcRfGq.js";import"./_commonjsHelpers-Cpj98o6Y.js";const G={title:"Foundations/Colors",parameters:{layout:"padded"}};function R(){const[o,s]=x.useState(null);return x.useEffect(()=>{s(I())},[]),o}function $(){return e.jsx("p",{style:{fontSize:13,color:"var(--text-dim)"},children:"Читаем токены из app.css…"})}function h(o,s,t){const r=o.find(a=>a.name===s);return r?B(t==="light"?r.light:r.dark,t):null}function y(o,s,t){const r=o.find(a=>a.name===s);return r?t==="light"?r.light:r.dark:""}const j=w,p=["light","dark"],d={name:"Все токены",render:()=>{const o=R();return e.jsx(E,{title:"Colors — токены палитры",lead:e.jsxs(e.Fragment,{children:["Имена собраны из правил ",e.jsx(n,{children:":root"})," и ",e.jsx(n,{children:"[data-theme='dark']"})," в ",e.jsx(n,{children:"styles/app.css"}),", значения сняты с зондов через ",e.jsx(n,{children:"getComputedStyle"}),". Новый токен появляется здесь сам — дублировать палитру в TS нельзя."]}),children:o?e.jsx(g,{title:`Все токены (${o.length})`,hint:e.jsxs(e.Fragment,{children:["Токены без отметки «своё значение» тёмная тема наследует у ",e.jsx(n,{children:":root"})," — это нормально для геометрии (",e.jsx(n,{children:"--space-*"}),", ",e.jsx(n,{children:"--radius-medium"}),") и подозрительно для цвета."]}),children:e.jsxs("table",{style:z,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:l,scope:"col",children:"токен"}),e.jsx("th",{style:l,scope:"col",children:"светлая"}),e.jsx("th",{style:l,scope:"col",children:"значение"}),e.jsx("th",{style:l,scope:"col",children:"тёмная"}),e.jsx("th",{style:l,scope:"col",children:"значение"}),e.jsx("th",{style:l,scope:"col",children:"в тёмной теме"})]})}),e.jsx("tbody",{children:o.map(s=>e.jsxs("tr",{children:[e.jsx("th",{style:{...i,...l,borderBottom:"1px solid var(--border-soft)",color:"var(--text)",textTransform:"none"},scope:"row",children:e.jsx(n,{children:s.name})}),e.jsx("td",{style:i,"data-theme":"light",children:s.isColor?e.jsx(m,{value:s.light}):e.jsx(f,{value:s.light})}),e.jsx("td",{style:i,children:e.jsx(n,{children:s.light})}),e.jsx("td",{style:{...i,background:"var(--bg)"},"data-theme":"dark",children:s.isColor?e.jsx(m,{value:s.dark}):e.jsx(f,{value:s.dark})}),e.jsx("td",{style:i,children:e.jsx(n,{children:s.dark})}),e.jsx("td",{style:{...i,fontSize:11,color:"var(--text-dim)"},children:s.darkOverride?"своё значение":"наследует светлое"})]},s.name))})]})}):e.jsx($,{})})}};function f({value:o}){return e.jsx("span",{"aria-hidden":"true",style:{display:"inline-block",width:o,height:12,background:"var(--accent)",borderRadius:2}})}const c={name:"Контраст пар",render:()=>{const o=R();if(!o)return e.jsx($,{});const s=p.flatMap(t=>j.filter(r=>{const a=u(h(o,r.fg,t),h(o,r.bg,t));return a!=null&&a<L[r.kind??"text"]}).map(r=>`${r.fg} на ${r.bg} (${t==="light"?"светлая":"тёмная"})`));return e.jsxs(E,{title:"Colors — контраст пар",lead:e.jsx(e.Fragment,{children:"Коэффициенты считаются здесь же по формуле WCAG 2.1 из вычисленных значений токенов. Порог: текст — 4.5:1 (1.4.3), границы элементов интерфейса — 3:1 (1.4.11), декоративные разделители показаны справочно."}),children:[e.jsx(g,{title:"Что не проходит AA",hint:"Список собирается из таблицы ниже — если он пуст, все пары в норме; если нет, правь токен, а не отдельное правило.",children:s.length===0?e.jsx("p",{style:{margin:0,fontSize:13},children:e.jsx("span",{className:"ci-lozenge ci-lozenge--success",children:"все пары проходят"})}):e.jsx("ul",{style:{margin:0,paddingLeft:18,fontSize:12,display:"grid",gap:4},children:s.map(t=>e.jsxs("li",{children:[e.jsx("span",{className:"ci-lozenge ci-lozenge--removed",children:"ниже AA"})," ",e.jsx(n,{children:t})]},t))})}),e.jsx(g,{title:"Пары целиком",children:e.jsxs("table",{style:z,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:l,scope:"col",children:"пара"}),e.jsx("th",{style:l,scope:"col",children:"где применяется"}),p.map(t=>e.jsx("th",{style:l,scope:"col",children:t==="light"?"светлая":"тёмная"},t))]})}),e.jsx("tbody",{children:j.map(t=>e.jsxs("tr",{children:[e.jsxs("th",{style:{...i,textAlign:"left",fontWeight:400},scope:"row",children:[e.jsx(n,{children:t.fg}),e.jsx("span",{style:{color:"var(--text-dim)"},children:" на "}),e.jsx(n,{children:t.bg})]}),e.jsx("td",{style:{...i,color:"var(--text-dim)"},children:t.usage}),p.map(r=>{const a=u(h(o,t.fg,r),h(o,t.bg,r));return e.jsx("td",{style:{...i,background:"var(--bg)"},"data-theme":r,children:e.jsxs("span",{style:{display:"inline-flex",flexDirection:"column",gap:4,alignItems:"flex-start"},children:[e.jsx(N,{fg:y(o,t.fg,r),bg:y(o,t.bg,r),kind:t.kind}),a==null?e.jsx(P,{}):e.jsx(O,{ratio:a,kind:t.kind})]})},r)})]},`${t.fg}-${t.bg}-${t.kind??"text"}`))})]})})]})}};function N({fg:o,bg:s,kind:t}){return t==="decor"?e.jsx("span",{style:{display:"inline-flex",alignItems:"center",width:84,height:20,background:s,borderRadius:"var(--radius-medium)"},children:e.jsx("span",{style:{display:"block",width:"100%",height:1,background:o}})}):t==="ui"?e.jsx("span",{style:{display:"inline-block",width:84,height:20,background:s,border:`2px solid ${o}`,borderRadius:"var(--radius-medium)"}}):e.jsx("span",{style:{background:s,color:o,padding:"2px 8px",borderRadius:"var(--radius-medium)",fontSize:12,fontWeight:600},children:"Текст 12px"})}var k,b,T,S,v;d.parameters={...d.parameters,docs:{...(k=d.parameters)==null?void 0:k.docs,source:{originalSource:`{
  name: 'Все токены',
  render: () => {
    const tokens = useTokens();
    return <Page title="Colors — токены палитры" lead={<>
            Имена собраны из правил <Mono>:root</Mono> и <Mono>[data-theme=&apos;dark&apos;]</Mono> в <Mono>styles/app.css</Mono>,
            значения сняты с зондов через <Mono>getComputedStyle</Mono>. Новый токен появляется здесь сам — дублировать палитру в TS
            нельзя.
          </>}>
        {!tokens ? <Loading /> : <Section title={\`Все токены (\${tokens.length})\`} hint={<>
                Токены без отметки «своё значение» тёмная тема наследует у <Mono>:root</Mono> — это нормально для геометрии
                (<Mono>--space-*</Mono>, <Mono>--radius-medium</Mono>) и подозрительно для цвета.
              </>}>
            <table style={TABLE}>
              <thead>
                <tr>
                  <th style={TH} scope="col">
                    токен
                  </th>
                  <th style={TH} scope="col">
                    светлая
                  </th>
                  <th style={TH} scope="col">
                    значение
                  </th>
                  <th style={TH} scope="col">
                    тёмная
                  </th>
                  <th style={TH} scope="col">
                    значение
                  </th>
                  <th style={TH} scope="col">
                    в тёмной теме
                  </th>
                </tr>
              </thead>
              <tbody>
                {tokens.map(token => <tr key={token.name}>
                    <th style={{
                ...TD,
                ...TH,
                borderBottom: '1px solid var(--border-soft)',
                color: 'var(--text)',
                textTransform: 'none'
              }} scope="row">
                      <Mono>{token.name}</Mono>
                    </th>
                    <td style={TD} data-theme="light">
                      {token.isColor ? <Swatch value={token.light} /> : <Ruler value={token.light} />}
                    </td>
                    <td style={TD}>
                      <Mono>{token.light}</Mono>
                    </td>
                    <td style={{
                ...TD,
                background: 'var(--bg)'
              }} data-theme="dark">
                      {token.isColor ? <Swatch value={token.dark} /> : <Ruler value={token.dark} />}
                    </td>
                    <td style={TD}>
                      <Mono>{token.dark}</Mono>
                    </td>
                    <td style={{
                ...TD,
                fontSize: 11,
                color: 'var(--text-dim)'
              }}>
                      {token.darkOverride ? 'своё значение' : 'наследует светлое'}
                    </td>
                  </tr>)}
              </tbody>
            </table>
          </Section>}
      </Page>;
  }
}`,...(T=(b=d.parameters)==null?void 0:b.docs)==null?void 0:T.source},description:{story:"Все токены: имя, образец и вычисленное значение в каждой теме.",...(v=(S=d.parameters)==null?void 0:S.docs)==null?void 0:v.description}}};var M,A,H,C,D;c.parameters={...c.parameters,docs:{...(M=c.parameters)==null?void 0:M.docs,source:{originalSource:`{
  name: 'Контраст пар',
  render: () => {
    const tokens = useTokens();
    if (!tokens) return <Loading />;
    const failing = THEMES.flatMap(theme => PAIRS.filter(pair => {
      const ratio = ratioOf(rgb(tokens, pair.fg, theme), rgb(tokens, pair.bg, theme));
      return ratio != null && ratio < AA_THRESHOLD[pair.kind ?? 'text'];
    }).map(pair => \`\${pair.fg} на \${pair.bg} (\${theme === 'light' ? 'светлая' : 'тёмная'})\`));
    return <Page title="Colors — контраст пар" lead={<>
            Коэффициенты считаются здесь же по формуле WCAG 2.1 из вычисленных значений токенов. Порог: текст — 4.5:1 (1.4.3),
            границы элементов интерфейса — 3:1 (1.4.11), декоративные разделители показаны справочно.
          </>}>
        <Section title="Что не проходит AA" hint="Список собирается из таблицы ниже — если он пуст, все пары в норме; если нет, правь токен, а не отдельное правило.">
          {failing.length === 0 ? <p style={{
          margin: 0,
          fontSize: 13
        }}>
              <span className="ci-lozenge ci-lozenge--success">все пары проходят</span>
            </p> : <ul style={{
          margin: 0,
          paddingLeft: 18,
          fontSize: 12,
          display: 'grid',
          gap: 4
        }}>
              {failing.map(item => <li key={item}>
                  <span className="ci-lozenge ci-lozenge--removed">ниже AA</span> <Mono>{item}</Mono>
                </li>)}
            </ul>}
        </Section>

        <Section title="Пары целиком">
          <table style={TABLE}>
            <thead>
              <tr>
                <th style={TH} scope="col">
                  пара
                </th>
                <th style={TH} scope="col">
                  где применяется
                </th>
                {THEMES.map(theme => <th style={TH} scope="col" key={theme}>
                    {theme === 'light' ? 'светлая' : 'тёмная'}
                  </th>)}
              </tr>
            </thead>
            <tbody>
              {PAIRS.map(pair => <tr key={\`\${pair.fg}-\${pair.bg}-\${pair.kind ?? 'text'}\`}>
                  <th style={{
                ...TD,
                textAlign: 'left',
                fontWeight: 400
              }} scope="row">
                    <Mono>{pair.fg}</Mono>
                    <span style={{
                  color: 'var(--text-dim)'
                }}> на </span>
                    <Mono>{pair.bg}</Mono>
                  </th>
                  <td style={{
                ...TD,
                color: 'var(--text-dim)'
              }}>{pair.usage}</td>
                  {THEMES.map(theme => {
                const ratio = ratioOf(rgb(tokens, pair.fg, theme), rgb(tokens, pair.bg, theme));
                return <td style={{
                  ...TD,
                  background: 'var(--bg)'
                }} data-theme={theme} key={theme}>
                        <span style={{
                    display: 'inline-flex',
                    flexDirection: 'column',
                    gap: 4,
                    alignItems: 'flex-start'
                  }}>
                          <Sample fg={value(tokens, pair.fg, theme)} bg={value(tokens, pair.bg, theme)} kind={pair.kind} />
                          {ratio == null ? <Dash /> : <Verdict ratio={ratio} kind={pair.kind} />}
                        </span>
                      </td>;
              })}
                </tr>)}
            </tbody>
          </table>
        </Section>
      </Page>;
  }
}`,...(H=(A=c.parameters)==null?void 0:A.docs)==null?void 0:H.source},description:{story:"Контраст пар: цифра, вердикт и живой образец в обеих темах.",...(D=(C=c.parameters)==null?void 0:C.docs)==null?void 0:D.description}}};const q=["AllTokens","Contrast"];export{d as AllTokens,c as Contrast,q as __namedExportsOrder,G as default};
