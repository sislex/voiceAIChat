import{j as B}from"./jsx-runtime-BYYWji4R.js";import{within as R,userEvent as n,expect as ka,fn as a}from"./index-DeN4tkzB.js";import{R as Ea}from"./RunFeed-gMpl9k0I.js";import{w as Ba}from"./storyBridges-cQngtz-K.js";import"./tools-iBbMKii-.js";import{N as Ra,g as I,h as La,i as L,j as T,k as b,s as Sa,l as va,m as xa,p as ba,q as fa,n as Ia,r as Ca,e as Ta}from"./ci-C1-DRnym.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./llmAccess-BLY4i_O6.js";import"./ciFormat-wlGR6KpA.js";import"./ansi-DtpFsZ9v.js";import"./clipboard-BEgkkb6H.js";import"./AnsiText-L5oy_LV7.js";import"./CiConsole-Ovgqiy62.js";import"./QuestionsForm-BIFaA7UX.js";import"./questions-Bk4wc6lB.js";import"./loadState-C9E-sPL9.js";import"./useCommands-isko1sz4.js";import"./commands-BOmIcTa-.js";import"./kbUsageFormat-DuWbHUyl.js";import"./fakeApi-Dd7dGTdR.js";import"./iframe-D-Q3L14w.js";import"./agentProtocol-ChPLBt7B.js";import"./projects-BdwKgk--.js";import"./projectTypes-C-9aONcK.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";const yr={title:"CI/RunFeed",component:Ea,args:{runId:"run-1",cache:Ca(),onSubscribe:a(),onUnsubscribe:a(),onLoad:a(),onRetry:a(),onRetryFromStep:a(),onDiscardAndRetry:a(),onCancel:a(),onAnswerInteraction:a(),now:()=>Ra,download:a()},decorators:[Ba(({ci:e})=>e._commands.push(...Ta())),e=>B.jsx("div",{style:{maxWidth:860},children:B.jsx(e,{})})]},s={args:{cache:fa()}},S={args:{cache:{...fa(),detail:{...L(b({status:"queued"}),[]),queue:{limit:2,occupied:2,waiting:[{runId:"run-1",taskId:"task-1",title:"Improve run feed",createdAt:Ra-9e4}],busy:[{runId:"busy",taskId:"task-2",title:"Build application",agentId:"MacBook",bypass:!1}]}}}}},v={args:{cache:va()},play:async({canvasElement:e})=>{await n.selectOptions(R(e).getByLabelText("Шаги"),"failed")}},x={args:A(),play:async({canvasElement:e})=>{const r=R(e);await n.type(r.getByRole("textbox",{name:"Поиск по логу"}),"packages"),await n.click(r.getByRole("button",{name:"Следующее"}))}};function A(){return{cache:{detail:L(b(),[T()]),log:xa(60),conclusion:null}}}const f={args:A(),play:async({canvasElement:e})=>{await n.click(R(e).getByRole("link",{name:"Строка 12"}))}},C={args:{cache:I()}},E={args:A(),parameters:{viewport:{defaultViewport:"mobile1"}},decorators:[e=>B.jsx("div",{style:{width:390,maxWidth:"100%"},children:B.jsx(e,{})})]},t={},o={args:{metrics:Ia(),onLoadMetrics:a()}},c={args:{cache:va()}},i={args:{cache:Sa()}},p={args:{cache:La()}},u={args:{cache:I()}},d={args:{cache:ba()}},m={args:{cache:{detail:L(b({status:"failed"}),[T({id:"dirty",title:"подготовить рабочую копию",status:"failed",exitCode:66,durationMs:900})]),log:[],conclusion:null}}},l={args:{cache:{detail:L(b(),[T()]),log:xa(1500),conclusion:null}}},g={args:{cache:{detail:null,log:[],conclusion:null,loading:!0}}},h={args:{cache:{detail:null,log:[],conclusion:null,error:"TypeError: Failed to fetch"}}},y={args:{cache:{...Ca(),error:"HTTP 503: сервер перезагружается"}}},w={args:{cache:Sa()},play:async({canvasElement:e})=>{const r=R(e);await n.click(r.getByText("Работа модели")),await n.click(await r.findByText("модель: npm test")),await ka(await r.findByText(/61 passed/)).toBeInTheDocument()}},k={args:{cache:I()},play:async({args:e,canvasElement:r})=>{const F=R(r);await n.click(F.getByLabelText("SQLite")),await n.click(F.getByRole("button",{name:"Отправить ответы"})),await ka(e.onAnswerInteraction).toHaveBeenCalledWith("run-1","it-1",{text:"SQLite"})}};var W,M,H,Q,j;s.parameters={...s.parameters,docs:{...(W=s.parameters)==null?void 0:W.docs,source:{originalSource:`{
  args: {
    cache: queuedRunCache()
  }
}`,...(H=(M=s.parameters)==null?void 0:M.docs)==null?void 0:H.source},description:{story:"В очереди: ран создан, шагов ещё нет — лента объясняет, чего ждать.",...(j=(Q=s.parameters)==null?void 0:Q.docs)==null?void 0:j.description}}};var D,q,P;S.parameters={...S.parameters,docs:{...(D=S.parameters)==null?void 0:D.docs,source:{originalSource:`{
  args: {
    cache: {
      ...queuedRunCache(),
      detail: {
        ...makeRunDetail(makeRun({
          status: 'queued'
        }), []),
        queue: {
          limit: 2,
          occupied: 2,
          waiting: [{
            runId: 'run-1',
            taskId: 'task-1',
            title: 'Improve run feed',
            createdAt: NOW - 90_000
          }],
          busy: [{
            runId: 'busy',
            taskId: 'task-2',
            title: 'Build application',
            agentId: 'MacBook',
            bypass: false
          }]
        }
      }
    }
  }
}`,...(P=(q=S.parameters)==null?void 0:q.docs)==null?void 0:P.source}}};var O,G,_;v.parameters={...v.parameters,docs:{...(O=v.parameters)==null?void 0:O.docs,source:{originalSource:`{
  args: {
    cache: failedRunCache()
  },
  play: async ({
    canvasElement
  }) => {
    await userEvent.selectOptions(within(canvasElement).getByLabelText('Шаги'), 'failed');
  }
}`,...(_=(G=v.parameters)==null?void 0:G.docs)==null?void 0:_.source}}};var N,V,U;x.parameters={...x.parameters,docs:{...(N=x.parameters)==null?void 0:N.docs,source:{originalSource:`{
  args: HugeLogArgs(),
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByRole('textbox', {
      name: 'Поиск по логу'
    }), 'packages');
    await userEvent.click(canvas.getByRole('button', {
      name: 'Следующее'
    }));
  }
}`,...(U=(V=x.parameters)==null?void 0:V.docs)==null?void 0:U.source}}};var z,J,K;f.parameters={...f.parameters,docs:{...(z=f.parameters)==null?void 0:z.docs,source:{originalSource:`{
  args: HugeLogArgs(),
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(within(canvasElement).getByRole('link', {
      name: 'Строка 12'
    }));
  }
}`,...(K=(J=f.parameters)==null?void 0:J.docs)==null?void 0:K.source}}};var X,Y,Z;C.parameters={...C.parameters,docs:{...(X=C.parameters)==null?void 0:X.docs,source:{originalSource:`{
  args: {
    cache: awaitingInputRunCache()
  }
}`,...(Z=(Y=C.parameters)==null?void 0:Y.docs)==null?void 0:Z.source}}};var $,ee,ae;E.parameters={...E.parameters,docs:{...($=E.parameters)==null?void 0:$.docs,source:{originalSource:`{
  args: HugeLogArgs(),
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  },
  decorators: [Story => <div style={{
    width: 390,
    maxWidth: '100%'
  }}><Story /></div>]
}`,...(ae=(ee=E.parameters)==null?void 0:ee.docs)==null?void 0:ae.source}}};var re,ne,se,te,oe;t.parameters={...t.parameters,docs:{...(re=t.parameters)==null?void 0:re.docs,source:{originalSource:"{}",...(se=(ne=t.parameters)==null?void 0:ne.docs)==null?void 0:se.source},description:{story:"Выполняется: первый шаг зелёный, второй идёт с логом, третий ждёт очереди.",...(oe=(te=t.parameters)==null?void 0:te.docs)==null?void 0:oe.description}}};var ce,ie,pe,ue,de;o.parameters={...o.parameters,docs:{...(ce=o.parameters)==null?void 0:ce.docs,source:{originalSource:`{
  args: {
    metrics: makeMetrics(),
    onLoadMetrics: fn()
  }
}`,...(pe=(ie=o.parameters)==null?void 0:ie.docs)==null?void 0:pe.source},description:{story:"Выполняется с метриками: у шага видно «типично» и долю текущего времени.",...(de=(ue=o.parameters)==null?void 0:ue.docs)==null?void 0:de.description}}};var me,le,ge,he,ye;c.parameters={...c.parameters,docs:{...(me=c.parameters)==null?void 0:me.docs,source:{originalSource:`{
  args: {
    cache: failedRunCache()
  }
}`,...(ge=(le=c.parameters)==null?void 0:le.docs)==null?void 0:ge.source},description:{story:"Упал на шаге: `npm test` с кодом 1, работа модели тоже свалилась — под ней\nвыбор движка и «Повторить работу модели», финальные команды не запускались.\nПлюс заключение модели сверху: что именно нужно от человека.",...(ye=(he=c.parameters)==null?void 0:he.docs)==null?void 0:ye.description}}};var we,ke,Re,Se,ve;i.parameters={...i.parameters,docs:{...(we=i.parameters)==null?void 0:we.docs,source:{originalSource:`{
  args: {
    cache: successRunCache()
  }
}`,...(Re=(ke=i.parameters)==null?void 0:ke.docs)==null?void 0:Re.source},description:{story:"Успех: все шаги зелёные, вызов команды моделью вложен под «Работу модели».",...(ve=(Se=i.parameters)==null?void 0:Se.docs)==null?void 0:ve.description}}};var xe,fe,Ce,Ee,Be;p.parameters={...p.parameters,docs:{...(xe=p.parameters)==null?void 0:xe.docs,source:{originalSource:`{
  args: {
    cache: autoFixRunCache()
  }
}`,...(Ce=(fe=p.parameters)==null?void 0:fe.docs)==null?void 0:Ce.source},description:{story:"Авто-фикс: шаг упал, модель разобралась — лозенг «исправлено моделью», попытка 2.",...(Be=(Ee=p.parameters)==null?void 0:Ee.docs)==null?void 0:Be.description}}};var Le,be,Ie,Te,Ae;u.parameters={...u.parameters,docs:{...(Le=u.parameters)==null?void 0:Le.docs,source:{originalSource:`{
  args: {
    cache: awaitingInputRunCache()
  }
}`,...(Ie=(be=u.parameters)==null?void 0:be.docs)==null?void 0:Ie.source},description:{story:"Ждёт ответа: уточняющий вопрос модели прямо внутри «Работы модели».",...(Ae=(Te=u.parameters)==null?void 0:Te.docs)==null?void 0:Ae.description}}};var Fe,We,Me,He,Qe;d.parameters={...d.parameters,docs:{...(Fe=d.parameters)==null?void 0:Fe.docs,source:{originalSource:`{
  args: {
    cache: planGateRunCache()
  }
}`,...(Me=(We=d.parameters)==null?void 0:We.docs)==null?void 0:Me.source},description:{story:"Режим плана: гейт «План готов — нужно решение» с «Одобрить» и «На доработку».",...(Qe=(He=d.parameters)==null?void 0:He.docs)==null?void 0:Qe.description}}};var je,De,qe,Pe,Oe;m.parameters={...m.parameters,docs:{...(je=m.parameters)==null?void 0:je.docs,source:{originalSource:`{
  args: {
    cache: {
      detail: makeRunDetail(makeRun({
        status: 'failed'
      }), [makeStep({
        id: 'dirty',
        title: 'подготовить рабочую копию',
        status: 'failed',
        exitCode: 66,
        durationMs: 900
      })]),
      log: [],
      conclusion: null
    }
  }
}`,...(qe=(De=m.parameters)==null?void 0:De.docs)==null?void 0:qe.source},description:{story:"Грязная рабочая копия (код 66): откат требует набрать слово-подтверждение.",...(Oe=(Pe=m.parameters)==null?void 0:Pe.docs)==null?void 0:Oe.description}}};var Ge,_e,Ne,Ve,Ue;l.parameters={...l.parameters,docs:{...(Ge=l.parameters)==null?void 0:Ge.docs,source:{originalSource:`{
  args: {
    cache: {
      detail: makeRunDetail(makeRun(), [makeStep()]),
      log: makeLogSheet(1500),
      conclusion: null
    }
  }
}`,...(Ne=(_e=l.parameters)==null?void 0:_e.docs)==null?void 0:Ne.source},description:{story:"Простыня лога: 1500 строк одного шага — видно, что хвост обрезан до 500.",...(Ue=(Ve=l.parameters)==null?void 0:Ve.docs)==null?void 0:Ue.description}}};var ze,Je,Ke,Xe,Ye;g.parameters={...g.parameters,docs:{...(ze=g.parameters)==null?void 0:ze.docs,source:{originalSource:`{
  args: {
    cache: {
      detail: null,
      log: [],
      conclusion: null,
      loading: true
    }
  }
}`,...(Ke=(Je=g.parameters)==null?void 0:Je.docs)==null?void 0:Ke.source},description:{story:"Загрузка: ленты ещё нет — скелетон шагов вместо пустого списка.",...(Ye=(Xe=g.parameters)==null?void 0:Xe.docs)==null?void 0:Ye.description}}};var Ze,$e,ea,aa,ra;h.parameters={...h.parameters,docs:{...(Ze=h.parameters)==null?void 0:Ze.docs,source:{originalSource:`{
  args: {
    cache: {
      detail: null,
      log: [],
      conclusion: null,
      error: 'TypeError: Failed to fetch'
    }
  }
}`,...(ea=($e=h.parameters)==null?void 0:$e.docs)==null?void 0:ea.source},description:{story:"Ошибка загрузки: сообщение, деталь под «Подробнее» и «Повторить».",...(ra=(aa=h.parameters)==null?void 0:aa.docs)==null?void 0:ra.description}}};var na,sa,ta,oa,ca;y.parameters={...y.parameters,docs:{...(na=y.parameters)==null?void 0:na.docs,source:{originalSource:`{
  args: {
    cache: {
      ...runningRunCache(),
      error: 'HTTP 503: сервер перезагружается'
    }
  }
}`,...(ta=(sa=y.parameters)==null?void 0:sa.docs)==null?void 0:ta.source},description:{story:"Ошибка поверх уже показанной ленты: данные остаются, ошибка — баннером.",...(ca=(oa=y.parameters)==null?void 0:oa.docs)==null?void 0:ca.description}}};var ia,pa,ua,da,ma;w.parameters={...w.parameters,docs:{...(ia=w.parameters)==null?void 0:ia.docs,source:{originalSource:`{
  args: {
    cache: successRunCache()
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByText('Работа модели'));
    await userEvent.click(await canvas.findByText('модель: npm test'));
    await expect(await canvas.findByText(/61 passed/)).toBeInTheDocument();
  }
}`,...(ua=(pa=w.parameters)==null?void 0:pa.docs)==null?void 0:ua.source},description:{story:`Раскрытие шага: успешные шаги свёрнуты (сами раскрываются только идущие,
упавшие и те, что ждут ответа). Клик по «Работе модели» показывает вложенные
вызовы команд, клик по вызову — его лог.`,...(ma=(da=w.parameters)==null?void 0:da.docs)==null?void 0:ma.description}}};var la,ga,ha,ya,wa;k.parameters={...k.parameters,docs:{...(la=k.parameters)==null?void 0:la.docs,source:{originalSource:`{
  args: {
    cache: awaitingInputRunCache()
  },
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByLabelText('SQLite'));
    await userEvent.click(canvas.getByRole('button', {
      name: 'Отправить ответы'
    }));
    await expect(args.onAnswerInteraction).toHaveBeenCalledWith('run-1', 'it-1', {
      text: 'SQLite'
    });
  }
}`,...(ha=(ga=k.parameters)==null?void 0:ga.docs)==null?void 0:ha.source},description:{story:"Ответ на уточняющий вопрос уходит в ран (а не новым ходом чата).",...(wa=(ya=k.parameters)==null?void 0:ya.docs)==null?void 0:wa.description}}};const wr=["Queued","ProjectQueue","StepFilters","LogSearch","LinePermalink","QuestionWithTimer","Mobile390","Running","RunningWithMetrics","FailedStep","Success","AutoFixed","AwaitingClarify","PlanGate","DirtyWorkspace","HugeLog","Loading","LoadError","StaleError","ExpandStep","AnswerClarify"];export{k as AnswerClarify,p as AutoFixed,u as AwaitingClarify,m as DirtyWorkspace,w as ExpandStep,c as FailedStep,l as HugeLog,f as LinePermalink,h as LoadError,g as Loading,x as LogSearch,E as Mobile390,d as PlanGate,S as ProjectQueue,C as QuestionWithTimer,s as Queued,t as Running,o as RunningWithMetrics,y as StaleError,v as StepFilters,i as Success,wr as __namedExportsOrder,yr as default};
