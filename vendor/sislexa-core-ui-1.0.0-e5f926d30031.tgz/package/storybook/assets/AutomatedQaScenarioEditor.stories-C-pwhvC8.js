import{A as V}from"./AutomatedQaScenarioEditor-DzQL2j1v.js";import"./jsx-runtime-BYYWji4R.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./qa-B4ObmSZt.js";import"./types-CmoD7ERW.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";const l=(...s)=>({id:"p1",automatedQaScenarios:s}),W={title:"Projects/Automated QA scenario",component:V,args:{detail:l(),isOwner:!0,onUpdate:()=>{}}},i={},o={args:{detail:l({name:"Вход и доска",startUrl:"https://staging.example.com/#/projects/p1",steps:[{id:"s1",title:"Открыть доску",action:{kind:"wait",selector:".jboard"}},{id:"s2",title:"Создать задачу",action:{kind:"click",selector:"#create"},expectText:"Новая задача"},{id:"s3",title:"Ввести название",action:{kind:"type",selector:"input[name=title]",text:"Проверка"},expectAbsentText:"Ошибка"}]})}},c={args:{...o.args,isOwner:!1}},a={args:{detail:l({name:"Локальный стенд",startUrl:"http://localhost:5173",steps:[{id:"s1",title:"Открыть доску",action:{kind:"wait",selector:".jboard"}}]})}},t={args:{detail:l({name:"Вход",startUrl:"https://staging.example.com/",steps:[{id:"s1",title:"Ввести логин",action:{kind:"type",selector:'[data-testid="login-username"]',text:"tester"},expectText:"Вход"}]},{name:"Доска проекта",startUrl:"https://staging.example.com/#/projects/p1",steps:[{id:"s1",title:"Создать задачу",action:{kind:"click",selector:'[data-testid="create-task"]'},expectText:"Новая задача"}]},{name:"Настройки",startUrl:"https://staging.example.com/#/projects/p1/settings",steps:[{id:"s1",title:"Открыть вкладку",action:{kind:"click",selector:'[data-testid="settings-tab"]'},expectText:"Общее"}]})}},n={args:{...t.args,onCheck:async()=>[{name:"Вход",passed:!0,blocked:null,steps:[],durationMs:1400},{name:"Доска проекта",passed:!1,durationMs:21400,steps:[],blocked:"Шаг «Открыть доску» проверить нельзя: Текст страницы прочитан не целиком (первые 20000 символов), ожидаемого текста «Задача создана» в этой части нет"}]},play:async({canvasElement:s})=>{const e=[...s.querySelectorAll("button")].find(d=>d.textContent==="Прогнать набор сейчас");e==null||e.click()}},r={args:{...t.args,onCheck:async()=>[{name:"Вход",passed:!0,blocked:null,steps:[],durationMs:1400},{name:"Доска проекта",passed:!1,blocked:null,durationMs:2600,steps:[{id:"s",title:"Создать задачу",status:"failed",detail:"локатор не найден",durationMs:5e3}],pageErrors:["Uncaught TypeError: Cannot read properties of undefined (reading 'columns') at BoardView.tsx:142"],screenshot:"data:image/svg+xml;utf8,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180"><rect width="320" height="180" fill="#e9e7dd"/><text x="20" y="100" font-family="sans-serif" font-size="20" fill="#4a4a44">Экран прогона</text></svg>')},{name:"Настройки",passed:!1,blocked:"Стартовый адрес не открылся",steps:[],durationMs:300}]},play:async({canvasElement:s})=>{const e=[...s.querySelectorAll("button")].find(d=>d.textContent==="Прогнать набор сейчас");e==null||e.click()}};var p,m,u;i.parameters={...i.parameters,docs:{...(p=i.parameters)==null?void 0:p.docs,source:{originalSource:"{}",...(u=(m=i.parameters)==null?void 0:m.docs)==null?void 0:u.source}}};var g,x,k;o.parameters={...o.parameters,docs:{...(g=o.parameters)==null?void 0:g.docs,source:{originalSource:`{
  args: {
    detail: detail({
      name: 'Вход и доска',
      startUrl: 'https://staging.example.com/#/projects/p1',
      steps: [{
        id: 's1',
        title: 'Открыть доску',
        action: {
          kind: 'wait',
          selector: '.jboard'
        }
      }, {
        id: 's2',
        title: 'Создать задачу',
        action: {
          kind: 'click',
          selector: '#create'
        },
        expectText: 'Новая задача'
      }, {
        id: 's3',
        title: 'Ввести название',
        action: {
          kind: 'type',
          selector: 'input[name=title]',
          text: 'Проверка'
        },
        expectAbsentText: 'Ошибка'
      }]
    })
  }
}`,...(k=(x=o.parameters)==null?void 0:x.docs)==null?void 0:k.source}}};var h,y,f;c.parameters={...c.parameters,docs:{...(h=c.parameters)==null?void 0:h.docs,source:{originalSource:`{
  args: {
    ...Filled.args,
    isOwner: false
  }
}`,...(f=(y=c.parameters)==null?void 0:y.docs)==null?void 0:f.source}}};var b,w,S,U,v;a.parameters={...a.parameters,docs:{...(b=a.parameters)==null?void 0:b.docs,source:{originalSource:`{
  args: {
    detail: detail({
      name: 'Локальный стенд',
      startUrl: 'http://localhost:5173',
      steps: [{
        id: 's1',
        title: 'Открыть доску',
        action: {
          kind: 'wait',
          selector: '.jboard'
        }
      }]
    })
  }
}`,...(S=(w=a.parameters)==null?void 0:w.docs)==null?void 0:S.source},description:{story:"Адрес, в который раннер не пойдёт. Состояние достижимо только значением из\nнастроек проекта, поэтому живёт в витрине: изолированный Chromium работает на\nсервере, и `localhost` с приватными сетями режет SSRF-гейт `validatePublicUrl`.",...(v=(U=a.parameters)==null?void 0:U.docs)==null?void 0:v.description}}};var M,C,E,T,j;t.parameters={...t.parameters,docs:{...(M=t.parameters)==null?void 0:M.docs,source:{originalSource:`{
  args: {
    detail: detail({
      name: 'Вход',
      startUrl: 'https://staging.example.com/',
      steps: [{
        id: 's1',
        title: 'Ввести логин',
        action: {
          kind: 'type',
          selector: '[data-testid="login-username"]',
          text: 'tester'
        },
        expectText: 'Вход'
      }]
    }, {
      name: 'Доска проекта',
      startUrl: 'https://staging.example.com/#/projects/p1',
      steps: [{
        id: 's1',
        title: 'Создать задачу',
        action: {
          kind: 'click',
          selector: '[data-testid="create-task"]'
        },
        expectText: 'Новая задача'
      }]
    }, {
      name: 'Настройки',
      startUrl: 'https://staging.example.com/#/projects/p1/settings',
      steps: [{
        id: 's1',
        title: 'Открыть вкладку',
        action: {
          kind: 'click',
          selector: '[data-testid="settings-tab"]'
        },
        expectText: 'Общее'
      }]
    })
  }
}`,...(E=(C=t.parameters)==null?void 0:C.docs)==null?void 0:E.source},description:{story:"Набор из нескольких сценариев: ради него круг 20 и делался.",...(j=(T=t.parameters)==null?void 0:T.docs)==null?void 0:j.description}}};var A,R,O,q,B;n.parameters={...n.parameters,docs:{...(A=n.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    ...ManyScenarios.args,
    onCheck: async () => [{
      name: 'Вход',
      passed: true,
      blocked: null,
      steps: [],
      durationMs: 1400
    }, {
      name: 'Доска проекта',
      passed: false,
      durationMs: 21400,
      steps: [],
      blocked: 'Шаг «Открыть доску» проверить нельзя: Текст страницы прочитан не целиком (первые 20000 символов), ожидаемого текста «Задача создана» в этой части нет'
    }]
  },
  play: async ({
    canvasElement
  }) => {
    const button = [...canvasElement.querySelectorAll('button')].find(el => el.textContent === 'Прогнать набор сейчас');
    button?.click();
  }
}`,...(O=(R=n.parameters)==null?void 0:R.docs)==null?void 0:O.source},description:{story:`Непроверяемый шаг (круг 25): страница длиннее предела чтения. Текст отказа
длинный и на телефоне переносится — состояние достижимо только ответом
сервера, поэтому живёт в витрине.`,...(B=(q=n.parameters)==null?void 0:q.docs)==null?void 0:B.description}}};var F,I,Q,z,P;r.parameters={...r.parameters,docs:{...(F=r.parameters)==null?void 0:F.docs,source:{originalSource:`{
  args: {
    ...ManyScenarios.args,
    onCheck: async () => [{
      name: 'Вход',
      passed: true,
      blocked: null,
      steps: [],
      durationMs: 1400
    }, {
      name: 'Доска проекта',
      passed: false,
      blocked: null,
      durationMs: 2600,
      steps: [{
        id: 's',
        title: 'Создать задачу',
        status: 'failed' as const,
        detail: 'локатор не найден',
        durationMs: 5000
      }],
      pageErrors: ['Uncaught TypeError: Cannot read properties of undefined (reading \\'columns\\') at BoardView.tsx:142'],
      // Снимок приходит содержимым: у разового прогона нет рана в БД (круг 28).
      screenshot: 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="320" height="180"><rect width="320" height="180" fill="#e9e7dd"/><text x="20" y="100" font-family="sans-serif" font-size="20" fill="#4a4a44">Экран прогона</text></svg>')
    }, {
      name: 'Настройки',
      passed: false,
      blocked: 'Стартовый адрес не открылся',
      steps: [],
      durationMs: 300
    }]
  },
  play: async ({
    canvasElement
  }) => {
    const button = [...canvasElement.querySelectorAll('button')].find(el => el.textContent === 'Прогнать набор сейчас');
    button?.click();
  }
}`,...(Q=(I=r.parameters)==null?void 0:I.docs)==null?void 0:Q.source},description:{story:`Итог разового прогона набора. Состояние приходит только ответом сервера,
поэтому живёт в витрине: пройденный, провалившийся и заблокированный сразу.`,...(P=(z=r.parameters)==null?void 0:z.docs)==null?void 0:P.description}}};const X=["Empty","Filled","ReadOnlyMember","InvalidStartUrl","ManyScenarios","CheckBlockedUnverifiable","CheckResults"];export{n as CheckBlockedUnverifiable,r as CheckResults,i as Empty,o as Filled,a as InvalidStartUrl,t as ManyScenarios,c as ReadOnlyMember,X as __namedExportsOrder,W as default};
