import{j as x}from"./jsx-runtime-BYYWji4R.js";import{within as o,userEvent as a,expect as r,fn as b}from"./index-DeN4tkzB.js";import{MachineUtility as qe}from"./MachineUtility-DwE3Ueiu.js";import"./tools-iBbMKii-.js";import"./ci-awuetLx1.js";import{d as k,m as E,a as Ge,e as Je,f as Ke,b as Qe}from"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-D-Q3L14w.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./EmptyState-q579drYF.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./Skeleton-42oMjovX.js";import"./ErrorState-CqsakWkx.js";import"./clipboard-BEgkkb6H.js";import"./loadState-C9E-sPL9.js";import"./ToolFrame-CqCmqPT9.js";import"./CodeDiff-eD9pwj9B.js";import"./codeHighlight-COY3V3up.js";import"./core-BwXZ_Otv.js";import"./mediaQuery-CCkbYk-e.js";import"./useCommands-isko1sz4.js";import"./commands-BOmIcTa-.js";import"./lazyScreen-CooZxeYV.js";import"./types-CmoD7ERW.js";import"./time-CfyNS7J_.js";import"./kb-CjYTCLN0.js";const Xe=[E({id:"m1",name:"MacBook"}),Qe({id:"m2",name:"Домашний ПК"})],Mn={title:"Machines/MachineUtility",component:qe,args:{tool:{kind:"console",agentId:"m1"},agents:Xe,ops:k(),variant:"embedded",onSwitchUtility:b(),onOpenMachines:b(),onClose:b()},decorators:[t=>x.jsx("div",{className:"msg ai",children:x.jsx("div",{className:"bub",style:{maxWidth:820},children:x.jsx(t,{})})})]},s={},I={args:{agents:[E({id:"m1",name:"Very long machine name on a mobile screen",version:"0.17.0"})],tool:{kind:"explorer",agentId:"m1",dir:!0}},decorators:[t=>x.jsx("div",{style:{width:390,maxWidth:"100%"},children:x.jsx(t,{})})]},B={args:{tool:{kind:"explorer",agentId:"m1",dir:!0},agents:[E({id:"m1",version:"0.17.0"})],ops:k({list:async()=>({root:"/r",cwd:"/r",entries:[{name:"large.txt",kind:"file",size:4e7,mtime:0}]}),readPrefix:async()=>({root:"/r",cwd:"/r",dataBase64:btoa("Prefix preview"),bytesRead:14,fileSize:4e7,truncated:!0})})},play:async({canvasElement:t})=>{const e=o(t);await a.click(await e.findByRole("button",{name:"📄 large.txt"})),await a.click(e.getByRole("button",{name:"Показать первые 200 КБ"})),await r(await e.findByText("Prefix preview")).toBeInTheDocument()}},f={args:{tool:{kind:"explorer",agentId:"m1",dir:!0}},play:async({canvasElement:t})=>{const e=o(t),n=await e.findAllByRole("checkbox");await a.click(n[0]),await a.click(n[1]),await r(e.getByText("Выбрано: 2")).toBeInTheDocument()}},i={args:{tool:{kind:"terminal",agentId:"m1"},pty:Ke()}},c={args:{tool:{kind:"explorer",agentId:"m1",path:"/home/dev/voiceAIChat",dir:!0}}},d={args:{tool:{kind:"explorer",agentId:"m1",path:"/home/dev/voiceAIChat/package.json"}}},m={args:{tool:{kind:"explorer",agentId:"m1",path:"/home/dev/пусто",dir:!0},ops:k({list:async()=>({root:"/home/dev",cwd:"/home/dev/пусто",entries:[]})})}},p={args:{tool:{kind:"explorer",agentId:"m1",path:"/root",dir:!0},ops:k({list:async()=>{throw new Error("Каталог /root запрещён политикой машины")}})}},l={args:{variant:"modal",tool:{kind:"explorer",agentId:"m1",dir:!0,path:"/home/dev"}}},u={play:async({canvasElement:t})=>{const e=o(t),n=e.getByRole("textbox");await a.type(n,"git status{Enter}"),await r(await e.findByText(/фейковые операции сториз/)).toBeInTheDocument()}},g={args:{ops:k({exec:(t,e,n)=>new Promise((Ze,$e)=>{n==null||n.addEventListener("abort",()=>$e(new Error("Команда отменена")))})})},play:async({canvasElement:t})=>{const e=o(t),n=e.getByRole("textbox");await a.type(n,"sleep 100{Enter}"),await a.click(await e.findByTitle("Стоп")),await r(await e.findByText("Отменено")).toBeInTheDocument(),await a.type(n,"{ArrowUp}"),await r(n).toHaveValue("sleep 100")}},v={args:{agents:[E({id:"m1",name:"MacBook"})],tool:{kind:"explorer",agentId:"m1",path:"/home/dev",dir:!0}}},y={args:{agents:[E({id:"m1",name:"Сборочный сервер",policy:Ge({allowWrite:!1,allowNetwork:!1,allowedDirs:["/srv/build","/tmp"]})})],tool:{kind:"explorer",agentId:"m1",path:"/srv/build",dir:!0}}},h={args:{tool:{kind:"explorer",agentId:"m1",path:"/home/dev/voiceAIChat",dir:!0}},play:async({args:t,canvasElement:e})=>{const n=o(e);await r(await n.findByLabelText(`Скачать ${Je()[2].name}`)).toBeInTheDocument(),await a.click(n.getByRole("button",{name:/Консоль/})),await r(t.onSwitchUtility).toHaveBeenCalledWith("console","m1","/home/dev/voiceAIChat")}},w={args:{tool:{kind:"console",agentId:"m1",path:"/home/dev/voiceAIChat"}},play:async({args:t,canvasElement:e})=>{const n=o(e);await a.click(n.getByRole("button",{name:/Проводник/})),await r(t.onSwitchUtility).toHaveBeenCalledWith("explorer","m1","/home/dev/voiceAIChat")}};var S,T,C,A,P;s.parameters={...s.parameters,docs:{...(S=s.parameters)==null?void 0:S.docs,source:{originalSource:"{}",...(C=(T=s.parameters)==null?void 0:T.docs)==null?void 0:C.source},description:{story:"Консоль без моста PTY (так работает desktop): однострочный ввод команды и её\nвывод по политике машины. `pty` не задан — виджет деградирует осознанно.",...(P=(A=s.parameters)==null?void 0:A.docs)==null?void 0:P.description}}};var M,R,D;I.parameters={...I.parameters,docs:{...(M=I.parameters)==null?void 0:M.docs,source:{originalSource:`{
  args: {
    agents: [makeAgent({
      id: 'm1',
      name: 'Very long machine name on a mobile screen',
      version: '0.17.0'
    })],
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      dir: true
    }
  },
  decorators: [Story => <div style={{
    width: 390,
    maxWidth: '100%'
  }}><Story /></div>]
}`,...(D=(R=I.parameters)==null?void 0:R.docs)==null?void 0:D.source}}};var j,W,H;B.parameters={...B.parameters,docs:{...(j=B.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      dir: true
    },
    agents: [makeAgent({
      id: 'm1',
      version: '0.17.0'
    })],
    ops: makeMachineOps({
      list: async () => ({
        root: '/r',
        cwd: '/r',
        entries: [{
          name: 'large.txt',
          kind: 'file',
          size: 40000000,
          mtime: 0
        }]
      }),
      readPrefix: async () => ({
        root: '/r',
        cwd: '/r',
        dataBase64: btoa('Prefix preview'),
        bytesRead: 14,
        fileSize: 40000000,
        truncated: true
      })
    })
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByRole('button', {
      name: '📄 large.txt'
    }));
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать первые 200 КБ'
    }));
    await expect(await canvas.findByText('Prefix preview')).toBeInTheDocument();
  }
}`,...(H=(W=B.parameters)==null?void 0:W.docs)==null?void 0:H.source}}};var O,U,_;f.parameters={...f.parameters,docs:{...(O=f.parameters)==null?void 0:O.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      dir: true
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const boxes = await canvas.findAllByRole('checkbox');
    await userEvent.click(boxes[0]);
    await userEvent.click(boxes[1]);
    await expect(canvas.getByText('Выбрано: 2')).toBeInTheDocument();
  }
}`,...(_=(U=f.parameters)==null?void 0:U.docs)==null?void 0:_.source}}};var F,z,L,N,V;i.parameters={...i.parameters,docs:{...(F=i.parameters)==null?void 0:F.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'terminal',
      agentId: 'm1'
    },
    pty: createFakePty()
  }
}`,...(L=(z=i.parameters)==null?void 0:z.docs)==null?void 0:L.source},description:{story:"Живой терминал: есть мост PTY — вместо однострочной консоли поднимается xterm.",...(V=(N=i.parameters)==null?void 0:N.docs)==null?void 0:V.description}}};var Y,$,q,G,J;c.parameters={...c.parameters,docs:{...(Y=c.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      path: '/home/dev/voiceAIChat',
      dir: true
    }
  }
}`,...(q=($=c.parameters)==null?void 0:$.docs)==null?void 0:q.source},description:{story:"Проводник по машине: содержимое каталога, размеры и время изменения.",...(J=(G=c.parameters)==null?void 0:G.docs)==null?void 0:J.description}}};var K,Q,X,Z,ee;d.parameters={...d.parameters,docs:{...(K=d.parameters)==null?void 0:K.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      path: '/home/dev/voiceAIChat/package.json'
    }
  }
}`,...(X=(Q=d.parameters)==null?void 0:Q.docs)==null?void 0:X.source},description:{story:"Проводник, открытый на файле: выделяет строку в родительской папке.",...(ee=(Z=d.parameters)==null?void 0:Z.docs)==null?void 0:ee.description}}};var ne,te,ae,re,oe;m.parameters={...m.parameters,docs:{...(ne=m.parameters)==null?void 0:ne.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      path: '/home/dev/пусто',
      dir: true
    },
    ops: makeMachineOps({
      list: async () => ({
        root: '/home/dev',
        cwd: '/home/dev/пусто',
        entries: []
      })
    })
  }
}`,...(ae=(te=m.parameters)==null?void 0:te.docs)==null?void 0:ae.source},description:{story:"Пустой каталог: список пуст, но панель и кнопки на месте.",...(oe=(re=m.parameters)==null?void 0:re.docs)==null?void 0:oe.description}}};var se,ie,ce,de,me;p.parameters={...p.parameters,docs:{...(se=p.parameters)==null?void 0:se.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      path: '/root',
      dir: true
    },
    ops: makeMachineOps({
      list: async () => {
        throw new Error('Каталог /root запрещён политикой машины');
      }
    })
  }
}`,...(ce=(ie=p.parameters)==null?void 0:ie.docs)==null?void 0:ce.source},description:{story:"Ошибка операции: машина отказала (политика или обрыв) — виджет это показывает.",...(me=(de=p.parameters)==null?void 0:de.docs)==null?void 0:me.description}}};var pe,le,ue,ge,ve;l.parameters={...l.parameters,docs:{...(pe=l.parameters)==null?void 0:pe.docs,source:{originalSource:`{
  args: {
    variant: 'modal',
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      dir: true,
      path: '/home/dev'
    }
  }
}`,...(ue=(le=l.parameters)==null?void 0:le.docs)==null?void 0:ue.source},description:{story:'Открыто из меню (`variant="modal"`): та же утилита, но окном с крестиком.',...(ve=(ge=l.parameters)==null?void 0:ge.docs)==null?void 0:ve.description}}};var ye,he,we,xe,ke;u.parameters={...u.parameters,docs:{...(ye=u.parameters)==null?void 0:ye.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const input = canvas.getByRole('textbox');
    await userEvent.type(input, 'git status{Enter}');
    await expect(await canvas.findByText(/фейковые операции сториз/)).toBeInTheDocument();
  }
}`,...(we=(he=u.parameters)==null?void 0:he.docs)==null?void 0:we.source},description:{story:"Выполнение команды в консоли: ввод → вывод фейковых операций.",...(ke=(xe=u.parameters)==null?void 0:xe.docs)==null?void 0:ke.description}}};var Ee,Ie,Be,fe,be;g.parameters={...g.parameters,docs:{...(Ee=g.parameters)==null?void 0:Ee.docs,source:{originalSource:`{
  args: {
    ops: makeMachineOps({
      exec: (_agentId, _command, signal) => new Promise((_resolve, reject) => {
        signal?.addEventListener('abort', () => reject(new Error('Команда отменена')));
      })
    })
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const input = canvas.getByRole('textbox');
    await userEvent.type(input, 'sleep 100{Enter}');
    await userEvent.click(await canvas.findByTitle('Стоп'));
    await expect(await canvas.findByText('Отменено')).toBeInTheDocument();
    await userEvent.type(input, '{ArrowUp}');
    await expect(input).toHaveValue('sleep 100');
  }
}`,...(Be=(Ie=g.parameters)==null?void 0:Ie.docs)==null?void 0:Be.source},description:{story:"История и отмена: ↑ достаёт набранное раньше, а пока команда идёт, рядом с ▶\nживёт «Стоп». Здесь `exec` висит до отмены — как настоящий долгий запрос.",...(be=(fe=g.parameters)==null?void 0:fe.docs)==null?void 0:be.description}}};var Se,Te,Ce,Ae,Pe;v.parameters={...v.parameters,docs:{...(Se=v.parameters)==null?void 0:Se.docs,source:{originalSource:`{
  args: {
    agents: [makeAgent({
      id: 'm1',
      name: 'MacBook'
    })],
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      path: '/home/dev',
      dir: true
    }
  }
}`,...(Ce=(Te=v.parameters)==null?void 0:Te.docs)==null?void 0:Ce.source},description:{story:`Общая шапка при ЕДИНСТВЕННОЙ машине: селектора нет, но имя и статус машины
(в сети, версия агента) всё равно видны — раньше в этом случае не было ничего.`,...(Pe=(Ae=v.parameters)==null?void 0:Ae.docs)==null?void 0:Pe.description}}};var Me,Re,De,je,We;y.parameters={...y.parameters,docs:{...(Me=y.parameters)==null?void 0:Me.docs,source:{originalSource:`{
  args: {
    agents: [makeAgent({
      id: 'm1',
      name: 'Сборочный сервер',
      policy: makePolicy({
        allowWrite: false,
        allowNetwork: false,
        allowedDirs: ['/srv/build', '/tmp']
      })
    })],
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      path: '/srv/build',
      dir: true
    }
  }
}`,...(De=(Re=y.parameters)==null?void 0:Re.docs)==null?void 0:De.source},description:{story:"Машина с запретами: бейджи «только чтение», «сеть запрещена» и «каталоги\nограничены» (подсказка перечисляет `allowedDirs`), а на месте кнопок изменения\nфайлов — пометка, почему их нет.",...(We=(je=y.parameters)==null?void 0:je.docs)==null?void 0:We.description}}};var He,Oe,Ue,_e,Fe;h.parameters={...h.parameters,docs:{...(He=h.parameters)==null?void 0:He.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'explorer',
      agentId: 'm1',
      path: '/home/dev/voiceAIChat',
      dir: true
    }
  },
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    // Имя файла в строке идёт вместе с иконкой, поэтому ждём его по кнопке действия.
    await expect(await canvas.findByLabelText(\`Скачать \${makeFsEntries()[2].name}\`)).toBeInTheDocument();
    await userEvent.click(canvas.getByRole('button', {
      name: /Консоль/
    }));
    await expect(args.onSwitchUtility).toHaveBeenCalledWith('console', 'm1', '/home/dev/voiceAIChat');
  }
}`,...(Ue=(Oe=h.parameters)==null?void 0:Oe.docs)==null?void 0:Ue.source},description:{story:"Из проводника переключаемся в консоль/терминал — та же машина, та же папка.",...(Fe=(_e=h.parameters)==null?void 0:_e.docs)==null?void 0:Fe.description}}};var ze,Le,Ne,Ve,Ye;w.parameters={...w.parameters,docs:{...(ze=w.parameters)==null?void 0:ze.docs,source:{originalSource:`{
  args: {
    tool: {
      kind: 'console',
      agentId: 'm1',
      path: '/home/dev/voiceAIChat'
    }
  },
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole('button', {
      name: /Проводник/
    }));
    await expect(args.onSwitchUtility).toHaveBeenCalledWith('explorer', 'm1', '/home/dev/voiceAIChat');
  }
}`,...(Ne=(Le=w.parameters)==null?void 0:Le.docs)==null?void 0:Ne.source},description:{story:"И обратно: из консоли — в проводник, папка утилиты сохраняется.",...(Ye=(Ve=w.parameters)==null?void 0:Ve.docs)==null?void 0:Ye.description}}};const Rn=["ConsoleWithoutPty","Mobile390","PrefixPreview","MultipleSelection","Terminal","Explorer","ExplorerOnFile","ExplorerEmptyDir","ExplorerError","AsModal","ConsoleCommand","ConsoleHistoryAndStop","SingleMachineHeader","RestrictedPolicy","SwitchExplorerToConsole","SwitchConsoleToExplorer"];export{l as AsModal,u as ConsoleCommand,g as ConsoleHistoryAndStop,s as ConsoleWithoutPty,c as Explorer,m as ExplorerEmptyDir,p as ExplorerError,d as ExplorerOnFile,I as Mobile390,f as MultipleSelection,B as PrefixPreview,y as RestrictedPolicy,v as SingleMachineHeader,w as SwitchConsoleToExplorer,h as SwitchExplorerToConsole,i as Terminal,Rn as __namedExportsOrder,Mn as default};
