import{j as e}from"./jsx-runtime-BYYWji4R.js";import"./index-ClcD9ViR.js";import{B as a}from"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import{E as g}from"./EmptyState-q579drYF.js";import"./_commonjsHelpers-Cpj98o6Y.js";function u({items:n,onRead:s}){return e.jsx("div",{className:"notification-history",children:n.length?e.jsxs(e.Fragment,{children:[e.jsx(a,{size:"sm",onClick:()=>s(),children:"Прочитать все"}),e.jsx("ul",{children:n.map(t=>e.jsxs("li",{"data-unread":!t.read,children:[e.jsx("p",{children:t.text}),e.jsx("time",{dateTime:new Date(t.time).toISOString(),children:new Date(t.time).toLocaleString()}),!t.read&&e.jsx(a,{size:"sm",variant:"ghost",onClick:()=>s(t.id),children:"Прочитано"})]},t.id))})]}):e.jsx(g,{title:"Уведомлений пока нет",description:"Здесь сохраняются результаты действий и события проектов."})})}u.__docgenInfo={description:"",methods:[],displayName:"NotificationHistory",props:{items:{required:!0,tsType:{name:"Array",elements:[{name:"ShellNotification"}],raw:"ShellNotification[]"},description:""},onRead:{required:!0,tsType:{name:"signature",type:"function",raw:"(id?: string) => void",signature:{arguments:[{type:{name:"string"},name:"id"}],return:{name:"void"}}},description:""}}};const N={title:"Shell/NotificationCenter",component:u,args:{items:[],onRead:()=>{}}},r={},i={args:{items:[{id:"n1",text:"Ран завершён",time:178925e7,source:"run",kind:"success",read:!1}]}};var o,c,d;r.parameters={...r.parameters,docs:{...(o=r.parameters)==null?void 0:o.docs,source:{originalSource:"{}",...(d=(c=r.parameters)==null?void 0:c.docs)==null?void 0:d.source}}};var m,p,l;i.parameters={...i.parameters,docs:{...(m=i.parameters)==null?void 0:m.docs,source:{originalSource:`{
  args: {
    items: [{
      id: 'n1',
      text: 'Ран завершён',
      time: 1789250000000,
      source: 'run',
      kind: 'success',
      read: false
    }]
  }
}`,...(l=(p=i.parameters)==null?void 0:p.docs)==null?void 0:l.source}}};const E=["Empty","Unread"];export{r as Empty,i as Unread,E as __namedExportsOrder,N as default};
