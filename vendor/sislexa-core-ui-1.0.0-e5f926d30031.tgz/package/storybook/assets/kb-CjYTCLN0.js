function t(e){return Math.ceil(Math.max(0,e)/4)}export{t as e};
