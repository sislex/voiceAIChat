const e=17e11;export{e as T};
