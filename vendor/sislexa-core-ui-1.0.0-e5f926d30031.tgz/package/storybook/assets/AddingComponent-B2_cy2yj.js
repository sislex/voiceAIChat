import{j as e}from"./jsx-runtime-BYYWji4R.js";import{useMDXComponents as s}from"./index-DUy19JZU.js";import{M as i}from"./index-GRoxyyiM.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-D-Q3L14w.js";import"./index-Brl4xq4Y.js";import"./index-Bhelpi4i.js";import"./index-Bhqu_tAV.js";function d(c){const n={a:"a",code:"code",h1:"h1",h2:"h2",li:"li",p:"p",pre:"pre",strong:"strong",ul:"ul",...s(),...c.components};return e.jsxs(e.Fragment,{children:[e.jsx(i,{title:"Foundations/Как добавлять компонент"}),`
`,e.jsx(n.h1,{id:"как-добавлять-компонент",children:"Как добавлять компонент"}),`
`,e.jsxs(n.p,{children:[`Короткий чек-лист перед тем, как заводить новый экран или виджет в
`,e.jsx(n.code,{children:"packages/ui"}),". Полные правила — в ",e.jsx(n.code,{children:"packages/ui/AGENTS.md"}),` (раздел «Правила») и в
`,e.jsx(n.code,{children:"docs/kb/ui.md"}),"; здесь — то, что чаще всего забывают."]}),`
`,e.jsx(n.h2,{id:"1-сначала-посмотри-нет-ли-готового-примитива",children:"1. Сначала посмотри, нет ли готового примитива"}),`
`,e.jsxs(n.p,{children:[e.jsx(n.code,{children:"components/ui/"})," уже закрывает большую часть случаев, и свой аналог заводить не нужно:"]}),`
`,e.jsxs(n.ul,{children:[`
`,e.jsxs(n.li,{children:["кнопка — ",e.jsx(n.code,{children:"Button"})," / ",e.jsx(n.code,{children:"IconButton"})," (варианты ",e.jsx(n.code,{children:"primary"})," / ",e.jsx(n.code,{children:"secondary"})," / ",e.jsx(n.code,{children:"ghost"})," / ",e.jsx(n.code,{children:"danger"}),", размеры ",e.jsx(n.code,{children:"sm"})," / ",e.jsx(n.code,{children:"md"}),");"]}),`
`,e.jsxs(n.li,{children:["модальное окно — ",e.jsx(n.code,{children:"Dialog"})," (портал, ловушка фокуса, Esc, полный экран на телефоне);"]}),`
`,e.jsxs(n.li,{children:["уведомление — ",e.jsx(n.code,{children:"useToast()"}),", подтверждение — ",e.jsx(n.code,{children:"useConfirm()"}),";"]}),`
`,e.jsxs(n.li,{children:["всплывающая панель инструмента — общий ",e.jsx(n.code,{children:"ToolFrame"}),"."]}),`
`]}),`
`,e.jsxs(n.p,{children:[e.jsx(n.code,{children:"window.confirm"})," / ",e.jsx(n.code,{children:"alert"})," / ",e.jsx(n.code,{children:"prompt"}),` запрещены: они не знают про тему, блокируют
поток и не кликаются в тестах.`]}),`
`,e.jsxs(n.h2,{id:"2-кнопка-без-подписи--iconbutton-с-aria-label-и-title",children:["2. Кнопка без подписи — ",e.jsx(n.code,{children:"IconButton"})," с ",e.jsx(n.code,{children:"aria-label"})," ",e.jsx(n.strong,{children:"и"})," ",e.jsx(n.code,{children:"title"})]}),`
`,e.jsxs(n.p,{children:["Оба поля обязательны на уровне типов, поэтому забыть их нельзя — ",e.jsx(n.code,{children:"tsc"}),` упадёт.
`,e.jsx(n.code,{children:"aria-label"})," читает скринридер, ",e.jsx(n.code,{children:"title"}),` показывает браузер как тултип: одного
`,e.jsx(n.code,{children:"aria-label"})," мало, мышью его не видно."]}),`
`,e.jsx(n.pre,{children:e.jsx(n.code,{className:"language-tsx",children:`<IconButton aria-label="Удалить задачу" title="Удалить задачу" onClick={remove}>
  ✕
</IconButton>
`})}),`
`,e.jsx(n.p,{children:`У кнопки с видимым текстом тултип не дублируй — только когда подписи одинаковые
и различает их лишь контекст.`}),`
`,e.jsx(n.h2,{id:"3-цвета--только-из-токенов",children:"3. Цвета — только из токенов"}),`
`,e.jsxs(n.p,{children:["В новом правиле не должно быть хардкода цвета. Берём токены из ",e.jsx(n.code,{children:":root"}),`:
`,e.jsx(n.code,{children:"--bg"}),", ",e.jsx(n.code,{children:"--panel"}),", ",e.jsx(n.code,{children:"--surface"}),", ",e.jsx(n.code,{children:"--text"}),", ",e.jsx(n.code,{children:"--text-dim"}),", ",e.jsx(n.code,{children:"--border"}),", ",e.jsx(n.code,{children:"--border-soft"}),`,
`,e.jsx(n.code,{children:"--accent"}),", ",e.jsx(n.code,{children:"--accent-fg"}),", ",e.jsx(n.code,{children:"--accent-soft"}),", ",e.jsx(n.code,{children:"--danger"}),", ",e.jsx(n.code,{children:"--danger-fg"}),`,
`,e.jsx(n.code,{children:"--surface-hover"}),", ",e.jsx(n.code,{children:"--ci-*"})," / ",e.jsx(n.code,{children:"--ci-*-bg"}),". Геометрия — ",e.jsx(n.code,{children:"--space-050/100/150"}),` и
`,e.jsx(n.code,{children:"--radius-medium"}),"."]}),`
`,e.jsxs(n.p,{children:["Не хватает токена — добавь его ",e.jsxs(n.strong,{children:["и в ",e.jsx(n.code,{children:":root"}),", и в ",e.jsx(n.code,{children:"[data-theme='dark']"})]}),`, а не
подставляй цвет в правило: иначе компонент выцветет в тёмной теме. Проверь
получившуюся пару в `,e.jsx(n.a,{href:"?path=/story/foundations-colors--contrast",children:"Foundations/Colors"}),` —
контраст текста на фоне должен быть не ниже AA (4.5:1; для рамок и заливок 3:1).`]}),`
`,e.jsxs(n.p,{children:["Иконка рисуется ",e.jsx(n.code,{children:"currentColor"}),`, а не своим цветом — тогда она следует теме и
варианту кнопки. Прошитые цвета видно в `,e.jsx(n.a,{href:"?path=/story/foundations-icons--grid",children:"Foundations/Icons"}),"."]}),`
`,e.jsx(n.h2,{id:"4-разметка",children:"4. Разметка"}),`
`,e.jsxs(n.ul,{children:[`
`,e.jsxs(n.li,{children:["Своего оверлея и ",e.jsx(n.code,{children:"position: fixed"})," у содержимого окна быть не должно — это дело ",e.jsx(n.code,{children:"Dialog"}),"."]}),`
`,e.jsxs(n.li,{children:["Всё, что рисует оверлей, регистрирует ",e.jsx(n.strong,{children:"один"})," слой через ",e.jsx(n.code,{children:"useDialogStack"}),"; свой слушатель Esc не вешаем."]}),`
`,e.jsxs(n.li,{children:["Мобильная вёрстка сразу: граница 720px, ",e.jsx(n.code,{children:"useMediaQuery(MOBILE_QUERY)"})," — только если нужна ",e.jsx(n.strong,{children:"другая разметка"}),", а не другие стили."]}),`
`,e.jsxs(n.li,{children:["Растущие поля ввода — ",e.jsx(n.code,{children:"useAutoGrow"}),"."]}),`
`,e.jsxs(n.li,{children:["Данные и настройки — через стор, а не ",e.jsx(n.code,{children:"fetch"})," из компонента; ошибка моста — тостом, а не тишиной."]}),`
`]}),`
`,e.jsx(n.h2,{id:"5-тесты-и-сториз",children:"5. Тесты и сториз"}),`
`,e.jsxs(n.ul,{children:[`
`,e.jsxs(n.li,{children:["Поведение — ",e.jsx(n.code,{children:"*.dom.test.tsx"})," рядом с компонентом: клик → вызван мост → изменился экран. Экраны с тостом или подтверждением рендерим через ",e.jsx(n.code,{children:"render"})," из ",e.jsx(n.code,{children:"src/test/uiRender.tsx"}),"."]}),`
`,e.jsxs(n.li,{children:["Сториз — ",e.jsx(n.code,{children:"*.stories.tsx"})," рядом же. Для примитива полезна матрица «вариант × размер × состояние» в обеих темах (см. ",e.jsx(n.code,{children:"UI/Button"}),"); для экрана — минимальный случай и пара краевых."]}),`
`,e.jsxs(n.li,{children:["Тема в сториз бесплатна: переключатель в тулбаре меняет ",e.jsx(n.code,{children:"data-theme"})," у корня и фон канвы. Если нужно сравнить темы на одном экране — рисуй два блока со своим ",e.jsx(n.code,{children:"data-theme"})," (как ",e.jsx(n.code,{children:"UI/Button"})," и ",e.jsx(n.code,{children:"Foundations/CI Status"}),")."]}),`
`,e.jsxs(n.li,{children:["Гейт: ",e.jsx(n.code,{children:"npm run -w @voicechat/ui typecheck && npm run -w @voicechat/ui test"}),". Storybook в гейт не входит, но ",e.jsx(n.code,{children:"*.stories.tsx"})," проверяются ",e.jsx(n.code,{children:"tsc"}),", а ",e.jsx(n.code,{children:"npm run -w @voicechat/ui build-storybook"})," — смоук-сборка витрины."]}),`
`]})]})}function m(c={}){const{wrapper:n}={...s(),...c.components};return n?e.jsx(n,{...c,children:e.jsx(d,{...c})}):d(c)}export{m as default};
