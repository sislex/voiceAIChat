import{within as Re,userEvent as s,expect as I}from"./index-DeN4tkzB.js";import{i as o,M as he}from"./MachineVpn-La7Ci6vX.js";import{A as Fe}from"./version-CuhpF6Tw.js";import"./tools-iBbMKii-.js";import{T}from"./time-CfyNS7J_.js";import{m as Me}from"./machines-jWuoyc9K.js";import"./jsx-runtime-BYYWji4R.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./agentProtocol-ChPLBt7B.js";const E=(e={})=>Me({version:Fe,...e});function i(e={}){return{observedAt:T,mode:"off",deviceId:"node1",tailnet:"test.ts.net",addresses:["100.64.0.1"],gatewayDeviceId:null,gatewayOnline:null,allowLan:!1,externalIp:"203.0.113.1",protected:!1,recoveryReady:!0,error:null,...e}}function a(e={}){return{state:{...o(),observed:i()},selectedGateway:{id:"gateway",name:"My Linux"},network:{tailnet:"test.ts.net",verifiedAt:T},gateways:[{id:"gateway",name:"My Linux"}],...e}}const r=e=>({read:async()=>structuredClone(e),change:async(t,P)=>({...e,state:{...e.state,desired:{mode:P.mode,gatewayId:P.gatewayId,allowLan:P.allowLan},revision:e.state.revision+1,phase:"applying"}}),connect:async()=>{}}),ea={title:"Machines/VPN",component:he,args:{agent:E(),bridge:r(a()),clock:()=>T}},c={},p={args:{bridge:r(a({network:null}))}},d={args:{bridge:{...r(a()),read:()=>new Promise(()=>{})}}},l={args:{agent:E({version:"0.1.0"})}},m={args:{agent:E({online:!1})}},g={args:{clock:()=>T+1e5}},u={args:{bridge:r(a({gateways:[]}))},play:async({canvasElement:e})=>{await s.selectOptions(await Re(e).findByLabelText("Режим VPN"),"client")}},w={args:{bridge:r(a({state:{...o(),desired:{mode:"server",gatewayId:null,allowLan:!1},observed:i({mode:"server"})}}))}},y={args:{bridge:r(a({state:{...o(),desired:{mode:"client",gatewayId:"gateway",allowLan:!1},observed:i({mode:"client",gatewayDeviceId:"node2",gatewayOnline:!0,protected:!0})}}))}},v={args:{bridge:r(a({state:{...o(),desired:{mode:"client",gatewayId:"gateway",allowLan:!1},observed:i({mode:"client",gatewayOnline:!1,protected:!0,externalIp:null})}}))}},V={args:{bridge:r(a({state:{...o(),phase:"applying",observed:i()}}))}},n=e=>({args:{bridge:r(a({state:{...o(),error:e,observed:i()}}))}}),b=n("not_installed"),f=n("service"),x=n("login"),S=n("permission"),k=n("guard"),B=n("policy"),O=n("apply"),L={play:async({canvasElement:e})=>{const t=Re(e);await s.selectOptions(await t.findByLabelText("Режим VPN"),"client"),await s.selectOptions(t.getByLabelText("VPN-шлюз"),"gateway"),await s.click(t.getByLabelText("Разрешить доступ к локальной сети")),await s.click(t.getByText("Применить режим")),await I(t.getByText(/разорвёт текущие сетевые соединения/)).toBeVisible(),await s.click(t.getByText("Подтвердить изменение VPN")),await I(await t.findByText("Запрошено: Подключиться к VPN")).toBeVisible()}};var N,A,C;c.parameters={...c.parameters,docs:{...(N=c.parameters)==null?void 0:N.docs,source:{originalSource:"{}",...(C=(A=c.parameters)==null?void 0:A.docs)==null?void 0:C.source}}};var R,h,F;p.parameters={...p.parameters,docs:{...(R=p.parameters)==null?void 0:R.docs,source:{originalSource:`{
  args: {
    bridge: vpnFixtureBridge(makeVpnView({
      network: null
    }))
  }
}`,...(F=(h=p.parameters)==null?void 0:h.docs)==null?void 0:F.source}}};var M,_,q;d.parameters={...d.parameters,docs:{...(M=d.parameters)==null?void 0:M.docs,source:{originalSource:`{
  args: {
    bridge: {
      ...vpnFixtureBridge(makeVpnView()),
      read: () => new Promise(() => undefined)
    }
  }
}`,...(q=(_=d.parameters)==null?void 0:_.docs)==null?void 0:q.source}}};var G,D,U;l.parameters={...l.parameters,docs:{...(G=l.parameters)==null?void 0:G.docs,source:{originalSource:`{
  args: {
    agent: makeAgent({
      version: '0.1.0'
    })
  }
}`,...(U=(D=l.parameters)==null?void 0:D.docs)==null?void 0:U.source}}};var j,z,H;m.parameters={...m.parameters,docs:{...(j=m.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    agent: makeAgent({
      online: false
    })
  }
}`,...(H=(z=m.parameters)==null?void 0:z.docs)==null?void 0:H.source}}};var J,K,Q;g.parameters={...g.parameters,docs:{...(J=g.parameters)==null?void 0:J.docs,source:{originalSource:`{
  args: {
    clock: () => VPN_TIME + 100_000
  }
}`,...(Q=(K=g.parameters)==null?void 0:K.docs)==null?void 0:Q.source}}};var W,X,Y;u.parameters={...u.parameters,docs:{...(W=u.parameters)==null?void 0:W.docs,source:{originalSource:`{
  args: {
    bridge: vpnFixtureBridge(makeVpnView({
      gateways: []
    }))
  },
  play: async ({
    canvasElement
  }) => {
    await userEvent.selectOptions(await within(canvasElement).findByLabelText('Режим VPN'), 'client');
  }
}`,...(Y=(X=u.parameters)==null?void 0:X.docs)==null?void 0:Y.source}}};var Z,$,ee;w.parameters={...w.parameters,docs:{...(Z=w.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    bridge: vpnFixtureBridge(makeVpnView({
      state: {
        ...initialVpnState(),
        desired: {
          mode: 'server',
          gatewayId: null,
          allowLan: false
        },
        observed: makeVpnObservation({
          mode: 'server'
        })
      }
    }))
  }
}`,...(ee=($=w.parameters)==null?void 0:$.docs)==null?void 0:ee.source}}};var ae,re,te;y.parameters={...y.parameters,docs:{...(ae=y.parameters)==null?void 0:ae.docs,source:{originalSource:`{
  args: {
    bridge: vpnFixtureBridge(makeVpnView({
      state: {
        ...initialVpnState(),
        desired: {
          mode: 'client',
          gatewayId: 'gateway',
          allowLan: false
        },
        observed: makeVpnObservation({
          mode: 'client',
          gatewayDeviceId: 'node2',
          gatewayOnline: true,
          protected: true
        })
      }
    }))
  }
}`,...(te=(re=y.parameters)==null?void 0:re.docs)==null?void 0:te.source}}};var ne,se,oe;v.parameters={...v.parameters,docs:{...(ne=v.parameters)==null?void 0:ne.docs,source:{originalSource:`{
  args: {
    bridge: vpnFixtureBridge(makeVpnView({
      state: {
        ...initialVpnState(),
        desired: {
          mode: 'client',
          gatewayId: 'gateway',
          allowLan: false
        },
        observed: makeVpnObservation({
          mode: 'client',
          gatewayOnline: false,
          protected: true,
          externalIp: null
        })
      }
    }))
  }
}`,...(oe=(se=v.parameters)==null?void 0:se.docs)==null?void 0:oe.source}}};var ie,ce,pe;V.parameters={...V.parameters,docs:{...(ie=V.parameters)==null?void 0:ie.docs,source:{originalSource:`{
  args: {
    bridge: vpnFixtureBridge(makeVpnView({
      state: {
        ...initialVpnState(),
        phase: 'applying',
        observed: makeVpnObservation()
      }
    }))
  }
}`,...(pe=(ce=V.parameters)==null?void 0:ce.docs)==null?void 0:pe.source}}};var de,le,me;b.parameters={...b.parameters,docs:{...(de=b.parameters)==null?void 0:de.docs,source:{originalSource:"preparation('not_installed')",...(me=(le=b.parameters)==null?void 0:le.docs)==null?void 0:me.source}}};var ge,ue,we;f.parameters={...f.parameters,docs:{...(ge=f.parameters)==null?void 0:ge.docs,source:{originalSource:"preparation('service')",...(we=(ue=f.parameters)==null?void 0:ue.docs)==null?void 0:we.source}}};var ye,ve,Ve;x.parameters={...x.parameters,docs:{...(ye=x.parameters)==null?void 0:ye.docs,source:{originalSource:"preparation('login')",...(Ve=(ve=x.parameters)==null?void 0:ve.docs)==null?void 0:Ve.source}}};var be,fe,xe;S.parameters={...S.parameters,docs:{...(be=S.parameters)==null?void 0:be.docs,source:{originalSource:"preparation('permission')",...(xe=(fe=S.parameters)==null?void 0:fe.docs)==null?void 0:xe.source}}};var Se,ke,Be;k.parameters={...k.parameters,docs:{...(Se=k.parameters)==null?void 0:Se.docs,source:{originalSource:"preparation('guard')",...(Be=(ke=k.parameters)==null?void 0:ke.docs)==null?void 0:Be.source}}};var Oe,Le,Te;B.parameters={...B.parameters,docs:{...(Oe=B.parameters)==null?void 0:Oe.docs,source:{originalSource:"preparation('policy')",...(Te=(Le=B.parameters)==null?void 0:Le.docs)==null?void 0:Te.source}}};var Pe,Ee,Ie;O.parameters={...O.parameters,docs:{...(Pe=O.parameters)==null?void 0:Pe.docs,source:{originalSource:"preparation('apply')",...(Ie=(Ee=O.parameters)==null?void 0:Ee.docs)==null?void 0:Ie.source}}};var Ne,Ae,Ce;L.parameters={...L.parameters,docs:{...(Ne=L.parameters)==null?void 0:Ne.docs,source:{originalSource:`{
  // @testCase TC-UI
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.selectOptions(await canvas.findByLabelText('Режим VPN'), 'client');
    await userEvent.selectOptions(canvas.getByLabelText('VPN-шлюз'), 'gateway');
    await userEvent.click(canvas.getByLabelText('Разрешить доступ к локальной сети'));
    await userEvent.click(canvas.getByText('Применить режим'));
    await expect(canvas.getByText(/разорвёт текущие сетевые соединения/)).toBeVisible();
    await userEvent.click(canvas.getByText('Подтвердить изменение VPN'));
    await expect(await canvas.findByText('Запрошено: Подключиться к VPN')).toBeVisible();
  }
}`,...(Ce=(Ae=L.parameters)==null?void 0:Ae.docs)==null?void 0:Ce.source}}};const aa=["Off","ConnectNetwork","Loading","OldAgent","Offline","Stale","NoGateways","Server","Connected","GatewayDown","Applying","MissingTailscale","StoppedService","LoginRequired","PermissionRequired","ProtectionRequired","PolicyConflict","ApplyError","ChangeRole"];export{O as ApplyError,V as Applying,L as ChangeRole,p as ConnectNetwork,y as Connected,v as GatewayDown,d as Loading,x as LoginRequired,b as MissingTailscale,u as NoGateways,c as Off,m as Offline,l as OldAgent,S as PermissionRequired,B as PolicyConflict,k as ProtectionRequired,w as Server,g as Stale,f as StoppedService,aa as __namedExportsOrder,ea as default};
