import{j as e}from"./jsx-runtime-BYYWji4R.js";import"./Toast-CcZfB6x2.js";import"./index-ClcD9ViR.js";import"./index-Brl4xq4Y.js";import{B as T}from"./Badge-zWzzcJYU.js";import{S as D,a as L,b as c,C as u,M as Q,A as _,c as M}from"./NewTaskStages-DKk_2SXR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./dateFormat-B8QlAdwY.js";const R={id:"c2",sequence:2,description:`Восстановление записи после потери сети
Сохранять аудио и продолжать отправку после повторного подключения.`,criteria:["Черновик хранится 24 часа","Статус озвучивается скринридером"],makeSources:[],attachments:[],createdBy:"alex",createdAt:Date.UTC(2026,8,7,12,40),preparationRunId:"prep-2",status:"submitted"},d=["Подготовка","Ready","Development","Component QA","Automated QA","Merge","Done"];function B({statuses:a}){return e.jsxs("div",{style:{padding:18,background:"var(--surface-sunken)"},children:[e.jsx(D,{eyebrow:"История подготовки",title:"Этапы подготовки к разработке",description:"Каждый новый набор доработок готовится отдельно.",badge:e.jsxs(T,{children:[a.length," этапа"]})}),e.jsx(L,{children:a.map((i,t)=>e.jsx(c,{number:t+1,status:i,eyebrow:`Этап ${t+1}`,title:t===0?"Подготовка задачи по первоначальному описанию":`Подготовка к разработке доработки ${t+1}`,workflow:d,cycle:t===0?null:{...R,id:`c${t}`,sequence:t+1},sourceTitle:"Источник этапа",sourceText:"Первоначальное описание, критерии приёмки, файлы задачи и Make-дизайн.",selected:t===a.length-1,connector:t<a.length-1,details:e.jsxs("p",{style:{color:"var(--text-dim)",margin:0},children:["Лента этапа — ",M[i]]})},i))})]})}const G={title:"Kanban/NewTaskCard/Stages",component:B},s={args:{statuses:["success","running"]}},r={args:{statuses:["idle","queued","running","waiting_for_answer","validating","paused","blocked","failed","timeout","cancelled","success","skipped"]}},o={args:{statuses:["success","failed","running"]},globals:{theme:"dark"}},n={args:{statuses:["success","running"]},parameters:{viewport:{defaultViewport:"mobile1"}}},l={render:()=>e.jsxs("div",{style:{padding:18,background:"var(--surface-sunken)"},children:[e.jsx(D,{eyebrow:"История проходов",title:"Component QA",description:"Отдельный проход для каждого development-цикла и набора доработок.",badge:e.jsx(T,{children:"2 прохода"})}),e.jsxs(L,{children:[e.jsx(c,{number:1,status:"success",eyebrow:"Проход 1",title:"Component QA · первоначальная постановка",workflow:d,sourceTitle:"Цикл 1",sourceText:"Результат разработки первоначальной постановки задачи.",connector:!0,children:e.jsx(u,{checks:[{id:"a",title:"Запуск прохода",note:"1 попытка",ok:!0},{id:"b",title:"Результат",note:"Успешно · 4 сент. 2026",ok:!0}]})}),e.jsxs(c,{number:2,status:"failed",eyebrow:"Проход 2",title:"Component QA · доработка 2",workflow:d,cycle:R,selected:!0,children:[e.jsx(u,{checks:[{id:"a",title:"Запуск прохода",note:"2 попытки",ok:!0},{id:"b",title:"Результат",note:"Ошибка · 7 сент. 2026",ok:!1}]}),e.jsx(Q,{items:[{label:"Прогресс",value:"64%"},{label:"Шаги",value:"4/7"},{label:"Проверки",value:"14/22"},{label:"Время",value:"8м 14с"}]}),e.jsx(_,{ariaLabel:"Попытки",selectedId:"b",attempts:[{id:"a",label:"Попытка 1",status:"cancelled",at:Date.UTC(2026,8,7,10)},{id:"b",label:"Попытка 2",status:"failed",at:Date.UTC(2026,8,7,12)}]})]})]})]})};var p,m,g;s.parameters={...s.parameters,docs:{...(p=s.parameters)==null?void 0:p.docs,source:{originalSource:`{
  args: {
    statuses: ['success', 'running']
  }
}`,...(g=(m=s.parameters)==null?void 0:m.docs)==null?void 0:g.source}}};var b,k,f;r.parameters={...r.parameters,docs:{...(b=r.parameters)==null?void 0:b.docs,source:{originalSource:`{
  args: {
    statuses: ['idle', 'queued', 'running', 'waiting_for_answer', 'validating', 'paused', 'blocked', 'failed', 'timeout', 'cancelled', 'success', 'skipped']
  }
}`,...(f=(k=r.parameters)==null?void 0:k.docs)==null?void 0:f.source}}};var w,v,S;o.parameters={...o.parameters,docs:{...(w=o.parameters)==null?void 0:w.docs,source:{originalSource:`{
  args: {
    statuses: ['success', 'failed', 'running']
  },
  globals: {
    theme: 'dark'
  }
}`,...(S=(v=o.parameters)==null?void 0:v.docs)==null?void 0:S.source}}};var h,C,j;n.parameters={...n.parameters,docs:{...(h=n.parameters)==null?void 0:h.docs,source:{originalSource:`{
  args: {
    statuses: ['success', 'running']
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(j=(C=n.parameters)==null?void 0:C.docs)==null?void 0:j.source}}};var y,A,x;l.parameters={...l.parameters,docs:{...(y=l.parameters)==null?void 0:y.docs,source:{originalSource:`{
  render: () => <div style={{
    padding: 18,
    background: 'var(--surface-sunken)'
  }}>
    <StageHeading eyebrow="История проходов" title="Component QA" description="Отдельный проход для каждого development-цикла и набора доработок." badge={<Badge>2 прохода</Badge>} />
    <StageRail>
      <StageCard number={1} status="success" eyebrow="Проход 1" title="Component QA · первоначальная постановка" workflow={workflow} sourceTitle="Цикл 1" sourceText="Результат разработки первоначальной постановки задачи." connector>
        <CheckList checks={[{
          id: 'a',
          title: 'Запуск прохода',
          note: '1 попытка',
          ok: true
        }, {
          id: 'b',
          title: 'Результат',
          note: 'Успешно · 4 сент. 2026',
          ok: true
        }]} />
      </StageCard>
      <StageCard number={2} status="failed" eyebrow="Проход 2" title="Component QA · доработка 2" workflow={workflow} cycle={cycle} selected>
        <CheckList checks={[{
          id: 'a',
          title: 'Запуск прохода',
          note: '2 попытки',
          ok: true
        }, {
          id: 'b',
          title: 'Результат',
          note: 'Ошибка · 7 сент. 2026',
          ok: false
        }]} />
        <MetricTiles items={[{
          label: 'Прогресс',
          value: '64%'
        }, {
          label: 'Шаги',
          value: '4/7'
        }, {
          label: 'Проверки',
          value: '14/22'
        }, {
          label: 'Время',
          value: '8м 14с'
        }]} />
        <AttemptList ariaLabel="Попытки" selectedId="b" attempts={[{
          id: 'a',
          label: 'Попытка 1',
          status: 'cancelled',
          at: Date.UTC(2026, 8, 7, 10)
        }, {
          id: 'b',
          label: 'Попытка 2',
          status: 'failed',
          at: Date.UTC(2026, 8, 7, 12)
        }]} />
      </StageCard>
    </StageRail>
  </div>
}`,...(x=(A=l.parameters)==null?void 0:A.docs)==null?void 0:x.source}}};const K=["PreparationRail","AllStatuses","Dark","Mobile","PipelinePass"];export{r as AllStatuses,o as Dark,n as Mobile,l as PipelinePass,s as PreparationRail,K as __namedExportsOrder,G as default};
