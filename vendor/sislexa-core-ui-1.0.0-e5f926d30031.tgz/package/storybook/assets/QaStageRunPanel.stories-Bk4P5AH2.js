import{j as v}from"./jsx-runtime-BYYWji4R.js";import{C as Oe}from"./ComponentQaPanel-Bfq_8f2I.js";import{Q as M}from"./QaStageRunPanel-BPHuupvB.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./qa-B4ObmSZt.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./StatusPill-Dn6iIbOr.js";import"./Badge-zWzzcJYU.js";import"./PanelHeading-CyQiDTtn.js";import"./MetricGrid-BvmJHgqt.js";import"./FeedItem-C_LU9yhH.js";import"./ProgressTrack-cilVHFpU.js";import"./useQaStageUpdates-CqPw_UKl.js";import"./usePolling-okXCim0o.js";import"./dateFormat-B8QlAdwY.js";function s(t,e){const a=!["queued","running","awaiting_input"].includes(e);return{id:`${t}-${e}`,projectId:"p1",taskId:"t1",kind:t==="component_qa"?"componentQaRun":t==="integration_tests"?"integrationTestsRun":"automatedQaRun",stage:t,status:e,attempt:2,triggeredBy:"alexey",branch:"CHAT-226",commitSha:"c".repeat(40),llmEngineId:"default",llmProvider:"codex",llmModel:"gpt-5.6-sol",currentStep:e==="awaiting_input"?"clarification":"quality-gate",progress:{current:e==="success"?4:2,total:4,label:"DOM / accessibility"},log:[{seq:1,at:Date.now(),stream:"system",text:"Ран запущен"},{seq:2,at:Date.now(),stream:e==="failed"?"err":"out",text:e==="failed"?"Проверка упала":"Проверка завершена"}],result:a?{gatePassed:e==="success",checks:["typecheck","DOM","integration"]}:null,scenarios:null,gateReasons:e==="gate_failed"?["missing_automation:case-1"]:[],error:e==="failed"?"Команда завершилась с кодом 1":null,createdAt:Date.now(),startedAt:Date.now(),finishedAt:a?Date.now():null,canCancel:!a,canRetry:e==="failed"||e==="gate_failed"}}const ut={title:"QA/Stage runs",excludeStories:["componentFixture"],component:M,args:{projectId:"p1",taskId:"t1",stage:"component_qa"},decorators:[(t,e)=>{const a=e.args.stage,Be=e.parameters.status??"running",x=e.parameters.verdict,He=x?{...s(a,x.passed===!0?"success":"failed"),result:x}:s(a,Be);return window.qa={listStageRuns:async()=>[He],startStageRun:async()=>s(a,"running"),cancelStageRun:async()=>s(a,"cancelled"),retryStageRun:async()=>s(a,"running"),answerStageRun:async()=>s(a,"running")},v.jsx(t,{})}]},k={activeRun:null,latestRun:null,runs:[],launchReasons:[],gateReasons:[],canStart:!1,canComplete:!1},o={id:"component",projectId:"p1",taskId:"t1",developmentRunId:"dev",linkedFixRunId:null,branch:"CHAT-459",commitSha:"a".repeat(40),attempt:1,status:"failed",uiImpact:"existing_components",readinessRunId:"prep",readinessVersion:"v1",scenarios:["passed","failed","not_applicable"].map((t,e)=>({testCase:{id:"TC"+e,title:"Сценарий "+e+" "+"ДлинноеНазвание".repeat(12),description:"",preconditions:"Storybook",testData:"",steps:"Нажать кнопку",expectedResult:"Открыто",required:!0,testType:"ui",automatable:!0,automationLinks:[],notAutomatedReason:"",alternativeManualVerification:"",comments:"",storybookStoryId:"qa-stage-runs--component-filters"},version:1,semanticHash:"v1",status:t,actualResult:"",diagnostic:""})),components:[],commands:[],artifacts:[{id:"shot",kind:"screenshot",name:"Снимок",url:"data:image/svg+xml,"+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="200" height="120"><rect width="200" height="120" fill="gray"/></svg>'),path:""}],failureClassification:null,blockerReasons:[],summary:"Найдена ошибка",log:"Long log ".repeat(1e3),storybookUrl:"https://storybook.example",createdAt:1,startedAt:2,finishedAt:42,staleReason:null,canCancel:!1,canRetry:!1};k.latestRun=o;k.runs=[o];const r={render:()=>(window.qa={getComponent:async()=>k},v.jsx(Oe,{projectId:"p1",taskId:"t1",active:!1}))},i={args:{stage:"automated_qa"},render:()=>{const t=s("automated_qa","failed");return t.scenarios=[{name:"Проверка создания задачи",startUrl:"https://preview.example",steps:[{id:"s",title:"Создать",action:{kind:"click",selector:"#create"}}]}],t.result={mode:"playwright",summary:"Сценарий провален",steps:[{id:"s",scenarioId:t.id+":scenario:0",title:"Создать задачу",status:"failed",detail:"Не найдена кнопка",durationMs:5200,pageErrors:["Ошибка страницы"]}],pageErrors:["Ошибка страницы"],screenshotUrl:o.artifacts[0].url},window.qa={listStageRuns:async()=>[t],retryStageRun:async()=>t},v.jsx(M,{projectId:"p1",taskId:"t1",stage:"automated_qa"})}},c={...r,parameters:{viewport:{defaultViewport:"mobile1"}}},d={args:{stage:"integration_tests"},render:()=>{const t={...o,readinessRunId:"prep",snapshotVersion:"v1",testCases:o.scenarios.map((e,a)=>({...e.testCase,automatable:a!==2,notAutomatedReason:a===2?"Нужен системный буфер":""})),automationLinks:[],failureClassification:null,failureReason:null,staleReason:null};return window.qa={getIntegration:async()=>({activeRun:null,latestRun:t,runs:[t],testCases:t.testCases,launchReasons:[],gateReasons:[],canStart:!1,canComplete:!1})},v.jsx(M,{projectId:"p1",taskId:"t1",stage:"integration_tests"})}},u={args:{stage:"component_qa"},parameters:{status:"running"}},m={args:{stage:"component_qa"},parameters:{status:"success"}},l={args:{stage:"component_qa"},parameters:{status:"failed"}},p={args:{stage:"component_qa"},parameters:{status:"awaiting_input"}},g={args:{stage:"integration_tests"},parameters:{status:"running"}},f={args:{stage:"integration_tests"},parameters:{status:"success"}},w={args:{stage:"integration_tests"},parameters:{status:"failed"}},h={args:{stage:"integration_tests"},parameters:{status:"awaiting_input"}},y={args:{stage:"automated_qa"},parameters:{status:"running"}},_={args:{stage:"automated_qa"},parameters:{status:"success"}},C={args:{stage:"automated_qa"},parameters:{status:"failed"}},A={args:{stage:"automated_qa"},parameters:{status:"awaiting_input"}},R={args:{stage:"automated_qa"},parameters:{verdict:{mode:"command",gatePassed:!1,passed:!1,summary:"Команда автотестов завершилась с кодом 1",classification:"implementation_defect",command:"npm test",exitCode:1,durationMs:184e3,logTail:`FAIL src/components/TaskCard.dom.test.tsx
  × показывает флаг`,steps:[],screenshotUrl:null}}},q={args:{stage:"automated_qa"},parameters:{verdict:{mode:"command",gatePassed:!1,passed:!1,summary:"Лимит времени Automated QA исчерпан",classification:"infrastructure",command:"npm test",exitCode:null,durationMs:18e5,logTail:"",steps:[],screenshotUrl:null}}},S={args:{stage:"automated_qa"},parameters:{verdict:{mode:"playwright",gatePassed:!1,passed:!1,summary:"Сценарий провален на шаге «Создать задачу»",classification:"implementation_defect",command:"http://localhost:5173/#/projects/p1",exitCode:null,durationMs:9400,logTail:"Создать задачу — failed: локатор «#create» не найден",steps:[{id:"s1",title:"Открыть доску",status:"passed",detail:"",durationMs:820},{id:"s2",title:"Создать задачу",status:"failed",detail:"локатор «#create» не найден",durationMs:5200},{id:"s3",title:"Проверить карточку",status:"skipped",detail:"Пропущен после провала предыдущего шага",durationMs:0}],screenshotUrl:null}}},n={args:{stage:"automated_qa"},parameters:{verdict:{mode:"playwright",gatePassed:!1,passed:!1,summary:"Сценарий «Доска» провален на шаге «Создать задачу»",classification:"implementation_defect",command:"http://localhost:5173/#/projects/p1",exitCode:null,durationMs:11200,logTail:"Доска: Создать задачу — failed: локатор «#create» не найден",steps:[{id:"s1",title:"Доска: Открыть доску",status:"passed",detail:"",durationMs:900},{id:"s2",title:"Доска: Создать задачу",status:"failed",detail:"локатор «#create» не найден",durationMs:5200,pageErrors:["Доска: Uncaught TypeError: Cannot read properties of undefined (reading 'columns') at BoardView.tsx:142"]}],pageErrors:["Доска: Uncaught TypeError: Cannot read properties of undefined (reading 'columns') at BoardView.tsx:142","Доска: Failed to load resource: the server responded with a status of 500 (/api/projects/p1/board)"],screenshotUrl:null}}},I={args:{stage:"automated_qa"},parameters:{verdict:{mode:"playwright",gatePassed:!0,passed:!0,summary:"Сценарий пройден: 3 шаг(ов)",classification:null,command:"http://localhost:5173/#/projects/p1",exitCode:null,durationMs:7300,logTail:"",steps:[{id:"s1",title:"Открыть доску",status:"passed",detail:"",durationMs:820},{id:"s2",title:"Создать задачу",status:"passed",detail:"",durationMs:3100},{id:"s3",title:"Проверить карточку",status:"passed",detail:"",durationMs:3380}],screenshotUrl:null}}};var P,j,T;r.parameters={...r.parameters,docs:{...(P=r.parameters)==null?void 0:P.docs,source:{originalSource:`{
  render: () => {
    window.qa = {
      getComponent: async () => componentFixture
    } as unknown as typeof window.qa;
    return <ComponentQaPanel projectId="p1" taskId="t1" active={false} />;
  }
}`,...(T=(j=r.parameters)==null?void 0:j.docs)==null?void 0:T.source}}};var U,b,F;i.parameters={...i.parameters,docs:{...(U=i.parameters)==null?void 0:U.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  render: () => {
    const run = fixture('automated_qa', 'failed');
    run.scenarios = [{
      name: 'Проверка создания задачи',
      startUrl: 'https://preview.example',
      steps: [{
        id: 's',
        title: 'Создать',
        action: {
          kind: 'click',
          selector: '#create'
        }
      }]
    }];
    run.result = {
      mode: 'playwright',
      summary: 'Сценарий провален',
      steps: [{
        id: 's',
        scenarioId: run.id + ':scenario:0',
        title: 'Создать задачу',
        status: 'failed',
        detail: 'Не найдена кнопка',
        durationMs: 5200,
        pageErrors: ['Ошибка страницы']
      }],
      pageErrors: ['Ошибка страницы'],
      screenshotUrl: componentRun.artifacts[0].url
    };
    window.qa = {
      listStageRuns: async () => [run],
      retryStageRun: async () => run
    } as unknown as typeof window.qa;
    return <QaStageRunPanel projectId="p1" taskId="t1" stage="automated_qa" />;
  }
}`,...(F=(b=i.parameters)==null?void 0:b.docs)==null?void 0:F.source}}};var E,V,Q;c.parameters={...c.parameters,docs:{...(E=c.parameters)==null?void 0:E.docs,source:{originalSource:`{
  ...ComponentFilters,
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(Q=(V=c.parameters)==null?void 0:V.docs)==null?void 0:Q.source}}};var D,L,B;d.parameters={...d.parameters,docs:{...(D=d.parameters)==null?void 0:D.docs,source:{originalSource:`{
  args: {
    stage: 'integration_tests'
  },
  render: () => {
    const run: import('@voicechat/shared/qa').IntegrationTestRun = {
      ...componentRun,
      readinessRunId: 'prep',
      snapshotVersion: 'v1',
      testCases: componentRun.scenarios.map((item, index) => ({
        ...item.testCase,
        automatable: index !== 2,
        notAutomatedReason: index === 2 ? 'Нужен системный буфер' : ''
      })),
      automationLinks: [],
      failureClassification: null,
      failureReason: null,
      staleReason: null
    };
    window.qa = {
      getIntegration: async () => ({
        activeRun: null,
        latestRun: run,
        runs: [run],
        testCases: run.testCases,
        launchReasons: [],
        gateReasons: [],
        canStart: false,
        canComplete: false
      })
    } as unknown as typeof window.qa;
    return <QaStageRunPanel projectId="p1" taskId="t1" stage="integration_tests" />;
  }
}`,...(B=(L=d.parameters)==null?void 0:L.docs)==null?void 0:B.source}}};var H,O,G;u.parameters={...u.parameters,docs:{...(H=u.parameters)==null?void 0:H.docs,source:{originalSource:`{
  args: {
    stage: 'component_qa'
  },
  parameters: {
    status: 'running'
  }
}`,...(G=(O=u.parameters)==null?void 0:O.docs)==null?void 0:G.source}}};var $,z,J;m.parameters={...m.parameters,docs:{...($=m.parameters)==null?void 0:$.docs,source:{originalSource:`{
  args: {
    stage: 'component_qa'
  },
  parameters: {
    status: 'success'
  }
}`,...(J=(z=m.parameters)==null?void 0:z.docs)==null?void 0:J.source}}};var K,N,W;l.parameters={...l.parameters,docs:{...(K=l.parameters)==null?void 0:K.docs,source:{originalSource:`{
  args: {
    stage: 'component_qa'
  },
  parameters: {
    status: 'failed'
  }
}`,...(W=(N=l.parameters)==null?void 0:N.docs)==null?void 0:W.source}}};var X,Y,Z;p.parameters={...p.parameters,docs:{...(X=p.parameters)==null?void 0:X.docs,source:{originalSource:`{
  args: {
    stage: 'component_qa'
  },
  parameters: {
    status: 'awaiting_input'
  }
}`,...(Z=(Y=p.parameters)==null?void 0:Y.docs)==null?void 0:Z.source}}};var ee,te,ae;g.parameters={...g.parameters,docs:{...(ee=g.parameters)==null?void 0:ee.docs,source:{originalSource:`{
  args: {
    stage: 'integration_tests'
  },
  parameters: {
    status: 'running'
  }
}`,...(ae=(te=g.parameters)==null?void 0:te.docs)==null?void 0:ae.source}}};var se,ne,re;f.parameters={...f.parameters,docs:{...(se=f.parameters)==null?void 0:se.docs,source:{originalSource:`{
  args: {
    stage: 'integration_tests'
  },
  parameters: {
    status: 'success'
  }
}`,...(re=(ne=f.parameters)==null?void 0:ne.docs)==null?void 0:re.source}}};var oe,ie,ce;w.parameters={...w.parameters,docs:{...(oe=w.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  args: {
    stage: 'integration_tests'
  },
  parameters: {
    status: 'failed'
  }
}`,...(ce=(ie=w.parameters)==null?void 0:ie.docs)==null?void 0:ce.source}}};var de,ue,me;h.parameters={...h.parameters,docs:{...(de=h.parameters)==null?void 0:de.docs,source:{originalSource:`{
  args: {
    stage: 'integration_tests'
  },
  parameters: {
    status: 'awaiting_input'
  }
}`,...(me=(ue=h.parameters)==null?void 0:ue.docs)==null?void 0:me.source}}};var le,pe,ge;y.parameters={...y.parameters,docs:{...(le=y.parameters)==null?void 0:le.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    status: 'running'
  }
}`,...(ge=(pe=y.parameters)==null?void 0:pe.docs)==null?void 0:ge.source}}};var fe,we,he;_.parameters={..._.parameters,docs:{...(fe=_.parameters)==null?void 0:fe.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    status: 'success'
  }
}`,...(he=(we=_.parameters)==null?void 0:we.docs)==null?void 0:he.source}}};var ye,_e,Ce;C.parameters={...C.parameters,docs:{...(ye=C.parameters)==null?void 0:ye.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    status: 'failed'
  }
}`,...(Ce=(_e=C.parameters)==null?void 0:_e.docs)==null?void 0:Ce.source}}};var Ae,Re,qe;A.parameters={...A.parameters,docs:{...(Ae=A.parameters)==null?void 0:Ae.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    status: 'awaiting_input'
  }
}`,...(qe=(Re=A.parameters)==null?void 0:Re.docs)==null?void 0:qe.source}}};var Se,Ie,ve;R.parameters={...R.parameters,docs:{...(Se=R.parameters)==null?void 0:Se.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    verdict: {
      mode: 'command',
      gatePassed: false,
      passed: false,
      summary: 'Команда автотестов завершилась с кодом 1',
      classification: 'implementation_defect',
      command: 'npm test',
      exitCode: 1,
      durationMs: 184000,
      logTail: 'FAIL src/components/TaskCard.dom.test.tsx\\n  × показывает флаг',
      steps: [],
      screenshotUrl: null
    }
  }
}`,...(ve=(Ie=R.parameters)==null?void 0:Ie.docs)==null?void 0:ve.source}}};var xe,Me,ke;q.parameters={...q.parameters,docs:{...(xe=q.parameters)==null?void 0:xe.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    verdict: {
      mode: 'command',
      gatePassed: false,
      passed: false,
      summary: 'Лимит времени Automated QA исчерпан',
      classification: 'infrastructure',
      command: 'npm test',
      exitCode: null,
      durationMs: 1800000,
      logTail: '',
      steps: [],
      screenshotUrl: null
    }
  }
}`,...(ke=(Me=q.parameters)==null?void 0:Me.docs)==null?void 0:ke.source}}};var Pe,je,Te;S.parameters={...S.parameters,docs:{...(Pe=S.parameters)==null?void 0:Pe.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    verdict: {
      mode: 'playwright',
      gatePassed: false,
      passed: false,
      summary: 'Сценарий провален на шаге «Создать задачу»',
      classification: 'implementation_defect',
      command: 'http://localhost:5173/#/projects/p1',
      exitCode: null,
      durationMs: 9400,
      logTail: 'Создать задачу — failed: локатор «#create» не найден',
      steps: [{
        id: 's1',
        title: 'Открыть доску',
        status: 'passed',
        detail: '',
        durationMs: 820
      }, {
        id: 's2',
        title: 'Создать задачу',
        status: 'failed',
        detail: 'локатор «#create» не найден',
        durationMs: 5200
      }, {
        id: 's3',
        title: 'Проверить карточку',
        status: 'skipped',
        detail: 'Пропущен после провала предыдущего шага',
        durationMs: 0
      }],
      screenshotUrl: null
    }
  }
}`,...(Te=(je=S.parameters)==null?void 0:je.docs)==null?void 0:Te.source}}};var Ue,be,Fe,Ee,Ve;n.parameters={...n.parameters,docs:{...(Ue=n.parameters)==null?void 0:Ue.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    verdict: {
      mode: 'playwright',
      gatePassed: false,
      passed: false,
      summary: 'Сценарий «Доска» провален на шаге «Создать задачу»',
      classification: 'implementation_defect',
      command: 'http://localhost:5173/#/projects/p1',
      exitCode: null,
      durationMs: 11200,
      logTail: 'Доска: Создать задачу — failed: локатор «#create» не найден',
      steps: [{
        id: 's1',
        title: 'Доска: Открыть доску',
        status: 'passed',
        detail: '',
        durationMs: 900
      }, {
        id: 's2',
        title: 'Доска: Создать задачу',
        status: 'failed',
        detail: 'локатор «#create» не найден',
        durationMs: 5200,
        pageErrors: ['Доска: Uncaught TypeError: Cannot read properties of undefined (reading \\'columns\\') at BoardView.tsx:142']
      }],
      pageErrors: ['Доска: Uncaught TypeError: Cannot read properties of undefined (reading \\'columns\\') at BoardView.tsx:142', 'Доска: Failed to load resource: the server responded with a status of 500 (/api/projects/p1/board)'],
      screenshotUrl: null
    }
  }
}`,...(Fe=(be=n.parameters)==null?void 0:be.docs)==null?void 0:Fe.source},description:{story:`Ошибки консоли страницы в вердикте (круг 27). Провалом сами по себе не
считаются, но при разборе шага отвечают быстрее снимка экрана.`,...(Ve=(Ee=n.parameters)==null?void 0:Ee.docs)==null?void 0:Ve.description}}};var Qe,De,Le;I.parameters={...I.parameters,docs:{...(Qe=I.parameters)==null?void 0:Qe.docs,source:{originalSource:`{
  args: {
    stage: 'automated_qa'
  },
  parameters: {
    verdict: {
      mode: 'playwright',
      gatePassed: true,
      passed: true,
      summary: 'Сценарий пройден: 3 шаг(ов)',
      classification: null,
      command: 'http://localhost:5173/#/projects/p1',
      exitCode: null,
      durationMs: 7300,
      logTail: '',
      steps: [{
        id: 's1',
        title: 'Открыть доску',
        status: 'passed',
        detail: '',
        durationMs: 820
      }, {
        id: 's2',
        title: 'Создать задачу',
        status: 'passed',
        detail: '',
        durationMs: 3100
      }, {
        id: 's3',
        title: 'Проверить карточку',
        status: 'passed',
        detail: '',
        durationMs: 3380
      }],
      screenshotUrl: null
    }
  }
}`,...(Le=(De=I.parameters)==null?void 0:De.docs)==null?void 0:Le.source}}};const mt=["componentFixture","ComponentFilters","AutomatedSelectiveRetry","ComponentMobile","IntegrationGroups","ComponentActive","ComponentSuccess","ComponentFailed","ComponentAwaitingAnswer","IntegrationActive","IntegrationSuccess","IntegrationFailed","IntegrationAwaitingAnswer","AutomatedActive","AutomatedSuccess","AutomatedFailed","AutomatedAwaitingAnswer","AutomatedCommandVerdict","AutomatedInfrastructureVerdict","AutomatedPlaywrightVerdict","AutomatedPlaywrightPageErrors","AutomatedPlaywrightPassed"];export{y as AutomatedActive,A as AutomatedAwaitingAnswer,R as AutomatedCommandVerdict,C as AutomatedFailed,q as AutomatedInfrastructureVerdict,n as AutomatedPlaywrightPageErrors,I as AutomatedPlaywrightPassed,S as AutomatedPlaywrightVerdict,i as AutomatedSelectiveRetry,_ as AutomatedSuccess,u as ComponentActive,p as ComponentAwaitingAnswer,l as ComponentFailed,r as ComponentFilters,c as ComponentMobile,m as ComponentSuccess,g as IntegrationActive,h as IntegrationAwaitingAnswer,w as IntegrationFailed,d as IntegrationGroups,f as IntegrationSuccess,mt as __namedExportsOrder,k as componentFixture,ut as default};
