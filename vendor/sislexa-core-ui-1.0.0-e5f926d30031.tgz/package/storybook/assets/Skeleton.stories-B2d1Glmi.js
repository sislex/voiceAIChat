import{j as e}from"./jsx-runtime-BYYWji4R.js";import"./Toast-CcZfB6x2.js";import"./index-ClcD9ViR.js";import"./index-Brl4xq4Y.js";import{S as m}from"./Skeleton-42oMjovX.js";import{T as a}from"./TaskCard-BuPlcnSm.js";import"./ProjectsApp-dH9TYZcw.js";import{m as t}from"./fixtures-CFkrQMEm.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./merge-CBY8VSWw.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./ciFormat-wlGR6KpA.js";import"./ansi-DtpFsZ9v.js";import"./kanbanMeta-CBiUCx3-.js";import"./Avatar-Ds_00F2y.js";import"./mediaQuery-CCkbYk-e.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./icons-MIP1fpxy.js";import"./projects-BdwKgk--.js";const o={projectName:"Голос Чат",allTasks:[],doneColumnIds:new Set,dragging:!1,onOpen:()=>{},onUpdate:()=>{},onDelete:()=>{},onMoveTop:()=>{},onMoveBottom:()=>{},onDragStart:()=>{},onDragEnd:()=>{}},E={title:"UI/Skeleton",component:m,parameters:{docs:{description:{component:"Скелетон показывается только на первой загрузке (данных ещё нет). При повторной загрузке содержимое остаётся на экране, а факт обновления показывает RefreshIndicator — правило в lib/loadState.ts. Анимация блика отключается медиазапросом prefers-reduced-motion: reduce."}}}},s={render:()=>e.jsxs("div",{className:"jboard",style:{display:"flex",gap:16,alignItems:"flex-start"},children:[e.jsxs("div",{className:"jcol",style:{width:272},children:[e.jsx("header",{className:"jcol-head",children:e.jsx("span",{className:"jcol-name",children:"скелетон"})}),e.jsx("div",{className:"jcol-body jcol-body--skel",children:e.jsx(m,{variant:"list",count:2,height:70,lines:2,itemClassName:"jcard-skel"})})]}),e.jsxs("div",{className:"jcol",style:{width:272},children:[e.jsx("header",{className:"jcol-head",children:e.jsx("span",{className:"jcol-name",children:"данные"})}),e.jsxs("div",{className:"jcol-body",style:{padding:"0 6px 4px",gap:8},children:[e.jsx(a,{...o,task:t({id:"g1",title:"Настоящая карточка задачи"})}),e.jsx(a,{...o,task:t({id:"g2",title:"И вторая — той же высоты"})})]})]})]})};var r,l,d,i,c;s.parameters={...s.parameters,docs:{...(r=s.parameters)==null?void 0:r.docs,source:{originalSource:`{
  render: () => <div className="jboard" style={{
    display: 'flex',
    gap: 16,
    alignItems: 'flex-start'
  }}>
      <div className="jcol" style={{
      width: 272
    }}>
        <header className="jcol-head">
          <span className="jcol-name">скелетон</span>
        </header>
        <div className="jcol-body jcol-body--skel">
          <Skeleton variant="list" count={2} height={70} lines={2} itemClassName="jcard-skel" />
        </div>
      </div>
      <div className="jcol" style={{
      width: 272
    }}>
        <header className="jcol-head">
          <span className="jcol-name">данные</span>
        </header>
        <div className="jcol-body" style={{
        padding: '0 6px 4px',
        gap: 8
      }}>
          <TaskCard {...cardProps} task={makeTask({
          id: 'g1',
          title: 'Настоящая карточка задачи'
        })} />
          <TaskCard {...cardProps} task={makeTask({
          id: 'g2',
          title: 'И вторая — той же высоты'
        })} />
        </div>
      </div>
    </div>
}`,...(d=(l=s.parameters)==null?void 0:l.docs)==null?void 0:d.source},description:{story:`Геометрия совпадает с контентом: слева косточки, справа настоящие карточки
задач той же высоты (70px). Разойдутся высоты — доска дёрнется в момент, когда
скелетон сменится данными, и это единственное, что здесь надо проверять глазами.`,...(c=(i=s.parameters)==null?void 0:i.docs)==null?void 0:c.description}}};const P=["MatchesContentGeometry"];export{s as MatchesContentGeometry,P as __namedExportsOrder,E as default};
