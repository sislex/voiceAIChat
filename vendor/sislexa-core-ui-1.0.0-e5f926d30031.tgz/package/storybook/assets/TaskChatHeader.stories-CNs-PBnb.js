import{j as e}from"./jsx-runtime-BYYWji4R.js";import{fn as ae}from"./index-DeN4tkzB.js";import{r as p}from"./index-ClcD9ViR.js";import{u as te,c as ne,a as re}from"./ci-awuetLx1.js";import{a as v,c as w,R as ce,f as oe}from"./ciFormat-wlGR6KpA.js";import{I as ie}from"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import{A as de}from"./AutomationProgressView-CuUxOFQT.js";import{r as h}from"./chat-DXuxoGTT.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./types-CmoD7ERW.js";import"./ansi-DtpFsZ9v.js";import"./usePolling-okXCim0o.js";import"./images-CH23vBlI.js";import"./tools-iBbMKii-.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";function le(a,s,m){const[u,k]=p.useState(0);return p.useEffect(()=>{if(s||a==null)return;const n=setInterval(()=>k(g=>g+1),1e3);return()=>clearInterval(n)},[s,a]),a==null?null:m()-a}function Z(a){var T,R,I;const s=a.context,m=a.now??Date.now,[u,k]=p.useState(!1),[n,g]=p.useState(a.defaultCollapsed??!0),ee=()=>g(f=>!f),t=s.run,x=t?te(t.status):!0,se=le((t==null?void 0:t.startedAt)??null,x,m),j=t?x?t.durationMs:se:null,r=ne(a.summary??(t?{status:t.status,slotProgress:{fixing:!1}}:null),s.columnSemantic==="done"),N=re(r),y=r!=null,C=n?"Развернуть виджет задачи":"Свернуть виджет задачи";return e.jsxs("section",{className:["taskchat",n&&"taskchat--collapsed",N&&`taskchat--ci-${N}`].filter(Boolean).join(" "),"data-testid":"task-chat-header",children:[s.columnSemantic==="cancelled"&&e.jsx("div",{className:"taskchat-cancelled",role:"status",children:"Задача отменена"}),e.jsxs("div",{className:"taskchat-top",children:[e.jsx(ie,{className:"taskchat-collapse",size:"sm","aria-expanded":!n,"aria-label":C,title:C,"data-testid":"task-chat-collapse",onClick:ee,children:n?"▸":"▾"}),e.jsxs("span",{className:"taskchat-crumbs",children:[!n&&e.jsxs(e.Fragment,{children:[e.jsx("span",{className:"taskchat-crumb",children:s.projectName}),s.epic&&e.jsxs(e.Fragment,{children:[e.jsx("span",{className:"taskchat-sep",children:"/"}),e.jsxs("span",{className:"taskchat-crumb",children:[s.epic.key," ",s.epic.title]})]}),s.story&&e.jsxs(e.Fragment,{children:[e.jsx("span",{className:"taskchat-sep",children:"/"}),e.jsxs("span",{className:"taskchat-crumb",children:[s.story.key," ",s.story.title]})]}),e.jsx("span",{className:"taskchat-sep",children:"/"})]}),e.jsxs("strong",{className:"taskchat-task",children:[s.task.key," ",s.task.title]})]}),n&&r&&y&&e.jsx("span",{className:`ci-lozenge ci-lozenge--${w(r.status)}`,children:v(r.status)}),e.jsx("button",{className:"taskchat-open",onClick:()=>a.onOpenTask(s.projectId,s.task.id),children:"Открыть задачу"})]}),!n&&e.jsxs("div",{className:"taskchat-meta",children:[s.columnName&&e.jsx("span",{className:"lozenge lozenge-neutral",title:"Этап воркфлоу",children:s.columnName}),r&&y&&e.jsx("span",{className:`ci-lozenge ci-lozenge--${w(r.status)}`,children:v(r.status)}),((R=(T=a.summary)==null?void 0:T.latestAttempt)==null?void 0:R.status)==="cancelled"&&e.jsx("span",{className:"taskchat-dim",children:"Последняя попытка отменена"}),t&&e.jsxs("span",{className:"taskchat-dim",children:["Режим: ",ce[t.mode]]}),j!=null&&e.jsxs("span",{className:"taskchat-dim","data-testid":"task-chat-elapsed",children:[x?"Работа заняла":"В работе"," ",oe(j)]}),s.agentName&&e.jsxs("span",{className:"taskchat-dim",title:"Машина разработки",children:["🖥 ",s.agentName]}),s.workdir&&e.jsxs("span",{className:"taskchat-dim taskchat-dir",title:s.workdir,children:["📁 ",s.workdir]}),t&&a.renderRunFeed&&e.jsx("button",{className:"taskchat-feed-toggle","aria-expanded":u,onClick:()=>k(f=>!f),children:u?"Скрыть ленту рана":"Лента рана"})]}),!n&&((I=a.summary)==null?void 0:I.progress)&&e.jsx(de,{progress:a.summary.progress,compact:!0,now:m}),!n&&u&&t&&a.renderRunFeed&&e.jsx("div",{className:"taskchat-feed",children:a.renderRunFeed(t.id)})]})}Z.__docgenInfo={description:"",methods:[],displayName:"TaskChatHeader",props:{context:{required:!0,tsType:{name:"TaskChatContext"},description:""},summary:{required:!1,tsType:{name:"union",raw:"CiRunSummary | null",elements:[{name:"CiRunSummary"},{name:"null"}]},description:`Живая сводка последнего рана задачи (тот же источник, что у доски): из неё
считается подсветка шапки. Нет сводки — берём статус из контекста, но флага
«модель чинит ошибку» там нет, и фикс выглядит как обычный ран.`},onOpenTask:{required:!0,tsType:{name:"signature",type:"function",raw:"(projectId: string, taskId: string) => void",signature:{arguments:[{type:{name:"string"},name:"projectId"},{type:{name:"string"},name:"taskId"}],return:{name:"void"}}},description:"Открыть карточку задачи на доске."},renderRunFeed:{required:!1,tsType:{name:"signature",type:"function",raw:"(runId: string) => JSX.Element",signature:{arguments:[{type:{name:"string"},name:"runId"}],return:{name:"JSX.Element"}}},description:"Лента рана рендерится наружу — чтобы не тащить сюда весь мост CI."},defaultCollapsed:{required:!1,tsType:{name:"boolean"},description:`С какого состояния открыть шапку. В приложении дефолт и есть поведение
(«свёрнута»), проп нужен витрине и тестам — иначе развёрнутый вид виден
только после клика.`},now:{required:!1,tsType:{name:"signature",type:"function",raw:"() => number",signature:{arguments:[],return:{name:"number"}}},description:""}}};const me=1e3+12*60*1e3,ze={title:"Chat/TaskChatHeader",component:Z,args:{context:h(),onOpenTask:ae(),now:()=>me,defaultCollapsed:!1},decorators:[a=>e.jsx("div",{style:{maxWidth:900},children:e.jsx(a,{})})]},c={args:{renderRunFeed:a=>e.jsxs("div",{className:"taskchat-dim",children:["Лента рана ",a]})}},o={args:{context:h({run:{id:"run-1",status:"awaiting_input",mode:"plan",startedAt:1e3,durationMs:null}})}},i={args:{context:h({run:{id:"run-1",status:"success",mode:"development",startedAt:1e3,durationMs:8*60*1e3}})}},d={args:{context:h({run:null})}},l={args:{defaultCollapsed:!0,renderRunFeed:a=>e.jsxs("div",{className:"taskchat-dim",children:["Лента рана ",a]})}};var S,F,b,_,E;c.parameters={...c.parameters,docs:{...(S=c.parameters)==null?void 0:S.docs,source:{originalSource:`{
  args: {
    renderRunFeed: runId => <div className="taskchat-dim">Лента рана {runId}</div>
  }
}`,...(b=(F=c.parameters)==null?void 0:F.docs)==null?void 0:b.source},description:{story:"Ран идёт: синяя подсветка, таймер работы, кнопка «Лента рана».",...(E=(_=c.parameters)==null?void 0:_.docs)==null?void 0:E.description}}};var A,z,O,q,M;o.parameters={...o.parameters,docs:{...(A=o.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    context: makeTaskChatContext({
      run: {
        id: 'run-1',
        status: 'awaiting_input',
        mode: 'plan',
        startedAt: 1_000,
        durationMs: null
      }
    })
  }
}`,...(O=(z=o.parameters)==null?void 0:z.docs)==null?void 0:O.source},description:{story:"Ран ждёт ответа модели — жёлтая подсветка, как у карточки на доске.",...(M=(q=o.parameters)==null?void 0:q.docs)==null?void 0:M.description}}};var L,W,B,D,H;i.parameters={...i.parameters,docs:{...(L=i.parameters)==null?void 0:L.docs,source:{originalSource:`{
  args: {
    context: makeTaskChatContext({
      run: {
        id: 'run-1',
        status: 'success',
        mode: 'development',
        startedAt: 1_000,
        durationMs: 8 * 60 * 1000
      }
    })
  }
}`,...(B=(W=i.parameters)==null?void 0:W.docs)==null?void 0:B.source},description:{story:"Ран завершён успехом: вместо таймера — итоговая длительность.",...(H=(D=i.parameters)==null?void 0:D.docs)==null?void 0:H.description}}};var P,$,J,X,U;d.parameters={...d.parameters,docs:{...(P=d.parameters)==null?void 0:P.docs,source:{originalSource:`{
  args: {
    context: makeTaskChatContext({
      run: null
    })
  }
}`,...(J=($=d.parameters)==null?void 0:$.docs)==null?void 0:J.source},description:{story:"Задача без рана: только иерархия, этап и машина.",...(U=(X=d.parameters)==null?void 0:X.docs)==null?void 0:U.description}}};var V,G,K,Q,Y;l.parameters={...l.parameters,docs:{...(V=l.parameters)==null?void 0:V.docs,source:{originalSource:`{
  args: {
    defaultCollapsed: true,
    renderRunFeed: runId => <div className="taskchat-dim">Лента рана {runId}</div>
  }
}`,...(K=(G=l.parameters)==null?void 0:G.docs)==null?void 0:K.source},description:{story:`Свёрнута — то, с чего чат задачи открывается: одна строка с ключом задачи,
статусом рана и «Открыть задачу».`,...(Y=(Q=l.parameters)==null?void 0:Q.docs)==null?void 0:Y.description}}};const Oe=["Running","AwaitingInput","Finished","WithoutRun","Collapsed"];export{o as AwaitingInput,l as Collapsed,i as Finished,c as Running,d as WithoutRun,Oe as __namedExportsOrder,ze as default};
