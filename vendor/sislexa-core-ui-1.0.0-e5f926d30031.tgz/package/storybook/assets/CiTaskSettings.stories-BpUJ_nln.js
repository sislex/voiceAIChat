import{j as p}from"./jsx-runtime-BYYWji4R.js";import{within as A,userEvent as G,expect as l,waitFor as J}from"./index-DeN4tkzB.js";import{C as K}from"./CiTaskSettings-B2RW3Tia.js";import{w as t}from"./storyBridges-cQngtz-K.js";import"./tools-iBbMKii-.js";import{f as o,e as N}from"./ci-C1-DRnym.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./ci-awuetLx1.js";import"./types-CmoD7ERW.js";import"./ciFormat-wlGR6KpA.js";import"./ansi-DtpFsZ9v.js";import"./llmAccess-BLY4i_O6.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./CiSlotEditor-DglnL3dM.js";import"./fakeApi-Dd7dGTdR.js";import"./iframe-D-Q3L14w.js";import"./agentProtocol-ChPLBt7B.js";import"./projects-BdwKgk--.js";import"./projectTypes-C-9aONcK.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";const a=({ci:e})=>{e._commands.push(...N())},Me={title:"CI/CiTaskSettings",component:K,args:{projectId:"p1",taskId:"t1",section:"model"},decorators:[e=>p.jsx("div",{style:{maxWidth:640},children:p.jsx(e,{})})]},n={decorators:[t(a)]},s={decorators:[t(e=>{a(e);const{ci:r}=e;r.getTaskCi=async()=>({config:{beforeModel:["cmd-1","cmd-2"],afterModel:["cmd-3","cmd-5"]},overridden:!0,projectDefault:{beforeModel:["cmd-1"],afterModel:[]},enabledStages:["before_model","model_work","after_model","summary"],browserCheck:{mode:"off",devServerPort:5173,startPath:"/"}}),r.getTaskCiLlm=async()=>({config:o({provider:"claude",model:"opus",mode:"plan"}),overridden:!0,projectDefault:o()})})]},d={decorators:[t(e=>{a(e),e.ci.getTaskCiLlm=async()=>({config:o({provider:"codex",model:"gpt-5-codex"}),overridden:!0,projectDefault:o()})})]},i={args:{section:"commands"},decorators:[t(e=>{a(e),e.ci.getTaskCi=async()=>({config:{beforeModel:[],afterModel:["cmd-5"]},overridden:!0,projectDefault:{beforeModel:[],afterModel:[]},enabledStages:["before_model","model_work","after_model","summary"],browserCheck:{mode:"off",devServerPort:5173,startPath:"/"}})})]},c={decorators:[t(e=>{a(e),e.ci.getTaskCiLlm=async()=>({config:o({mode:"plan"}),overridden:!1,projectDefault:o({mode:"plan"})})})]},m={decorators:[t(a)],play:async({canvasElement:e})=>{const r=A(e);await G.selectOptions(r.getByLabelText("Степень уточнения"),"detailed"),await l(r.getByLabelText("Число вопросов")).toHaveValue(3),await J(()=>l(r.getByRole("button",{name:"Сохранить движок и модель"})).toBeInTheDocument())}};var f,g,u,C,v;n.parameters={...n.parameters,docs:{...(f=n.parameters)==null?void 0:f.docs,source:{originalSource:`{
  decorators: [withBridges(seedCommands)]
}`,...(u=(g=n.parameters)==null?void 0:g.docs)==null?void 0:u.source},description:{story:"Унаследовано от проекта: слоты пусты, лозенги — «унаследовано».",...(v=(C=n.parameters)==null?void 0:C.docs)==null?void 0:v.description}}};var b,y,k,w,h;s.parameters={...s.parameters,docs:{...(b=s.parameters)==null?void 0:b.docs,source:{originalSource:`{
  decorators: [withBridges(bridges => {
    seedCommands(bridges);
    const {
      ci
    } = bridges;
    ci.getTaskCi = async () => ({
      config: {
        beforeModel: ['cmd-1', 'cmd-2'],
        afterModel: ['cmd-3', 'cmd-5']
      },
      overridden: true,
      projectDefault: {
        beforeModel: ['cmd-1'],
        afterModel: []
      },
      enabledStages: ['before_model', 'model_work', 'after_model', 'summary'],
      browserCheck: {
        mode: 'off',
        devServerPort: 5173,
        startPath: '/'
      }
    });
    ci.getTaskCiLlm = async () => ({
      config: makeLlmConfig({
        provider: 'claude',
        model: 'opus',
        mode: 'plan'
      }),
      overridden: true,
      projectDefault: makeLlmConfig()
    });
  })]
}`,...(k=(y=s.parameters)==null?void 0:y.docs)==null?void 0:k.source},description:{story:"Переопределено: у задачи свои слоты и свой движок — лозенги это показывают.",...(h=(w=s.parameters)==null?void 0:w.docs)==null?void 0:h.description}}};var x,M,T,L,S;d.parameters={...d.parameters,docs:{...(x=d.parameters)==null?void 0:x.docs,source:{originalSource:`{
  decorators: [withBridges(bridges => {
    seedCommands(bridges);
    bridges.ci.getTaskCiLlm = async () => ({
      config: makeLlmConfig({
        provider: 'codex',
        model: 'gpt-5-codex'
      }),
      overridden: true,
      projectDefault: makeLlmConfig()
    });
  })]
}`,...(T=(M=d.parameters)==null?void 0:M.docs)==null?void 0:T.source},description:{story:"Движок Codex: список моделей другой, стоимость хода Codex не сообщает.",...(S=(L=d.parameters)==null?void 0:L.docs)==null?void 0:S.description}}};var j,B,_,D,P;i.parameters={...i.parameters,docs:{...(j=i.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    section: 'commands'
  },
  decorators: [withBridges(bridges => {
    seedCommands(bridges);
    bridges.ci.getTaskCi = async () => ({
      config: {
        beforeModel: [],
        afterModel: ['cmd-5']
      },
      overridden: true,
      projectDefault: {
        beforeModel: [],
        afterModel: []
      },
      enabledStages: ['before_model', 'model_work', 'after_model', 'summary'],
      browserCheck: {
        mode: 'off',
        devServerPort: 5173,
        startPath: '/'
      }
    });
  })]
}`,...(_=(B=i.parameters)==null?void 0:B.docs)==null?void 0:_.source},description:{story:`Cleanup без подготовки: в слоте «после» есть команда, освобождающая рабочую
копию, а в «до» нет ни одной — экран предупреждает, потому что удалять будет
нечего (или не то).`,...(P=(D=i.parameters)==null?void 0:D.docs)==null?void 0:P.description}}};var E,I,O,F,R;c.parameters={...c.parameters,docs:{...(E=c.parameters)==null?void 0:E.docs,source:{originalSource:`{
  decorators: [withBridges(bridges => {
    seedCommands(bridges);
    bridges.ci.getTaskCiLlm = async () => ({
      config: makeLlmConfig({
        mode: 'plan'
      }),
      overridden: false,
      projectDefault: makeLlmConfig({
        mode: 'plan'
      })
    });
  })]
}`,...(O=(I=c.parameters)==null?void 0:I.docs)==null?void 0:O.source},description:{story:"Режим «План»: подсказка обещает остановку на одобрении плана.",...(R=(F=c.parameters)==null?void 0:F.docs)==null?void 0:R.description}}};var W,H,V,q,z;m.parameters={...m.parameters,docs:{...(W=m.parameters)==null?void 0:W.docs,source:{originalSource:`{
  decorators: [withBridges(seedCommands)],
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.selectOptions(canvas.getByLabelText('Степень уточнения'), 'detailed');
    await expect(canvas.getByLabelText('Число вопросов')).toHaveValue(3);
    await waitFor(() => expect(canvas.getByRole('button', {
      name: 'Сохранить движок и модель'
    })).toBeInTheDocument());
  }
}`,...(V=(H=m.parameters)==null?void 0:H.docs)==null?void 0:V.source},description:{story:`Детальное уточнение: появляется поле «сколько вопросов» (1–30) и кнопка
сохранения — она видна только у несохранённой правки.`,...(z=(q=m.parameters)==null?void 0:q.docs)==null?void 0:z.description}}};const Te=["Inherited","Overridden","CodexEngine","CleanupWarning","PlanMode","ClarifyDetailed"];export{m as ClarifyDetailed,i as CleanupWarning,d as CodexEngine,n as Inherited,s as Overridden,c as PlanMode,Te as __namedExportsOrder,Me as default};
