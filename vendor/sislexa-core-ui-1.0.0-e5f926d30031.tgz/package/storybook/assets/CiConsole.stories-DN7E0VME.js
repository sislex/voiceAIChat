import{within as p,userEvent as m,expect as d,fn as J}from"./index-DeN4tkzB.js";import{C as K}from"./CiConsole-Ovgqiy62.js";import{w as n}from"./storyBridges-cQngtz-K.js";import"./tools-iBbMKii-.js";import{m as F,a as P}from"./ci-C1-DRnym.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./jsx-runtime-BYYWji4R.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./clipboard-BEgkkb6H.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./AnsiText-L5oy_LV7.js";import"./ansi-DtpFsZ9v.js";import"./fakeApi-Dd7dGTdR.js";import"./iframe-D-Q3L14w.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";import"./projects-BdwKgk--.js";import"./projectTypes-C-9aONcK.js";import"./ci-awuetLx1.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";const ve={title:"CI/CiConsole",component:K,parameters:{layout:"fullscreen"},args:{runId:"run-1",onClose:J()}},o={decorators:[n()]},a={decorators:[n(({ci:t})=>{for(const e of F(2e3))t._emitLog("run-1",e)})]},s={decorators:[n(({ci:t})=>{for(const e of P("s-test"))t._emitLog("run-1",e)})]},r={decorators:[n(({ci:t})=>{for(const e of F(30))t._emitLog("run-1",e);t.consoleExec=async(e,G)=>({output:`$ ${G}
apps  packages  package.json  README.md
`,exitCode:0,rejected:!1,message:""})})],play:async({canvasElement:t})=>{const e=p(t);await m.type(e.getByLabelText("Команда консоли"),"ls"),await m.click(e.getByRole("button",{name:"Выполнить"})),await d(await e.findByText(/package\.json/)).toBeInTheDocument()}},c={decorators:[n(({ci:t})=>{t.consoleExec=async()=>({output:"",exitCode:null,rejected:!0,message:"Команда отклонена: в режиме только чтения запись запрещена"})})],play:async({canvasElement:t})=>{const e=p(t);await m.type(e.getByLabelText("Команда консоли"),"rm -rf node_modules"),await m.click(e.getByRole("button",{name:"Выполнить"})),await d(await e.findByText(/Команда отклонена/)).toBeInTheDocument()}},i={decorators:[n()],play:async({canvasElement:t})=>{const e=p(t);await m.click(e.getByRole("button",{name:"Режим редактирования"})),await d(e.getByText("режим редактирования")).toBeInTheDocument()}};var l,u,g,y,w;o.parameters={...o.parameters,docs:{...(l=o.parameters)==null?void 0:l.docs,source:{originalSource:`{
  decorators: [withBridges()]
}`,...(g=(u=o.parameters)==null?void 0:u.docs)==null?void 0:g.source},description:{story:"Пустая консоль: лога у рана ещё нет — только приглашение к команде.",...(w=(y=o.parameters)==null?void 0:y.docs)==null?void 0:w.description}}};var f,B,v,E,x;a.parameters={...a.parameters,docs:{...(f=a.parameters)==null?void 0:f.docs,source:{originalSource:`{
  decorators: [withBridges(({
    ci
  }) => {
    for (const line of makeLogSheet(2000)) ci._emitLog('run-1', line);
  })]
}`,...(v=(B=a.parameters)==null?void 0:B.docs)==null?void 0:v.source},description:{story:"Простыня лога: 2000 строк — то, что реально приходит от `npm ci`.",...(x=(E=a.parameters)==null?void 0:E.docs)==null?void 0:x.description}}};var h,k,C,L,T;s.parameters={...s.parameters,docs:{...(h=s.parameters)==null?void 0:h.docs,source:{originalSource:`{
  decorators: [withBridges(({
    ci
  }) => {
    for (const line of makeAnsiLog('s-test')) ci._emitLog('run-1', line);
  })]
}`,...(C=(k=s.parameters)==null?void 0:k.docs)==null?void 0:C.source},description:{story:`Лог с ANSI-раскраской (npm, vitest): экранированные последовательности мы не
разбираем — консоль показывает их как есть. Сториз это фиксирует: пока
ANSI-парсера нет, «цветной» вывод читается хуже обычного.`,...(T=(L=s.parameters)==null?void 0:L.docs)==null?void 0:T.description}}};var I,_,S,b,j;r.parameters={...r.parameters,docs:{...(I=r.parameters)==null?void 0:I.docs,source:{originalSource:`{
  decorators: [withBridges(({
    ci
  }) => {
    for (const line of makeLogSheet(30)) ci._emitLog('run-1', line);
    ci.consoleExec = async (_runId, command) => ({
      output: \`$ \${command}\\napps  packages  package.json  README.md\\n\`,
      exitCode: 0,
      rejected: false,
      message: ''
    });
  })],
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByLabelText('Команда консоли'), 'ls');
    await userEvent.click(canvas.getByRole('button', {
      name: 'Выполнить'
    }));
    await expect(await canvas.findByText(/package\\.json/)).toBeInTheDocument();
  }
}`,...(S=(_=r.parameters)==null?void 0:_.docs)==null?void 0:S.source},description:{story:"Выполненная команда: read-only ветка сервера отвечает по белому списку.",...(j=(b=r.parameters)==null?void 0:b.docs)==null?void 0:j.description}}};var A,R,D,M,$;c.parameters={...c.parameters,docs:{...(A=c.parameters)==null?void 0:A.docs,source:{originalSource:`{
  decorators: [withBridges(({
    ci
  }) => {
    ci.consoleExec = async () => ({
      output: '',
      exitCode: null,
      rejected: true,
      message: 'Команда отклонена: в режиме только чтения запись запрещена'
    });
  })],
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByLabelText('Команда консоли'), 'rm -rf node_modules');
    await userEvent.click(canvas.getByRole('button', {
      name: 'Выполнить'
    }));
    await expect(await canvas.findByText(/Команда отклонена/)).toBeInTheDocument();
  }
}`,...(D=(R=c.parameters)==null?void 0:R.docs)==null?void 0:D.source},description:{story:"Команда отклонена политикой: сервер режет запись по белому списку.",...($=(M=c.parameters)==null?void 0:M.docs)==null?void 0:$.description}}};var H,N,O,q,z;i.parameters={...i.parameters,docs:{...(H=i.parameters)==null?void 0:H.docs,source:{originalSource:`{
  decorators: [withBridges()],
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Режим редактирования'
    }));
    await expect(canvas.getByText('режим редактирования')).toBeInTheDocument();
  }
}`,...(O=(N=i.parameters)==null?void 0:N.docs)==null?void 0:O.source},description:{story:"Режим редактирования: лозенг меняется, а через 5 минут гаснет сам.",...(z=(q=i.parameters)==null?void 0:q.docs)==null?void 0:z.description}}};const Ee=["Empty","HugeLog","AnsiColors","AfterCommand","RejectedCommand","EditMode"];export{r as AfterCommand,s as AnsiColors,i as EditMode,o as Empty,a as HugeLog,c as RejectedCommand,Ee as __namedExportsOrder,ve as default};
