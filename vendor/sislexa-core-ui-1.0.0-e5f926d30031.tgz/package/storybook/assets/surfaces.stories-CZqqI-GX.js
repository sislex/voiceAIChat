import{j as e}from"./jsx-runtime-BYYWji4R.js";import"./types-CmoD7ERW.js";import"./tools-iBbMKii-.js";import{r as M}from"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";M.createContext(null);function q({model:a}){return e.jsxs("nav",{className:"chat-navigation","aria-label":"Разговоры",children:[e.jsx("button",{type:"button",onClick:a.create,children:"+ Новый разговор"}),a.loading?e.jsx("p",{role:"status",children:"Загрузка…"}):a.items.length===0?e.jsx("p",{children:a.emptyLabel??"Разговоров пока нет"}):e.jsx("ul",{children:a.items.map(r=>e.jsx("li",{"data-active":r.active||void 0,children:e.jsxs("button",{type:"button",onClick:r.open,children:[e.jsx("strong",{children:r.title}),r.subtitle&&e.jsx("span",{children:r.subtitle}),r.badge&&e.jsx("span",{children:r.badge})]})},r.id))})]})}function R({children:a}){return e.jsx("main",{className:"chat-page",children:a})}function k({navigation:a,children:r}){return e.jsxs("section",{className:"chat-app",children:[a&&e.jsx(q,{model:a}),e.jsx(R,{children:r})]})}function P({children:a,header:r}){return e.jsxs("section",{className:"embedded-chat","aria-label":"Встроенный чат",children:[r,e.jsx("div",{className:"embedded-chat__body",children:a})]})}function I({chat:a,rightPane:r,mobilePane:w="chat",className:A}){return e.jsxs("section",{className:["split-chat-workspace",A].filter(Boolean).join(" "),"data-mobile-pane":w,children:[e.jsx("div",{className:"split-chat-workspace__chat",children:a}),e.jsx("div",{className:"split-chat-workspace__right",children:r})]})}q.__docgenInfo={description:"",methods:[],displayName:"ChatNavigation",props:{model:{required:!0,tsType:{name:"ChatNavigationModel"},description:""}}};R.__docgenInfo={description:"",methods:[],displayName:"ChatPage",props:{children:{required:!0,tsType:{name:"ReactNode"},description:""}}};k.__docgenInfo={description:"",methods:[],displayName:"ChatApp",props:{navigation:{required:!1,tsType:{name:"ChatNavigationModel"},description:""},children:{required:!0,tsType:{name:"ReactNode"},description:""}}};P.__docgenInfo={description:"",methods:[],displayName:"EmbeddedChat",props:{children:{required:!0,tsType:{name:"ReactNode"},description:""},header:{required:!1,tsType:{name:"ReactNode"},description:""}}};I.__docgenInfo={description:"",methods:[],displayName:"SplitChatWorkspace",props:{chat:{required:!0,tsType:{name:"ReactNode"},description:""},rightPane:{required:!0,tsType:{name:"ReactNode"},description:""},mobilePane:{required:!1,tsType:{name:"union",raw:"'chat' | 'right'",elements:[{name:"literal",value:"'chat'"},{name:"literal",value:"'right'"}]},description:"",defaultValue:{value:"'chat'",computed:!1}},className:{required:!1,tsType:{name:"string"},description:""}}};const L={title:"Chat/Public surfaces",component:k},o={items:[{id:"c1",title:"Первый разговор",subtitle:"Только что",badge:"CI",active:!0,open(){}}],create(){}},s={args:{navigation:{items:[],create(){}},children:e.jsx("p",{children:"Начните новый разговор"})}},t={args:{navigation:o,children:e.jsxs("div",{children:[e.jsx("p",{children:"Пользователь: Привет"}),e.jsx("p",{children:"Ассистент: Чем помочь?"})]})}},n={args:{children:e.jsx(P,{header:e.jsx("strong",{children:"Задача CHAT-237"}),children:e.jsx("p",{children:"Встроенный разговор"})})}},i={args:{children:e.jsx(I,{chat:e.jsx("p",{children:"Чат"}),rightPane:e.jsx("div",{"aria-label":"Правая панель",children:"Reader"})})}},c={args:{navigation:o,children:e.jsxs("div",{"aria-live":"polite",children:[e.jsx("p",{children:"Ассистент печатает…"}),e.jsx("p",{children:"В очереди: 1 сообщение"})]})}},d={args:{navigation:o,children:e.jsx("p",{role:"status",children:"Соединение потеряно. Переподключение…"})}};var p,l,h;s.parameters={...s.parameters,docs:{...(p=s.parameters)==null?void 0:p.docs,source:{originalSource:`{
  args: {
    navigation: {
      items: [],
      create() {}
    },
    children: <p>Начните новый разговор</p>
  }
}`,...(h=(l=s.parameters)==null?void 0:l.docs)==null?void 0:h.source}}};var m,u,g;t.parameters={...t.parameters,docs:{...(m=t.parameters)==null?void 0:m.docs,source:{originalSource:`{
  args: {
    navigation,
    children: <div><p>Пользователь: Привет</p><p>Ассистент: Чем помочь?</p></div>
  }
}`,...(g=(u=t.parameters)==null?void 0:u.docs)==null?void 0:g.source}}};var x,j,v;n.parameters={...n.parameters,docs:{...(x=n.parameters)==null?void 0:x.docs,source:{originalSource:`{
  args: {
    children: <EmbeddedChat header={<strong>Задача CHAT-237</strong>}><p>Встроенный разговор</p></EmbeddedChat>
  }
}`,...(v=(j=n.parameters)==null?void 0:j.docs)==null?void 0:v.source}}};var b,N,C;i.parameters={...i.parameters,docs:{...(b=i.parameters)==null?void 0:b.docs,source:{originalSource:`{
  args: {
    children: <SplitChatWorkspace chat={<p>Чат</p>} rightPane={<div aria-label="Правая панель">Reader</div>} />
  }
}`,...(C=(N=i.parameters)==null?void 0:N.docs)==null?void 0:C.source}}};var f,y,_;c.parameters={...c.parameters,docs:{...(f=c.parameters)==null?void 0:f.docs,source:{originalSource:`{
  args: {
    navigation,
    children: <div aria-live="polite"><p>Ассистент печатает…</p><p>В очереди: 1 сообщение</p></div>
  }
}`,...(_=(y=c.parameters)==null?void 0:y.docs)==null?void 0:_.source}}};var S,T,E;d.parameters={...d.parameters,docs:{...(S=d.parameters)==null?void 0:S.docs,source:{originalSource:`{
  args: {
    navigation,
    children: <p role="status">Соединение потеряно. Переподключение…</p>
  }
}`,...(E=(T=d.parameters)==null?void 0:T.docs)==null?void 0:E.source}}};const O=["Empty","Messages","Embedded","Split","StreamingQueued","Disconnected"];export{d as Disconnected,n as Embedded,s as Empty,t as Messages,i as Split,c as StreamingQueued,O as __namedExportsOrder,L as default};
