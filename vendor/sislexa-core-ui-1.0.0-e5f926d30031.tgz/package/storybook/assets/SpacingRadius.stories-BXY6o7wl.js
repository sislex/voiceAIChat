import{j as e}from"./jsx-runtime-BYYWji4R.js";import{r as p}from"./index-ClcD9ViR.js";import{B as c}from"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import{P as f,S as l,M as a,a as S,b as i,c as n,r as b,v as z}from"./parts-C1UcRfGq.js";import"./_commonjsHelpers-Cpj98o6Y.js";const E={title:"Foundations/Spacing & Radius",parameters:{layout:"padded"}};function w(){const[s,t]=p.useState(null);return p.useEffect(()=>{t(b().filter(r=>r.name.startsWith("--space")||r.name.startsWith("--radius")).map(r=>({...r,usage:z(r.name)})))},[]),s}const R={"--space-050":"зазор внутри строки: иконка и подпись, лозенг и текст, ячейки лозенгов","--space-100":"шаг между соседними элементами: кнопки в ряд, поля формы, элементы шапки","--space-150":"внутренний отступ блока: паддинг кнопки, карточки, панели","--radius-medium":"скругление всего, что похоже на плашку: кнопка, поле, карточка, лозенг"},d={name:"Шкала",render:()=>{const s=w();return e.jsx(f,{title:"Spacing & Radius",lead:e.jsxs(e.Fragment,{children:["Шкала намеренно короткая: три отступа и один радиус. Нужен четвёртый шаг — сначала проверь, не подходит ли существующий; новый токен добавляется в ",e.jsx(a,{children:":root"})," и в тёмную тему сразу."]}),children:s?e.jsxs(e.Fragment,{children:[e.jsx(l,{title:"Линейки",hint:"Ширина полосы равна значению токена — масштаб настоящий, без коэффициентов.",children:e.jsx("div",{style:{display:"grid",gap:10},children:s.map(t=>e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:12},children:[e.jsx(a,{children:t.name}),e.jsx("span",{"aria-hidden":"true",style:{display:"inline-block",width:t.light,height:16,background:"var(--accent)",borderRadius:t.name.startsWith("--radius")?t.light:2}}),e.jsx("span",{style:{fontSize:12,color:"var(--text-dim)"},children:t.light})]},t.name))})}),e.jsx(l,{title:"Что для чего",children:e.jsxs("table",{style:S,children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{style:i,scope:"col",children:"токен"}),e.jsx("th",{style:i,scope:"col",children:"значение"}),e.jsx("th",{style:i,scope:"col",children:"применение"}),e.jsx("th",{style:i,scope:"col",children:"правил в app.css"}),e.jsx("th",{style:i,scope:"col",children:"примеры селекторов"})]})}),e.jsx("tbody",{children:s.map(t=>e.jsxs("tr",{children:[e.jsx("th",{style:{...n,textAlign:"left",fontWeight:400},scope:"row",children:e.jsx(a,{children:t.name})}),e.jsx("td",{style:n,children:e.jsx(a,{children:t.light})}),e.jsx("td",{style:{...n,color:"var(--text-dim)"},children:R[t.name]??"—"}),e.jsx("td",{style:n,children:t.usage.count}),e.jsx("td",{style:{...n,color:"var(--text-dim)"},children:e.jsx(a,{children:t.usage.selectors.join(", ")||"—"})})]},t.name))})]})})]}):e.jsx("p",{style:{fontSize:13,color:"var(--text-dim)"},children:"Читаем токены из app.css…"})})}},o={name:"В деле",render:()=>e.jsxs(f,{title:"Spacing & Radius — примеры",lead:"Слева живая разметка на токенах, справка — какой шаг за что отвечает. Хардкод пикселей в новых правилах не нужен: он ломает плотность на телефоне.",children:[e.jsx(l,{title:"Ряд кнопок: зазор — --space-100",hint:"Одинаковый шаг между кнопками во всём приложении: и в модалке, и в шапке чата.",children:e.jsxs("div",{style:{display:"flex",gap:"var(--space-100)"},children:[e.jsx(c,{variant:"primary",children:"Сохранить"}),e.jsx(c,{variant:"secondary",children:"Отмена"}),e.jsx(c,{variant:"ghost",children:"Ещё"})]})}),e.jsx(l,{title:"Плашка: паддинг --space-150, радиус --radius-medium",children:e.jsxs("div",{style:{background:"var(--surface)",border:"1px solid var(--border)",borderRadius:"var(--radius-medium)",padding:"var(--space-150)",display:"grid",gap:"var(--space-100)",maxWidth:360},children:[e.jsx("strong",{style:{fontSize:13},children:"Карточка"}),e.jsx("span",{style:{fontSize:12,color:"var(--text-dim)"},children:"Заголовок и текст разделены шагом --space-100."}),e.jsxs("span",{style:{display:"inline-flex",alignItems:"center",gap:"var(--space-050)",fontSize:12},children:[e.jsx("span",{className:"ci-lozenge ci-lozenge--neutral",children:"лозенг"}),"подпись через --space-050"]})]})}),e.jsx(l,{title:"Радиус на разных размерах",hint:"Один радиус на всё: кнопка, поле и лозенг выглядят одной семьёй.",children:e.jsxs("div",{style:{display:"flex",gap:"var(--space-100)",alignItems:"center",flexWrap:"wrap"},children:[[24,40,72].map(s=>e.jsx("span",{"aria-hidden":"true",style:{width:s,height:s,background:"var(--accent-soft)",border:"1px solid var(--accent)",borderRadius:"var(--radius-medium)"}},s)),e.jsxs("span",{style:{fontSize:12,color:"var(--text-dim)"},children:["круглым остаётся только ",e.jsx(a,{children:".vc-btn--circle"})," — там радиус свой, 50%"]})]})})]})};var h,m,x;d.parameters={...d.parameters,docs:{...(h=d.parameters)==null?void 0:h.docs,source:{originalSource:`{
  name: 'Шкала',
  render: () => {
    const rows = useGeometry();
    return <Page title="Spacing & Radius" lead={<>
            Шкала намеренно короткая: три отступа и один радиус. Нужен четвёртый шаг — сначала проверь, не подходит ли
            существующий; новый токен добавляется в <Mono>:root</Mono> и в тёмную тему сразу.
          </>}>
        {!rows ? <p style={{
        fontSize: 13,
        color: 'var(--text-dim)'
      }}>Читаем токены из app.css…</p> : <>
            <Section title="Линейки" hint="Ширина полосы равна значению токена — масштаб настоящий, без коэффициентов.">
              <div style={{
            display: 'grid',
            gap: 10
          }}>
                {rows.map(token => <div key={token.name} style={{
              display: 'flex',
              alignItems: 'center',
              gap: 12
            }}>
                    <Mono>{token.name}</Mono>
                    <span aria-hidden="true" style={{
                display: 'inline-block',
                width: token.light,
                height: 16,
                background: 'var(--accent)',
                borderRadius: token.name.startsWith('--radius') ? token.light : 2
              }} />
                    <span style={{
                fontSize: 12,
                color: 'var(--text-dim)'
              }}>{token.light}</span>
                  </div>)}
              </div>
            </Section>

            <Section title="Что для чего">
              <table style={TABLE}>
                <thead>
                  <tr>
                    <th style={TH} scope="col">
                      токен
                    </th>
                    <th style={TH} scope="col">
                      значение
                    </th>
                    <th style={TH} scope="col">
                      применение
                    </th>
                    <th style={TH} scope="col">
                      правил в app.css
                    </th>
                    <th style={TH} scope="col">
                      примеры селекторов
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map(token => <tr key={token.name}>
                      <th style={{
                  ...TD,
                  textAlign: 'left',
                  fontWeight: 400
                }} scope="row">
                        <Mono>{token.name}</Mono>
                      </th>
                      <td style={TD}>
                        <Mono>{token.light}</Mono>
                      </td>
                      <td style={{
                  ...TD,
                  color: 'var(--text-dim)'
                }}>{PURPOSE[token.name] ?? '—'}</td>
                      <td style={TD}>{token.usage.count}</td>
                      <td style={{
                  ...TD,
                  color: 'var(--text-dim)'
                }}>
                        <Mono>{token.usage.selectors.join(', ') || '—'}</Mono>
                      </td>
                    </tr>)}
                </tbody>
              </table>
            </Section>
          </>}
      </Page>;
  }
}`,...(x=(m=d.parameters)==null?void 0:m.docs)==null?void 0:x.source}}};var y,g,u,v,j;o.parameters={...o.parameters,docs:{...(y=o.parameters)==null?void 0:y.docs,source:{originalSource:`{
  name: 'В деле',
  render: () => <Page title="Spacing & Radius — примеры" lead="Слева живая разметка на токенах, справка — какой шаг за что отвечает. Хардкод пикселей в новых правилах не нужен: он ломает плотность на телефоне.">
      <Section title="Ряд кнопок: зазор — --space-100" hint="Одинаковый шаг между кнопками во всём приложении: и в модалке, и в шапке чата.">
        <div style={{
        display: 'flex',
        gap: 'var(--space-100)'
      }}>
          <Button variant="primary">Сохранить</Button>
          <Button variant="secondary">Отмена</Button>
          <Button variant="ghost">Ещё</Button>
        </div>
      </Section>

      <Section title="Плашка: паддинг --space-150, радиус --radius-medium">
        <div style={{
        background: 'var(--surface)',
        border: '1px solid var(--border)',
        borderRadius: 'var(--radius-medium)',
        padding: 'var(--space-150)',
        display: 'grid',
        gap: 'var(--space-100)',
        maxWidth: 360
      }}>
          <strong style={{
          fontSize: 13
        }}>Карточка</strong>
          <span style={{
          fontSize: 12,
          color: 'var(--text-dim)'
        }}>Заголовок и текст разделены шагом --space-100.</span>
          <span style={{
          display: 'inline-flex',
          alignItems: 'center',
          gap: 'var(--space-050)',
          fontSize: 12
        }}>
            <span className="ci-lozenge ci-lozenge--neutral">лозенг</span>
            подпись через --space-050
          </span>
        </div>
      </Section>

      <Section title="Радиус на разных размерах" hint="Один радиус на всё: кнопка, поле и лозенг выглядят одной семьёй.">
        <div style={{
        display: 'flex',
        gap: 'var(--space-100)',
        alignItems: 'center',
        flexWrap: 'wrap'
      }}>
          {[24, 40, 72].map(size => <span key={size} aria-hidden="true" style={{
          width: size,
          height: size,
          background: 'var(--accent-soft)',
          border: '1px solid var(--accent)',
          borderRadius: 'var(--radius-medium)'
        }} />)}
          <span style={{
          fontSize: 12,
          color: 'var(--text-dim)'
        }}>
            круглым остаётся только <Mono>.vc-btn--circle</Mono> — там радиус свой, 50%
          </span>
        </div>
      </Section>
    </Page>
}`,...(u=(g=o.parameters)==null?void 0:g.docs)==null?void 0:u.source},description:{story:"Примеры применения: ряд кнопок, плашка и вложенные отступы — всё на токенах.",...(j=(v=o.parameters)==null?void 0:v.docs)==null?void 0:j.description}}};const I=["Scale","InUse"];export{o as InUse,d as Scale,I as __namedExportsOrder,E as default};
