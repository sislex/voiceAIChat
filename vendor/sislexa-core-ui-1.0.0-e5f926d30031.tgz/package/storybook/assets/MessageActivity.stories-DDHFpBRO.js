import{j as p}from"./jsx-runtime-BYYWji4R.js";import{within as F,userEvent as J,expect as K}from"./index-DeN4tkzB.js";import{M as P}from"./MessageActivity-DR8202wn.js";import{o as Q,p as m}from"./chat-DXuxoGTT.js";import"./ci-awuetLx1.js";import"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./view-0MbJGw9Y.js";import"./animations--P72MiAI.js";import"./images-CH23vBlI.js";import"./tools-iBbMKii-.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./types-CmoD7ERW.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";const ye={title:"Chat/MessageActivity",component:P,args:{activity:Q,detailed:!1},decorators:[c=>p.jsx("div",{className:"msg ai",children:p.jsx("div",{className:"bub",style:{maxWidth:720},children:p.jsx(c,{})})})]},t={},r={args:{detailed:!0}},a={args:{detailed:!0,execTarget:"MacBook"}},s={args:{live:!0,voice:"thinking",activity:[m({summary:"Bash: npm test"})]}},i={args:{live:!0,voice:"speaking",activity:[m({kind:"thinking",summary:"Думаю над правкой"})]}},o={args:{detailed:!0,activity:Array.from({length:24},(c,e)=>m({kind:e%3===0?"tool_use":e%3===1?"tool_result":"thinking",summary:e%3===1?`✓ результат шага ${e}`:`Bash: шаг ${e} очень длинной команды с аргументами --reporter=verbose --coverage`,detail:`подробности действия ${e}`}))}},n={args:{detailed:!0},play:async({canvasElement:c})=>{const e=F(c);await J.click(e.getByText("Bash: ls -la")),await K(e.getByTestId("activity-raw")).toHaveTextContent('{"type":"assistant"}')}};var d,l,u,v,g;t.parameters={...t.parameters,docs:{...(d=t.parameters)==null?void 0:d.docs,source:{originalSource:"{}",...(u=(l=t.parameters)==null?void 0:l.docs)==null?void 0:u.source},description:{story:"Свёрнуто: только счётчик действий — так выглядит завершённый ход по умолчанию.",...(g=(v=t.parameters)==null?void 0:v.docs)==null?void 0:g.description}}};var y,h,k,x,S;r.parameters={...r.parameters,docs:{...(y=r.parameters)==null?void 0:y.docs,source:{originalSource:`{
  args: {
    detailed: true
  }
}`,...(k=(h=r.parameters)==null?void 0:h.docs)==null?void 0:k.source},description:{story:"Подробно: секция на каждое действие, детали раскрываются кликом.",...(S=(x=r.parameters)==null?void 0:x.docs)==null?void 0:S.description}}};var B,A,E,T,M;a.parameters={...a.parameters,docs:{...(B=a.parameters)==null?void 0:B.docs,source:{originalSource:`{
  args: {
    detailed: true,
    execTarget: 'MacBook'
  }
}`,...(E=(A=a.parameters)==null?void 0:A.docs)==null?void 0:E.source},description:{story:"Команды шли на машину — у каждой секции метка «где».",...(M=(T=a.parameters)==null?void 0:T.docs)==null?void 0:M.description}}};var _,f,w,C,j;s.parameters={...s.parameters,docs:{...(_=s.parameters)==null?void 0:_.docs,source:{originalSource:`{
  args: {
    live: true,
    voice: 'thinking',
    activity: [makeActivity({
      summary: 'Bash: npm test'
    })]
  }
}`,...(w=(f=s.parameters)==null?void 0:f.docs)==null?void 0:w.source},description:{story:"Живой ход: спиннер и фраза статуса вместо тишины.",...(j=(C=s.parameters)==null?void 0:C.docs)==null?void 0:j.description}}};var $,L,b,I,O;i.parameters={...i.parameters,docs:{...($=i.parameters)==null?void 0:$.docs,source:{originalSource:`{
  args: {
    live: true,
    voice: 'speaking',
    activity: [makeActivity({
      kind: 'thinking',
      summary: 'Думаю над правкой'
    })]
  }
}`,...(b=(L=i.parameters)==null?void 0:L.docs)==null?void 0:b.source},description:{story:"Живой ход во время озвучки предыдущего ответа: фраза статуса другая.",...(O=(I=i.parameters)==null?void 0:I.docs)==null?void 0:O.description}}};var W,D,H,N,Y;o.parameters={...o.parameters,docs:{...(W=o.parameters)==null?void 0:W.docs,source:{originalSource:`{
  args: {
    detailed: true,
    activity: Array.from({
      length: 24
    }, (_, i) => makeActivity({
      kind: i % 3 === 0 ? 'tool_use' : i % 3 === 1 ? 'tool_result' : 'thinking',
      summary: i % 3 === 1 ? \`✓ результат шага \${i}\` : \`Bash: шаг \${i} очень длинной команды с аргументами --reporter=verbose --coverage\`,
      detail: \`подробности действия \${i}\`
    }))
  }
}`,...(H=(D=o.parameters)==null?void 0:D.docs)==null?void 0:H.source},description:{story:"Много действий: 24 секции — проверка плотности длинного хода.",...(Y=(N=o.parameters)==null?void 0:N.docs)==null?void 0:Y.description}}};var G,R,V,q,z;n.parameters={...n.parameters,docs:{...(G=n.parameters)==null?void 0:G.docs,source:{originalSource:`{
  args: {
    detailed: true
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByText('Bash: ls -la'));
    await expect(canvas.getByTestId('activity-raw')).toHaveTextContent('{"type":"assistant"}');
  }
}`,...(V=(R=n.parameters)==null?void 0:R.docs)==null?void 0:V.source},description:{story:"Раскрытая секция: сырой stream-json и детали — по клику, как в проде.",...(z=(q=n.parameters)==null?void 0:q.docs)==null?void 0:z.description}}};const he=["Count","Detailed","OnMachine","Live","LiveWhileSpeaking","ManySections","ExpandedSection"];export{t as Count,r as Detailed,n as ExpandedSection,s as Live,i as LiveWhileSpeaking,o as ManySections,a as OnMachine,he as __namedExportsOrder,ye as default};
