import{j as e}from"./jsx-runtime-BYYWji4R.js";import{r as W}from"./index-ClcD9ViR.js";import{userEvent as r,expect as i,within as Fe,fn as C}from"./index-DeN4tkzB.js";import{P as qe,u as Ve,a as ze}from"./useAiAssist-CtGDklNp.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./clipboard-BEgkkb6H.js";import"./icons-MIP1fpxy.js";const u=[{id:"clear",title:"Ясно и конкретно",text:"Сделай формулировку ясной и однозначной.",enabled:!0,readonly:!0},{id:"short",title:"Кратко",text:"Убери повторы и лишние слова.",enabled:!0},{id:"tone",title:"Официальный тон",text:"Используй спокойный официальный тон.",enabled:!1}],Me=[{id:"1",text:"Подготовь краткое описание продукта с его ключевыми преимуществами."},{id:"2",text:"Сформулируй убедительное описание продукта и добавь призыв к действию."},{id:"3",text:"Опиши продукт официальным тоном, выделив пользу для клиента."}],Ne=C(async a=>Me);function o({generator:a=Ne,initialPrompts:s=u,writable:p=!0,maxBlocks:n,dark:c=!1}){const[l,g]=W.useState(s);return W.useEffect(()=>{document.documentElement.dataset.theme=c?"dark":"light"},[c]),e.jsx("div",{"data-theme":c?"dark":"light",style:{minHeight:760,background:c?"#111827":"#eef1f7"},children:e.jsx(qe,{open:!0,prompts:l,onPromptsChange:p?g:void 0,generate:a,onApply:C(),onClose:C(),debounceMs:50,maxBlocks:n})})}const t=()=>Fe(document.body);async function Oe(a="описание продукта"){const s=t();return await r.type(s.getByLabelText("Что нужно сформулировать"),a),await r.click(s.getByRole("button",{name:"Предложить варианты"})),await s.findByText(Me[0].text),s}async function _e(a=2){const s=await Oe(),p=await s.findAllByText("Добавить");for(let n=0;n<a;n++)await r.click(p[n]);return s}async function y(){const a=t();await r.click(a.getByLabelText("Настройки")),await i(a.getByRole("dialog")).toHaveAccessibleName("Настройки подсказок")}const rt={title:"AI Assist/PromptBuilder",parameters:{layout:"fullscreen"},render:()=>e.jsx(o,{})},x={},w={render:()=>e.jsx(o,{generator:()=>new Promise(()=>{})}),play:async()=>{await r.type(t().getByLabelText("Что нужно сформулировать"),"текст"),await r.click(t().getByRole("button",{name:"Предложить варианты"})),await i(await t().findByText("Генерирую варианты…")).toBeInTheDocument()}},B={play:async()=>{await Oe()}},h={render:()=>e.jsx(o,{generator:async()=>[]}),play:async()=>{await r.type(t().getByLabelText("Что нужно сформулировать"),"текст"),await r.click(t().getByRole("button",{name:"Предложить варианты"})),await i(await t().findByText("Вариантов нет")).toBeInTheDocument()}},T={render:()=>e.jsx(o,{generator:async()=>{throw new globalThis.Error("mock")}}),play:async()=>{await r.type(t().getByLabelText("Что нужно сформулировать"),"текст"),await r.click(t().getByRole("button",{name:"Предложить варианты"})),await i(await t().findByText("Не удалось получить варианты")).toBeInTheDocument()}},d={play:async()=>{await _e(2)}},f=d,b={render:()=>e.jsx(o,{maxBlocks:1}),play:async()=>{const a=await _e(1);i(a.getAllByText("Добавить")[1]).toBeDisabled()}},v={render:()=>e.jsx(o,{generator:async()=>[{id:"long",text:"Очень длинный текст. ".repeat(80)}]}),play:async()=>{await r.type(t().getByLabelText("Что нужно сформулировать"),"длинный текст"),await r.click(t().getByRole("button",{name:"Предложить варианты"}))}},D={render:()=>e.jsx(o,{dark:!0})},S={render:()=>e.jsx(o,{initialPrompts:[]}),play:async()=>{await y()}},k={play:async()=>{await y()}},E={play:async()=>{await y(),await r.click(t().getAllByText("Изменить")[0])}},j={play:async()=>{await y();const a=t().getByText("Ясно и конкретно").closest("article");i(Fe(a).queryByText("Удалить")).not.toBeInTheDocument()}},P={render:()=>e.jsx(o,{writable:!1}),play:async()=>{await y(),i(t().queryByText("Добавить промпт")).not.toBeInTheDocument()}};function A({textarea:a=!1,prompts:s=u,label:p="Сообщение"}){const[n,c]=W.useState(""),l=W.useRef(null),g=Ve({value:n,onChange:m=>l.current&&ze(l.current,m),prompts:s,generate:Ne}),He=a?e.jsx("textarea",{ref:l,"data-ai-assist":!0,value:n,"aria-label":p,onChange:m=>c(m.target.value)}):e.jsx("input",{ref:l,"data-ai-assist":!0,value:n,"aria-label":p,onChange:m=>c(m.target.value)});return e.jsxs("div",{style:{padding:80},children:[e.jsxs("div",{className:"ai-assist-wrap",children:[He,e.jsx("button",{className:"ai-assist-trigger",...g.triggerProps,children:"🪄"})]}),e.jsx(qe,{...g.popupProps,debounceMs:50})]})}const R={render:()=>e.jsx(A,{})},I={render:()=>e.jsx(A,{textarea:!0})},L={render:()=>e.jsxs(e.Fragment,{children:[e.jsx(A,{label:"Название",prompts:[u[0]]}),e.jsx(A,{textarea:!0,label:"Описание",prompts:[u[1],u[2]]})]})};var F,q,M;x.parameters={...x.parameters,docs:{...(F=x.parameters)==null?void 0:F.docs,source:{originalSource:"{}",...(M=(q=x.parameters)==null?void 0:q.docs)==null?void 0:M.source}}};var N,O,_;w.parameters={...w.parameters,docs:{...(N=w.parameters)==null?void 0:N.docs,source:{originalSource:`{
  render: () => <Demo generator={() => new Promise(() => {})} />,
  play: async () => {
    await userEvent.type(canvas().getByLabelText('Что нужно сформулировать'), 'текст');
    await userEvent.click(canvas().getByRole('button', {
      name: 'Предложить варианты'
    }));
    await expect(await canvas().findByText('Генерирую варианты…')).toBeInTheDocument();
  }
}`,...(_=(O=w.parameters)==null?void 0:O.docs)==null?void 0:_.source}}};var H,V,z;B.parameters={...B.parameters,docs:{...(H=B.parameters)==null?void 0:H.docs,source:{originalSource:`{
  play: async () => {
    await enter();
  }
}`,...(z=(V=B.parameters)==null?void 0:V.docs)==null?void 0:z.source}}};var G,J,K;h.parameters={...h.parameters,docs:{...(G=h.parameters)==null?void 0:G.docs,source:{originalSource:`{
  render: () => <Demo generator={async () => []} />,
  play: async () => {
    await userEvent.type(canvas().getByLabelText('Что нужно сформулировать'), 'текст');
    await userEvent.click(canvas().getByRole('button', {
      name: 'Предложить варианты'
    }));
    await expect(await canvas().findByText('Вариантов нет')).toBeInTheDocument();
  }
}`,...(K=(J=h.parameters)==null?void 0:J.docs)==null?void 0:K.source}}};var Q,U,X;T.parameters={...T.parameters,docs:{...(Q=T.parameters)==null?void 0:Q.docs,source:{originalSource:`{
  render: () => <Demo generator={async () => {
    throw new globalThis.Error('mock');
  }} />,
  play: async () => {
    await userEvent.type(canvas().getByLabelText('Что нужно сформулировать'), 'текст');
    await userEvent.click(canvas().getByRole('button', {
      name: 'Предложить варианты'
    }));
    await expect(await canvas().findByText('Не удалось получить варианты')).toBeInTheDocument();
  }
}`,...(X=(U=T.parameters)==null?void 0:U.docs)==null?void 0:X.source}}};var Y,Z,$;d.parameters={...d.parameters,docs:{...(Y=d.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  play: async () => {
    await addBlocks(2);
  }
}`,...($=(Z=d.parameters)==null?void 0:Z.docs)==null?void 0:$.source}}};var ee,te,ae;f.parameters={...f.parameters,docs:{...(ee=f.parameters)==null?void 0:ee.docs,source:{originalSource:"WithBlocks",...(ae=(te=f.parameters)==null?void 0:te.docs)==null?void 0:ae.source}}};var re,se,ne;b.parameters={...b.parameters,docs:{...(re=b.parameters)==null?void 0:re.docs,source:{originalSource:`{
  render: () => <Demo maxBlocks={1} />,
  play: async () => {
    const c = await addBlocks(1);
    expect(c.getAllByText('Добавить')[1]).toBeDisabled();
  }
}`,...(ne=(se=b.parameters)==null?void 0:se.docs)==null?void 0:ne.source}}};var oe,ce,ie;v.parameters={...v.parameters,docs:{...(oe=v.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  render: () => <Demo generator={async () => [{
    id: 'long',
    text: 'Очень длинный текст. '.repeat(80)
  }]} />,
  play: async () => {
    await userEvent.type(canvas().getByLabelText('Что нужно сформулировать'), 'длинный текст');
    await userEvent.click(canvas().getByRole('button', {
      name: 'Предложить варианты'
    }));
  }
}`,...(ie=(ce=v.parameters)==null?void 0:ce.docs)==null?void 0:ie.source}}};var pe,le,me;D.parameters={...D.parameters,docs:{...(pe=D.parameters)==null?void 0:pe.docs,source:{originalSource:`{
  render: () => <Demo dark />
}`,...(me=(le=D.parameters)==null?void 0:le.docs)==null?void 0:me.source}}};var de,ue,ye;S.parameters={...S.parameters,docs:{...(de=S.parameters)==null?void 0:de.docs,source:{originalSource:`{
  render: () => <Demo initialPrompts={[]} />,
  play: async () => {
    await settings();
  }
}`,...(ye=(ue=S.parameters)==null?void 0:ue.docs)==null?void 0:ye.source}}};var ge,xe,we;k.parameters={...k.parameters,docs:{...(ge=k.parameters)==null?void 0:ge.docs,source:{originalSource:`{
  play: async () => {
    await settings();
  }
}`,...(we=(xe=k.parameters)==null?void 0:xe.docs)==null?void 0:we.source}}};var Be,he,Te;E.parameters={...E.parameters,docs:{...(Be=E.parameters)==null?void 0:Be.docs,source:{originalSource:`{
  play: async () => {
    await settings();
    await userEvent.click(canvas().getAllByText('Изменить')[0]);
  }
}`,...(Te=(he=E.parameters)==null?void 0:he.docs)==null?void 0:Te.source}}};var fe,be,ve;j.parameters={...j.parameters,docs:{...(fe=j.parameters)==null?void 0:fe.docs,source:{originalSource:`{
  play: async () => {
    await settings();
    const row = canvas().getByText('Ясно и конкретно').closest('article')!;
    expect(within(row).queryByText('Удалить')).not.toBeInTheDocument();
  }
}`,...(ve=(be=j.parameters)==null?void 0:be.docs)==null?void 0:ve.source}}};var De,Se,ke;P.parameters={...P.parameters,docs:{...(De=P.parameters)==null?void 0:De.docs,source:{originalSource:`{
  render: () => <Demo writable={false} />,
  play: async () => {
    await settings();
    expect(canvas().queryByText('Добавить промпт')).not.toBeInTheDocument();
  }
}`,...(ke=(Se=P.parameters)==null?void 0:Se.docs)==null?void 0:ke.source}}};var Ee,je,Pe;R.parameters={...R.parameters,docs:{...(Ee=R.parameters)==null?void 0:Ee.docs,source:{originalSource:`{
  render: () => <FieldDemo />
}`,...(Pe=(je=R.parameters)==null?void 0:je.docs)==null?void 0:Pe.source}}};var Re,Ie,Le;I.parameters={...I.parameters,docs:{...(Re=I.parameters)==null?void 0:Re.docs,source:{originalSource:`{
  render: () => <FieldDemo textarea />
}`,...(Le=(Ie=I.parameters)==null?void 0:Ie.docs)==null?void 0:Le.source}}};var We,Ae,Ce;L.parameters={...L.parameters,docs:{...(We=L.parameters)==null?void 0:We.docs,source:{originalSource:`{
  render: () => <><FieldDemo label="Название" prompts={[prompts[0]]} /><FieldDemo textarea label="Описание" prompts={[prompts[1], prompts[2]]} /></>
}`,...(Ce=(Ae=L.parameters)==null?void 0:Ae.docs)==null?void 0:Ce.source}}};const st=["Default","Loading","SuggestionsReady","EmptyResult","Error","WithBlocks","WithPreview","MaxBlocksReached","LongContent","DarkTheme","SettingsEmpty","SettingsWithPrompts","SettingsEditing","SettingsWithReadonlyPrompts","SettingsWithoutOnPromptsChange","InsideInput","InsideTextarea","TwoFieldsWithDifferentPrompts"];export{D as DarkTheme,x as Default,h as EmptyResult,T as Error,R as InsideInput,I as InsideTextarea,w as Loading,v as LongContent,b as MaxBlocksReached,E as SettingsEditing,S as SettingsEmpty,k as SettingsWithPrompts,j as SettingsWithReadonlyPrompts,P as SettingsWithoutOnPromptsChange,B as SuggestionsReady,L as TwoFieldsWithDifferentPrompts,d as WithBlocks,f as WithPreview,st as __namedExportsOrder,rt as default};
