import{j as p}from"./jsx-runtime-BYYWji4R.js";import{within as I,userEvent as c,expect as l,fn as N}from"./index-DeN4tkzB.js";import{D as R}from"./agentProtocol-ChPLBt7B.js";import{A as G}from"./AgentCard-DXgovfRw.js";import"./tools-iBbMKii-.js";import"./ci-awuetLx1.js";import{m,a as s,b as H,c as U}from"./machines-jWuoyc9K.js";import"./clarification-D4IICFLg.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./types-CmoD7ERW.js";import"./version-CuhpF6Tw.js";import"./time-CfyNS7J_.js";import"./kb-CjYTCLN0.js";const se={title:"Machines/AgentCard",component:G,args:{agent:m({id:"m1",name:"MacBook",policy:s()}),onSetPolicy:N()},decorators:[e=>p.jsx("div",{style:{maxWidth:640},children:p.jsx(e,{})})]},a={},n={args:{agent:H({id:"m2",name:"Домашний ПК",policy:s()})}},t={args:{agent:m({id:"m3",name:"Новая машина",policy:{...R}})}},r={args:{agent:U({name:"Pixel (только чтение)",policy:s({allowNetwork:!1,allowWrite:!1,allowPatterns:["^git ","^npm "],skills:[]})})},play:async({canvasElement:e})=>{await l(I(e).getByText("^git")).toBeInTheDocument()}},o={args:{agent:m({id:"m1",name:"MacBook",policy:s({skills:[]})})},play:async({args:e,canvasElement:M})=>{const i=I(M);await c.type(i.getByPlaceholderText("Имя (напр. сборка)"),"сборка"),await c.type(i.getByPlaceholderText("Команда (npm run build)"),"npm run build"),await c.click(i.getByLabelText("Добавить навык")),await l(e.onSetPolicy).toHaveBeenCalledWith("m1",l.objectContaining({skills:[{name:"сборка",command:"npm run build"}]}))}};var d,g,y,u,k;a.parameters={...a.parameters,docs:{...(d=a.parameters)==null?void 0:d.docs,source:{originalSource:"{}",...(y=(g=a.parameters)==null?void 0:g.docs)==null?void 0:y.source},description:{story:"Заполненная политика: разрешённый каталог, запреты и два навыка.",...(k=(u=a.parameters)==null?void 0:u.docs)==null?void 0:k.description}}};var P,f,x,w,A;n.parameters={...n.parameters,docs:{...(P=n.parameters)==null?void 0:P.docs,source:{originalSource:`{
  args: {
    agent: makeOfflineAgent({
      id: 'm2',
      name: 'Домашний ПК',
      policy: makePolicy()
    })
  }
}`,...(x=(f=n.parameters)==null?void 0:f.docs)==null?void 0:x.source},description:{story:"Офлайн: агент на машине не запущен, но политику править можно — она живёт на сервере.",...(A=(w=n.parameters)==null?void 0:w.docs)==null?void 0:A.description}}};var v,B,E,h,T;t.parameters={...t.parameters,docs:{...(v=t.parameters)==null?void 0:v.docs,source:{originalSource:`{
  args: {
    agent: makeAgent({
      id: 'm3',
      name: 'Новая машина',
      policy: {
        ...DEFAULT_AGENT_POLICY
      }
    })
  }
}`,...(E=(B=t.parameters)==null?void 0:B.docs)==null?void 0:E.source},description:{story:"Пустая политика (машина только добавлена): всё разрешено, списки пусты.",...(T=(h=t.parameters)==null?void 0:h.docs)==null?void 0:T.description}}};var b,S,C,D,O;r.parameters={...r.parameters,docs:{...(b=r.parameters)==null?void 0:b.docs,source:{originalSource:`{
  args: {
    agent: makeAndroidAgent({
      name: 'Pixel (только чтение)',
      policy: makePolicy({
        allowNetwork: false,
        allowWrite: false,
        allowPatterns: ['^git ', '^npm '],
        skills: []
      })
    })
  },
  play: async ({
    canvasElement
  }) => {
    await expect(within(canvasElement).getByText('^git')).toBeInTheDocument();
  }
}`,...(C=(S=r.parameters)==null?void 0:S.docs)==null?void 0:C.source},description:{story:"Жёсткая политика: разрешены только свои паттерны, навыков нет.",...(O=(D=r.parameters)==null?void 0:D.docs)==null?void 0:O.description}}};var j,L,_,W,F;o.parameters={...o.parameters,docs:{...(j=o.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    agent: makeAgent({
      id: 'm1',
      name: 'MacBook',
      policy: makePolicy({
        skills: []
      })
    })
  },
  play: async ({
    args,
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByPlaceholderText('Имя (напр. сборка)'), 'сборка');
    await userEvent.type(canvas.getByPlaceholderText('Команда (npm run build)'), 'npm run build');
    await userEvent.click(canvas.getByLabelText('Добавить навык'));
    await expect(args.onSetPolicy).toHaveBeenCalledWith('m1', expect.objectContaining({
      skills: [{
        name: 'сборка',
        command: 'npm run build'
      }]
    }));
  }
}`,...(_=(L=o.parameters)==null?void 0:L.docs)==null?void 0:_.source},description:{story:"Новый навык: имя, команда, «Добавить» — политика уходит сразу, без «Сохранить».",...(F=(W=o.parameters)==null?void 0:W.docs)==null?void 0:F.description}}};const ie=["FilledPolicy","Offline","DefaultPolicy","RestrictedPolicy","AddSkill"];export{o as AddSkill,t as DefaultPolicy,a as FilledPolicy,n as Offline,r as RestrictedPolicy,ie as __namedExportsOrder,se as default};
