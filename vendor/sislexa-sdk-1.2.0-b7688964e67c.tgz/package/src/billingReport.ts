import { assertPlatformIdentifier } from './platformOperation.js'
import { parseBillingUsageEvidence, type BillingUsageEvidence } from './billingUsage.js'
import type { PlatformTokenCounts } from './platformUsage.js'

export interface BillingUsageEvent {
  readonly version: 1
  readonly eventId: string
  readonly reservationId: string
  readonly operationId: string
  readonly userId: string
  readonly tenantId: string
  readonly environmentId: string
  readonly actorClientId: string
  readonly originModuleId: string
  readonly occurredAt: number
  readonly actualMicroUsd: number
  readonly usage?: BillingUsageEvidence
}

export interface BillingUsageReportFilter {
  readonly userId: string
  readonly tenantId: string
  readonly environmentId: string
  readonly from: number
  readonly to: number
}

export interface BillingUsageModule extends PlatformTokenCounts {
  readonly moduleId: string
  readonly events: number
  readonly actualMicroUsd: number
  /** Integer hundredths of one percent; null means there is no matching cost. */
  readonly costShareBasisPoints: number | null
  /** Integer hundredths of one percent; null means no token evidence exists. */
  readonly tokenShareBasisPoints: number | null
  readonly totalTokens: number
}

export interface BillingUsageDay extends PlatformTokenCounts {
  readonly day: string
  readonly events: number
  readonly actualMicroUsd: number
  readonly totalTokens: number
}

export interface BillingUsageReport extends PlatformTokenCounts {
  readonly version: 1
  readonly from: number
  readonly to: number
  readonly events: number
  readonly actualMicroUsd: number
  readonly totalTokens: number
  readonly modules: readonly BillingUsageModule[]
  readonly days: readonly BillingUsageDay[]
}

const TOKEN_FIELDS = ['inputTokens', 'outputTokens', 'cacheReadTokens', 'cacheWriteTokens'] as const
type Totals = { -readonly [K in keyof PlatformTokenCounts]: number } & { events: number; actualMicroUsd: number; totalTokens: number }

const empty = (): Totals => ({
  inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0,
  events: 0, actualMicroUsd: 0, totalTokens: 0,
})

function integer(value: unknown, field: string): asserts value is number {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) throw new Error(`Invalid billing report field: ${field}`)
}

function add(left: number, right: number): number {
  const result = left + right
  if (!Number.isSafeInteger(result)) throw new Error('Billing report exceeds safe integer range')
  return result
}

function share(value: number, total: number): number | null {
  if (total === 0) return null
  return Number((BigInt(value) * 10_000n + BigInt(total) / 2n) / BigInt(total))
}

/** Normalize an event before a service returns or aggregates it. Authentication
 * and producer authorization remain the responsibility of the service boundary. */
export function parseBillingUsageEvent(value: BillingUsageEvent): BillingUsageEvent {
  if (!value || value.version !== 1) throw new Error('Unsupported billing usage event')
  const fields = ['eventId', 'reservationId', 'operationId', 'userId', 'tenantId', 'environmentId', 'actorClientId', 'originModuleId'] as const
  for (const field of fields) assertPlatformIdentifier(value[field], field)
  integer(value.occurredAt, 'occurredAt')
  integer(value.actualMicroUsd, 'actualMicroUsd')
  const usage = value.usage === undefined ? undefined : parseBillingUsageEvidence(value.usage)
  return Object.freeze({
    version: 1, eventId: value.eventId, reservationId: value.reservationId, operationId: value.operationId,
    userId: value.userId, tenantId: value.tenantId, environmentId: value.environmentId,
    actorClientId: value.actorClientId, originModuleId: value.originModuleId,
    occurredAt: value.occurredAt, actualMicroUsd: value.actualMicroUsd, ...(usage ? { usage } : {}),
  })
}

/** Summarize finalized ledger events for one authenticated account. Periods are
 * half-open [from, to); day buckets use UTC so callers can split local periods. */
export function summarizeBillingUsage(events: readonly BillingUsageEvent[], filter: BillingUsageReportFilter): BillingUsageReport {
  for (const field of ['userId', 'tenantId', 'environmentId'] as const) assertPlatformIdentifier(filter[field], field)
  integer(filter.from, 'from'); integer(filter.to, 'to')
  if (filter.to <= filter.from) throw new Error('Invalid billing report period')
  const totals = empty(), modules = new Map<string, Totals>(), days = new Map<string, Totals>(), seen = new Map<string, string>()
  for (const raw of events) {
    const event = parseBillingUsageEvent(raw)
    const fingerprint = JSON.stringify(event)
    const previous = seen.get(event.eventId)
    if (previous !== undefined) {
      if (previous !== fingerprint) throw new Error('Conflicting billing usage event')
      continue
    }
    seen.set(event.eventId, fingerprint)
    if (event.userId !== filter.userId || event.tenantId !== filter.tenantId || event.environmentId !== filter.environmentId
      || event.occurredAt < filter.from || event.occurredAt >= filter.to) continue
    const module = modules.get(event.originModuleId) ?? empty()
    const dayKey = new Date(event.occurredAt).toISOString().slice(0, 10)
    const day = days.get(dayKey) ?? empty()
    for (const target of [totals, module, day]) {
      target.events = add(target.events, 1)
      target.actualMicroUsd = add(target.actualMicroUsd, event.actualMicroUsd)
      if (event.usage) for (const field of TOKEN_FIELDS) {
        target[field] = add(target[field], event.usage.tokens[field])
        target.totalTokens = add(target.totalTokens, event.usage.tokens[field])
      }
    }
    modules.set(event.originModuleId, module)
    days.set(dayKey, day)
  }
  return {
    version: 1, from: filter.from, to: filter.to, ...totals,
    modules: [...modules].map(([moduleId, value]) => ({ moduleId, ...value,
      costShareBasisPoints: share(value.actualMicroUsd, totals.actualMicroUsd),
      tokenShareBasisPoints: share(value.totalTokens, totals.totalTokens),
    })).sort((a, b) => b.actualMicroUsd - a.actualMicroUsd || b.totalTokens - a.totalTokens || a.moduleId.localeCompare(b.moduleId)),
    days: [...days].map(([day, value]) => ({ day, ...value })).sort((a, b) => a.day.localeCompare(b.day)),
  }
}
