import { createServer } from 'node:http'
import { createReadStream } from 'node:fs'
import { stat } from 'node:fs/promises'
import { resolve, extname, sep } from 'node:path'
import { createGateway, localConfig } from './gateway.mjs'
const config = localConfig(), gateway = createGateway(config), root = resolve(import.meta.dirname, 'dist')
const server = createServer((req, res) => gateway(req, res, () => {
  void (async () => {
    if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(405); res.end(); return }
    let file
    try { const url = new URL(req.url, 'http://localhost'); file = resolve(root, '.' + decodeURIComponent(url.pathname === '/' ? '/index.html' : url.pathname)) }
    catch { res.writeHead(400); res.end(); return }
    if (!file.startsWith(root + sep)) { res.writeHead(404); res.end(); return }
    try {
      const info = await stat(file)
      if (!info.isFile()) throw Error('not a file')
      const type = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.webmanifest': 'application/manifest+json', '.png': 'image/png' }[extname(file)] || 'application/octet-stream'
      res.writeHead(200, { 'content-type': type, 'content-length': info.size, 'cache-control': 'no-store', 'x-sislexa-ui': 'image-studio', 'x-content-type-options': 'nosniff', 'x-robots-tag': 'noindex' })
      if (req.method === 'HEAD') res.end()
      else createReadStream(file).on('error', () => res.destroy()).pipe(res)
    } catch { res.writeHead(404); res.end('Not found. Build the standalone studio with npm run studio.') }
  })()
}))
server.listen(config.port, '127.0.0.1', () => console.log(`Image Studio: http://127.0.0.1:${config.port}`))
for (const signal of ['SIGTERM', 'SIGINT']) process.once(signal, () => { server.closeAllConnections(); server.close() })
