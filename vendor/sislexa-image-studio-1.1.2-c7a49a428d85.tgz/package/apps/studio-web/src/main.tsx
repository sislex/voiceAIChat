import { createRoot } from 'react-dom/client'
import { App } from './App'
import '@voicechat/ui-kit/styles.css'
import '@voicechat/ui-foundation/styles.css'
import '@voicechat/image-studio-app/styles.css'
import './styles.css'

createRoot(document.getElementById('root')!).render(<App />)
