import type { ImageStudioPaneProps } from '@voicechat/image-studio-app/panelContract'
import type { Conversation, SessionUser } from '@shared/types'
import { serverErrorMessage } from '@shared/serverErrors'

export class HttpError extends Error {
  constructor(readonly status: number, message: string) { super(message) }
}

export function createStudioClient(fetcher: typeof fetch = fetch, cookie = () => document.cookie) {
  async function response(path: string, init: RequestInit = {}) {
    const headers = new Headers(init.headers)
    if (init.body !== undefined) headers.set('content-type', 'application/json')
    const csrf = cookie().split(';').map(item => item.trim()).find(item => item.startsWith('vc_csrf='))?.slice(8)
    if (csrf) headers.set('x-vc-csrf', decodeURIComponent(csrf))
    const result = await fetcher(path, { ...init, headers, credentials: 'include' })
    if (!result.ok) {
      const body: unknown = await result.json().catch(() => null)
      throw new HttpError(result.status, result.status === 401 ? 'Сессия завершена. Войдите снова.' : serverErrorMessage(body && typeof body === 'object' ? body : null) || `Не удалось выполнить запрос (${result.status}).`)
    }
    return result
  }
  async function request<T>(path: string, init?: RequestInit): Promise<T> {
    const result = await response(path, init)
    const text = await result.text()
    return text ? JSON.parse(text) as T : undefined as T
  }
  const path = (id: string, suffix: string) => `/api/image-studio/${encodeURIComponent(id)}/${suffix}`
  const post = <T,>(id: string, suffix: string, body: unknown = {}) => request<T>(path(id, suffix), { method: 'POST', body: JSON.stringify(body) })
  const api: ImageStudioPaneProps['api'] = {
    'imgstudio:list': ({ conversationId }) => request(path(conversationId, 'files')),
    'imgstudio:read': async ({ conversationId, path: file }) => {
      const result = await response(path(conversationId, `file?path=${encodeURIComponent(file)}`))
      const bytes = new Uint8Array(await result.arrayBuffer())
      let binary = ''
      for (const byte of bytes) binary += String.fromCharCode(byte)
      return { path: file, dataBase64: btoa(binary) }
    },
    'imgstudio:upload': ({ conversationId, ...body }) => post(conversationId, 'file', body),
    'imgstudio:delete': ({ conversationId, path: file }) => request(path(conversationId, `file?path=${encodeURIComponent(file)}`), { method: 'DELETE' }),
    'imgstudio:rename': ({ conversationId, ...body }) => post(conversationId, 'rename', body),
    'imgstudio:generate': ({ conversationId, ...body }) => post(conversationId, 'generate', body),
    'imgstudio:edit': ({ conversationId, ...body }) => post(conversationId, 'edit', body),
    'imgstudio:retouch': ({ conversationId, ...body }) => post(conversationId, 'retouch', body),
    'imgstudio:extract': ({ conversationId, ...body }) => post(conversationId, 'extract', body),
    'imgstudio:place': ({ conversationId, ...body }) => post(conversationId, 'place', body),
    'imgstudio:restoreVersion': ({ conversationId, ...body }) => post(conversationId, 'restore-version', body),
    'imgstudio:cancel': ({ conversationId }) => post(conversationId, 'cancel'),
    'imgstudio:run': ({ conversationId }) => request(path(conversationId, 'run')),
    'imgstudio:publish': ({ conversationId, ...body }) => post(conversationId, 'publish', body),
    'imgstudio:publication': ({ conversationId }) => request(path(conversationId, 'publication')),
    'imgstudio:unpublish': ({ conversationId }) => request(path(conversationId, 'publish'), { method: 'DELETE' }),
    'imgstudio:transfer': ({ conversationId, ...body }) => post(conversationId, 'transfer', body),
    'imgstudio:trash': ({ conversationId }) => request(path(conversationId, 'trash')),
    'imgstudio:restore': ({ conversationId, name }) => post(conversationId, 'restore', { name }),
    'imgstudio:purge': ({ conversationId, name }) => post(conversationId, 'trash/purge', name === undefined ? {} : { name }),
    'imgstudio:preview': ({ conversationId, settings }) => post(conversationId, 'preview', { settings }),
    'imgstudio:enqueue': ({ conversationId, ...body }) => post(conversationId, 'tasks', body),
    'imgstudio:tasks': ({ conversationId }) => request(path(conversationId, 'tasks')),
    'imgstudio:cancelTask': ({ conversationId, taskId }) => request(path(conversationId, `tasks/${encodeURIComponent(taskId)}`), { method: 'DELETE' }),
    'imgstudio:tags': ({ conversationId, ...body }) => post(conversationId, 'tags', body)
  }
  return {
    api,
    me: () => request<{ user: SessionUser | null }>('/api/session/me'),
    galleries: () => request<Conversation[]>('/api/conversations?scope=images&includeCompleted=1'),
    createGallery: (title: string) => request<Conversation>('/api/conversations', { method: 'POST', body: JSON.stringify({ title, scope: 'images', assistantKind: 'images' }) }),
    logout: () => request<void>('/api/session/logout', { method: 'POST' })
  }
}
export type StudioClient = ReturnType<typeof createStudioClient>
