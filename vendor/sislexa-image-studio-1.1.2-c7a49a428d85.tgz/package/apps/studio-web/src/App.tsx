import { useCallback, useEffect, useState } from 'react'
import { ImageStudioPane } from '@voicechat/image-studio-app/components/ImageStudioPane'
import { ImageStudioGuideContent } from '@voicechat/image-studio-app/components/ImageStudioGuide'
import { Button, Dialog, UiProviders } from '@voicechat/ui-kit'
import type { Conversation, SessionUser } from '@shared/types'
import { createStudioClient, HttpError, type StudioClient } from './api'

const defaultClient = createStudioClient()
const LAST_GALLERY_KEY = 'studio-last-gallery'
function lastGallery() { try { return localStorage.getItem(LAST_GALLERY_KEY) ?? '' } catch { return '' } }
function galleryInHash() {
  try { return decodeURIComponent(location.hash.match(/^#\/images\/([^/]+)/)?.[1] ?? '') } catch { return '' }
}
/** `#/guide` is the features page; it needs no session and keeps the gallery choice for the way back. */
function guideInHash() { return /^#\/guide(?:\/|$)/.test(location.hash) }
export function App({ client = defaultClient }: { client?: StudioClient }) {
  const [user, setUser] = useState<SessionUser | null>(null)
  const [galleries, setGalleries] = useState<Conversation[]>([])
  const [active, setActive] = useState(galleryInHash)
  const [guide, setGuide] = useState(guideInHash)
  // Phones lose the network mid-edit; a banner explains failed requests before the person retries.
  const [offline, setOffline] = useState(() => typeof navigator !== 'undefined' && navigator.onLine === false)
  useEffect(() => {
    const on = () => setOffline(false), off = () => setOffline(true)
    addEventListener('online', on); addEventListener('offline', off)
    return () => { removeEventListener('online', on); removeEventListener('offline', off) }
  }, [])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [creating, setCreating] = useState(false)
  const [busy, setBusy] = useState(false)
  const [title, setTitle] = useState('')
  const select = (id: string) => {
    location.hash = `/images/${encodeURIComponent(id)}`
    setActive(id)
    // A plain reload of "/" returns to the gallery the person worked in last.
    try { localStorage.setItem(LAST_GALLERY_KEY, id) } catch { /* storage is optional */ }
  }
  const fail = useCallback((cause: unknown) => {
    if (cause instanceof HttpError && cause.status === 401) { setUser(null); setGalleries([]) }
    setError(cause instanceof Error ? cause.message : 'Не удалось загрузить студию.')
  }, [])
  const load = useCallback(async () => {
    setLoading(true); setError('')
    try {
      const { user: current } = await client.me()
      setUser(current)
      if (!current) { setGalleries([]); return }
      const items = (await client.galleries()).filter(item => item.assistantKind === 'images')
      setGalleries(items)
      const requested = galleryInHash() || sessionStorage.getItem('studio-return-gallery') || lastGallery()
      sessionStorage.removeItem('studio-return-gallery')
      if (guideInHash()) {
        // The features page owns the address: remember a gallery for the way back, do not rewrite the hash.
        setActive(items.some(item => item.id === requested) ? requested : items[0]?.id ?? '')
        return
      }
      if (items.some(item => item.id === requested)) {
        if (!galleryInHash()) select(requested)
        else setActive(requested)
      } else if (items[0]) select(items[0].id)
      else setActive('')
    } catch (cause) { fail(cause) } finally { setLoading(false) }
  }, [client, fail])
  useEffect(() => { void load() }, [load])
  // n outside inputs opens the new-gallery dialog, like the panel's single-letter shortcuts.
  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const tag = (event.target as HTMLElement | null)?.tagName
      if (event.key.toLowerCase() !== 'n' || event.metaKey || event.ctrlKey || event.altKey || tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return
      if (!user || guide || creating) return
      event.preventDefault()
      setTitle(`Картинки ${galleries.length + 1}`)
      setCreating(true)
    }
    addEventListener('keydown', onKey)
    return () => removeEventListener('keydown', onKey)
  }, [user, guide, creating, galleries.length])
  useEffect(() => {
    const change = () => { setGuide(guideInHash()); if (!guideInHash()) setActive(galleryInHash()) }
    addEventListener('hashchange', change)
    return () => removeEventListener('hashchange', change)
  }, [])
  const gallery = galleries.find(item => item.id === active)
  // The tab title names the open gallery: several studio tabs stop looking alike.
  useEffect(() => {
    const base = guide ? 'Что умеет студия · Image Studio' : gallery ? `${gallery.title || 'Без названия'} · Image Studio` : 'Image Studio · Sislexa'
    document.title = offline ? `(офлайн) ${base}` : base
  }, [guide, gallery, offline])
  return <UiProviders><div className="studio-app">
    <header className="studio-header"><div className="studio-brand"><span aria-hidden="true">✦</span><div><h1>Image Studio</h1><p>Sislexa</p></div></div>
      <div className="studio-account">
        {guide
          ? <a className="studio-nav-link" href={active ? `#/images/${encodeURIComponent(active)}` : '#/'}>← К галерее</a>
          : <a className="studio-nav-link" href="#/guide">Что умеет студия</a>}
        {user && <><span>{user.name}</span><Button variant="ghost" disabled={busy} onClick={async () => {
        setBusy(true); setError('')
        try { await client.logout(); setUser(null); setGalleries([]); setActive(''); location.hash = '' } catch (cause) { fail(cause) } finally { setBusy(false) }
      }}>Выйти</Button></>}
      </div>
    </header>
    {guide && <main className="studio-guide" aria-labelledby="studio-guide-title">
      <h2 id="studio-guide-title">Что умеет студия картинок</h2>
      <ImageStudioGuideContent />
    </main>}
    {offline && <div className="studio-offline" role="status">Нет сети — галерея показывает то, что уже загружено; правки и генерация подождут соединения.</div>}
    {!guide && error && <div className="studio-error" role="alert">{error} <Button onClick={() => void load()}>Повторить</Button></div>}
    {guide ? null : loading ? <main className="studio-welcome" role="status">Загружаем студию…</main> : !user ? <main className="studio-welcome"><h2>Ваши идеи в картинках</h2><p>Создавайте, загружайте и редактируйте изображения в своих галереях.</p><a className="studio-login" href="/login/" onClick={() => { if (active) sessionStorage.setItem('studio-return-gallery', active) }}>Войти</a></main> : <>
      <nav className="studio-galleries" aria-label="Галереи"><label htmlFor="gallery">Галерея{galleries.length > 1 ? ` (${galleries.length})` : ''}</label><select id="gallery" value={gallery?.id ?? ''} onChange={event => select(event.target.value)} disabled={!galleries.length}><option value="" disabled>Выберите галерею</option>{galleries.map(item => <option key={item.id} value={item.id}>{item.title || 'Без названия'}</option>)}</select><Button disabled={offline} title={offline ? 'Нет сети' : undefined} onClick={() => { setTitle(`Картинки ${galleries.length + 1}`); setCreating(true) }}>Новая галерея</Button><Button variant="ghost" aria-label="Обновить список галерей" title="Обновить список галерей" disabled={loading} onClick={() => void load()}>↻</Button></nav>
      <main className="studio-content">{gallery ? <ImageStudioPane key={gallery.id} conversationId={gallery.id} api={client.api} otherChats={galleries.filter(item => item.id !== gallery.id).map(({ id, title }) => ({ id, title }))} /> : <div className="studio-welcome"><h2>{galleries.length ? 'Выберите галерею' : 'Создайте первую галерею'}</h2><p>Здесь появятся ваши изображения и инструменты для работы с ними.</p><Button onClick={() => { setTitle(`Картинки ${galleries.length + 1}`); setCreating(true) }}>Создать галерею</Button></div>}</main>
    </>}
    {creating && <Dialog title="Новая галерея" padded onClose={() => { if (!busy) setCreating(false) }}><form className="studio-create" onSubmit={async event => {
      event.preventDefault(); if (!title.trim() || busy) return
      setBusy(true); setError('')
      try { const created = await client.createGallery(title.trim()); setGalleries(items => [created, ...items]); select(created.id); setCreating(false) } catch (cause) { fail(cause) } finally { setBusy(false) }
    }}><label htmlFor="gallery-title">Название галереи</label><input id="gallery-title" autoFocus maxLength={200} value={title} onChange={event => setTitle(event.target.value)} disabled={busy} /><Button type="submit" disabled={busy || !title.trim()}>{busy ? 'Создаём…' : 'Создать'}</Button></form></Dialog>}
    <footer className="studio-footer"><span>Image Studio {typeof __STUDIO_VERSION__ === 'string' ? __STUDIO_VERSION__ : 'dev'}</span><a href="#/guide">Справочник</a><a href="https://github.com/sislex/image-studio/blob/main/docs/changelog.md" target="_blank" rel="noopener noreferrer">Что нового</a><a href="https://github.com/sislex/image-studio" target="_blank" rel="noopener noreferrer">Исходники</a></footer>
  </div></UiProviders>
}
