/// <reference types="vite/client" />
/** Package version baked in at build time; tests see the fallback. */
declare const __STUDIO_VERSION__: string | undefined
