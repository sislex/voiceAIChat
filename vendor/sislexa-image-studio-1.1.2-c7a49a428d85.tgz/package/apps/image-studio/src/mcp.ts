import type { FastifyInstance } from 'fastify'
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js'
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js'
import { z } from 'zod'
import sharp from 'sharp'
import { IMAGE_STUDIO_MCP_PATH, imageStudioMime, isImageStudioConversation, type ImageStudioSelection } from '@voicechat/image-studio-contracts'
import type { ImageStudioCore, ImageStudioGenerator } from './core.js'
import type { ImageStudioStore } from './studio.js'
import { detectImageStudioObjects, extractImageStudioSelection, magicWandImageStudioSelection, placeImageStudioObject, retouchImageStudioSelection } from './selection.js'
import { versionChain } from './versions.js'
import { nameFromPrompt, withSourceExtension } from './naming.js'

type TextResult = { content: Array<{ type: 'text'; text: string }>; isError?: boolean }
const text = (value: string, isError = false): TextResult => isError
  ? { content: [{ type: 'text', text: value }], isError: true }
  : { content: [{ type: 'text', text: value }] }

const rectangle = z.object({ kind: z.literal('rectangle'), x: z.number().nonnegative(), y: z.number().nonnegative(), width: z.number().positive(), height: z.number().positive() })
const lasso = z.object({ kind: z.literal('lasso'), points: z.array(z.object({ x: z.number().nonnegative(), y: z.number().nonnegative() })).min(3).max(500) })
const wand = z.object({ kind: z.literal('wand'), x: z.number().nonnegative(), y: z.number().nonnegative(), tolerance: z.number().int().min(1).max(255).optional() })
const selectionSchema = z.union([rectangle, lasso, wand])

function derivedBase(path: string, suffix: string): string {
  const dot = path.lastIndexOf('.')
  return `${dot > 0 ? path.slice(0, dot) : path}-${suffix}.png`
}

export function registerImageStudioMcp(app: FastifyInstance, deps: {
  store: ImageStudioStore
  core: Pick<ImageStudioCore, 'conversation'>
  generator: (userId: string) => Promise<ImageStudioGenerator>
}, secret: string): void {
  const active = new Set<string>()
  app.register(async (scope) => {
    scope.removeAllContentTypeParsers()
    scope.addContentTypeParser('*', (_request, _payload, done) => done(null, undefined))
    scope.post<{ Querystring: { conv?: string; user?: string; k?: string; ro?: string } }>(IMAGE_STUDIO_MCP_PATH, async (request, reply) => {
      if (!secret || request.query.k !== secret) return reply.code(403).send({ error: 'forbidden' })
      const conversationId = request.query.conv ?? ''
      const userId = request.query.user ?? ''
      const conversation = await deps.core.conversation(userId, conversationId)
      if (!conversation || !isImageStudioConversation(conversation)) return reply.code(404).send({ error: 'conversation not found' })
      const readOnly = request.query.ro === '1'
      const server = new McpServer({ name: 'image_studio', version: '1.0.0' })
      const blocked = (): TextResult => text('Отклонено: режим «План» разрешает только image_list, image_open и image_find_objects.', true)
      const describe = (error: unknown): TextResult => text(error instanceof Error ? error.message : String(error), true)
      const modelRun = async <T>(operation: (generator: ImageStudioGenerator) => Promise<T>): Promise<T> => {
        if (active.has(conversationId)) throw new Error('В этой студии уже идёт генерация или ретушь')
        active.add(conversationId)
        try { return await operation(await deps.generator(userId)) } finally { active.delete(conversationId) }
      }
      const resolveSelection = async (source: Buffer, selection: z.infer<typeof selectionSchema>): Promise<ImageStudioSelection> => selection.kind === 'wand'
        ? magicWandImageStudioSelection(source, selection.x, selection.y, selection.tolerance)
        : selection

      server.registerTool('image_list', {
        description: 'Список изображений студии с операцией, исходником и историей, новые сверху (order: new | name | size). Начинай работу с этого инструмента. Для большой галереи задай query (подстрока имени, промпта или тега), tag (точный тег), limit или since (updatedAt в миллисекундах: только изменённое позже); summary: true даёт только счётчики.',
        inputSchema: { query: z.string().max(200).optional(), limit: z.number().int().min(1).max(200).optional(), since: z.number().int().nonnegative().optional(), order: z.enum(['new', 'name', 'size']).optional(), summary: z.boolean().optional(), tag: z.string().max(80).optional() }
      }, async ({ query, limit, since, order, summary, tag }) => {
        try {
          const listed = await deps.store.list(conversationId)
          if (summary) {
            // Counts instead of rows: an overview of a large gallery costs a few tokens, not hundreds.
            const byOperation: Record<string, number> = {}
            for (const file of listed) { const key = file.operation ?? (file.source ? 'edit' : 'upload'); byOperation[key] = (byOperation[key] ?? 0) + 1 }
            const byTag: Record<string, number> = {}
            for (const file of listed) for (const tag of file.tags ?? []) byTag[tag] = (byTag[tag] ?? 0) + 1
            return text(JSON.stringify({ total: listed.length, bytes: listed.reduce((sum, file) => sum + file.size, 0), byOperation, byTag, newest: listed[0]?.path ?? null, oldest: listed.at(-1)?.path ?? null }, null, 2))
          }
          const all = order === 'name' ? [...listed].sort((a, b) => a.path.localeCompare(b.path, 'ru')) : order === 'size' ? [...listed].sort((a, b) => b.size - a.size) : listed
          const needle = query?.trim().toLowerCase()
          const wanted = tag?.trim().toLowerCase()
          const tagged = wanted ? all.filter((file) => (file.tags ?? []).some((value) => value.toLowerCase() === wanted)) : all
          const fresh = since ? tagged.filter((file) => file.updatedAt > since) : tagged
          const matched = needle ? fresh.filter((file) => [file.path, file.prompt ?? '', ...(file.tags ?? [])].some((value) => value.toLowerCase().includes(needle))) : fresh
          const shown = limit ? matched.slice(0, limit) : matched
          const note = shown.length < matched.length ? `\n… показано ${shown.length} из ${matched.length}; уточни query или увеличь limit` : ''
          return text(JSON.stringify(shown, null, 2) + note)
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_open', {
        description: 'Открыть изображение модели и прочитать его метаданные вместе с цепочкой версий (versions: от исходника к последней правке) и размерами в пикселях (width, height). Используй перед любой правкой или выделением. Картинка отдаётся уменьшенной до maxSide (по умолчанию 1600 px по длинной стороне); координаты выделения задавай в пикселях оригинала.',
        inputSchema: { path: z.string(), maxSide: z.number().int().min(256).max(4096).optional() }
      }, async ({ path, maxSide }) => {
        try {
          const data = await deps.store.readBuffer(conversationId, path)
          if (!data) return text(`Файл «${path}» не найден`, true)
          const files = await deps.store.list(conversationId)
          const file = files.find((item) => item.path === path)
          const originalMime = imageStudioMime(path)
          const supported = ['image/png', 'image/jpeg', 'image/webp', 'image/gif'].includes(originalMime)
          const probe = sharp(data, { limitInputPixels: 64_000_000 })
          const { width = 0, height = 0, hasAlpha = false } = await probe.metadata().catch(() => ({ width: 0, height: 0, hasAlpha: false }))
          const side = maxSide ?? 1600
          // A 12 MB original in the model context costs tokens and time; a fitted copy is enough to look at.
          // Opaque copies go out as JPEG (a fraction of the PNG bytes); transparency keeps PNG.
          const shrink = Math.max(width, height) > side
          const fitted = shrink || !supported ? sharp(data, { limitInputPixels: 64_000_000 }).rotate().resize({ width: side, height: side, fit: 'inside', withoutEnlargement: true }) : null
          const image = fitted ? await (hasAlpha ? fitted.png() : fitted.jpeg({ quality: 85 })).toBuffer() : data
          const shrunkMime = hasAlpha ? 'image/png' : 'image/jpeg'
          // A published gallery gives every visible frame a shareable address.
          const publication = await deps.store.publication(conversationId).catch(() => null)
          const shared = publication && (!publication.settings || publication.settings.items.some((item) => item.path === path)) ? `/g/${publication.token}/file?path=${encodeURIComponent(path)}` : undefined
          return { content: [
            // The chain tells the assistant which version is current and where a rollback would land.
            { type: 'text' as const, text: JSON.stringify({ ...(file ?? { path }), width, height, ...(shrink ? { shownAt: side } : {}), ...(shared ? { publicUrl: shared } : {}), versions: versionChain(files, path) }, null, 2) },
            { type: 'image' as const, data: image.toString('base64'), mimeType: fitted ? shrunkMime : originalMime }
          ] }
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_find_objects', {
        description: 'Найти крупные объекты и людей на простом фоне. Возвращает прямоугольники в пикселях исходного изображения; для сложной сцены используй image_open и выделение wand или lasso.',
        inputSchema: { path: z.string(), tolerance: z.number().int().min(1).max(255).optional() }
      }, async ({ path, tolerance }) => {
        try {
          const source = await deps.store.readBuffer(conversationId, path)
          if (!source) return text(`Файл «${path}» не найден`, true)
          return text(JSON.stringify(await detectImageStudioObjects(source, tolerance), null, 2))
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_generate', {
        description: 'Создать новое изображение по промпту. Результат автоматически становится первой версией новой ветки. style, size (например 1024x1024), negative (чего не должно быть) и noText дописываются к промпту так же, как это делает панель; tags помечают файл для отбора.',
        inputSchema: { prompt: z.string().min(1).max(4000), name: z.string().optional(), references: z.array(z.string()).max(4).optional(), style: z.string().max(200).optional(), size: z.string().max(40).optional(), negative: z.string().max(400).optional(), noText: z.boolean().optional(), tags: z.array(z.string().max(80)).max(30).optional() }
      }, async ({ prompt, name, references, style, size, negative, noText, tags }) => {
        if (readOnly) return blocked()
        try {
          const referenceFiles: Array<{ name: string; data: Buffer }> = []
          for (const path of references ?? []) {
            const data = await deps.store.readBuffer(conversationId, path)
            if (!data) return text(`Референс «${path}» не найден`, true)
            referenceFiles.push({ name: path, data })
          }
          // Same wording the panel appends, so pictures from chat and from the composer look alike.
          const fullPrompt = [prompt, style ? `Стиль: ${style}.` : '', size ? `Размер изображения: ${size.replace('×', 'x')}` : '', negative ? `Не должно быть на изображении: ${negative}.` : '', noText ? 'Не добавляй на изображение никакой текст, надписи и водяные знаки.' : ''].filter(Boolean).join('\n')
          const data = await modelRun((generator) => generator({ prompt: fullPrompt, references: referenceFiles }))
          const path = await deps.store.freeName(conversationId, name?.trim() || nameFromPrompt(prompt))
          const file = await deps.store.writeBuffer(conversationId, path, data)
          const parameters = style || size || negative || noText ? { ...(style ? { style } : {}), ...(size ? { size } : {}), ...(negative ? { negative } : {}), ...(noText ? { noText } : {}) } : undefined
          const cleanTags = tags?.map((tag) => tag.trim()).filter(Boolean)
          await deps.store.setMeta(conversationId, path, { prompt, operation: 'generate', ...(parameters ? { parameters } : {}), ...(cleanTags?.length ? { tags: [...new Set(cleanTags)] } : {}) })
          return text(`Создано: ${file.path}`)
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_edit', {
        description: 'Изменить всё изображение по промпту. Исходник сохраняется, результат записывается новой версией (name — своё имя результата, иначе имя исходника с номером). references — до четырёх файлов галереи как образцы стиля или объекта.',
        inputSchema: { path: z.string(), prompt: z.string().min(1).max(4000), references: z.array(z.string()).max(4).optional(), name: z.string().max(200).optional(), tags: z.array(z.string().max(80)).max(30).optional() }
      }, async ({ path, prompt, references, name, tags }) => {
        if (readOnly) return blocked()
        try {
          const source = await deps.store.readBuffer(conversationId, path)
          if (!source) return text(`Файл «${path}» не найден`, true)
          const referenceFiles: Array<{ name: string; data: Buffer }> = []
          for (const reference of references ?? []) {
            const data = await deps.store.readBuffer(conversationId, reference)
            if (!data) return text(`Референс «${reference}» не найден`, true)
            referenceFiles.push({ name: reference, data })
          }
          const data = await modelRun((generator) => generator({ prompt, source, sourceName: path, ...(referenceFiles.length ? { references: referenceFiles } : {}) }))
          const target = await deps.store.freeName(conversationId, name?.trim() ? withSourceExtension(path, name) : path)
          await deps.store.writeBuffer(conversationId, target, data)
          // Tags default to the source's: a version of a tagged picture stays findable by the same tag.
          const inherited = (await deps.store.meta(conversationId, path))?.tags ?? []
          const cleanTags = [...new Set([...(tags ?? inherited)].map((tag) => tag.trim()).filter(Boolean))]
          await deps.store.setMeta(conversationId, target, { prompt, source: path, operation: 'edit', ...(cleanTags.length ? { tags: cleanTags } : {}) })
          // The chain in the answer saves a round trip before the next edit.
          const chain = versionChain(await deps.store.list(conversationId), target)
          return text(`Новая версия: ${target}. Исходник ${path} сохранён. Цепочка версий: ${chain.join(' → ')}.`)
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_retouch', {
        description: 'Безопасно изменить только прямоугольник или лассо. Пиксели вне выделения копируются из исходника и не меняются.',
        inputSchema: { path: z.string(), prompt: z.string().min(1).max(4000), selection: selectionSchema, references: z.array(z.string()).max(4).optional() }
      }, async ({ path, prompt, selection, references }) => {
        if (readOnly) return blocked()
        try {
          const original = await deps.store.readBuffer(conversationId, path)
          if (!original) return text(`Файл «${path}» не найден`, true)
          const referenceData: Buffer[] = []
          for (const reference of references ?? []) {
            const data = await deps.store.readBuffer(conversationId, reference)
            if (!data) return text(`Референс «${reference}» не найден`, true)
            referenceData.push(data)
          }
          const resolvedSelection = await resolveSelection(original, selection)
          const result = await modelRun(async (generator) => retouchImageStudioSelection({
            original, selection: resolvedSelection, prompt, references: referenceData,
            generate: ({ crop, mask, width, height, references: refs }) => generator({
              prompt, source: crop, sourceName: 'selection.png', mask, targetSize: { width, height },
              references: refs.map((data, index) => ({ name: `reference-${index + 1}.png`, data }))
            })
          }))
          const target = await deps.store.freeName(conversationId, derivedBase(path, 'ретушь'))
          await deps.store.writeBuffer(conversationId, target, result.image)
          await deps.store.setMeta(conversationId, target, { prompt, source: path, operation: 'retouch', selection: result.bounds })
          return text(`Ретушь сохранена: ${target}. Вне выделения исходные пиксели сохранены.`)
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_extract', {
        description: 'Извлечь прямоугольник или лассо в отдельный прозрачный PNG для независимой правки.',
        inputSchema: { path: z.string(), selection: selectionSchema }
      }, async ({ path, selection }) => {
        if (readOnly) return blocked()
        try {
          const original = await deps.store.readBuffer(conversationId, path)
          if (!original) return text(`Файл «${path}» не найден`, true)
          const result = await extractImageStudioSelection(original, await resolveSelection(original, selection))
          const target = await deps.store.freeName(conversationId, derivedBase(path, 'объект'))
          await deps.store.writeBuffer(conversationId, target, result.image)
          await deps.store.setMeta(conversationId, target, { source: path, operation: 'extract', selection: result.bounds })
          return text(`Объект сохранён: ${target}. Позиция ${result.bounds.x},${result.bounds.y}; размер ${result.bounds.width}×${result.bounds.height}.`)
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_place', {
        description: 'Вернуть извлечённый и при необходимости отредактированный объект на исходное изображение. Без координат используется исходная позиция.',
        inputSchema: { objectPath: z.string(), basePath: z.string().optional(), x: z.number().int().nonnegative().optional(), y: z.number().int().nonnegative().optional(), width: z.number().int().positive().optional(), height: z.number().int().positive().optional() }
      }, async ({ objectPath, basePath, x, y, width, height }) => {
        if (readOnly) return blocked()
        try {
          const origin = await deps.store.extractionOrigin(conversationId, objectPath)
          const base = basePath ?? origin?.path
          if (!base) return text('Не найден исходник извлечённого объекта; укажите basePath', true)
          const baseData = await deps.store.readBuffer(conversationId, base)
          const objectData = await deps.store.readBuffer(conversationId, objectPath)
          if (!baseData || !objectData) return text('Исходник или объект не найден', true)
          const placed = await placeImageStudioObject({ base: baseData, object: objectData, x: x ?? origin?.bounds.x ?? 0, y: y ?? origin?.bounds.y ?? 0, width: width ?? origin?.bounds.width, height: height ?? origin?.bounds.height })
          const target = await deps.store.freeName(conversationId, derivedBase(base, 'с-объектом'))
          await deps.store.writeBuffer(conversationId, target, placed)
          await deps.store.setMeta(conversationId, target, { source: base, operation: 'place', selection: { kind: 'rectangle', x: x ?? origin?.bounds.x ?? 0, y: y ?? origin?.bounds.y ?? 0, width: width ?? origin?.bounds.width ?? 1, height: height ?? origin?.bounds.height ?? 1 } })
          return text(`Объект ${objectPath} возвращён: ${target}.`)
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_restore', {
        description: 'Откатить текущую ветку к исторической версии без удаления последующих версий.',
        inputSchema: { currentPath: z.string(), targetPath: z.string() }
      }, async ({ currentPath, targetPath }) => {
        if (readOnly) return blocked()
        try {
          if (!await deps.store.readBuffer(conversationId, currentPath)) return text(`Текущая версия «${currentPath}» не найдена`, true)
          const targetData = await deps.store.readBuffer(conversationId, targetPath)
          if (!targetData) return text(`Историческая версия «${targetPath}» не найдена`, true)
          const path = await deps.store.freeName(conversationId, derivedBase(currentPath, 'восстановлено'))
          await deps.store.writeBuffer(conversationId, path, targetData)
          await deps.store.setMeta(conversationId, path, { source: currentPath, operation: 'restore', restoredFrom: targetPath })
          return text(`Восстановлено в новую версию ${path}; ${currentPath} и ${targetPath} сохранены.`)
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_rename', {
        description: 'Переименовать изображение; связи истории обновляются автоматически. Без расширения в новом имени берётся расширение исходного файла.',
        inputSchema: { from: z.string(), to: z.string() }
      }, async ({ from, to }) => {
        if (readOnly) return blocked()
        try {
          const target = withSourceExtension(from, to)
          await deps.store.rename(conversationId, from, target)
          return text(`Переименовано: ${from} → ${target}`)
        } catch (error) { return describe(error) }
      })

      server.registerTool('image_delete', {
        description: 'Переместить изображение в корзину на семь дней.',
        inputSchema: { path: z.string() }
      }, async ({ path }) => {
        if (readOnly) return blocked()
        try { await deps.store.delete(conversationId, path); return text(`Перемещено в корзину: ${path}`) } catch (error) { return describe(error) }
      })

      const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined, enableJsonResponse: true })
      reply.raw.on('close', () => { void transport.close(); void server.close() })
      await server.connect(transport)
      await transport.handleRequest(request.raw, reply.raw, request.body)
    })
  })
}

export { IMAGE_STUDIO_MCP_PATH }
