import { join } from 'node:path'
import type { FastifyInstance } from 'fastify'
import { parseImages } from '@voicechat/shared'
import { isImageStudioConversation, type ImageStudioFile } from '@voicechat/image-studio-contracts'
import type { ImageStudioCore } from './core.js'
import type { ImageStudioService } from './service.js'
import { ImageStudioStore } from './studio.js'
import { registerImageStudioRoutes, type ImageStudioRouteStats } from './routes.js'
import { registerImageStudioMcp } from './mcp.js'

/** Rough budget for the gallery listing inside the assistant prompt. */
const PROMPT_CONTEXT_LISTING_CHARS = 3500

export function createImageStudioModule(opts: { dataDir: string; core: ImageStudioCore; mcpSecret: string; trashDays?: number }) {
  const { core } = opts
  // Каталог тот же, что до выделения: существующие галереи не требуют миграции.
  const store = new ImageStudioStore(join(opts.dataDir, 'image-studio'), { ...(opts.trashDays !== undefined ? { trashDays: opts.trashDays } : {}) })
  const service: ImageStudioService = {
    async promptContext(conversationId) {
      const files = await store.list(conversationId)
      const describe = (file: ImageStudioFile): string => {
        const parts: string[] = []
        if (file.operation) parts.push(file.operation)
        if (file.source) parts.push(`из ${file.source}`)
        if (file.prompt) parts.push(`промпт: ${file.prompt.slice(0, 80)}`)
        // Tags are how people name pictures in conversation ("та, что с тегом обложка").
        if (file.tags?.length) parts.push(`теги: ${file.tags.slice(0, 6).join(', ')}`)
        return `- ${file.path}${parts.length ? ` (${parts.join('; ')})` : ''}`
      }
      // The block rides in every turn: cap it so a gallery of long prompts does not crowd out the conversation.
      const sorted = [...files].sort((a, b) => b.updatedAt - a.updatedAt)
      let recent = sorted.slice(0, 30)
      let listing = recent.map(describe).join('\n')
      while (listing.length > PROMPT_CONTEXT_LISTING_CHARS && recent.length > 5) {
        recent = recent.slice(0, Math.max(5, Math.floor(recent.length / 2)))
        listing = recent.map(describe).join('\n')
      }
      const tagNames = [...new Set(files.flatMap((file) => file.tags ?? []))].sort((a, b) => a.localeCompare(b, 'ru'))
      const tagsNote = tagNames.length ? `Теги галереи: ${tagNames.slice(0, 20).join(', ')}${tagNames.length > 20 ? ', …' : ''}. Новые картинки по теме можно помечать теми же тегами (параметр tags у image_generate и image_edit).` : ''
      const trashed = await store.listTrash(conversationId).catch(() => [])
      const trashNote = trashed.length ? `В корзине ${trashed.length} файлов (${trashed.slice(0, 5).map((item) => item.name).join(', ')}${trashed.length > 5 ? ', …' : ''}); их можно вернуть через панель — если пользователь ищет пропавшую картинку, подскажи это.` : ''
      const publication = await store.publication(conversationId).catch(() => null)
      const publicNote = publication ? `Галерея опубликована: относительный адрес /g/${publication.token}/${publication.passwordHash ? ' (закрыта паролем)' : ''}, наружу видно ${publication.settings ? `${publication.settings.items.length} из ${files.length}` : 'все'} файлов; если пользователь просит ссылку — назови этот адрес и предложи открыть его в приложении.` : ''
      const stats = routeStats?.()
      const queueNote = stats && (stats.running || stats.queued)
        ? `Сейчас в этой студии уже идёт генерация (выполняется: ${stats.running}, ожидает: ${stats.queued}); новая одновременно не запустится — дождись результата или скажи об этом пользователю.`
        : ''
      return [
        '## Студия картинок',
        'Это чат студии картинок: пользователь собирает галерею изображений этого разговора, она открыта у него справа.',
        'Любую просьбу нарисовать, сгенерировать, изменить, поправить, ретушировать или собрать картинку выполняй только инструментами MCP-сервера image_studio: image_generate для новой картинки, image_edit для правки всей картинки, image_retouch для правки области, image_extract и image_place для работы с отдельным объектом, image_restore для отката.',
        'Не рисуй иными средствами и не сохраняй файлы мимо студии: картинка, созданная другим инструментом или записанная на диск напрямую, в галерею не попадает и пользователь её не увидит.',
        'Перед правкой существующей картинки вызови image_list и image_open: поле versions показывает цепочку от исходника к последней правке — правь последний элемент, если пользователь не указал другой шаг; после операции коротко назови пользователю созданный файл.',
        'Если инструменты image_* недоступны в этом ходе, сообщи об этом пользователю, а созданный файл покажи штатным fenced-блоком image с абсолютным путём: так он будет перенесён в галерею.',
        listing ? `Сейчас в галерее (${files.length} файлов, новые сверху):\n${listing}${files.length > recent.length ? `\n… и ещё ${files.length - recent.length}` : ''}` : 'Галерея пока пуста.',
        publicNote,
        tagsNote,
        trashNote,
        queueNote
      ].filter(Boolean).join('\n')
    },
    async captureImages(userId, conversationId, finalText) {
      const conversation = await core.conversation(userId, conversationId)
      if (!conversation || !isImageStudioConversation(conversation)) return
      for (const image of parseImages(finalText).images.slice(0, 10)) {
        try {
          const file = await core.readGenerated(userId, image.path)
          if (!file?.dataBase64) continue
          const original = image.path.split('/').pop() ?? 'изображение.png'
          const readable = /^exec-[0-9a-f-]{20,}\./i.test(original) ? `из-чата${original.slice(original.lastIndexOf('.'))}` : original
          const bytes = Buffer.from(file.dataBase64, 'base64')
          // The assistant often repeats an earlier picture in a later answer; the gallery keeps one copy.
          if (await store.findByContent(conversationId, bytes)) continue
          const name = await store.freeName(conversationId, readable)
          await store.writeBuffer(conversationId, name, bytes)
          // The block's caption is the closest thing to a prompt for a chat picture: it shows on the card and is searchable.
          const caption = image.caption?.trim().slice(0, 400)
          await store.setMeta(conversationId, name, { operation: 'generate', ...(caption ? { prompt: caption } : {}) })
        } catch {
          // Не-картинка, квота или недоступный файл не должны ломать ход чата.
        }
      }
    }
  }
  let routeStats: (() => ImageStudioRouteStats) | null = null
  return {
    store, service,
    register(app: FastifyInstance) {
      registerImageStudioMcp(app, { store, core, generator: async (userId) => (input) => core.generate(userId, input) }, opts.mcpSecret)
      routeStats = registerImageStudioRoutes(app, { core, store, generator: async (userId) => (input) => core.generate(userId, input) }).stats
    },
    /** Live counters for health: null until routes are registered. */
    stats(): ImageStudioRouteStats | null { return routeStats?.() ?? null }
  }
}
