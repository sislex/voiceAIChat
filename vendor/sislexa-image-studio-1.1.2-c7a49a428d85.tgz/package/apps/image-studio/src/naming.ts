// A readable file name from a prompt: the first three words, lowercased, joined
// with dashes, letters of any script kept. "синий кит в очках" reads better in a
// gallery than "изображение-7.png"; the panel derives names the same way, this
// copy serves MCP and the queue when the caller passes no name.
export function nameFromPrompt(prompt: string, fallback = 'изображение.png'): string {
  const words = prompt.toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu, '').split(/\s+/).filter(Boolean).slice(0, 3)
  const stem = words.join('-').slice(0, 48).replace(/^-+|-+$/g, '')
  return stem ? `${stem}.png` : fallback
}

/**
 * A rename target without an image extension inherits the source's one:
 * "кот" for "кот.png" means "кот.png", not a file the gallery would refuse.
 */
export function withSourceExtension(from: string, to: string): string {
  const trimmed = to.trim()
  if (!trimmed || /\.(png|jpe?g|webp|gif|svg)$/i.test(trimmed)) return trimmed
  const dot = from.lastIndexOf('.')
  return dot > 0 ? `${trimmed}${from.slice(dot)}` : trimmed
}
