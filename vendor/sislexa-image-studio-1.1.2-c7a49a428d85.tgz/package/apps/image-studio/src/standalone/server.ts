import { fileURLToPath } from 'node:url'
import { randomUUID } from 'node:crypto'
import { createComponentRuntime } from '@sislexa/component-runtime'
import { applicationRuntimeMetadata } from '@voicechat/shared'
import { IMAGE_STUDIO_LIMITS } from '@voicechat/image-studio-contracts'
import Fastify from 'fastify'
import { createRpcDispatcher, RpcError, type RpcRequest } from '@voicechat/shared'
import { INTERNAL_IMAGE_STUDIO_SERVICE_PATH, IMAGE_STUDIO_SERVICE_METHODS, IMAGE_STUDIO_HEALTH_PATH, IMAGE_STUDIO_GENERATION_TIMEOUT_MS } from '@voicechat/image-studio-contracts'
import type { ImageStudioCore } from '../core.js'
import { createImageStudioModule } from '../module.js'
import type { ImageStudioStandaloneConfig } from './config.js'
import { HttpImageStudioCore } from './httpCore.js'
import { registerForwardedAuth } from './auth.js'

export async function buildImageStudioServer(opts: {
  config: ImageStudioStandaloneConfig
  core?: ImageStudioCore
  fetchImpl?: typeof fetch
  logger?: boolean
}) {
  const config = { ...opts.config }
  if (!config.componentConfigPath && !config.internalToken) throw new Error('Image Studio standalone requires VC_INTERNAL_TOKEN')
  if (!config.mcpSecret) throw new Error('Image Studio standalone requires VC_MCP_SECRET')
  // preClose cancels generation first; unfinished uploads must not block process shutdown.
  const app = Fastify({
    logger: opts.logger ?? false,
    forceCloseConnections: true,
    // A gateway or browser that sends x-request-id gets its id echoed and logged, so one trace spans the hop.
    genReqId: (req) => {
      const incoming = req.headers['x-request-id']
      const value = Array.isArray(incoming) ? incoming[0] : incoming
      return value && /^[A-Za-z0-9._:-]{4,128}$/.test(value) ? value : `req-${randomUUID().replace(/-/g, '').slice(0, 12)}`
    }
  })
  // The request id from the log lands in the response, so a screenshot of an error can be matched to a log line.
  app.addHook('onSend', async (req, reply) => { reply.header('x-request-id', req.id) })
  const component = config.componentConfigPath ? await createComponentRuntime({
    contractFile: fileURLToPath(new URL('../../component-contract.json', import.meta.url)),
    configFile: config.componentConfigPath, metadata: applicationRuntimeMetadata('image-studio', process.env), fetchImpl: opts.fetchImpl,
  }) : undefined
  component?.register(app)
  const dependency = component?.dependency('core', { timeoutMs: IMAGE_STUDIO_GENERATION_TIMEOUT_MS })
  if (dependency) { config.coreUrl = dependency.url; config.internalToken = dependency.token }
  const fetchImpl = dependency?.fetchImpl ?? opts.fetchImpl
  const core = opts.core ?? new HttpImageStudioCore({ coreUrl: config.coreUrl, token: config.internalToken, fetchImpl })
  registerForwardedAuth(app, { coreUrl: config.coreUrl, token: config.internalToken, fetchImpl })
  const studio = createImageStudioModule({ dataDir: config.dataDir, core, mcpSecret: config.mcpSecret, ...(config.trashDays !== undefined ? { trashDays: config.trashDays } : {}) })
  studio.register(app)
  const dispatch = createRpcDispatcher(studio.service, IMAGE_STUDIO_SERVICE_METHODS)
  // Секрет проверяется до разбора тела: пользовательский Bearer здесь не подходит.
  app.register(async (internal) => {
    internal.addHook('onRequest', async (req, reply) => {
      const verdict = component ? component.authorize(req.headers.authorization, 'image-studio.service') : { ok: req.headers.authorization === `Bearer ${config.internalToken}`, status: 401 }
      if (!verdict.ok) return reply.code('status' in verdict ? verdict.status : 401).send({ error: 'component_access_denied' })
    })
    internal.post<{ Body: RpcRequest }>(INTERNAL_IMAGE_STUDIO_SERVICE_PATH, async (req, reply) => {
      try { return { result: await dispatch(req.body ?? { method: '', args: [] }) } } catch (error) {
        return reply.code(error instanceof RpcError ? error.status : 500).send({ error: error instanceof Error ? error.message : String(error) })
      }
    })
  })
  const startedAt = Date.now()
  // Uptime and queue counters let an operator see a stuck generation or a restart loop from the health check alone.
  app.get(IMAGE_STUDIO_HEALTH_PATH, async () => {
    // A volume below the write headroom means every upload and generation fails: the probe must say so.
    const freeBytes = await studio.store.freeBytes()
    const queue = studio.stats()
    // A task waiting for half an hour means the runner or Core is stuck; a full disk means every write fails.
    const problem = freeBytes !== null && freeBytes <= 64 * 1024 * 1024 ? 'disk_full' : queue && queue.oldestQueuedAgeSeconds > 1800 ? 'queue_stuck' : null
    return { application: applicationRuntimeMetadata('image-studio', process.env), ok: problem === null, ...(problem ? { problem } : {}), service: 'image-studio', version: config.version, startedAt: new Date(startedAt).toISOString(), uptimeSeconds: Math.round((Date.now() - startedAt) / 1000), queue, galleries: await studio.store.galleryCount().catch(() => null), freeBytes, limits: { maxFileBytes: IMAGE_STUDIO_LIMITS.maxFileBytes, maxConversationBytes: IMAGE_STUDIO_LIMITS.maxConversationBytes, maxPromptChars: IMAGE_STUDIO_LIMITS.maxPromptChars, trashDays: studio.store.trashDays } }
  })
  return { app, studio }
}
