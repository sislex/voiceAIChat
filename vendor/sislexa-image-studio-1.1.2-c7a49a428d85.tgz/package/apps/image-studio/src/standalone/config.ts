import { readFileSync } from 'node:fs'

function packageVersion(): string | null {
  try { return (JSON.parse(readFileSync(new URL('../../package.json', import.meta.url), 'utf8')) as { version?: string }).version ?? null } catch { return null }
}

export interface ImageStudioStandaloneConfig {
  componentConfigPath?: string
  host: string
  port: number
  dataDir: string
  coreUrl: string
  internalToken: string
  mcpSecret: string
  version: string | null
  /** Days a deleted file stays in the trash; unset keeps the built-in seven. */
  trashDays: number | undefined
}

export function loadImageStudioStandaloneConfig(env: NodeJS.ProcessEnv = process.env): ImageStudioStandaloneConfig {
  return {
    componentConfigPath: env.SISLEXA_COMPONENT_CONFIG || undefined,
    host: env.HOST ?? '127.0.0.1',
    port: Number(env.PORT ?? 8796),
    dataDir: env.VC_IMAGE_STUDIO_DATA_DIR ?? env.VC_DATA_DIR ?? 'data',
    coreUrl: env.VC_CORE_URL ?? 'http://127.0.0.1:8787',
    internalToken: env.VC_INTERNAL_TOKEN ?? '',
    mcpSecret: env.VC_MCP_SECRET ?? '',
    // Without a release tag the package version still tells operators which build answers.
    version: env.VC_RELEASE_VERSION || packageVersion(),
    trashDays: env.VC_IMAGE_STUDIO_TRASH_DAYS && Number(env.VC_IMAGE_STUDIO_TRASH_DAYS) > 0 ? Number(env.VC_IMAGE_STUDIO_TRASH_DAYS) : undefined
  }
}
