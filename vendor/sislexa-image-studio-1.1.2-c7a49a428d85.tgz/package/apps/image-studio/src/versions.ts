// Version chain of a gallery file: up through `source` to the root, then down
// along the first child of each step. The panel keeps the same rule in its own
// library; the server copy lets the assistant see the steps through MCP without
// the two packages importing each other.
import type { ImageStudioFile } from '@voicechat/image-studio-contracts'

export function versionChain(files: ImageStudioFile[], path: string): string[] {
  const byPath = new Map(files.map((file) => [file.path, file]))
  if (!byPath.has(path)) return []
  const visited = new Set<string>([path])
  const chain = [path]
  let current = byPath.get(path)
  while (current?.source && byPath.has(current.source) && !visited.has(current.source)) {
    visited.add(current.source)
    chain.unshift(current.source)
    current = byPath.get(current.source)
  }
  let tail = path
  for (;;) {
    const next = files.filter((file) => file.source === tail && !visited.has(file.path)).sort((a, b) => a.updatedAt - b.updatedAt)[0]
    if (!next) break
    visited.add(next.path)
    chain.push(next.path)
    tail = next.path
  }
  return chain
}
