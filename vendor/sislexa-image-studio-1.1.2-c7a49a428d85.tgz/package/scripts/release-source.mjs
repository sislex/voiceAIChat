import {execFileSync} from 'node:child_process'
import {readFileSync,writeFileSync} from 'node:fs'
import {resolve} from 'node:path'
const root=new URL('../',import.meta.url)
const commit=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim()
if(execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim())throw Error('Release archives require a clean committed checkout')
const owner=JSON.parse(readFileSync(new URL('package.json',root),'utf8'))
const pkg=JSON.parse(readFileSync(resolve('package.json'),'utf8'))
writeFileSync(resolve('release-source.json'),JSON.stringify({schemaVersion:1,repository:owner.repository.url,version:pkg.version,commit},null,2)+'\n')
