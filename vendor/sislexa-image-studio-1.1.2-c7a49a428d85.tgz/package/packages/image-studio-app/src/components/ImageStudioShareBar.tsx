// Публикация галереи студии: опубликовать, скопировать ссылку, открыть
// страницу, закрыть паролем, снять. Отдельным файлом — потому что это цельный
// кусок с четырьмя состояниями (не опубликовано, опубликовано, под паролем,
// грузится), а панель и без него читается плохо. Логика — у панели.
import { Button } from '@voicechat/ui-kit'

interface Props {
  /** null — не опубликовано, undefined — состояние ещё грузится. */
  url: string | null | undefined
  views: number | null
  views7: number | null
  passwordProtected: boolean
  /** How many files the public page shows; null when the server does not report it. */
  count?: number | null
  busy: boolean
  onPublish: () => void
  onCopyLink: () => void
  onOpenPage: () => void
  onPassword: () => void
  onUnpublish: () => void
  /** Native share sheet (phones); absent where the browser has no navigator.share. */
  onShare?: () => void
}

export function ImageStudioShareBar({
  url, views, views7, passwordProtected, count, busy,
  onPublish, onCopyLink, onOpenPage, onPassword, onUnpublish, onShare
}: Props): JSX.Element | null {
  if (url === undefined) return null
  if (url === null) return <Button size="sm" variant="ghost" disabled={busy} onClick={onPublish}>Поделиться</Button>
  return <>
    <Button
      size="sm"
      variant="ghost"
      title={views !== null ? `Просмотров всего: ${views}${views7 !== null ? ` · за 7 дней: ${views7}` : ''}` : 'Скопировать ссылку'}
      onClick={onCopyLink}
    >Ссылка на галерею{typeof count === 'number' ? ` · ${count} 🖼` : ''}{views ? ` · ${views} 👁${views7 ? ` (${views7} за неделю)` : ''}` : ''}</Button>
    <Button size="sm" variant="ghost" onClick={onOpenPage}>Открыть страницу</Button>
    {onShare && <Button size="sm" variant="ghost" title="Системное окно отправки: мессенджер, почта, заметки" onClick={onShare}>Отправить…</Button>}
    <Button size="sm" variant="ghost" title={passwordProtected ? 'Пароль установлен — изменить или снять' : 'Закрыть галерею паролем для зрителей'} onClick={onPassword}>
      {passwordProtected ? 'Пароль 🔒' : 'Пароль…'}
    </Button>
    <Button size="sm" variant="ghost" onClick={onUnpublish}>Снять публикацию</Button>
  </>
}
