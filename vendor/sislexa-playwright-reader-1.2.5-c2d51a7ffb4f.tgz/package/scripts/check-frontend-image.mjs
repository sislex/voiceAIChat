import { execFileSync } from 'node:child_process'
import { mkdtempSync, mkdirSync, rmSync } from 'node:fs'
import { resolve, join } from 'node:path'

const docker = args => execFileSync('docker', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'inherit'] }).trim()
const commit = process.env.APPLICATION_COMMIT ?? execFileSync('git', ['rev-parse', 'HEAD'], { encoding: 'utf8' }).trim()
const version = process.env.APPLICATION_VERSION ?? '1.1.0'
const parent = process.env.DELIVERY_ATTEMPT_ROOT ? join(process.env.DELIVERY_ATTEMPT_ROOT, 'artifacts') : resolve('artifacts')
mkdirSync(parent, { recursive: true })
const temp = mkdtempSync(join(parent, 'frontend-image-'))
let image
try {
  const iid = join(temp, 'iid')
  docker(['build', '--target', 'frontend', '--build-arg', 'APPLICATION_VERSION=' + version,
    '--build-arg', 'APPLICATION_COMMIT=' + commit, '--iidfile', iid, '.'])
  const { readFileSync } = await import('node:fs')
  image = readFileSync(iid, 'utf8').trim()
  const bytes = Number(docker(['image', 'inspect', '--format', '{{.Size}}', image]))
  console.log(JSON.stringify({ target: 'frontend', image, bytes, budgetBytes: 200_000_000 }))
  if (!Number.isSafeInteger(bytes) || bytes <= 0 || bytes >= 200_000_000)
    throw new Error('Frontend image must be smaller than 200 MB')
  // No published host port and no persistent service; verify the actual image.
  docker(['run', '--rm', '--network', 'none', '--entrypoint', 'node', image, '--input-type=module', '-e', `
    import assert from 'node:assert/strict';
    import { existsSync } from 'node:fs';
    assert.equal(existsSync('/app/node_modules'), false);
    await import('/app/scripts/application-frontend-server.mjs');
    try {
      const response = await fetch('http://127.0.0.1:8080/manifest.json');
      assert.equal(response.status, 200);
      const manifest = await response.json();
      const asset = await fetch('http://127.0.0.1:8080/' + manifest.entry.path);
      assert.equal(asset.status, 200);
      assert.ok((await asset.arrayBuffer()).byteLength);
      assert.equal((await fetch('http://127.0.0.1:8080/v1/health')).status, 200);
      process.exit(0);
    } catch (error) { console.error(error); process.exit(1); }
  `])
} finally {
  rmSync(temp, { recursive: true, force: true })
  // Build output stays available for the supervisor's image-size evidence.
}
