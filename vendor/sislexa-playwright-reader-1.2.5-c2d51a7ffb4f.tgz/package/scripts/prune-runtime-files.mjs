import { readdirSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

// Keep runtime TypeScript and metadata. Do not follow workspace symlinks.
export function pruneRuntimeFiles(root) {
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    const path = join(root, entry.name)
    if (entry.isSymbolicLink()) continue
    if ((entry.isDirectory() && /^(?:test|tests|__tests__|__mocks__|stories|coverage)$/.test(entry.name)) ||
        (entry.isFile() && /(?:\.(?:test|spec|stories)\.[cm]?[jt]sx?$|\.map$|\.tsbuildinfo$)/.test(entry.name)))
      rmSync(path, { recursive: true, force: true })
    else if (entry.isDirectory()) pruneRuntimeFiles(path)
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href)
  for (const root of process.argv.slice(2)) pruneRuntimeFiles(root)
