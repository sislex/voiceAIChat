import { readdirSync, readFileSync, existsSync } from 'node:fs'
import { basename, resolve, relative } from 'node:path'
import ts from 'typescript'

export const directories = ['apps/playwright-reader', 'packages/playwright-reader-contracts', 'packages/playwright-reader-app', 'packages/browser-contracts', 'apps/browser-runner', 'scripts']
const isTest = file => /\.(?:test|spec)\.[cm]?[jt]sx?$/.test(file)
const owner = file => directories.find(directory => file.startsWith(`${directory}/`))
const moduleName = file => basename(file).replace(/\.(?:dom\.)?(?:test|spec)\.[cm]?[jt]sx?$|\.[cm]?[jt]sx?$/g, '')

/** Select changed, matching-name and bounded direct-importer tests, in that order. */
export function selectTaskTests(changed, tests) {
  changed = changed.filter(file => !/\.(?:md|mdx|rst|txt)$/.test(file))
  const changedSet = new Set(changed)
  const selected = new Set(tests.filter(test => changedSet.has(test.path)).map(test => test.path))
  const sources = changed.filter(file => !isTest(file) && /\.[cm]?[jt]sx?$/.test(file))
  for (const test of tests) {
    if (sources.some(file => owner(file) === owner(test.path) && moduleName(file) === moduleName(test.path))) selected.add(test.path)
  }
  const importers = tests.filter(test => !selected.has(test.path) && test.imports.some(file => changedSet.has(file)))
  if (importers.length <= 10) for (const test of importers) selected.add(test.path)
  return { paths: [...selected], deferred: importers.length > 10 ? importers.length : 0,
    packages: directories.filter(directory => directory !== 'scripts' && changed.some(file => file.startsWith(`${directory}/`))) }
}

export function planTaskTests(changed, root = process.cwd()) {
  if (!changed.some(file => owner(file))) return selectTaskTests(changed, [])
  const tests = []
  for (const directory of directories) {
    const configPath = resolve(root, directory, 'tsconfig.json')
    const config = existsSync(configPath) ? ts.readConfigFile(configPath, ts.sys.readFile).config : {}
    const options = ts.parseJsonConfigFileContent(config, ts.sys, resolve(root, directory)).options
    const visit = folder => {
      if (!existsSync(folder)) return
      for (const entry of readdirSync(folder, { withFileTypes: true })) {
        if (['node_modules', 'dist', '.git'].includes(entry.name)) continue
        const path = resolve(folder, entry.name)
        if (entry.isDirectory()) visit(path)
        else if (isTest(path)) {
          const imports = ts.preProcessFile(readFileSync(path, 'utf8'), true, true).importedFiles.flatMap(item => {
            const result = ts.resolveModuleName(item.fileName, path, options, ts.sys).resolvedModule
            return result ? [relative(root, result.resolvedFileName)] : []
          })
          tests.push({ path: relative(root, path), imports })
        }
      }
    }
    visit(resolve(root, directory))
  }
  return selectTaskTests(changed, tests)
}
