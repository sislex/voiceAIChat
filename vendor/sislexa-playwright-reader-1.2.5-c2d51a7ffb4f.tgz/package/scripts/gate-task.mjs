import { execFileSync, spawn } from 'node:child_process'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import { directories, planTaskTests } from './affected-tests.mjs'

export const MAX_TESTS = 1000
export const MAX_MS = 60_000
export function startDeadline(onTimeout) {
  const timer = setTimeout(onTimeout, MAX_MS)
  return () => clearTimeout(timer)
}
export function testSelection(files) {
  const flatten = tasks => tasks.flatMap(task => task.type === 'test' ? [task] : flatten(task.tasks ?? []))
  return { count: flatten(files).length, paths: files.map(file => file.filepath) }
}
/** A budget breach exits 2 (contract in Core docs/plans/dev-lane-v1.md «Общий контракт»). */
export class BudgetError extends Error {}
export function assertBudget(count, elapsed) {
  if (count > MAX_TESTS || elapsed >= MAX_MS) throw new BudgetError(`Task gate budget exceeded: ${count}/${MAX_TESTS} tests, ${elapsed}/${MAX_MS} ms. Narrow the task or use the supervisor gate.`)
}
export function changedFiles(base = 'HEAD') {
  const git = (...args) => execFileSync('git', args, { encoding: 'utf8' }).split('\0').filter(Boolean)
  return [...new Set([...git('diff', '--name-only', '-z', base, '--'), ...git('ls-files', '--others', '--exclude-standard', '-z')])]
}
export async function runTaskGate(files = changedFiles()) {
  const started = Date.now()
  const summary = () => console.log(`GATE-TASK: tests=${count} seconds=${((Date.now() - started) / 1000).toFixed(1)}`)
  const slow = () => { console.log('GATE-TASK-SLOW:'); for (const path of selections.flat()) console.log(path) }
  const stopDeadline = startDeadline(() => { console.error('Task gate exceeded 60 s'); summary(); slow(); process.exit(2) })
  const contexts = []
  const selections = []
  let count = 0

  try {
    const plan = planTaskTests(files)
    if (plan.deferred) console.log(`GATE-TASK-DEFERRED: ${plan.deferred} direct importer file(s) left to the promotion gate`)
    const createVitest = plan.paths.length ? (await import('vitest/node')).createVitest : null
    for (const directory of directories) {
      const paths = plan.paths.filter(file => file.startsWith(`${directory}/`))
      if (!paths.length) { contexts.push(null); selections.push([]); continue }
      // Repository scripts use node:test, not workspace Vitest configurations.
      if (directory === 'scripts') { contexts.push(null); selections.push(paths); continue }
      const ctx = await createVitest('test', {
        root: resolve(directory), config: resolve(directory, 'vitest.config.ts'),
        watch: false, include: paths.map(file => file.slice(directory.length + 1)), passWithNoTests: true,
        fileParallelism: true, minWorkers: 1, maxWorkers: 4,
      })
      contexts.push(ctx)
      const collected = await ctx.collect()
      const selection = testSelection(collected.tests)
      selections.push(selection.paths)
      if (collected.errors.length || collected.tests.some(file => file.result?.state === 'fail')) throw new Error('Test collection failed')
      count += selection.count
      assertBudget(count, Date.now() - started)
    }
    console.log(`Task gate: ${count}/${MAX_TESTS} selected tests; 60 s total budget; no browser suite`)
    for (let i = 0; i < contexts.length; i++) {
      const ctx = contexts[i]
      const directory = directories[i]
      if (plan.packages.includes(directory)) {
        await new Promise((accept, reject) => {
          const child = spawn(process.execPath, [resolve('scripts/typecheck.mjs')], { cwd: resolve(directory), stdio: 'inherit' })
          const kill = () => child.kill('SIGTERM')
          process.once('exit', kill)
          child.on('error', reject)
          child.on('exit', code => { process.removeListener('exit', kill); code === 0 ? accept() : reject(new Error(`Typecheck failed: ${directory}`)) })
        })
      }
      if (directory === 'scripts' && selections[i].length) {
        const result = await new Promise((accept, reject) => {
          const child = spawn(process.execPath, ['--test', '--test-reporter=tap', ...selections[i]], { stdio: ['ignore', 'pipe', 'inherit'] })
          let output = ''
          child.stdout.on('data', chunk => { output += chunk; process.stdout.write(chunk) })
          const kill = () => child.kill('SIGTERM')
          process.once('exit', kill)
          child.on('error', reject)
          child.on('exit', code => {
            process.removeListener('exit', kill)
            accept({ code, count: Number(output.match(/^# tests (\d+)$/m)?.[1] ?? 0) })
          })
        })
        count += result.count
        assertBudget(count, Date.now() - started)
        if (result.code !== 0) throw new Error('Selected Node script tests failed')
      } else if (selections[i].length) await ctx.start(selections[i])
      if (ctx) {
        const report = tasks => { for (const task of tasks) {
          if (task.type === 'test') console.log(`GATE-TASK-CASE: ${task.name} seconds=${((task.result?.duration ?? 0) / 1000).toFixed(3)}`)
          else report(task.tasks ?? [])
        } }
        report(ctx.state.getFiles())
      }
      if (ctx && (ctx.state.getFiles().some(file => file.result?.state === 'fail') || ctx.state.getUnhandledErrors().length)) throw new Error('Selected tests failed')
      assertBudget(count, Date.now() - started)
    }
    summary()
  } catch (error) {
    summary()
    if (error instanceof BudgetError) slow()
    throw error
  } finally {
    await Promise.all(contexts.filter(Boolean).map(ctx => ctx.close()))
    stopDeadline()
  }
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const args = process.argv.slice(2)
  const at = args.indexOf('--base')
  const files = at >= 0 ? changedFiles(args[at + 1]) : args.length ? args : undefined
  runTaskGate(files).catch(error => { console.error(error.message); process.exitCode = error instanceof BudgetError ? 2 : 1 })
}
