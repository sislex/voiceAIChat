import { build } from 'vite'
import { resolve } from 'node:path'
import { pathToFileURL } from 'node:url'

// Bundle pinned shared validators without runtime packages or a TypeScript loader.
export async function buildFrontendServer(outDir = 'dist/frontend-server') {
  await build({
    configFile: false,
    ssr: { noExternal: true },
    build: {
      ssr: resolve('scripts/application-frontend-server.mjs'),
      outDir, emptyOutDir: true, sourcemap: false, minify: false,
      rollupOptions: { output: { entryFileNames: 'application-frontend-server.mjs', inlineDynamicImports: true } }
    }
  })
}
if (process.argv[1] && import.meta.url === pathToFileURL(resolve(process.argv[1])).href)
  await buildFrontendServer()
