# Sislexa Desktop

Independent Electron chat client. Connect to any compatible Sislexa server through
the server URL setup window. The chat UI is a pinned artifact owned by `sislex/sislexa-core-ui`; machine
mode consumes the published Agent runtime. No sibling repository is required.

Run `npm ci`, `npm run gate`, then `npm run dev`. Production server credentials
are entered through the normal login screen. Persistent machine tokens stay in
Electron safeStorage. Legacy local conversations are imported idempotently after
login; the original SQLite file is retained.

Version 1.0.7 consumes Core API 1.x, Core UI 1.4.4 / Desktop host 1.x and Agent
0.20.x / machine protocol 1.x. Exact dependency archives are locked in vendor.
`npm run dist` builds the macOS ARM64 DMG; `npm run pack:release` publishes the
built client archive for Core integration checks. Product chat tests live in
`sislex/sislexa-core-ui`; Electron configuration, migration and packaging tests belong here.

The standard gate checks types, the build and packaged renderer. Electron application
tests are temporarily opt-in through `npm run gate:electron`; that command launches
real Electron against isolated temporary user data and checks server setup → published
chat login, persisted origin and preload isolation.
Changing server origin reloads the renderer without restarting a local backend.

Chat-client 1.0.1 keeps the previous Electron renderer's Chrome 126 build target
and disables the browser module-preload polyfill. Using Vite's generic browser
defaults increases the artifact and fails Core's existing route-size budgets.

Packaged chat assets load at the fixed secure origin `sislexa://app`.
Only this custom scheme resolves local files. HTTP(S) requests retain Chromium's
normal CORS, TLS and HttpOnly cookie policy. Core must allow `sislexa://app` in
`VC_CORS_ORIGINS` (included by default starting with Core 0.1.325). There is no
null/wildcard CORS, HTTP interception or disabled web security. Traversal and
foreign-origin requests cannot map into the renderer folder. The native gate
checks actual login transport, HttpOnly cookies and rejection of unrelated origins.

The browser/renderer owner is now `sislex/sislexa-core-ui`. Desktop updates only the pinned renderer archive and keeps native packaging, preload and migration tests here. The former chat-client 1.0.1 dependency is retained solely for the frozen legacy import DTO/default-settings contract; its renderer is no longer loaded or copied.

The Core UI 1.5.0 renderer archive is pinned by SHA-256 `51a8c29b8f1ba152292ec69d2d185b9ea7b2c5b5d560fe0cfe2d83d11f790288` from owner commit `9b6264a5741b16fb45c8efd2123a25f25756c939`. Desktop copies its prebuilt renderer through the package export; it does not compile Core UI source. The opt-in native gate checks login, session cookies, preload isolation and existing voice-capable renderer startup.
