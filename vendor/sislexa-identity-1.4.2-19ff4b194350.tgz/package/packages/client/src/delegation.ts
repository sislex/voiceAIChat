import {
  IDENTITY_DELEGATION_PATHS as paths, isDelegationIdentifier, isDelegationIntrospection,
  type DelegationIntrospectionClient
} from '../../contracts/src/delegation.js'

export interface DelegationTransport {
  url: string
  /** Component credential authorizes introspection only, never the delegated user. */
  token: string
  fetchImpl?: typeof fetch
  now?: () => number
}

export class DelegationDependencyError extends Error {
  readonly statusCode = 503
  constructor() { super('Identity delegation dependency unavailable') }
}

/** No cache or retry: each operation observes a fresh authoritative verdict. */
export function createDelegationIntrospectionClient(transport: DelegationTransport): DelegationIntrospectionClient {
  const endpoint = new URL(paths.introspect, transport.url)
  if (!['https:', 'http:'].includes(endpoint.protocol) || endpoint.username || endpoint.password || !transport.token.trim()) throw new TypeError('Invalid delegation transport')
  return {
    async introspect(input) {
      if (!input || typeof input.token !== 'string' || !input.token.trim() || input.token.length > 16384 || !isDelegationIdentifier(input.audience)) throw new TypeError('Invalid introspection request')
      try {
        const response = await (transport.fetchImpl ?? fetch)(endpoint, {
          method: 'POST', headers: { authorization: `Bearer ${transport.token}`, 'content-type': 'application/json' },
          body: JSON.stringify({ token: input.token, audience: input.audience }),
          credentials: 'omit', redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(15000)
        })
        if (!response.ok) throw new DelegationDependencyError()
        const verdict: unknown = await response.json()
        if (!isDelegationIntrospection(verdict)) throw new DelegationDependencyError()
        if (!verdict.active) return verdict
        const now = (transport.now ?? Date.now)()
        if (!Number.isSafeInteger(now) || now < 0 || verdict.principal.audience !== input.audience || verdict.principal.issuedAt > now) throw new DelegationDependencyError()
        if (verdict.principal.expiresAt <= now) return { version: 1, active: false }
        return verdict
      } catch {
        // Never expose a token-bearing URL, request body, or dependency error body.
        throw new DelegationDependencyError()
      }
    }
  }
}
