import{j as a}from"./jsx-runtime-BYYWji4R.js";import{r as z}from"./index-ClcD9ViR.js";import{fn as s,within as H,userEvent as g,expect as d}from"./index-DeN4tkzB.js";import{V as W}from"./VoiceBar-C4oHZInD.js";import{q as P}from"./chat-COYZgq2j.js";import"./ci-D4ljpCSx.js";import"./machines-mJ7_PUPS.js";import"./clarification-BhK1l2ki.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";import"./hotkeys-4oJJtujI.js";import"./types-CmoD7ERW.js";import"./autoGrow-CoBFBF9S.js";import"./view-0MbJGw9Y.js";import"./animations--P72MiAI.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./icons-M-fant0Z.js";import"./images-CH23vBlI.js";import"./tools-D2dVYbOd.js";import"./questions-Bk4wc6lB.js";import"./time-CfyNS7J_.js";import"./agentProtocol-ChPLBt7B.js";import"./version-CuhpF6Tw.js";import"./kb-CjYTCLN0.js";const l=()=>{},Fa={title:"Chat/VoiceBar",component:W,args:{state:"idle",draft:"",diarization:!0,detectedSpeakers:[],attachments:[],onDraftChange:s(),onSubmitText:s(),onStartVoice:s(),onStopVoice:s(),onStopSpeak:s(),onCancelRequest:s(),onAddFiles:s(),onRemoveAttachment:s(),defaultCollapsed:!1},decorators:[t=>a.jsx("div",{style:{maxWidth:860},children:a.jsx(t,{})})]},y={},N={args:{draft:"Сохранённый черновик беседы. Длинный текст остаётся доступным для редактирования."},decorators:[t=>a.jsx("div",{style:{width:390,maxWidth:"100%"},children:a.jsx(t,{})})]},V={args:{attachments:[{localId:"pasted",name:"clipboard.svg",status:"ready",previewUrl:'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="80" height="60"%3E%3Crect width="80" height="60" fill="skyblue"/%3E%3C/svg%3E'}]}},h={args:{draft:"Разберись, почему упал шаг npm test в последнем ране."}},f={args:{state:"listening",detectedSpeakers:[1,2]}},v={args:{state:"listening",detectedSpeakers:[1],diarization:!1}},w={args:{state:"transcribing"}},ya=`
  .waiting-in-feed-story { display: grid; min-height: 420px; grid-template-rows: 1fr auto; }
  .waiting-in-feed-story__timeline {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    gap: 10px;
    min-height: 260px;
    padding: 20px 14px;
    background: var(--bg);
  }
  .waiting-in-feed-story__message {
    align-self: flex-end;
    max-width: min(76%, 560px);
    padding: 9px 12px;
    border-radius: 14px 14px 4px 14px;
    background: var(--accent);
    color: white;
  }
  .waiting-in-feed-story__preparing {
    align-self: flex-start;
    display: flex;
    align-items: center;
    gap: 7px;
    min-height: 26px;
    color: var(--text-dim);
    font-size: 13px;
  }
  .waiting-in-feed-story__dots { letter-spacing: 2px; color: var(--accent); }
`,x={args:{state:"thinking",draft:"Следующее сообщение в очередь"},render:t=>a.jsxs("div",{className:"waiting-in-feed-story",children:[a.jsx("style",{children:ya}),a.jsxs("div",{className:"waiting-in-feed-story__timeline",role:"log","aria-label":"Сообщения",children:[a.jsx("div",{className:"waiting-in-feed-story__message",children:"Проверь, почему последний тест падает только в CI"}),a.jsxs("div",{className:"waiting-in-feed-story__preparing",role:"status",children:[a.jsx("span",{className:"waiting-in-feed-story__dots","aria-hidden":"true",children:"•••"}),a.jsx("span",{children:"Готовим ответ…"})]})]}),a.jsx(W,{...t})]})},S={args:{state:"thinking",replyStarted:!0,draft:"А ещё проверь кэш npm"}},C={args:{state:"speaking"}},T={args:{voiceInputEnabled:!1}},ha=`
  .attachment-preview-story .attchips { align-items: flex-end; }
  .attachment-preview-story .attpreview-image {
    background:
      linear-gradient(145deg, transparent 55%, rgba(255,255,255,.22) 56% 64%, transparent 65%),
      radial-gradient(circle at 72% 28%, #ffd166 0 7px, transparent 8px),
      linear-gradient(155deg, #7db7e8 0 48%, #4f8f6a 49% 67%, #315f49 68%);
  }
  .attachment-preview-story .attpreview-image > span { display: none; }
`,u={decorators:[t=>a.jsxs("div",{className:"attachment-preview-story",children:[a.jsx("style",{children:ha}),a.jsx(t,{})]})],args:{draft:"Вот скриншот и лог рана",attachments:[P({name:"скриншот-падения.png"}),P({name:"ci-run-1934.log",mimeType:"text/plain"})]}},b={args:{layout:"centered",draft:"",userDisplayName:"Анна"}},I={args:{layout:"docked",draft:"Следующее сообщение"}},k={args:{draft:`Первая строка
Вторая строка
Третья строка`}},E={args:{draft:Array.from({length:10},(t,e)=>`Строка ${e+1}: детали задачи`).join(`
`)}},B={args:{draft:`Первая строка
Вторая строка
Третья строка`},play:async({canvasElement:t})=>{const e=H(t);await g.click(e.getByTestId("composer-size-toggle")),await d(e.getByLabelText("Поле ввода сообщения").closest(".voicebar")).toHaveClass("voicebar--expanded")}},A={args:{draft:"Посмотри изображение",attachments:[{localId:"processing-image",status:"processing",name:"большой-скриншот.png",mimeType:"image/png"}]}},_={decorators:u.decorators,args:{draft:"Посмотри изображение",attachments:[{localId:"ready-image",status:"ready",name:"готовый-скриншот.png",mimeType:"image/png"}]}},j={args:{draft:"Посмотри изображение",onRetryAttachment:s(),attachments:[{localId:"error-image",status:"error",name:"сломанный-скриншот.png",mimeType:"image/png",error:"Не удалось загрузить"}]}},q={args:{draft:"Три изображения",onRetryAttachment:s(),attachments:[{localId:"processing",status:"processing",name:"обработка.png",mimeType:"image/png"},{localId:"ready",status:"ready",name:"готово.png",mimeType:"image/png"},{localId:"error",status:"error",name:"ошибка.png",mimeType:"image/png",error:"Сеть недоступна"}]}},ua=Array.from({length:5},(t,e)=>({id:`queue-${e+1}`,conversationId:"storybook-chat",messageId:`message-${e+1}`,text:e===1?"Очень длинное ожидающее сообщение, проверяющее перенос текста и доступность действий при увеличенном размере шрифта.":`Ожидающее сообщение ${e+1}`,attachments:e===0?["image-upload","document-upload"]:[],...e===0?{attachmentDetails:[{uploadId:"image-upload",path:"/fixtures/image.png",name:"image.png",mimeType:"image/png",size:1024},{uploadId:"document-upload",path:"/fixtures/document.pdf",name:"document.pdf",mimeType:"application/pdf",size:2048}]}:{},position:e+1,status:"queued",createdAt:e+1}));function fa(t){const[e,m]=z.useState(ua);return a.jsx(W,{...t,queuedTurns:e,onEditQueued:(n,i)=>{var c;m(o=>o.map(r=>r.id===n?{...r,text:i}:r)),(c=t.onEditQueued)==null||c.call(t,n,i)},onDeleteQueued:n=>{var i;m(c=>c.filter(o=>o.id!==n).map((o,r)=>({...o,position:r+1}))),(i=t.onDeleteQueued)==null||i.call(t,n)},onSendQueuedNow:n=>{var i;m(c=>{const o=c.find(r=>r.id===n);return o?[o,...c.filter(r=>r.id!==n)].map((r,ga)=>({...r,position:ga+1})):c}),(i=t.onSendQueuedNow)==null||i.call(t,n)}})}const p={render:t=>a.jsx(fa,{...t}),args:{state:"thinking",queuedTurns:ua,onEditQueued:s(),onDeleteQueued:s(),onSendQueuedNow:s()},play:async({canvasElement:t})=>{const e=H(t);await d(e.getAllByTestId("turn-queue-item")).toHaveLength(3),await g.click(e.getByRole("button",{name:"Показать ещё 2"})),await d(e.getAllByTestId("turn-queue-item")).toHaveLength(5),await g.click(e.getByRole("button",{name:"Отправить сейчас сообщение № 5"})),await d(e.getAllByTestId("turn-queue-item")[0]).toHaveTextContent("Ожидающее сообщение 5")}},D={args:{...p.args,defaultCollapsed:!0,allowCollapse:!0},parameters:{viewport:{defaultViewport:"mobile1"}},play:async({canvasElement:t})=>{const e=H(t);await d(e.queryByLabelText("Поле ввода сообщения")).not.toBeInTheDocument(),await d(e.getAllByTestId("turn-queue-item")).toHaveLength(3),await g.click(e.getByRole("button",{name:"Показать ещё 2"})),await d(e.getAllByTestId("turn-queue-item")).toHaveLength(5)}},L={args:{...p.args,queuePaused:!0,requestError:"Движок недоступен"}},Q={args:{allowCollapse:!0,defaultCollapsed:!0,draft:"Проверь, почему шаг npm test падает только в CI"},parameters:{viewport:{defaultViewport:"mobile1"}}},R={args:{allowCollapse:!0,defaultCollapsed:!0,state:"thinking"},parameters:{viewport:{defaultViewport:"mobile1"}}};function va({initial:t="",state:e="idle"}){const[m,n]=z.useState(t),[i,c]=z.useState([]);return a.jsxs("div",{style:{maxWidth:860},children:[i.length>0&&a.jsx("ul",{className:"attchips","data-testid":"sent-messages",children:i.map((o,r)=>a.jsx("li",{className:"attchip",children:o},r))}),a.jsx(W,{defaultCollapsed:!1,state:e,draft:m,diarization:!0,detectedSpeakers:[],attachments:[],onDraftChange:n,onSubmitText:()=>{c(o=>[...o,m]),n("")},onStartVoice:l,onStopVoice:l,onStopSpeak:l,onCancelRequest:l,onAddFiles:l,onRemoveAttachment:l})]})}const M={render:()=>a.jsx(va,{}),play:async({canvasElement:t})=>{const e=H(t);await g.type(e.getByLabelText("Поле ввода сообщения"),"Проверь гейт пакета ui"),await g.click(e.getByLabelText("Отправить сообщение")),await d(e.getByTestId("sent-messages")).toHaveTextContent("Проверь гейт пакета ui"),await d(e.getByLabelText("Поле ввода сообщения")).toHaveValue("")}};var U,F,$,O,G;y.parameters={...y.parameters,docs:{...(U=y.parameters)==null?void 0:U.docs,source:{originalSource:"{}",...($=(F=y.parameters)==null?void 0:F.docs)==null?void 0:$.source},description:{story:"Простой: композер пуст, кнопка справа — микрофон.",...(G=(O=y.parameters)==null?void 0:O.docs)==null?void 0:G.description}}};var J,K,X;N.parameters={...N.parameters,docs:{...(J=N.parameters)==null?void 0:J.docs,source:{originalSource:`{
  args: {
    draft: 'Сохранённый черновик беседы. Длинный текст остаётся доступным для редактирования.'
  },
  decorators: [Story => <div style={{
    width: 390,
    maxWidth: '100%'
  }}><Story /></div>]
}`,...(X=(K=N.parameters)==null?void 0:K.docs)==null?void 0:X.source}}};var Y,Z,ee;V.parameters={...V.parameters,docs:{...(Y=V.parameters)==null?void 0:Y.docs,source:{originalSource:`{
  args: {
    attachments: [{
      localId: 'pasted',
      name: 'clipboard.svg',
      status: 'ready',
      previewUrl: 'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="80" height="60"%3E%3Crect width="80" height="60" fill="skyblue"/%3E%3C/svg%3E'
    }]
  }
}`,...(ee=(Z=V.parameters)==null?void 0:Z.docs)==null?void 0:ee.source}}};var te,ae,re,se,ne;h.parameters={...h.parameters,docs:{...(te=h.parameters)==null?void 0:te.docs,source:{originalSource:`{
  args: {
    draft: 'Разберись, почему упал шаг npm test в последнем ране.'
  }
}`,...(re=(ae=h.parameters)==null?void 0:ae.docs)==null?void 0:re.source},description:{story:"Набранный черновик: микрофон сменился на «отправить».",...(ne=(se=h.parameters)==null?void 0:se.docs)==null?void 0:ne.description}}};var oe,ie,ce,de,pe;f.parameters={...f.parameters,docs:{...(oe=f.parameters)==null?void 0:oe.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    detectedSpeakers: [1, 2]
  }
}`,...(ce=(ie=f.parameters)==null?void 0:ie.docs)==null?void 0:ce.source},description:{story:"Запись: волна, «Готово» и строка обнаруженных говорящих.",...(pe=(de=f.parameters)==null?void 0:de.docs)==null?void 0:pe.description}}};var me,le,ue,ge,ye;v.parameters={...v.parameters,docs:{...(me=v.parameters)==null?void 0:me.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    detectedSpeakers: [1],
    diarization: false
  }
}`,...(ue=(le=v.parameters)==null?void 0:le.docs)==null?void 0:ue.source},description:{story:"Запись без диаризации: чипы говорящих становятся общим «Вы».",...(ye=(ge=v.parameters)==null?void 0:ge.docs)==null?void 0:ye.description}}};var he,fe,ve,we,xe;w.parameters={...w.parameters,docs:{...(he=w.parameters)==null?void 0:he.docs,source:{originalSource:`{
  args: {
    state: 'transcribing'
  }
}`,...(ve=(fe=w.parameters)==null?void 0:fe.docs)==null?void 0:ve.source},description:{story:"Распознавание: транскрипт финализируется, композер ещё заблокирован.",...(xe=(we=w.parameters)==null?void 0:we.docs)==null?void 0:xe.description}}};var Se,Ce,Te,be,Ie;x.parameters={...x.parameters,docs:{...(Se=x.parameters)==null?void 0:Se.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    draft: 'Следующее сообщение в очередь'
  },
  render: args => <div className="waiting-in-feed-story">
      <style>{waitingInFeedStoryCss}</style>
      <div className="waiting-in-feed-story__timeline" role="log" aria-label="Сообщения">
        <div className="waiting-in-feed-story__message">Проверь, почему последний тест падает только в CI</div>
        <div className="waiting-in-feed-story__preparing" role="status">
          <span className="waiting-in-feed-story__dots" aria-hidden="true">•••</span>
          <span>Готовим ответ…</span>
        </div>
      </div>
      <VoiceBar {...args} />
    </div>
}`,...(Te=(Ce=x.parameters)==null?void 0:Ce.docs)==null?void 0:Te.source},description:{story:"До первого фрагмента подготовка видна в ленте, не увеличивая нижнюю панель.",...(Ie=(be=x.parameters)==null?void 0:be.docs)==null?void 0:Ie.description}}};var ke,Ee,Be,Ae,_e;S.parameters={...S.parameters,docs:{...(ke=S.parameters)==null?void 0:ke.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    replyStarted: true,
    draft: 'А ещё проверь кэш npm'
  }
}`,...(Be=(Ee=S.parameters)==null?void 0:Ee.docs)==null?void 0:Be.source},description:{story:"Пошёл стрим ответа: композер снова доступен под черновик, отправка — нет.",...(_e=(Ae=S.parameters)==null?void 0:Ae.docs)==null?void 0:_e.description}}};var je,qe,De,Le,Qe;C.parameters={...C.parameters,docs:{...(je=C.parameters)==null?void 0:je.docs,source:{originalSource:`{
  args: {
    state: 'speaking'
  }
}`,...(De=(qe=C.parameters)==null?void 0:qe.docs)==null?void 0:De.source},description:{story:"Озвучка ответа: композер доступен, красная кнопка останавливает речь.",...(Qe=(Le=C.parameters)==null?void 0:Le.docs)==null?void 0:Qe.description}}};var Re,Me,Ne,Ve,He;T.parameters={...T.parameters,docs:{...(Re=T.parameters)==null?void 0:Re.docs,source:{originalSource:`{
  args: {
    voiceInputEnabled: false
  }
}`,...(Ne=(Me=T.parameters)==null?void 0:Me.docs)==null?void 0:Ne.source},description:{story:"Микрофон недоступен: движок распознавания не поднялся (нет модели, нет доступа\nк устройству) — голосовой ввод выключен целиком, кнопки микрофона нет, и в\nпростое панель молчит вместо подсказки про пробел. Текст самой ошибки живёт в\nбаннере ленты (`ChatColumn`, сториз `WithError`).",...(He=(Ve=T.parameters)==null?void 0:Ve.docs)==null?void 0:He.description}}};var We,ze,Pe,Ue,Fe;u.parameters={...u.parameters,docs:{...(We=u.parameters)==null?void 0:We.docs,source:{originalSource:`{
  decorators: [Story => <div className="attachment-preview-story">
      <style>{attachmentPreviewStoryCss}</style>
      <Story />
    </div>],
  args: {
    draft: 'Вот скриншот и лог рана',
    attachments: [makeUpload({
      name: 'скриншот-падения.png'
    }), makeUpload({
      name: 'ci-run-1934.log',
      mimeType: 'text/plain'
    })]
  }
}`,...(Pe=(ze=u.parameters)==null?void 0:ze.docs)==null?void 0:Pe.source},description:{story:"Изображение показано миниатюрой с именем снизу; прочие файлы остаются чипами.",...(Fe=(Ue=u.parameters)==null?void 0:Ue.docs)==null?void 0:Fe.description}}};var $e,Oe,Ge,Je,Ke;b.parameters={...b.parameters,docs:{...($e=b.parameters)==null?void 0:$e.docs,source:{originalSource:`{
  args: {
    layout: 'centered',
    draft: '',
    userDisplayName: 'Анна'
  }
}`,...(Ge=(Oe=b.parameters)==null?void 0:Oe.docs)==null?void 0:Ge.source},description:{story:"Пустой чат: композер по центру с приветствием.",...(Ke=(Je=b.parameters)==null?void 0:Je.docs)==null?void 0:Ke.description}}};var Xe,Ye,Ze,et,tt;I.parameters={...I.parameters,docs:{...(Xe=I.parameters)==null?void 0:Xe.docs,source:{originalSource:`{
  args: {
    layout: 'docked',
    draft: 'Следующее сообщение'
  }
}`,...(Ze=(Ye=I.parameters)==null?void 0:Ye.docs)==null?void 0:Ze.source},description:{story:"Разговор начат: композер закреплён внизу колонки.",...(tt=(et=I.parameters)==null?void 0:et.docs)==null?void 0:tt.description}}};var at,rt,st,nt,ot;k.parameters={...k.parameters,docs:{...(at=k.parameters)==null?void 0:at.docs,source:{originalSource:`{
  args: {
    draft: 'Первая строка\\nВторая строка\\nТретья строка'
  }
}`,...(st=(rt=k.parameters)==null?void 0:rt.docs)==null?void 0:st.source},description:{story:"Поле начинается с одной строки и растёт на каждую новую строку текста.",...(ot=(nt=k.parameters)==null?void 0:nt.docs)==null?void 0:ot.description}}};var it,ct,dt,pt,mt;E.parameters={...E.parameters,docs:{...(it=E.parameters)==null?void 0:it.docs,source:{originalSource:`{
  args: {
    draft: Array.from({
      length: 10
    }, (_, index) => \`Строка \${index + 1}: детали задачи\`).join('\\n')
  }
}`,...(dt=(ct=E.parameters)==null?void 0:ct.docs)==null?void 0:dt.source},description:{story:"После четырёх строк высота ограничена, текст прокручивается внутри поля.",...(mt=(pt=E.parameters)==null?void 0:pt.docs)==null?void 0:mt.description}}};var lt,ut,gt,yt,ht;B.parameters={...B.parameters,docs:{...(lt=B.parameters)==null?void 0:lt.docs,source:{originalSource:`{
  args: {
    draft: 'Первая строка\\nВторая строка\\nТретья строка'
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByTestId('composer-size-toggle'));
    await expect(canvas.getByLabelText('Поле ввода сообщения').closest('.voicebar')).toHaveClass('voicebar--expanded');
  }
}`,...(gt=(ut=B.parameters)==null?void 0:ut.docs)==null?void 0:gt.source},description:{story:"Редактор раскрыт вручную; play оставляет story в раскрытом состоянии.",...(ht=(yt=B.parameters)==null?void 0:yt.docs)==null?void 0:ht.description}}};var ft,vt,wt,xt,St;A.parameters={...A.parameters,docs:{...(ft=A.parameters)==null?void 0:ft.docs,source:{originalSource:`{
  args: {
    draft: 'Посмотри изображение',
    attachments: [{
      localId: 'processing-image',
      status: 'processing',
      name: 'большой-скриншот.png',
      mimeType: 'image/png'
    }]
  }
}`,...(wt=(vt=A.parameters)==null?void 0:vt.docs)==null?void 0:wt.source},description:{story:"Изображение обрабатывается: плитка зарезервирована, отправка заблокирована.",...(St=(xt=A.parameters)==null?void 0:xt.docs)==null?void 0:St.description}}};var Ct,Tt,bt,It,kt;_.parameters={..._.parameters,docs:{...(Ct=_.parameters)==null?void 0:Ct.docs,source:{originalSource:`{
  decorators: WithAttachments.decorators,
  args: {
    draft: 'Посмотри изображение',
    attachments: [{
      localId: 'ready-image',
      status: 'ready',
      name: 'готовый-скриншот.png',
      mimeType: 'image/png'
    }]
  }
}`,...(bt=(Tt=_.parameters)==null?void 0:Tt.docs)==null?void 0:bt.source},description:{story:"Изображение готово и может быть отправлено.",...(kt=(It=_.parameters)==null?void 0:It.docs)==null?void 0:kt.description}}};var Et,Bt,At,_t,jt;j.parameters={...j.parameters,docs:{...(Et=j.parameters)==null?void 0:Et.docs,source:{originalSource:`{
  args: {
    draft: 'Посмотри изображение',
    onRetryAttachment: fn(),
    attachments: [{
      localId: 'error-image',
      status: 'error',
      name: 'сломанный-скриншот.png',
      mimeType: 'image/png',
      error: 'Не удалось загрузить'
    }]
  }
}`,...(At=(Bt=j.parameters)==null?void 0:Bt.docs)==null?void 0:At.source},description:{story:"Ошибка изображения: плитка сохраняется, доступны повтор и удаление.",...(jt=(_t=j.parameters)==null?void 0:_t.docs)==null?void 0:jt.description}}};var qt,Dt,Lt,Qt,Rt;q.parameters={...q.parameters,docs:{...(qt=q.parameters)==null?void 0:qt.docs,source:{originalSource:`{
  args: {
    draft: 'Три изображения',
    onRetryAttachment: fn(),
    attachments: [{
      localId: 'processing',
      status: 'processing',
      name: 'обработка.png',
      mimeType: 'image/png'
    }, {
      localId: 'ready',
      status: 'ready',
      name: 'готово.png',
      mimeType: 'image/png'
    }, {
      localId: 'error',
      status: 'error',
      name: 'ошибка.png',
      mimeType: 'image/png',
      error: 'Сеть недоступна'
    }]
  }
}`,...(Lt=(Dt=q.parameters)==null?void 0:Dt.docs)==null?void 0:Lt.source},description:{story:"Смешанные статусы вложений явно блокируют отправку до устранения проблем.",...(Rt=(Qt=q.parameters)==null?void 0:Qt.docs)==null?void 0:Rt.description}}};var Mt,Nt,Vt,Ht,Wt;p.parameters={...p.parameters,docs:{...(Mt=p.parameters)==null?void 0:Mt.docs,source:{originalSource:`{
  render: args => <MessageQueueDemo {...args} />,
  args: {
    state: 'thinking',
    queuedTurns,
    onEditQueued: fn(),
    onDeleteQueued: fn(),
    onSendQueuedNow: fn()
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(3);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать ещё 2'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(5);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Отправить сейчас сообщение № 5'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')[0]).toHaveTextContent('Ожидающее сообщение 5');
  }
}`,...(Vt=(Nt=p.parameters)==null?void 0:Nt.docs)==null?void 0:Vt.source},description:{story:"Свёрнутая очередь показывает первые три элемента и счётчик остальных.",...(Wt=(Ht=p.parameters)==null?void 0:Ht.docs)==null?void 0:Wt.description}}};var zt,Pt,Ut,Ft,$t;D.parameters={...D.parameters,docs:{...(zt=D.parameters)==null?void 0:zt.docs,source:{originalSource:`{
  args: {
    ...MessageQueue.args,
    defaultCollapsed: true,
    allowCollapse: true
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await expect(canvas.queryByLabelText('Поле ввода сообщения')).not.toBeInTheDocument();
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(3);
    await userEvent.click(canvas.getByRole('button', {
      name: 'Показать ещё 2'
    }));
    await expect(canvas.getAllByTestId('turn-queue-item')).toHaveLength(5);
  }
}`,...(Ut=(Pt=D.parameters)==null?void 0:Pt.docs)==null?void 0:Ut.source},description:{story:"Мобильный дефолт: очередь доступна, хотя само поле ввода свёрнуто.",...($t=(Ft=D.parameters)==null?void 0:Ft.docs)==null?void 0:$t.description}}};var Ot,Gt,Jt,Kt,Xt;L.parameters={...L.parameters,docs:{...(Ot=L.parameters)==null?void 0:Ot.docs,source:{originalSource:`{
  args: {
    ...MessageQueue.args,
    queuePaused: true,
    requestError: 'Движок недоступен'
  }
}`,...(Jt=(Gt=L.parameters)==null?void 0:Gt.docs)==null?void 0:Jt.source},description:{story:"Ошибка текущего хода оставляет ожидающие элементы на явной паузе.",...(Xt=(Kt=L.parameters)==null?void 0:Kt.docs)==null?void 0:Xt.description}}};var Yt,Zt,ea,ta,aa;Q.parameters={...Q.parameters,docs:{...(Yt=Q.parameters)==null?void 0:Yt.docs,source:{originalSource:`{
  args: {
    allowCollapse: true,
    defaultCollapsed: true,
    draft: 'Проверь, почему шаг npm test падает только в CI'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(ea=(Zt=Q.parameters)==null?void 0:Zt.docs)==null?void 0:ea.source},description:{story:`Свёрнутый композер — то, с чего чат открывается: поле убрано в строку, в ней
черновик (иначе вложения или состояние хода). Так под ленту сообщений
отдаётся вся высота колонки.`,...(aa=(ta=Q.parameters)==null?void 0:ta.docs)==null?void 0:aa.description}}};var ra,sa,na,oa,ia;R.parameters={...R.parameters,docs:{...(ra=R.parameters)==null?void 0:ra.docs,source:{originalSource:`{
  args: {
    allowCollapse: true,
    defaultCollapsed: true,
    state: 'thinking'
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(na=(sa=R.parameters)==null?void 0:sa.docs)==null?void 0:na.source},description:{story:"Свёрнут во время хода: кнопка остановки остаётся в строке, а не прячется.",...(ia=(oa=R.parameters)==null?void 0:oa.docs)==null?void 0:ia.description}}};var ca,da,pa,ma,la;M.parameters={...M.parameters,docs:{...(ca=M.parameters)==null?void 0:ca.docs,source:{originalSource:`{
  render: () => <ControlledVoiceBar />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.type(canvas.getByLabelText('Поле ввода сообщения'), 'Проверь гейт пакета ui');
    await userEvent.click(canvas.getByLabelText('Отправить сообщение'));
    await expect(canvas.getByTestId('sent-messages')).toHaveTextContent('Проверь гейт пакета ui');
    await expect(canvas.getByLabelText('Поле ввода сообщения')).toHaveValue('');
  }
}`,...(pa=(da=M.parameters)==null?void 0:da.docs)==null?void 0:pa.source},description:{story:`Отправка сообщения: набрать текст → кнопка микрофона сменилась на «отправить» →
клик отправляет и очищает поле. Enter делает то же (Shift+Enter — перенос).`,...(la=(ma=M.parameters)==null?void 0:ma.docs)==null?void 0:la.description}}};const $a=["Idle","RestoredDraft390","PastedImage","WithDraft","Listening","ListeningWithoutDiarization","Transcribing","WaitingForModel","ReplyStreaming","Speaking","MicUnavailable","WithAttachments","EmptyCentered","ConversationDocked","Multiline","CappedScroll","Expanded","AttachmentProcessing","AttachmentReady","AttachmentError","AttachmentMixedStatuses","MessageQueue","MessageQueueCollapsedComposer","MessageQueuePausedAfterError","Collapsed","CollapsedWhileThinking","SendMessage"];export{j as AttachmentError,q as AttachmentMixedStatuses,A as AttachmentProcessing,_ as AttachmentReady,E as CappedScroll,Q as Collapsed,R as CollapsedWhileThinking,I as ConversationDocked,b as EmptyCentered,B as Expanded,y as Idle,f as Listening,v as ListeningWithoutDiarization,p as MessageQueue,D as MessageQueueCollapsedComposer,L as MessageQueuePausedAfterError,T as MicUnavailable,k as Multiline,V as PastedImage,S as ReplyStreaming,N as RestoredDraft390,M as SendMessage,C as Speaking,w as Transcribing,x as WaitingForModel,u as WithAttachments,h as WithDraft,$a as __namedExportsOrder,Fa as default};
