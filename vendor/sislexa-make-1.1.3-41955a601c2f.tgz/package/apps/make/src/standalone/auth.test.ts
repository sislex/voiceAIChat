// Forward authentication to core: preserve headers and use core's verdict as the response status.
// Recheck every request; unavailable Core returns 503 rather than cached access.
import Fastify, { type FastifyInstance } from 'fastify'
import { afterEach, describe, expect, it } from 'vitest'
import { INTERNAL_WHOAMI_PATH, type WhoamiRequest, type WhoamiResponse } from '../internal.js'
import { registerForwardedAuth } from './auth.js'

const TOKEN = 'internal-token'
let app: FastifyInstance
let seen: WhoamiRequest[] = []
let verdict: (req: WhoamiRequest) => WhoamiResponse = () => ({ ok: true, user: { name: 'ann', role: 'developer' } })
let coreDown = false

async function setup(): Promise<void> {
  seen = []; coreDown = false
  app = Fastify()
  const fetchImpl: typeof fetch = async (input, init) => {
    if (coreDown) throw new Error('ECONNREFUSED')
    expect(String(input)).toBe(`http://core.test${INTERNAL_WHOAMI_PATH}`)
    expect(new Headers(init?.headers).get('authorization')).toBe(`Bearer ${TOKEN}`)
    const body = JSON.parse(String(init?.body)) as WhoamiRequest
    seen.push(body)
    return new Response(JSON.stringify(verdict(body)), { status: 200, headers: { 'content-type': 'application/json' } })
  }
  registerForwardedAuth(app, { coreUrl: 'http://core.test/', token: TOKEN, fetchImpl })
  app.get('/api/make/x', async (req) => ({ user: (req as unknown as { user: unknown }).user }))
  app.put('/api/make/x', async (req) => ({ user: (req as unknown as { user: unknown }).user }))
  app.get('/api/preview/make/x/index.html', async (req) => ({ user: (req as unknown as { user: unknown }).user }))
  app.get('/p/token/index.html', async () => ({ public: true }))
  await app.ready()
}
afterEach(async () => { await app?.close() })

describe('registerForwardedAuth', () => {
  it('пересылает метод, путь и cookie/Bearer/CSRF; вне /api/ не вмешивается', async () => {
    await setup()
    const res = await app.inject({ method: 'PUT', url: '/api/make/x?rev=1', headers: { cookie: 'vc_session=s1; vc_csrf=c1', 'x-vc-csrf': 'c1', authorization: 'Bearer t' } })
    expect(res.statusCode).toBe(200)
    expect(res.json()).toEqual({ user: { name: 'ann', role: 'developer' } })
    expect(seen).toEqual([{ method: 'PUT', url: '/api/make/x?rev=1', headers: { cookie: 'vc_session=s1; vc_csrf=c1', authorization: 'Bearer t', 'x-vc-csrf': 'c1' } }])
    expect((await app.inject({ method: 'GET', url: '/p/token/index.html' })).json()).toEqual({ public: true })
    expect(seen).toHaveLength(1)
  })

  it('вердикт ядра становится ответом: 401/403 с тем же текстом', async () => {
    await setup()
    verdict = () => ({ ok: false, status: 403, error: 'csrf' })
    const res = await app.inject({ method: 'PUT', url: '/api/make/x', headers: { cookie: 'vc_session=s1' } })
    expect(res.statusCode).toBe(403)
    expect(res.json()).toEqual({ error: 'csrf' })
    verdict = () => ({ ok: false, status: 401, error: 'unauthorized' })
    expect((await app.inject({ method: 'GET', url: '/api/make/x' })).statusCode).toBe(401)
    verdict = () => ({ ok: true, user: { name: 'ann', role: 'developer' } })
  })

  it('rechecks reads immediately after a tariff denial and when Core becomes unavailable', async () => {
    await setup()
    const headers = { authorization: 'Bearer t' }
    expect((await app.inject({ url: '/api/make/x', headers })).statusCode).toBe(200)
    verdict = () => ({ ok: false, status: 403, error: 'capability_unavailable' })
    expect((await app.inject({ url: '/api/make/x', headers })).statusCode).toBe(403)
    expect(seen).toHaveLength(2)
    coreDown = true
    expect((await app.inject({ url: '/api/make/x', headers })).statusCode).toBe(503)
    verdict = () => ({ ok: true, user: { name: 'ann', role: 'developer' } })
  })

  it('ядро недоступно — 503 core_unavailable, а не 401', async () => {
    await setup()
    coreDown = true
    const res = await app.inject({ method: 'GET', url: '/api/make/x', headers: { authorization: 'Bearer t' } })
    expect(res.statusCode).toBe(503)
    expect(res.json()).toEqual({ error: 'core_unavailable' })
  })
})
