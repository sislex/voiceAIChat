export interface PtyContext {
  /** Рабочий каталог shell в фокусе (из /proc/<pid>/cwd), если удалось прочитать. */
  cwd: string | null
  /** Имя процесса в фокусе терминала (shell/nano/vim/ssh/top), если определено. */
  foreground: string | null
  /** Активен ли альтернативный экран (полноэкранный TUI: nano/vim/less/top). */
  altScreen: boolean
}

export function consolePtyId(conversationId: string): string {
  return `console:${conversationId}`
}
