import type { KanbanColumnSemanticType } from './projects'

export type MergeStage = 'queued' | 'checking' | 'fetching' | 'merging' | 'resolving_conflicts' | 'kb_update' | 'testing' | 'pushing' | 'success' | 'failed' | 'cancelled' | 'decision_required'
export type MergeRunStatus = MergeStage | 'deploying' | 'production_checks' | 'rolling_back' | 'timeout'
export type MergeStageStatus = 'queued' | 'running' | 'passed' | 'failed' | 'skipped'
export type MergeLlmFallbackReason = 'provider_unavailable' | 'model_unavailable'

export interface MergeLlmOverride {
  provider?: 'claude' | 'codex'
  model?: string
}

export const ACTIVE_MERGE_STATUSES: readonly MergeRunStatus[] = [
  'queued', 'checking', 'fetching', 'merging', 'resolving_conflicts', 'kb_update', 'testing', 'pushing', 'deploying', 'production_checks', 'rolling_back'
]

export interface MergeConflict { path: string; kind?: string }
export interface MergeCheck {
  name: string; command: string; status: MergeStageStatus
  startedAt: number; finishedAt: number | null; durationMs: number | null
  exitCode: number | null; timedOut: boolean; output: string
}
export interface MergeStageRecord {
  stage: MergeStage; status: MergeStageStatus; startedAt: number | null
  finishedAt: number | null; durationMs: number | null; exitCode: number | null
  timedOut: boolean; message: string | null; log: string
}

export interface MergeRun {
  id: string
  projectId: string
  taskId: string
  status: MergeRunStatus
  triggeredBy: string
  sourceBranch: string
  targetBranch: 'main'
  sourceSha: string | null
  targetSha: string | null
  mergeSha: string | null
  revertSha: string | null
  agentId: string
  machineName?: string | null
  /** Monotonic assignment revision; legacy rows start at zero. */
  assignmentVersion?: number
  llmEngineId: string | null
  llmProvider: 'claude' | 'codex'
  llmModel: string
  /** Запрошенная пара присутствует у новых ранов; legacy-записи её не имеют. */
  requestedLlmProvider?: 'claude' | 'codex' | null
  requestedLlmModel?: string | null
  llmFallbackReason?: MergeLlmFallbackReason | null
  stage: MergeStage
  stages: MergeStageRecord[]
  conflicts: string[]
  conflictDetails: MergeConflict[]
  checks: MergeCheck[]
  deployId: string | null
  deployVersion: string | null
  productionStatus: string | null
  error: string | null
  recommendedAction: string | null
  log: string
  canCancel: boolean
  canRetry: boolean
  pushStartedAt: number | null
  startedAt: number | null
  finishedAt: number | null
  createdAt: number
}

/** Delayed queued snapshots must not undo a newer assignment or a claimed run. */
export function acceptMergeSnapshot(current: Pick<MergeRun, 'id' | 'status' | 'assignmentVersion'> | undefined,
  next: Pick<MergeRun, 'id' | 'status' | 'assignmentVersion'>): boolean {
  if (!current || current.id !== next.id) return true
  if ((next.assignmentVersion ?? 0) < (current.assignmentVersion ?? 0)) return false
  return !(current.status !== 'queued' && next.status === 'queued')
}

export interface ChangeMergeMachineRequest {
  agentId: string
  expectedAssignmentVersion: number
}

export type ChangeMergeMachineResult =
  | { ok: true; run: MergeRun }
  | { ok: false; code: 'not_queued' | 'assignment_changed'; error: string; run: MergeRun }
  | { ok: false; code: 'not_found' | 'forbidden' | 'readiness_failed'; error: string; readiness?: MergeMachineReadiness }

export type MergeMachineReadinessCode =
  | 'ready'
  | 'machine_offline'
  | 'storage_missing'
  | 'storage_not_found'
  | 'storage_marker_invalid'
  | 'storage_path_invalid'
  | 'storage_policy_denied'
  | 'storage_symlink'
  | 'storage_read_only'
  | 'clone_invalid'
  | 'git_unavailable'

export interface MergeMachineReadiness {
  ready: boolean
  selectable: boolean
  mode: 'managed' | 'legacy' | null
  code: MergeMachineReadinessCode
  message: string
  clonePath?: string
}

export interface MergeMachineOption {
  agentId: string
  name: string
  readiness: MergeMachineReadiness
}

export interface MergeMachinesResponse {
  machines: MergeMachineOption[]
  defaultAgentId: string | null
}

export interface MergeAvailability {
  semanticType: KanbanColumnSemanticType
  sourceBranch?: string | null
  alreadyMerged?: boolean
  hasActiveRun?: boolean
  permitted?: boolean
  machineBound?: boolean
}

/** Успешный merge блокирует только тот source SHA, который действительно был слит. */
export function isCurrentMergeSourceMerged(input: { sourceSha?: string | null; mergedSourceSha?: string | null; mergedSha?: string | null }): boolean {
  return Boolean(input.mergedSha && input.sourceSha && input.sourceSha === input.mergedSourceSha)
}

/** Единое правило UI; сервер независимо проверяет каждый инвариант при старте. */
export function canStartMerge(input: MergeAvailability): boolean {
  return input.semanticType === 'awaiting_merge'
    && Boolean(input.sourceBranch?.trim())
    && !input.alreadyMerged
    && !input.hasActiveRun
    && input.permitted !== false
    && input.machineBound !== false
}

export function isActiveMergeStatus(status: MergeRunStatus): boolean {
  return ACTIVE_MERGE_STATUSES.includes(status)
}

/** Копия репозитория задачи на машине: dev-workspace или merge-клон.
 *  Запись живёт до подтверждённого удаления каталога (state='deleted'). */
export interface TaskRepository {
  id: string
  projectId: string
  taskId: string
  agentId: string
  machineName: string | null
  path: string
  kind: 'dev-workspace' | 'merge-clone'
  state: 'active' | 'deleted'
  createdAt: number
  deletedAt: number | null
}
