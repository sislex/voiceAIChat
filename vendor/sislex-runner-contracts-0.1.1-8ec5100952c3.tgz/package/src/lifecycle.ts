/** Additive v1 administration API. Only the master bearer token may use it. */
export const RUNNER_LIFECYCLE_PATH = '/v1/admin/lifecycle'

export interface RunnerLifecycle {
  draining: boolean
  activeRuns: number
}
