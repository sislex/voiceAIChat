# @sislexa/chat-ui 0.3.0

Standalone production chat views for React 18. Install the exact peer versions
listed in this archive's package manifest. The SDK archive used by this release
is `sislexa-sdk-1.2.0-629530a3a2a4.tgz` (source commit `7f45178`); older archives
with the same SDK version do not necessarily expose these chat/session ports.
Use the owner lock and immutable artifacts, not a mutable SDK source checkout.

| Public entry | Exports |
| --- | --- |
| `@sislexa/chat-ui` | `SharedChat`, `ChatColumn`, `VoiceBar`, `ChatSettings` |
| `@sislexa/chat-ui/standalone` | `createStandaloneChat`, `StandaloneChatView`, runtime/options types |
| `@sislexa/chat-ui/skins` | `PageChat`, `WidgetChat`, view props |
| `@sislexa/chat-ui/settings` | Rich Core `ConversationSettings` |
| `@sislexa/chat-ui/assistant` | Owner-aware `KanbanAssistant`, `WidgetAssistantFrame` |

```tsx
import { UiProviders } from '@voicechat/ui-kit'
import { createStandaloneChat } from '@sislexa/chat-ui/standalone'
import { PageChat, WidgetChat } from '@sislexa/chat-ui/skins'
import '@sislexa/chat-ui/styles.css'
import '@sislexa/chat-ui/app.css'
import '@sislexa/chat-ui/content.css'
import '@voicechat/chat-app/styles.css'

const chat = createStandaloneChat({
  baseUrl: location.origin,
  conversationId: authorizedConversationId,
  instanceId: 'host/view-1',
})
await chat.start()
// Mount under the host's existing React root:
const view = <UiProviders><PageChat chat={chat}
  settingsFields={[{ key: 'model', label: 'Model', type: 'text' }]} /></UiProviders>
// WidgetChat uses the same runtime; changing skin does not reconnect.
// On host logout, principal change or final view teardown:
chat.dispose()
```

`start()` initiates bootstrap/connection. Observe `getState()`/`subscribe()` for
readiness; only `ready` enables advertised Core capabilities. The standard views
subscribe automatically. Creation and teardown belong to the host, outside React
render; mounting or StrictMode remounting a view does not dispose the runtime.
Give each simultaneous instance its own runtime. Each has an independent socket,
session, request cancellation, settings controller, store and in-memory drafts.
`instanceId` is a non-secret label, not a persistent credential or storage key.

The host must already authenticate the browser. The concrete SDK session adapter
calls `POST /api/chat/session` and retains its short-lived credential in memory.
It uses the same session for REST, uploads, revisioned settings and `/ws`.
History and message mutations use Core's public conversation/message routes.
No global `window.api`, Identity singleton or localStorage credential is required.
For cross-origin cookie sessions pass `credentials: 'include'` and configure
server-side CORS/CSRF. Never provide long-lived application credentials to a page.

Core must implement the version-1 `chat.connect`/`chat.ready` protocol. On required
resynchronization, the adapter reloads authoritative history before readiness;
Core's following `claude.active` and `claude.queue` snapshots restore active turns
and queues through the production store. Superseded reloads are aborted. Neither
reconnect nor settings conflicts automatically replay mutations.

WebSocket 4401 invalidates the expired session and reacquires it with bounded SDK
retries. WebSocket 4403, HTTP 401/403 and denied session acquisition clear the
instance's messages/draft and dispose its requests/socket. The view asks for login.
After sign-in or terminal connection failure, dispose the old runtime and create
a fresh one. Other instances retain their own lifecycle; the server still checks
authorization for every request.

`settingsOwner` selects `account`, `conversation` (default), or `device`.
`settingsFields` declares the host's supported canonical settings controls.
Persisted saves carry the accepted revision; conflicts require explicit reload.
Conversation null values inherit account values. Device preferences never enter
server patches. Voice capture/playback and owner-specific tool actions require
explicit host ports on the lower-level `SharedChat`; the standalone sample is
text-only and does not claim microphone support.

The external sample generator and verification live in the owner repository at
`scripts/standalone-chat-sample.mjs` and `system-tests/consumer-host`. It installs
real archives outside the workspace, builds without source aliases, and tests
native HTTP/WebSocket behavior. Candidate builds do not publish artifacts.
Registry publication requires the owner's clean committed release gate and
immutable archives; deployed Identity/Core commissioning is a separate step.
