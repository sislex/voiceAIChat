import{j as P}from"./jsx-runtime-BYYWji4R.js";import{userEvent as s,within as m}from"./index-DeN4tkzB.js";import{a as Ee}from"./fakeApi-BOVGwKVE.js";import{EnvironmentsPanel as O}from"./EnvironmentsPanel-DjjI4_YE.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-CkvR-LPe.js";import"./types-DFdjDDUq.js";import"./tools-D2dVYbOd.js";import"./agentProtocol-ChPLBt7B.js";import"./projects-B9njsDhM.js";import"./projectTypes-C-9aONcK.js";import"./ci-DFdZK10C.js";import"./git-p1B0wyA1.js";import"./time-CfyNS7J_.js";import"./dateFormat-Mm5g7L0f.js";import"./release-C-C1sGXa.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./usePolling-okXCim0o.js";import"./Skeleton-42oMjovX.js";import"./EmptyState-q579drYF.js";import"./ErrorState-CqsakWkx.js";import"./environmentsBridge-DYeWK7_9.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";const o={id:"test-stand",projectId:"p1",name:"Проверка",mode:"managed",state:"draft",storageId:"storage-1",machines:["machine-1"],checkoutPath:"/storage/stand/app",composeProject:"sx-test-stand",port:null,createdBy:"owner",createdAt:1,updatedAt:1},Me=[{agentId:"machine-1",name:"Готовая машина",path:"",reposRoot:"",storageId:"storage-1",storage:{id:"storage-1",machineId:"machine-1",rootPath:"/storage",status:"ready",formatVersion:1}},{agentId:"machine-2",name:"Хранилище недоступно",path:"",reposRoot:"",storageId:"storage-2",storage:{id:"storage-2",machineId:"machine-2",rootPath:"/storage",status:"offline",formatVersion:1}}],j=[{key:"VC_ADMIN_PASSWORD",label:"Пароль администратора",secret:!0,required:!0,generated:!1,set:!0,value:null,source:"user",updatedBy:"owner",updatedAt:1},{key:"VC_PUBLIC_URL",label:"Публичный адрес",secret:!1,required:!1,generated:!1,set:!0,value:"https://stand.example",source:"user",updatedBy:"owner",updatedAt:1}],Se={environmentId:o.id,machineId:"machine-1",checkedAt:1,ready:!1,port:17800,checks:[{id:"docker",status:"passed",message:"Docker доступен"},{id:"memory",status:"warning",message:"Рекомендуется 8 ГБ"},{id:"disk",status:"failed",message:"Недостаточно места"}]},t=Date.UTC(2026,9,2,9,0),n=e=>e.repeat(40),A="https://github.com/sislex/sislexa-kanban",E="https://github.com/sislex/make",x="https://github.com/sislex/sielexa-ui",M={mode:"external",storageId:null,state:"ready",composeProject:null,port:null,id:"production",projectId:"p1",name:"Production",machines:["prod-89.125.68.35"],checkoutPath:"/root/ChatAI/voiceAIChat",createdBy:"admin",createdAt:t,updatedAt:t},Be={...M,id:"staging",name:"Staging",machines:["makbook-m1"],checkoutPath:"/Users/alex/stage"},be=[{core:null,id:"c2",environmentId:"production",revision:2,note:"Kanban 0.1.2 на проверку",createdBy:"admin",createdAt:t-6e5,modules:[{repository:A,version:"0.1.2",commit:n("b")},{repository:E,version:"1.3.1",commit:n("e")},{repository:x,version:"0.1.4",commit:n("d")}]},{core:null,id:"c1",environmentId:"production",revision:1,note:"Initial observation",createdBy:"admin",createdAt:t-864e5,modules:[{repository:A,version:"0.1.1",commit:n("a")},{repository:E,version:"1.3.1",commit:n("e")},{repository:x,version:"0.1.3",commit:n("3")}]}],we=[{repository:A,name:"Kanban",services:["kanban"],desired:{version:"0.1.2",commit:n("b")},actual:{version:"0.1.1",commit:n("a")},action:"switch",reason:null},{repository:E,name:"Make",services:["make-api","make-worker"],desired:{version:"1.3.1",commit:n("e")},actual:{version:"1.3.1",commit:n("e")},action:"none",reason:null}],xe={repository:x,name:"UI Kit",services:[],desired:{version:"0.1.4",commit:n("d")},actual:{version:"0.1.3",commit:n("3")},action:"needs_core_release",reason:"Module is embedded in Core"},S=(e,a="")=>({service:"kanban",from:`ghcr.io/sislex/kanban:${n("a")}`,to:`ghcr.io/sislex/kanban:${n("b")}`,status:e,log:a}),R={kind:"apply",id:"op1",environmentId:"production",configurationId:"c2",previousConfigurationId:"c1",status:"succeeded",steps:[S("passed",`pulling
switching
healthy`)],startedBy:"admin",startedAt:t-3e5,finishedAt:t-24e4,error:null},i={...R,id:"op2",status:"health_check",steps:[S("running",`pulling
switching`)],startedAt:t-2e4,finishedAt:null},Re={baseBranch:"main",applications:[{repository:A,name:"Kanban",applicationId:"kanban",current:null,releases:[{version:"0.1.3",commit:n("c"),publishedAt:"2026-10-02T08:00:00Z"},{version:"0.1.2",commit:n("b"),publishedAt:"2026-10-01T08:00:00Z"}]},{repository:E,name:"Make",applicationId:"make",current:null,releases:[{version:"1.3.2",commit:n("f"),publishedAt:"2026-10-01T09:30:00Z"},{version:"1.3.1",commit:n("e"),publishedAt:"2026-09-30T18:00:00Z"}]}]};function c(e={}){const a={observation:{environmentId:"production",machineId:M.machines[0],observedAt:t,core:{version:"0.1.360",commit:n("9")},services:[]},core:{desired:null,actual:{version:"0.1.360",commit:n("9")},action:"none"},modules:e.modules??we},d=e.configurations??be;return{"environments:list":async()=>e.list??[M,Be],"environments:configurations":async()=>d,"environments:saveConfiguration":async({modules:B,note:Ae})=>({...d[0],id:"c3",revision:3,modules:B,note:Ae}),"environments:observe":async()=>a.observation,"environments:diff":async()=>a,"environments:apply":async()=>({...i,status:"pending",steps:[S("pending")]}),"environments:operations":async()=>e.operations??[R],"environments:rollback":async()=>({...i,id:"op3",configurationId:"c1",status:"pending",steps:[S("pending")]})}}function ke(){const e=Ee();return e["releases:composition"]=async()=>Re,e}const an={title:"Operations/Releases/EnvironmentsPanel",component:O,args:{projectId:"p1",baseBranch:"main",owner:!0,environments:c(),api:ke(),onComposeCore:()=>{}},render:e=>P.jsx("div",{style:{maxWidth:960,padding:16},children:P.jsx(O,{...e})})},p={},l={args:{environments:{...c({list:[{...o,machines:["primary","worker"]}],operations:[]}),"environments:links":async()=>["pending","open","down"].map((e,a)=>({id:String(a),environmentId:o.id,service:`service-${a}`,clientMachineId:"worker",serverMachineId:"primary",servicePort:8080,listenPort:17e3+a,state:e})),"environments:provision":async()=>({...i,kind:"provision",steps:["links","snapshot","restore"].map(e=>({kind:"stage",service:e,from:null,to:"ready",status:"running",log:""}))})}},play:async({canvasElement:e})=>{const a=m(e);await s.selectOptions(await a.findByLabelText("База стенда"),"production-snapshot"),await s.click(await a.findByRole("button",{name:"Изменить версии"})),await s.selectOptions(await a.findByLabelText("Машина Kanban"),"worker")}},u={args:{environments:c({operations:[i,R]})}},v={args:{environments:c({modules:[...we,xe]})}},g={args:{environments:c({list:[],configurations:[],operations:[]})}},y={args:{owner:!1,onComposeCore:void 0}},h={parameters:{viewport:{defaultViewport:"mobile1"}}},f={play:async({canvasElement:e})=>{const a=m(e);await s.click(await a.findByRole("button",{name:"Изменить версии"})),await s.selectOptions(await a.findByLabelText("Выбрать версию Kanban"),`0.1.3@${n("c")}`)}},Ie={...c({list:[o,M],configurations:[],operations:[]}),"environments:create":async({id:e,name:a,machineId:d,storageId:B})=>({...o,id:e,name:a,machines:[d],storageId:B}),"environments:readiness":async()=>Se,"environments:settings":async()=>j,"environments:saveSettings":async()=>j,"environments:provision":async()=>({...i,kind:"provision",id:"provision",status:"preparing",steps:[{kind:"stage",service:"readiness",from:null,to:"ready",status:"running",log:""}]}),"environments:remove":async()=>({...i,kind:"remove",id:"remove",status:"removing",steps:[{kind:"stage",service:"down",from:null,to:"stopped",status:"running",log:""}]})},C=ke();C["projects:get"]=async()=>({machines:Me});const r={args:{environments:Ie,api:C}},b={args:{environments:{...Ie,"environments:list":async()=>[{...o,state:"ready",port:17800}],"environments:configurations":async()=>[{...be[0],environmentId:o.id}]},api:C}},w={...r,play:async({canvasElement:e})=>{await s.click(await m(e).findByRole("button",{name:"Новое окружение"}))}},k={...r,play:async({canvasElement:e})=>{await s.click(await m(e).findByRole("button",{name:"Проверить машину"}))}},I={...r,play:async({canvasElement:e})=>{await s.click(await m(e).findByRole("button",{name:"Настройки и секреты"}))}};var T,K,_;p.parameters={...p.parameters,docs:{...(T=p.parameters)==null?void 0:T.docs,source:{originalSource:"{}",...(_=(K=p.parameters)==null?void 0:K.docs)==null?void 0:_.source}}};var D,L,V;l.parameters={...l.parameters,docs:{...(D=l.parameters)==null?void 0:D.docs,source:{originalSource:`{
  args: {
    environments: {
      ...environments({
        list: [{
          ...managedEnvironment,
          machines: ['primary', 'worker']
        }],
        operations: []
      }),
      'environments:links': async () => (['pending', 'open', 'down'] as const).map((state, index) => ({
        id: String(index),
        environmentId: managedEnvironment.id,
        service: \`service-\${index}\`,
        clientMachineId: 'worker',
        serverMachineId: 'primary',
        servicePort: 8080,
        listenPort: 17000 + index,
        state
      })),
      'environments:provision': async () => ({
        ...running,
        kind: 'provision',
        steps: ['links', 'snapshot', 'restore'].map(service => ({
          kind: 'stage',
          service,
          from: null,
          to: 'ready',
          status: 'running',
          log: ''
        }))
      })
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.selectOptions(await canvas.findByLabelText('База стенда'), 'production-snapshot');
    await userEvent.click(await canvas.findByRole('button', {
      name: 'Изменить версии'
    }));
    await userEvent.selectOptions(await canvas.findByLabelText('Машина Kanban'), 'worker');
  }
}`,...(V=(L=l.parameters)==null?void 0:L.docs)==null?void 0:V.source}}};var U,$,N;u.parameters={...u.parameters,docs:{...(U=u.parameters)==null?void 0:U.docs,source:{originalSource:`{
  args: {
    environments: environments({
      operations: [running, succeeded]
    })
  }
}`,...(N=($=u.parameters)==null?void 0:$.docs)==null?void 0:N.source}}};var Z,q,W;v.parameters={...v.parameters,docs:{...(Z=v.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    environments: environments({
      modules: [...modules, embedded]
    })
  }
}`,...(W=(q=v.parameters)==null?void 0:q.docs)==null?void 0:W.source}}};var F,z,G;g.parameters={...g.parameters,docs:{...(F=g.parameters)==null?void 0:F.docs,source:{originalSource:`{
  args: {
    environments: environments({
      list: [],
      configurations: [],
      operations: []
    })
  }
}`,...(G=(z=g.parameters)==null?void 0:z.docs)==null?void 0:G.source}}};var H,J,Q;y.parameters={...y.parameters,docs:{...(H=y.parameters)==null?void 0:H.docs,source:{originalSource:`{
  args: {
    owner: false,
    onComposeCore: undefined
  }
}`,...(Q=(J=y.parameters)==null?void 0:J.docs)==null?void 0:Q.source}}};var X,Y,ee;h.parameters={...h.parameters,docs:{...(X=h.parameters)==null?void 0:X.docs,source:{originalSource:`{
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(ee=(Y=h.parameters)==null?void 0:Y.docs)==null?void 0:ee.source}}};var ne,ae,se;f.parameters={...f.parameters,docs:{...(ne=f.parameters)==null?void 0:ne.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(await canvas.findByRole('button', {
      name: 'Изменить версии'
    }));
    await userEvent.selectOptions(await canvas.findByLabelText('Выбрать версию Kanban'), \`0.1.3@\${sha('c')}\`);
  }
}`,...(se=(ae=f.parameters)==null?void 0:ae.docs)==null?void 0:se.source}}};var te,re,oe;r.parameters={...r.parameters,docs:{...(te=r.parameters)==null?void 0:te.docs,source:{originalSource:`{
  args: {
    environments: managedApi,
    api: projectApi
  }
}`,...(oe=(re=r.parameters)==null?void 0:re.docs)==null?void 0:oe.source}}};var ie,ce,me;b.parameters={...b.parameters,docs:{...(ie=b.parameters)==null?void 0:ie.docs,source:{originalSource:`{
  args: {
    environments: {
      ...managedApi,
      'environments:list': async () => [{
        ...managedEnvironment,
        state: 'ready',
        port: 17800
      }],
      'environments:configurations': async () => [{
        ...configurations[0]!,
        environmentId: managedEnvironment.id
      }]
    },
    api: projectApi
  }
}`,...(me=(ce=b.parameters)==null?void 0:ce.docs)==null?void 0:me.source}}};var de,pe,le;w.parameters={...w.parameters,docs:{...(de=w.parameters)==null?void 0:de.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Новое окружение'
    }));
  }
}`,...(le=(pe=w.parameters)==null?void 0:pe.docs)==null?void 0:le.source}}};var ue,ve,ge;k.parameters={...k.parameters,docs:{...(ue=k.parameters)==null?void 0:ue.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Проверить машину'
    }));
  }
}`,...(ge=(ve=k.parameters)==null?void 0:ve.docs)==null?void 0:ge.source}}};var ye,he,fe;I.parameters={...I.parameters,docs:{...(ye=I.parameters)==null?void 0:ye.docs,source:{originalSource:`{
  ...ManagedDraft,
  play: async ({
    canvasElement
  }) => {
    await userEvent.click(await within(canvasElement).findByRole('button', {
      name: 'Настройки и секреты'
    }));
  }
}`,...(fe=(he=I.parameters)==null?void 0:he.docs)==null?void 0:fe.source}}};const sn=["SwitchOneService","MultiMachineSnapshot","Applying","EmbeddedModules","NotObserved","ReadOnlyMember","Mobile","EditVersions","ManagedDraft","ManagedReady","CreateManaged","MachineReadiness","SettingsAndSecrets"];export{u as Applying,w as CreateManaged,f as EditVersions,v as EmbeddedModules,k as MachineReadiness,r as ManagedDraft,b as ManagedReady,h as Mobile,l as MultiMachineSnapshot,g as NotObserved,y as ReadOnlyMember,I as SettingsAndSecrets,p as SwitchOneService,sn as __namedExportsOrder,an as default};
