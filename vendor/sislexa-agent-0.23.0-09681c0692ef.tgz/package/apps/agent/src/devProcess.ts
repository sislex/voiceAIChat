import { createHash, randomUUID } from 'node:crypto'
import { spawn, type ChildProcess } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { createServer } from 'node:net'
import { dirname, join, resolve } from 'node:path'
import { createInterface } from 'node:readline'
import { resolveShellInfo } from './platform.js'
import type {
  DevProcessErrorCode, DevProcessLogsRequest, DevProcessLogsResult, DevProcessMethod,
  DevProcessRequestMessage, DevProcessResponseMessage, DevProcessStartRequest,
  DevProcessStartResult, DevProcessStatus, DevProcessStopRequest, DevProcessStopResult
} from '@sislexa/agent-contracts'

const MAX_LOG_LINES = 1_000
const DEFAULT_LOG_LINES = 200
const DEFAULT_READINESS_TIMEOUT_MS = 120_000

type LogLine = DevProcessLogsResult['lines'][number]
interface PersistedProcess {
  standId: string
  component: DevProcessStatus['component']
  repository: string
  sha: string
  port: number
  pid: number
  worktree: string
  startedAt: number
  url: string
}
interface RuntimeProcess extends PersistedProcess {
  child?: ChildProcess
  state: DevProcessStatus['state']
  exitCode?: number | null
  lines: LogLine[]
  secrets: string[]
}
interface Registry { version: 1; processes: PersistedProcess[] }

export class DevProcessError extends Error {
  constructor(readonly code: DevProcessErrorCode, message: string) { super(message) }
}

export interface DevProcessManagerOptions {
  dataDir: string
  readinessTimeoutMs?: number
  readinessPollMs?: number
  now?: () => number
}

const keyOf = (target: { standId: string; component: string }): string => `${target.standId}\0${target.component}`
const digest = (value: string): string => createHash('sha256').update(value).digest('hex')
const alive = (pid: number): boolean => {
  try { process.kill(pid, 0); return true } catch { return false }
}
const safeMessage = (error: unknown): string => error instanceof Error ? error.message : String(error)

function quoteShell(value: string): string {
  if (process.platform === 'win32') return `"${value.replace(/"/g, '""')}"`
  return `'${value.replace(/'/g, `'"'"'`)}'`
}

/** Spawn through the platform shell so command discovery matches exec and PTY. */
function spawnTool(command: string, args: string[], options: { cwd?: string; env?: NodeJS.ProcessEnv; detached?: boolean } = {}): ChildProcess {
  const shell = resolveShellInfo().shell
  const line = [command, ...args].map(quoteShell).join(' ')
  const shellArgs = process.platform === 'win32' && /cmd(?:\.exe)?$/i.test(shell) ? ['/d', '/s', '/c', line] : ['-c', line]
  return spawn(shell, shellArgs, {
    cwd: options.cwd,
    env: options.env,
    detached: options.detached,
    stdio: ['ignore', 'pipe', 'pipe'],
    windowsHide: true
  })
}

async function runTool(command: string, args: string[], cwd?: string): Promise<void> {
  await new Promise<void>((resolvePromise, reject) => {
    const child = spawnTool(command, args, { cwd })
    let stderr = ''
    child.stderr?.on('data', chunk => { stderr = (stderr + String(chunk)).slice(-4_096) })
    child.on('error', reject)
    child.on('exit', code => code === 0 ? resolvePromise() : reject(new Error(`${command} exited ${code}: ${stderr.trim()}`)))
  })
}

export class DevProcessManager {
  private readonly root: string
  private readonly mirrors: string
  private readonly worktrees: string
  private readonly caches: string
  private readonly registryPath: string
  private readonly processes = new Map<string, RuntimeProcess>()
  private readonly operations = new Map<string, Promise<unknown>>()
  private readonly now: () => number
  private readonly readinessTimeoutMs: number
  private readonly readinessPollMs: number

  constructor(options: DevProcessManagerOptions) {
    this.root = resolve(options.dataDir, 'dev-processes')
    this.mirrors = join(this.root, 'mirrors')
    this.worktrees = join(this.root, 'worktrees')
    this.caches = join(this.root, 'dependency-cache')
    this.registryPath = join(this.root, 'registry.json')
    this.now = options.now ?? Date.now
    this.readinessTimeoutMs = options.readinessTimeoutMs ?? DEFAULT_READINESS_TIMEOUT_MS
    this.readinessPollMs = options.readinessPollMs ?? 250
    mkdirSync(this.root, { recursive: true, mode: 0o700 })
    this.reconcile()
  }

  async handle(message: DevProcessRequestMessage): Promise<DevProcessResponseMessage> {
    const method = message.t as DevProcessMethod
    try {
      let result: DevProcessStartResult | DevProcessStopResult | DevProcessStatus | DevProcessLogsResult
      if (message.t === 'devProcess.start') result = await this.exclusive(message, () => this.start(message))
      else if (message.t === 'devProcess.stop') result = await this.exclusive(message, () => this.stop(message))
      else if (message.t === 'devProcess.status') result = this.status(message)
      else result = this.logs(message)
      return { t: `${method}.result`, requestId: message.requestId, result } as DevProcessResponseMessage
    } catch (error) {
      const code = error instanceof DevProcessError ? error.code : 'internal_error'
      return { t: 'devProcess.error', requestId: message.requestId, method, code, message: safeMessage(error) }
    }
  }

  async close(): Promise<void> {
    await Promise.all([...this.processes.values()].map(processInfo => this.stop(processInfo)))
  }

  private async exclusive<T>(target: { standId: string; component: string }, operation: () => Promise<T>): Promise<T> {
    const key = keyOf(target)
    if (this.operations.has(key)) throw new DevProcessError('operation_conflict', 'Another operation is in progress')
    const running = operation()
    this.operations.set(key, running)
    try { return await running } finally { this.operations.delete(key) }
  }

  private validateStart(request: DevProcessStartRequest): void {
    if (!/^[a-f0-9]{40}$/.test(request.sha) || !request.repository || !Number.isInteger(request.port) || request.port < 1 || request.port > 65535) {
      throw new DevProcessError('invalid_request', 'Invalid repository, SHA, or port')
    }
    try {
      const url = new URL(request.repository)
      if (url.username || url.password) throw new DevProcessError('invalid_request', 'Repository URL must not contain credentials')
    } catch (error) {
      if (error instanceof DevProcessError) throw error
      // Local paths and Git scp-style URLs are valid and use the configured credential helper.
    }
    if (!request.command.length || request.command.some(value => !value || value.includes('\0'))) {
      throw new DevProcessError('invalid_request', 'Invalid command')
    }
    for (const [name, value] of Object.entries(request.env)) {
      if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name) || value.includes('\0')) throw new DevProcessError('invalid_request', 'Invalid environment')
    }
  }

  private async start(request: DevProcessStartRequest): Promise<DevProcessStartResult> {
    this.validateStart(request)
    const existing = this.processes.get(keyOf(request))
    if (existing?.state === 'ready' && existing.sha === request.sha && existing.repository === request.repository && existing.port === request.port && alive(existing.pid)) {
      return this.toStartResult(existing)
    }
    if (existing) await this.stop(existing)
    await this.assertPortFree(request.port)

    const repoHash = digest(request.repository)
    const mirror = join(this.mirrors, `${repoHash}.git`)
    const worktree = join(this.worktrees, digest(`${request.standId}\0${request.component}`))
    mkdirSync(dirname(mirror), { recursive: true, mode: 0o700 })
    mkdirSync(dirname(worktree), { recursive: true, mode: 0o700 })
    try {
      if (!existsSync(mirror)) await runTool('git', ['clone', '--mirror', request.repository, mirror])
      else await runTool('git', ['-C', mirror, 'fetch', '--prune', 'origin'])
    } catch (error) {
      throw new DevProcessError('repository_unavailable', `Repository checkout failed: ${this.redact(safeMessage(error), Object.values(request.env))}`)
    }
    try { await runTool('git', ['-C', mirror, 'cat-file', '-e', `${request.sha}^{commit}`]) }
    catch { throw new DevProcessError('ref_not_found', 'Requested commit is unavailable') }
    rmSync(worktree, { recursive: true, force: true })
    try { await runTool('git', ['-C', mirror, 'worktree', 'prune']); await runTool('git', ['-C', mirror, 'worktree', 'add', '--detach', worktree, request.sha]) }
    catch (error) { throw new DevProcessError('ref_not_found', `Commit checkout failed: ${this.redact(safeMessage(error), Object.values(request.env))}`) }

    try { await this.installDependencies(worktree) }
    catch (error) { await this.removeWorktree(mirror, worktree); throw new DevProcessError('dependency_failed', this.redact(safeMessage(error), Object.values(request.env))) }

    const startedAt = this.now()
    const url = `http://127.0.0.1:${request.port}`
    const secrets = Object.values(request.env).filter(value => value.length >= 4)
    const env = { ...process.env, ...request.env, PORT: String(request.port) }
    let child: ChildProcess
    try { child = spawnTool(request.command[0], request.command.slice(1), { cwd: worktree, env, detached: process.platform !== 'win32' }) }
    catch (error) { await this.removeWorktree(mirror, worktree); throw new DevProcessError('process_start_failed', safeMessage(error)) }
    if (!child.pid) { await this.removeWorktree(mirror, worktree); throw new DevProcessError('process_start_failed', 'Process did not start') }
    const runtime: RuntimeProcess = { ...request, pid: child.pid, worktree, startedAt, url, child, state: 'starting', lines: [], secrets }
    this.processes.set(keyOf(request), runtime)
    this.capture(runtime, 'stdout', child.stdout)
    this.capture(runtime, 'stderr', child.stderr)
    child.on('exit', code => {
      runtime.exitCode = code
      if (runtime.state !== 'stopping') runtime.state = 'failed'
      this.persist()
    })
    child.on('error', error => this.append(runtime, 'stderr', safeMessage(error)))
    this.persist()
    try {
      await this.waitForReadiness(runtime, request.env.SISLEXA_READINESS_PATH ?? '/')
      runtime.state = 'ready'
      this.persist()
      return this.toStartResult(runtime)
    } catch (error) {
      await this.stop(runtime)
      if (error instanceof DevProcessError) throw error
      throw new DevProcessError('readiness_timeout', safeMessage(error))
    }
  }

  private async installDependencies(worktree: string): Promise<void> {
    const lock = ['package-lock.json', 'npm-shrinkwrap.json'].map(name => join(worktree, name)).find(existsSync)
    if (!lock) throw new Error('No supported npm lockfile found')
    const cache = join(this.caches, digest(readFileSync(lock).toString('base64')))
    mkdirSync(cache, { recursive: true, mode: 0o700 })
    await runTool('npm', ['ci', '--cache', cache, '--prefer-offline', '--no-audit', '--no-fund'], worktree)
  }

  private async waitForReadiness(runtime: RuntimeProcess, path: string): Promise<void> {
    if (!path.startsWith('/') || path.startsWith('//')) throw new DevProcessError('invalid_request', 'Readiness path must start with /')
    const deadline = this.now() + this.readinessTimeoutMs
    while (this.now() < deadline) {
      if (!alive(runtime.pid) || runtime.state === 'failed') throw new DevProcessError('process_start_failed', 'Process exited before readiness')
      try {
        const response = await fetch(`${runtime.url}${path}`, { signal: AbortSignal.timeout(Math.max(100, this.readinessPollMs)) })
        if (response.ok) return
      } catch { /* server is not ready yet */ }
      await new Promise(resolvePromise => setTimeout(resolvePromise, this.readinessPollMs))
    }
    throw new DevProcessError('readiness_timeout', 'Readiness check timed out')
  }

  private status(target: { standId: string; component: DevProcessStatus['component'] }): DevProcessStatus {
    const processInfo = this.processes.get(keyOf(target))
    if (!processInfo) return { ...target, state: 'stopped' }
    if (!alive(processInfo.pid) && processInfo.state !== 'stopping') processInfo.state = 'failed'
    return { standId: processInfo.standId, component: processInfo.component, state: processInfo.state,
      repository: processInfo.repository, sha: processInfo.sha, url: processInfo.url,
      startedAt: processInfo.startedAt, exitCode: processInfo.exitCode }
  }

  private logs(request: DevProcessLogsRequest): DevProcessLogsResult {
    const limit = request.limit ?? DEFAULT_LOG_LINES
    if (!Number.isInteger(limit) || limit < 1 || limit > MAX_LOG_LINES) throw new DevProcessError('invalid_request', 'Log limit must be 1..1000')
    const all = this.processes.get(keyOf(request))?.lines ?? []
    return { standId: request.standId, component: request.component, lines: all.slice(-limit), truncated: all.length > limit }
  }

  private async stop(target: DevProcessStopRequest | RuntimeProcess): Promise<DevProcessStopResult> {
    const runtime = this.processes.get(keyOf(target))
    if (!runtime) return { standId: target.standId, component: target.component, state: 'stopped' }
    runtime.state = 'stopping'
    await this.terminate(runtime.pid)
    const mirror = join(this.mirrors, `${digest(runtime.repository)}.git`)
    await this.removeWorktree(mirror, runtime.worktree)
    this.processes.delete(keyOf(runtime))
    this.persist()
    return { standId: target.standId, component: target.component, state: 'stopped' }
  }

  private async terminate(pid: number): Promise<void> {
    if (!alive(pid)) return
    try { process.kill(process.platform === 'win32' ? pid : -pid, 'SIGTERM') } catch { try { process.kill(pid, 'SIGTERM') } catch { return } }
    const deadline = this.now() + 5_000
    while (alive(pid) && this.now() < deadline) await new Promise(resolvePromise => setTimeout(resolvePromise, 50))
    if (alive(pid)) {
      if (process.platform === 'win32') { try { await runTool('taskkill', ['/pid', String(pid), '/t', '/f']) } catch { /* gone */ } }
      else { try { process.kill(-pid, 'SIGKILL') } catch { try { process.kill(pid, 'SIGKILL') } catch { /* gone */ } } }
    }
  }

  private async removeWorktree(mirror: string, worktree: string): Promise<void> {
    if (existsSync(mirror)) {
      try { await runTool('git', ['-C', mirror, 'worktree', 'remove', '--force', worktree]) } catch { rmSync(worktree, { recursive: true, force: true }) }
      try { await runTool('git', ['-C', mirror, 'worktree', 'prune']) } catch { /* best effort */ }
    } else rmSync(worktree, { recursive: true, force: true })
  }

  private async assertPortFree(port: number): Promise<void> {
    await new Promise<void>((resolvePromise, reject) => {
      const server = createServer()
      server.once('error', () => reject(new DevProcessError('port_unavailable', 'Allocated port is unavailable')))
      server.listen(port, '127.0.0.1', () => server.close(() => resolvePromise()))
    })
  }

  private capture(runtime: RuntimeProcess, stream: LogLine['stream'], source: NodeJS.ReadableStream | null): void {
    if (!source) return
    createInterface({ input: source }).on('line', text => this.append(runtime, stream, text))
  }
  private append(runtime: RuntimeProcess, stream: LogLine['stream'], text: string): void {
    runtime.lines.push({ stream, text: this.redact(text, runtime.secrets), at: this.now() })
    if (runtime.lines.length > MAX_LOG_LINES) runtime.lines.splice(0, runtime.lines.length - MAX_LOG_LINES)
  }
  private redact(text: string, secrets: string[]): string {
    let filtered = text.replace(/(https?:\/\/)[^/@\s]+@/gi, '$1***@')
    for (const secret of secrets.sort((a, b) => b.length - a.length)) filtered = filtered.split(secret).join('[REDACTED]')
    return filtered
  }
  private toStartResult(runtime: RuntimeProcess): DevProcessStartResult {
    return { standId: runtime.standId, component: runtime.component, state: 'ready', repository: runtime.repository,
      sha: runtime.sha, url: runtime.url, startedAt: runtime.startedAt }
  }

  private reconcile(): void {
    let registry: Registry = { version: 1, processes: [] }
    try { registry = JSON.parse(readFileSync(this.registryPath, 'utf8')) as Registry } catch { /* first run or corrupt registry */ }
    for (const saved of registry.processes ?? []) {
      if (alive(saved.pid) && existsSync(saved.worktree)) this.processes.set(keyOf(saved), { ...saved, state: 'ready', lines: [], secrets: [] })
      else rmSync(saved.worktree, { recursive: true, force: true })
    }
    this.persist()
  }
  private persist(): void {
    const registry: Registry = { version: 1, processes: [...this.processes.values()].filter(item => alive(item.pid)).map(({ child: _child, state: _state, lines: _lines, secrets: _secrets, exitCode: _exitCode, ...saved }) => saved) }
    mkdirSync(dirname(this.registryPath), { recursive: true, mode: 0o700 })
    const temporary = `${this.registryPath}.${randomUUID()}.tmp`
    writeFileSync(temporary, JSON.stringify(registry), { mode: 0o600 })
    renameSync(temporary, this.registryPath)
  }
}
