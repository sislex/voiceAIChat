import { networkInterfaces } from 'node:os'
import type { Socket } from 'node:net'
import type { AgentToServer } from '@sislexa/agent-contracts'

export const TUNNEL_HIGH_WATER_MARK = 4 * 1024 * 1024

export function tunnelBindHost(
  host: 'loopback' | 'docker-host' = 'loopback',
  platform: string = process.platform,
  interfaces = networkInterfaces()
): string {
  if (host === 'loopback') return '127.0.0.1'
  if (host !== 'docker-host') throw new Error('Invalid tunnel host')
  if (platform !== 'linux') return '127.0.0.1'
  // The host-side address of Docker's default bridge is its gateway.
  const gateway = interfaces.docker0?.find((address) => address.family === 'IPv4' && !address.internal)
  if (!gateway) throw new Error('Docker bridge gateway is unavailable')
  return gateway.address
}

export type TunnelSend = (message: AgentToServer, done?: () => void) => void

export function attachTunnelFlow(socket: Socket, tunnelId: string, connectionId: string, send: TunnelSend) {
  let remotePaused = false
  let pendingBytes = 0
  let writePaused = false
  const updateReads = () => {
    if (socket.destroyed) return
    if (remotePaused || pendingBytes >= TUNNEL_HIGH_WATER_MARK) socket.pause()
    else socket.resume()
  }
  socket.on('data', (data: Buffer) => {
    pendingBytes += data.length
    updateReads()
    send({ t: 'tunnel.data', tunnelId, connectionId, data: data.toString('base64') }, () => {
      pendingBytes -= data.length
      updateReads()
    })
  })
  socket.on('drain', () => {
    if (!writePaused) return
    writePaused = false
    send({ t: 'tunnel.resume', tunnelId, connectionId })
  })
  return {
    pause(paused: boolean) { remotePaused = paused; updateReads() },
    write(data: Buffer) {
      if (socket.destroyed) return
      socket.write(data)
      if (!writePaused && socket.writableLength >= TUNNEL_HIGH_WATER_MARK) {
        writePaused = true
        send({ t: 'tunnel.pause', tunnelId, connectionId })
      }
    }
  }
}
