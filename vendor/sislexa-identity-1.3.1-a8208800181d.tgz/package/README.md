# Sislexa Identity

Identity owns user registration, authentication, recovery, TOTP, sessions, device
trust, login UI, account UI and reusable profile/session components. Core owns
project/resource authorization and account report aggregation. Service grants and
user credentials are distinct: a component grant never signs a user in.

## Run independently

Use Node 22.13+ and npm. `npm ci && npm run build`, then:

```sh
npm run init:local
IDENTITY_DATA_DIR="$PWD/data" \
SISLEXA_COMPONENT_CONFIG="$PWD/data/components.json" \
npm start
```

The server listens on `127.0.0.1:8798`; open `/login/`. Set
`IDENTITY_ADMIN_PASSWORD` for the initial admin, or enable self-registration with
`IDENTITY_SIGNUP_ENABLED=true`. Without SMTP, verification links go to the server
log. Set `IDENTITY_PUBLIC_URL=http://localhost:8798/login` so those links open the
standalone login screen. Never expose a development server with console mail.
`VC_SMTP_URL` and `VC_MAIL_FROM` configure production mail.

`npm run dev:login` and `npm run dev:account` run independent Vite clients;
`IDENTITY_API_URL` points their `/api` proxy to Identity. The account's session,
password and 2FA controls work independently. Usage, project/machine summaries and
security reports require the declared Core dependency; their data remains in Core.

## Dependencies and permissions

`apps/server/component-contract.json` fixes supported Core/API ranges and exact
scopes. Installation configuration selects dependency URLs and private token files;
it cannot widen a release's scopes or version range. Declare the optional Core
dependency to enable registration policy, invitations, account reports and deletion
cleanup. Core must provide `identity.core`. Core consumes Identity with
`identity.verify`, `identity.session`, `identity.store` and `identity.events`.
Provider-owned grants are issued/revoked with the component-runtime CLI. Store
registries and token files outside this checkout; no credentials belong in Git.
`config/standalone.json` exposes no service RPC grants.

Core mounts `/login/` and `/account/` from Identity on its public origin, preserving
same-origin HttpOnly cookies. Per-request authentication fails closed on an Identity
outage. CSRF and login rate limits run in Identity; forwarded IPs are accepted only
through the protected session RPC. Core keeps its resource permission checks and
checks WebSocket commands again. The event cursor includes a server epoch so a
restart cannot silently skip new revocations.

## Storage and migration

SQLite (`IDENTITY_DATA_DIR/identity.db`) is the local default. Production can set
`IDENTITY_DATABASE_URL` to PostgreSQL. The first extraction deliberately retains
the existing PostgreSQL database and its user keys/foreign keys; this is a shared
storage trust boundary, not independent databases. Identity owns the identity DDL
and repository; Core imports the DDL for schema composition and retains existing
historical migrations. Both initializers use the same PostgreSQL advisory lock.

Set `IDENTITY_SESSION_SECRET_FILE` to the existing Core `session.secret` during
migration. Do not generate a new secret: that would invalidate active sessions.
Identity's remote store port replaces both Core's public repository and inter-domain
identity calls. The embedded compatibility mode imports this repository's source;
there is no second local implementation.

Remote user deletion quarantines the account and revokes sessions before asking
Core to delete domain data. Those steps are idempotent. If Core fails, the account
remains blocked and retryable; credentials are deleted only after cleanup succeeds.
No distributed transaction is claimed. Embedded deletion retains its local SQL
transaction. Run one Identity writer per installation until credential flows are
made safe for multiple writers; TOTP tickets and rate-limit windows are in memory.

## Personal tenants and tariffs

Identity 1.1 owns `tenants`, `tenant_memberships`, `tariff_plans` and
`tenant_tariffs`. Every existing and newly created user receives one stable personal
tenant, its owner membership and the Standard tariff. User creation and tenant
provisioning share a transaction; repeat initialization inserts missing rows only.
SQLite and PostgreSQL enforce unique ownership and cascading user deletion.
Existing password hashes, system roles, sessions and per-user LLM spend limits
are preserved. Core's embedded database initializer must call the exported
`initializePersonalTenants` after schema migration using the same SQL connection.

System role, tenant membership and product capabilities are separate. Standard
initially enables all current modules. A tariff never grants administration,
project membership or provider scopes. Existing resource ownership remains scoped
to users; this release does not introduce shared organizational tenants or move
project data. Billing prices, payment collection and credit purchases are outside
this release. The existing monthly LLM spend limit remains an independent check.

`GET /api/session/account-access` reads the authenticated user's current tenant,
system role, tariff and effective capabilities. Admin-only `/api/session/tariffs`
supports listing and creation, and `PUT .../tariffs/:id` requires `expectedRevision`.
`/api/session/tariff-assignments` lists assignments; `PUT .../:user` accepts only
`tariffId`. Cookie mutations require CSRF. Capability IDs are allowlisted product
operations, never permission strings. Assignment and plan edits emit user events.
Account and administration routes remain reachable without product capabilities
so administrators can repair their own assignments.

User authentication resolves account context from current storage on every request;
tokens do not contain authoritative tariff claims. A supplied `x-sislexa-tenant-id`
must match that user's personal tenant. Product HTTP routes enforce capabilities;
the Core host additionally checks conversation kind, WebSocket commands and queued
execution. The server client fails closed if an older provider omits account context.
The embeddable account screen accepts the host-injected `AccountTariffClient`, shows
role/workspace/tariff separately, and lazy-loads the administrator editor. Standalone
Account uses the same bridge and interface.

## Packages and release

- `apps/server`: standalone API and identity storage.
- `apps/login`, `apps/account`: independent Vite builds and embeddable components.
- `packages/client`, `packages/contracts`: browser/server bridges and RPC contract.
- `packages/profile-app`, `packages/sessions-app`, `packages/sessions-core`: reusable UI/policy.
- `packages/storage-sql`: shared SQL drivers/schema translator used by Core and Identity.

`npm run gate` runs all type checks, tests, builds and a real standalone process smoke. PostgreSQL integration tests
use `VC_TEST_DB_URL`; unit tests never require production credentials.
The source archive is `@sislexa/identity`. `npm pack` requires a clean commit and
records its full SHA in `release-source.json`. Consumers pin the archive integrity,
version and SHA. `dependency-snapshots.json` records immutable shared dependency sources.

After `npm pack`, run `node scripts/pack-sessions-core.mjs <output-directory>`
to publish the dependency-free `@sislexa/identity-sessions-core` archive from the
same clean commit. API consumers use it without pulling in browser or SQL drivers.

The account summary reuses shared UI-kit layout and badges. Tariff editor CSS is
loaded with its lazy dialog so ordinary account navigation stays within the host
Web/Electron route budgets.


## Stable billing subjects

Identity 1.2.0 creates one opaque `identity_subjects.id` per user in the same
transaction as personal tenant provisioning. Existing accounts are backfilled
idempotently without changing password hashes, login names, roles or sessions.
Account access and authenticated account context expose `userId`; consumers must
not substitute the login name if an older provider omits it. Deleting and
recreating the same login produces a new subject, preventing billing history reuse.
The mapping supports cascading login-key updates, but this release does not add
an account rename API or migrate all legacy resource keys.

The PostgreSQL schema translator now preserves both ON UPDATE and ON DELETE
foreign-key actions in either order, including inline references. Real PostgreSQL
migration/concurrency/deletion checks accompany SQLite atomic provisioning tests.
A root npm override binds UI Foundation's compatible older shared requirement to
the same pinned Shared 0.1.3 snapshot used by the server; no registry fallback is
required for private contract packages.

### Session activity RPC

Identity 1.2.1 serializes `sessionActivity` as JSON entry tuples and its client
restores the repository Map. This preserves active session counts and timestamps
for remote admin user lists. Deploy the provider before Core consumers pinned to
1.2.1; the updated client rejects lossy legacy responses instead of reporting all
users as inactive. No database or session-secret migration is required.

## Application-owned story checks

UI workspace tests discover and compose their own `src/**/*.stories.tsx` files,
wrap them with the shared UI providers and run the shared axe serious/critical
checks against the entire document, including portals. Required product states
remain covered. These tests run in the repository's mandatory `npm run gate`;
Core must not discover or run this application's stories from its source archive.

Session and profile style mobile-boundary checks run in their owner workspaces,
including both 720px maximum and 721px minimum media queries. These checks moved
from Core so its normal gate need not inspect Identity's internal stylesheets.

## Released UI library compatibility

Identity 1.2.2 consumes UI Kit `>=0.1.2 <0.2.0` and UI Foundation
`>=0.1.4 <0.2.0`, verified against `sislex/sielexa-ui` release 1.0.1. The owner
archive's exact versions, source commit and integrity remain in dependency-snapshots.json.
The peer ranges replace historical exact 0.1.0/0.1.2 pins that prevented consumers
from installing the independently released libraries. Identity owns its component
tests and stories; this dependency release changes no session, credential or SQL
protocol. Production API rollout is independent of a Core library consumer update.

## Consumer distribution (1.2.3)

The release archive includes owner-built login/account pages and explicit public
client, contracts, session/profile and SQL exports. Internal imports use paths within this owner archive, so installation does not depend on Core compatibility workspaces
or owner workspace symlinks. Internal tests and stories remain in this repository,
run in its full gate and are excluded from consumer archives. Public TSX explicitly
selects the automatic JSX runtime for consumers without this repository tsconfig.
`npm run pack:release` requires a clean commit, builds pages and records provenance
and archive integrity. Core cutover and production rollout are separate steps.

The installed-consumer regression packs and extracts Identity into a temporary
consumer, rejects all former `@voicechat/identity-*`, profile, sessions and SQL
workspace imports, and renders the profile through public exports without a
consumer tsconfig. This check guards both dependency independence and JSX runtime
selection; it does not replace service authentication/storage tests or the smoke
login/account flow.

## Owner image publication

The Check workflow runs the complete owner gate. Version tags publish Linux AMD64
images from the exact tested commit; `workflow_dispatch` accepts an existing
`release_ref` tag to publish an already released source revision. The tag must
match package.json. Images carry version and commit tags under `ghcr.io/sislex/`.
Deployment selects an immutable commit/digest and preserves installation settings
and data volumes; publication itself does not deploy a service.

Identity's gate owns the login selector and store SQL ownership regressions that
formerly inspected Identity implementation from Core. The store guard checks
that direct reads and writes stay within `IDENTITY_TABLES`; cross-application
cleanup continues through injected ports. Core retains consumer integration tests.

Identity 1.3.0 resolves the preview-run cookie name through the public Browser
contract, allowing Core to remove its copied product model. Credential, session,
CSRF and preview-key authorization semantics are unchanged.

Identity 1.3.0 also owns the account entitlement/tariff validation and password
policy models, including their former Core unit suites. The public
`contracts/accountAccess` and `contracts/passwordPolicy` exports are canonical;
Core transport types consume these contracts without retaining copied validators.

Identity owns the migrated authentication/device regression suite in
`apps/server/src/users/auth.regression.test.ts`. It exercises actual standalone
routes and SQL storage, with fixtures only for external settings/project ports.
Core retains CORS, resource isolation, legacy Core database migrations and admin
orchestration checks; it does not run these internal Identity regressions.

`npm run gate` builds the standalone account UI and runs its session filter and
390px geometry regressions in Chromium (`npm run test:e2e`). Install Chromium
with `npx playwright install chromium` before the first local gate. These owner
UI tests use actual Identity HTTP/session storage and remain usable with the
external Core summary provider unavailable. Core keeps WebSocket refresh and
resource-access integration coverage.
The plain login accessibility regression also runs in Identity, alongside its
existing error-state accessibility case; Core does not render login internals.


### SQLite session contract ownership

The twelve shared session-store contract cases run against the actual Identity
SQLite adapter. This closes the remaining test-only dependency on Core's DB
constructor. The adapter accepts only its Identity port; resource cleanup fixtures
are inert and no neighboring repository is needed. Core retains route/resource and
WebSocket revocation integration tests.


### Account product regression ownership

Identity owns the fifteen AccountPage data-transformation and screen-behavior
cases migrated from Core. They exercise profile/access, demand-loaded tabs,
period/history filtering, CSV export and recovery against explicit API fixtures.
Core retains six checks of its own read cache, session invalidation and route
performance adapter when embedding the public account page.


Version 1.3.1 fixes the standalone AccountPage read port: empty data is never
reported fresh, concurrent reads share a request, successful reads expire after
30 seconds, and errors remain retryable. The bounded cache belongs to a mounted
page and is never shared between accounts. Core can still inject its own resource
cache/invalidation port. The migrated product tests caught the previous stub's
skipped access/history/machine requests when Core was absent.
