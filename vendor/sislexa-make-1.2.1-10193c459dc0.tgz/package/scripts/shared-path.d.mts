export function sharedSource(): string
