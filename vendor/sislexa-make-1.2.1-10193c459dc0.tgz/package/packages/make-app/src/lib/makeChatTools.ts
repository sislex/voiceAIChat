import type { ChatColumnProps } from '@sislexa/chat-ui'
import type { RendererFsBridge, RendererFilesBridge } from '@voicechat/shared/ipc'

export interface MakeChatToolPorts {
  fs: RendererFsBridge
  files: RendererFilesBridge
  download(name: string, bytes: Uint8Array): void
}

/** Bind file and command widgets to public host bridges with a fixed project scope. */
export function createMakeChatTools(ports: MakeChatToolPorts, projectId?: string) {
  const fs = ports.fs
  const machineOps: NonNullable<ChatColumnProps['machineOps']> = {
    list: (agent, path) => fs.list(agent, path, projectId),
    read: (agent, path) => fs.read(agent, path, projectId),
    ...(fs.readPrefix && { readPrefix: (agent: string, path: string) => fs.readPrefix!(agent, path, projectId) }),
    write: (agent, path, data) => fs.write(agent, path, data, projectId),
    remove: (agent, path) => fs.remove(agent, path, projectId),
    ...(fs.trash && { trash: (agent: string, path: string) => fs.trash!(agent, path, projectId) }),
    ...(fs.copyTo && { copyTo: (agent: string, path: string, target: string, dir?: string) => fs.copyTo!(agent, path, target, dir, projectId) }),
    rename: (agent, from, to) => fs.rename(agent, from, to, projectId),
    mkdir: (agent, path) => fs.mkdir(agent, path, projectId),
    exec: (agent, command, signal) => fs.exec(agent, command, signal, projectId),
    async download(agent, path, name) {
      const result = await fs.read(agent, path, projectId)
      if (typeof result.dataBase64 !== 'string') throw new Error('File bytes are unavailable')
      ports.download(name, Uint8Array.from(atob(result.dataBase64), byte => byte.charCodeAt(0)))
    },
    async upload(agent, dir, file) {
      const bytes = new Uint8Array(await file.arrayBuffer())
      let binary = ''
      for (const byte of bytes) binary += String.fromCharCode(byte)
      return fs.write(agent, `${dir.replace(/\/$/, '')}/${file.name}`, btoa(binary), projectId)
    }
  }
  return { machineOps, readServerFile: (path: string) => ports.files.read(path) }
}
