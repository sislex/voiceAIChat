import { createChatRuntime, type ChatRuntimeOptions } from '@voicechat/chat-app/runtime/chatRuntime'
import { createSdkChatAdapter, type SdkChatPorts } from '@voicechat/chat-app/runtime/sdkAdapter'
import { createMakeChatAdapter } from '@voicechat/chat-app/runtime/hostAdapters'
import { createSettingsController, type RevisionedSettingsPort } from '@voicechat/chat-app/runtime/settingsController'
import type { ChatStore } from '@voicechat/chat-app/store/chatStore'
import type { EditorContextPayload } from '@voicechat/shared/types'

/** Keep editor context local to this panel and capture it through the public submit API. */
export function createMakeContextAdapter(source: ChatStore, conversationId: string) {
  let context: EditorContextPayload | null = null
  let disposed = false
  const assertActive = () => {
    if (disposed || source.getState().activeId !== conversationId) throw new Error('Make chat is no longer selected')
  }
  const store: ChatStore = {
    ...source,
    actions: {
      ...source.actions,
      submitText: (element, editor) => {
        assertActive()
        return source.actions.submitText(element, editor ?? context ?? undefined)
      },
      submitFix: async text => {
        assertActive()
        source.actions.setDraft(text)
        return source.actions.submitText(undefined, context ?? undefined)
      }
    }
  }
  const callbacks = createMakeChatAdapter(store, conversationId)
  return {
    store,
    onInsertToChat(text: string) { assertActive(); callbacks.onInsertToChat(text) },
    async onAskAssistant(text: string) { assertActive(); await callbacks.onAskAssistant(text) },
    async onAttachImage(file: File) { assertActive(); await callbacks.onAttachImage(file) },
    onEditorContext(value: EditorContextPayload | null) { if (!disposed) context = value ? { ...value } : null },
    dispose() { disposed = true; context = null }
  }
}

export interface MakeChatRuntimeOptions extends Omit<ChatRuntimeOptions, 'events' | 'preferenceNamespace' | 'chat'> {
  chat: Omit<ChatRuntimeOptions['chat'], 'turn' | 'uploads:add'>
  /** Authenticated account/session namespace; never pass credentials. */
  preferenceNamespace: string
  conversationId: string
  sdk: SdkChatPorts
  settingsPort: RevisionedSettingsPort
}

/** The host owns authentication and SDK transport; Make only binds public ports. */
export function createMakeChatRuntime(options: MakeChatRuntimeOptions) {
  const { conversationId, sdk, settingsPort, preferenceNamespace, ...deps } = options
  if (!conversationId || !preferenceNamespace.trim()) throw new Error('Make chat identity and conversation are required')
  const settings = createSettingsController(settingsPort, conversationId)
  const sdkAdapter = createSdkChatAdapter(sdk, () => { void settings.load() })
  const runtime = createChatRuntime({
    ...deps,
    chat: { ...deps.chat, turn: sdkAdapter.turn, 'uploads:add': sdkAdapter.upload },
    events: sdkAdapter.events,
    preferenceNamespace: `${preferenceNamespace}:make:${conversationId}`
  })
  const context = createMakeContextAdapter(runtime.store, conversationId)
  let disposed = false
  let starting: Promise<void> | undefined
  return {
    ...context,
    settings: {
      ...settings,
      async save(...args: Parameters<typeof settings.save>) {
        const saved = await settings.save(...args)
        if (saved && !disposed) await runtime.store.actions.selectConversation(conversationId)
        return saved
      }
    },
    start() {
      if (disposed) return Promise.reject(new Error('Make chat is disposed'))
      return starting ??= (async () => {
        await runtime.start()
        if (disposed) return
        await runtime.store.actions.ensureSectionConversations('make')
        if (disposed) return
        const selected = await runtime.store.actions.selectConversation(conversationId)
        if (disposed) return
        if (!selected || runtime.store.getState().activeConversation?.assistantKind !== 'make') {
          runtime.store.actions.reset()
          throw new Error('Make conversation is unavailable')
        }
        await settings.load()
      })().catch(error => { starting = undefined; throw error })
    },
    dispose() {
      if (disposed) return
      disposed = true
      context.dispose()
      settings.dispose()
      runtime.dispose()
      sdkAdapter.dispose()
    }
  }
}

export type MakeChatRuntime = ReturnType<typeof createMakeChatRuntime>
