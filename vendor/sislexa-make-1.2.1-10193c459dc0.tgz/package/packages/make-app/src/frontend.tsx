import { MakeSharedView } from './components/MakeSharedView'
import '@voicechat/ui-foundation/styles.css'
import { MakePane } from './components/MakePane'
import { MakeWorkspace } from './components/MakeWorkspace'
import { createMakeChatRuntime } from './lib/makeChatAdapter'
import { createMakeChatTools } from './lib/makeChatTools'
import '@sislexa/chat-ui/content.css'
import './panel.css'
declare const __APPLICATION_VERSION__: string
declare const __APPLICATION_COMMIT__: string | null
// Register only through the host API, which also supplies React and UI contexts.
;(window as unknown as { VoiceChatApplicationHost: { register(id: string, version: string, commit: string | null, component: unknown): void } }).VoiceChatApplicationHost.register('make-ui', __APPLICATION_VERSION__, __APPLICATION_COMMIT__, { default: MakeWorkspace, pane: MakePane, shared: MakeSharedView, createChatRuntime: createMakeChatRuntime, createChatTools: createMakeChatTools })
