import{j as S}from"./jsx-runtime-BYYWji4R.js";import{T as Ua}from"./TaskCard-BR-FadGD.js";import{m as e,e as r}from"./fixtures-J6FpERiu.js";import"./index-ClcD9ViR.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./merge-CBY8VSWw.js";import"./ci-DFdZK10C.js";import"./types-DFdjDDUq.js";import"./ciFormat-BG9i2Mqq.js";import"./ansi-DtpFsZ9v.js";import"./kanbanMeta-CBiUCx3-.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./Avatar-Ds_00F2y.js";import"./mediaQuery-CCkbYk-e.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./icons-M-fant0Z.js";import"./projects-B9njsDhM.js";const Fa=e({id:"ep1",type:"epic",title:"Платёжная система"}),y={args:{task:e({title:"C20: Environments UI",external:{source:"Delivery",externalId:"C20",managed:!0,url:"https://delivery.example/tasks/C20"}})}},or={title:"Kanban/TaskCard",component:Ua,args:{projectName:"Голос Чат",allTasks:[Fa],doneColumnIds:new Set(["done"]),dragging:!1,onOpen:()=>{},onUpdate:()=>{},onDelete:()=>{},onMoveTop:()=>{},onMoveBottom:()=>{}},decorators:[M=>S.jsx("div",{className:"jboard",style:{padding:16},children:S.jsx("div",{className:"jcol",style:{width:272},children:S.jsx("div",{className:"jcol-body",style:{padding:"8px 6px"},children:S.jsx(M,{})})})})]},t={args:{task:e({title:"Поправить отступ в шапке"})}},n={args:{task:e({title:"Интеграция платёжного шлюза",parentId:"ep1"})}},s={args:{task:e({title:"Срочно: падает прод",flagged:!0,priority:"urgent"})}},o={args:{task:e({id:"full",title:"Оплата картой: полный сценарий с 3-DS подтверждением",parentId:"ep1",labels:["payments","critical"],storyPoints:8,dueDate:Date.now()-24*60*60*1e3,flagged:!0,assignee:"bob",priority:"high",seq:42}),allTasks:[Fa,e({id:"ch1",parentId:"full",columnId:"done",title:"Форма"}),e({id:"ch2",parentId:"full",columnId:"wip",title:"Шлюз"})]}},i={args:{task:e({title:"Выпущено в прод",columnId:"done",assignee:"admin"})}},c={args:{task:e({title:"Спроектировать и реализовать сценарий обработки переполнения текста, включая перенос строк и обрезание СловаБезПробеловКотороеОченьДлинное"+"ещёдлиннее".repeat(8)})}},m={args:{task:e({title:"Меня тащат"}),dragging:!0}},p={args:{task:{id:"br",projectId:"p1",columnId:"x",type:"task",parentId:"ghost",title:"Битая задача",description:"",acceptanceCriteria:"",priority:"medium",assignee:null,labels:[],skills:[],storyPoints:null,dueDate:null,flagged:!1,seq:0,position:0,createdAt:1,updatedAt:1}}},d={args:{task:e({title:"Ран выполняется"}),ciSummary:r(),onStartCi:()=>{},onOpenCiRun:()=>{}}},u={args:{task:e({title:"Модель исправляет ошибку"}),ciSummary:r({slotProgress:{done:4,total:6,phase:"Модель исправляет ошибку",fixing:!0}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},l={args:{task:e({title:"Есть вопросы к пользователю"}),ciSummary:r({status:"awaiting_input",awaitingInput:!0,slotProgress:{done:3,total:6,phase:"Модель ждёт ответа"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},g={args:{task:e({title:"Ран упал"}),ciSummary:r({status:"failed",modelActive:!1,slotProgress:{done:4,total:6,phase:"Финальные команды (1/2)"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},k={args:{task:e({title:"Готово к пересборке прода"}),ciSummary:r({status:"success",modelActive:!1,slotProgress:{done:6,total:6,phase:"Резюме"}}),onStartCi:()=>{},onOpenCiRun:()=>{}}},a=(M,Ha={})=>e({columnId:M,...Ha}),T={args:{columnSemanticType:"backlog",task:a("backlog",{labels:["ui"],storyPoints:3}),onStartPreparation:()=>{}}},C={args:{columnSemanticType:"preparation",task:a("preparation",{taskPreparationStatus:"running"}),onStartPreparation:()=>{}}},f={args:{columnSemanticType:"preparation",task:a("preparation",{taskPreparationStatus:"failed",taskPreparationError:"Не заполнены критерии приёмки"}),onStartPreparation:()=>{}}},h={args:{columnSemanticType:"ready",task:a("ready",{skills:["storybook","a11y"],agentId:"prod-10e"}),onStartCi:()=>{}}},A={args:{columnSemanticType:"development",task:a("development"),ciSummary:r(),onOpenCiRun:()=>{}}},P={args:{columnSemanticType:"component_qa",task:a("component_qa",{latestRunResult:{id:"qa-1",kind:"component_qa",status:"success",outcome:"success",createdAt:1,finishedAt:2}})}},I={args:{columnSemanticType:"integration_tests",task:a("integration_tests")}},R={args:{columnSemanticType:"automated_qa",task:a("automated_qa",{latestRunResult:{id:"qa-2",kind:"automated_qa",status:"failed",outcome:"failure",createdAt:1,finishedAt:2}})}},_={args:{columnSemanticType:"manual_qa",task:a("manual_qa")}},q={args:{columnSemanticType:"awaiting_merge",task:a("awaiting_merge",{mergeSourceBranch:"feature/CHAT-375",mergePermitted:!0,mergeMachineBound:!0}),onStartMerge:()=>{}}},b={args:{columnSemanticType:"merge",task:a("merge",{mergeSourceBranch:"feature/CHAT-375",activeMergeRunId:"merge-1"})}},v={args:{columnSemanticType:"done",task:a("done",{mergeSourceBranch:"feature/CHAT-375",doneAt:Date.UTC(2026,7,29),latestRunResult:{id:"run-1",kind:"merge",status:"success",outcome:"success",createdAt:1,finishedAt:2}})}},x={args:{columnSemanticType:"cancelled",task:a("cancelled",{taskPreparationError:"Отменено пользователем"})}},D={args:{columnSemanticType:"decision_required",task:a("decision_required",{taskPreparationError:"Нужно выбрать стратегию миграции"})}},w={args:{columnSemanticType:"development",task:a("development",{title:"Длинный мобильный заголовок карточки задачи ".repeat(4)}),ciSummary:r(),onOpenCiRun:()=>{}},parameters:{viewport:{defaultViewport:"mobile1"}}};var E,O,B;y.parameters={...y.parameters,docs:{...(E=y.parameters)==null?void 0:E.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'C20: Environments UI',
      external: {
        source: 'Delivery',
        externalId: 'C20',
        managed: true,
        url: 'https://delivery.example/tasks/C20'
      }
    })
  }
}`,...(B=(O=y.parameters)==null?void 0:O.docs)==null?void 0:B.source}}};var j,Q,F,H,U;t.parameters={...t.parameters,docs:{...(j=t.parameters)==null?void 0:j.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Поправить отступ в шапке'
    })
  }
}`,...(F=(Q=t.parameters)==null?void 0:Q.docs)==null?void 0:F.source},description:{story:"Минимальная задача: только заголовок, тип и приоритет по умолчанию.",...(U=(H=t.parameters)==null?void 0:H.docs)==null?void 0:U.description}}};var L,N,V,W,K;n.parameters={...n.parameters,docs:{...(L=n.parameters)==null?void 0:L.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Интеграция платёжного шлюза',
      parentId: 'ep1'
    })
  }
}`,...(V=(N=n.parameters)==null?void 0:N.docs)==null?void 0:V.source},description:{story:"С чипом эпика-родителя.",...(K=(W=n.parameters)==null?void 0:W.docs)==null?void 0:K.description}}};var z,G,J,X,Y;s.parameters={...s.parameters,docs:{...(z=s.parameters)==null?void 0:z.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Срочно: падает прод',
      flagged: true,
      priority: 'urgent'
    })
  }
}`,...(J=(G=s.parameters)==null?void 0:G.docs)==null?void 0:J.source},description:{story:"Помечена флагом — жёлтая карточка.",...(Y=(X=s.parameters)==null?void 0:X.docs)==null?void 0:Y.description}}};var Z,$,ee,ae,re;o.parameters={...o.parameters,docs:{...(Z=o.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      id: 'full',
      title: 'Оплата картой: полный сценарий с 3-DS подтверждением',
      parentId: 'ep1',
      labels: ['payments', 'critical'],
      storyPoints: 8,
      dueDate: Date.now() - 24 * 60 * 60 * 1000,
      flagged: true,
      assignee: 'bob',
      priority: 'high',
      seq: 42
    }),
    allTasks: [epic, makeTask({
      id: 'ch1',
      parentId: 'full',
      columnId: 'done',
      title: 'Форма'
    }), makeTask({
      id: 'ch2',
      parentId: 'full',
      columnId: 'wip',
      title: 'Шлюз'
    })]
  }
}`,...(ee=($=o.parameters)==null?void 0:$.docs)==null?void 0:ee.source},description:{story:"Все атрибуты сразу: эпик, метки, флаг, просроченный срок, поинты, аватар, подзадачи.",...(re=(ae=o.parameters)==null?void 0:ae.docs)==null?void 0:re.description}}};var te,ne,se,oe,ie;i.parameters={...i.parameters,docs:{...(te=i.parameters)==null?void 0:te.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Выпущено в прод',
      columnId: 'done',
      assignee: 'admin'
    })
  }
}`,...(se=(ne=i.parameters)==null?void 0:ne.docs)==null?void 0:se.source},description:{story:"В колонке «Готово» — ключ зачёркнут.",...(ie=(oe=i.parameters)==null?void 0:oe.docs)==null?void 0:ie.description}}};var ce,me,pe,de,ue;c.parameters={...c.parameters,docs:{...(ce=c.parameters)==null?void 0:ce.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Спроектировать и реализовать сценарий обработки переполнения текста, включая перенос строк и обрезание СловаБезПробеловКотороеОченьДлинное' + 'ещёдлиннее'.repeat(8)
    })
  }
}`,...(pe=(me=c.parameters)==null?void 0:me.docs)==null?void 0:pe.source},description:{story:"Очень длинный заголовок и слово без пробелов.",...(ue=(de=c.parameters)==null?void 0:de.docs)==null?void 0:ue.description}}};var le,ge,ke,Se,ye;m.parameters={...m.parameters,docs:{...(le=m.parameters)==null?void 0:le.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Меня тащат'
    }),
    dragging: true
  }
}`,...(ke=(ge=m.parameters)==null?void 0:ge.docs)==null?void 0:ke.source},description:{story:"Состояние перетаскивания.",...(ye=(Se=m.parameters)==null?void 0:Se.docs)==null?void 0:ye.description}}};var Te,Ce,fe,he,Ae;p.parameters={...p.parameters,docs:{...(Te=p.parameters)==null?void 0:Te.docs,source:{originalSource:`{
  args: {
    task: {
      id: 'br',
      projectId: 'p1',
      columnId: 'x',
      type: 'task',
      parentId: 'ghost',
      title: 'Битая задача',
      description: '',
      acceptanceCriteria: '',
      priority: 'medium',
      assignee: null,
      labels: [],
      skills: [],
      storyPoints: null,
      dueDate: null,
      flagged: false,
      seq: 0,
      position: 0,
      createdAt: 1,
      updatedAt: 1
    } as Task
  }
}`,...(fe=(Ce=p.parameters)==null?void 0:Ce.docs)==null?void 0:fe.source},description:{story:"Битые данные (через каст) — компонент не падает на уровне карточки.",...(Ae=(he=p.parameters)==null?void 0:he.docs)==null?void 0:Ae.description}}};var Pe,Ie,Re,_e,qe;d.parameters={...d.parameters,docs:{...(Pe=d.parameters)==null?void 0:Pe.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Ран выполняется'
    }),
    ciSummary: makeCiSummary(),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(Re=(Ie=d.parameters)==null?void 0:Ie.docs)==null?void 0:Re.source},description:{story:"Ран идёт: голубая рамка медленно «дышит», запуск недоступен — только лента.",...(qe=(_e=d.parameters)==null?void 0:_e.docs)==null?void 0:qe.description}}};var be,ve,xe,De,we;u.parameters={...u.parameters,docs:{...(be=u.parameters)==null?void 0:be.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Модель исправляет ошибку'
    }),
    ciSummary: makeCiSummary({
      slotProgress: {
        done: 4,
        total: 6,
        phase: 'Модель исправляет ошибку',
        fixing: true
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(xe=(ve=u.parameters)==null?void 0:ve.docs)==null?void 0:xe.source},description:{story:"Шаг упал, модель разбирается: медленное красное мигание.",...(we=(De=u.parameters)==null?void 0:De.docs)==null?void 0:we.description}}};var Me,Ee,Oe,Be,je;l.parameters={...l.parameters,docs:{...(Me=l.parameters)==null?void 0:Me.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Есть вопросы к пользователю'
    }),
    ciSummary: makeCiSummary({
      status: 'awaiting_input',
      awaitingInput: true,
      slotProgress: {
        done: 3,
        total: 6,
        phase: 'Модель ждёт ответа'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(Oe=(Ee=l.parameters)==null?void 0:Ee.docs)==null?void 0:Oe.source},description:{story:"Ран ждёт ответа пользователя: частое жёлтое мигание.",...(je=(Be=l.parameters)==null?void 0:Be.docs)==null?void 0:je.description}}};var Qe,Fe,He,Ue,Le;g.parameters={...g.parameters,docs:{...(Qe=g.parameters)==null?void 0:Qe.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Ран упал'
    }),
    ciSummary: makeCiSummary({
      status: 'failed',
      modelActive: false,
      slotProgress: {
        done: 4,
        total: 6,
        phase: 'Финальные команды (1/2)'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(He=(Fe=g.parameters)==null?void 0:Fe.docs)==null?void 0:He.source},description:{story:"Ран свалился окончательно: частое красное мигание.",...(Le=(Ue=g.parameters)==null?void 0:Ue.docs)==null?void 0:Le.description}}};var Ne,Ve,We,Ke,ze;k.parameters={...k.parameters,docs:{...(Ne=k.parameters)==null?void 0:Ne.docs,source:{originalSource:`{
  args: {
    task: makeTask({
      title: 'Готово к пересборке прода'
    }),
    ciSummary: makeCiSummary({
      status: 'success',
      modelActive: false,
      slotProgress: {
        done: 6,
        total: 6,
        phase: 'Резюме'
      }
    }),
    onStartCi: () => {},
    onOpenCiRun: () => {}
  }
}`,...(We=(Ve=k.parameters)==null?void 0:Ve.docs)==null?void 0:We.source},description:{story:"Разработка закончена, ждёт пересборки прода: статичная зелёная рамка.",...(ze=(Ke=k.parameters)==null?void 0:Ke.docs)==null?void 0:ze.description}}};var Ge,Je,Xe;T.parameters={...T.parameters,docs:{...(Ge=T.parameters)==null?void 0:Ge.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'backlog',
    task: stageTask('backlog', {
      labels: ['ui'],
      storyPoints: 3
    }),
    onStartPreparation: () => {}
  }
}`,...(Xe=(Je=T.parameters)==null?void 0:Je.docs)==null?void 0:Xe.source}}};var Ye,Ze,$e;C.parameters={...C.parameters,docs:{...(Ye=C.parameters)==null?void 0:Ye.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'preparation',
    task: stageTask('preparation', {
      taskPreparationStatus: 'running'
    }),
    onStartPreparation: () => {}
  }
}`,...($e=(Ze=C.parameters)==null?void 0:Ze.docs)==null?void 0:$e.source}}};var ea,aa,ra;f.parameters={...f.parameters,docs:{...(ea=f.parameters)==null?void 0:ea.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'preparation',
    task: stageTask('preparation', {
      taskPreparationStatus: 'failed',
      taskPreparationError: 'Не заполнены критерии приёмки'
    }),
    onStartPreparation: () => {}
  }
}`,...(ra=(aa=f.parameters)==null?void 0:aa.docs)==null?void 0:ra.source}}};var ta,na,sa;h.parameters={...h.parameters,docs:{...(ta=h.parameters)==null?void 0:ta.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'ready',
    task: stageTask('ready', {
      skills: ['storybook', 'a11y'],
      agentId: 'prod-10e'
    }),
    onStartCi: () => {}
  }
}`,...(sa=(na=h.parameters)==null?void 0:na.docs)==null?void 0:sa.source}}};var oa,ia,ca;A.parameters={...A.parameters,docs:{...(oa=A.parameters)==null?void 0:oa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'development',
    task: stageTask('development'),
    ciSummary: makeCiSummary(),
    onOpenCiRun: () => {}
  }
}`,...(ca=(ia=A.parameters)==null?void 0:ia.docs)==null?void 0:ca.source}}};var ma,pa,da;P.parameters={...P.parameters,docs:{...(ma=P.parameters)==null?void 0:ma.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'component_qa',
    task: stageTask('component_qa', {
      latestRunResult: {
        id: 'qa-1',
        kind: 'component_qa',
        status: 'success',
        outcome: 'success',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(da=(pa=P.parameters)==null?void 0:pa.docs)==null?void 0:da.source}}};var ua,la,ga;I.parameters={...I.parameters,docs:{...(ua=I.parameters)==null?void 0:ua.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'integration_tests',
    task: stageTask('integration_tests')
  }
}`,...(ga=(la=I.parameters)==null?void 0:la.docs)==null?void 0:ga.source}}};var ka,Sa,ya;R.parameters={...R.parameters,docs:{...(ka=R.parameters)==null?void 0:ka.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'automated_qa',
    task: stageTask('automated_qa', {
      latestRunResult: {
        id: 'qa-2',
        kind: 'automated_qa',
        status: 'failed',
        outcome: 'failure',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(ya=(Sa=R.parameters)==null?void 0:Sa.docs)==null?void 0:ya.source}}};var Ta,Ca,fa;_.parameters={..._.parameters,docs:{...(Ta=_.parameters)==null?void 0:Ta.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'manual_qa',
    task: stageTask('manual_qa')
  }
}`,...(fa=(Ca=_.parameters)==null?void 0:Ca.docs)==null?void 0:fa.source}}};var ha,Aa,Pa;q.parameters={...q.parameters,docs:{...(ha=q.parameters)==null?void 0:ha.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'awaiting_merge',
    task: stageTask('awaiting_merge', {
      mergeSourceBranch: 'feature/CHAT-375',
      mergePermitted: true,
      mergeMachineBound: true
    }),
    onStartMerge: () => {}
  }
}`,...(Pa=(Aa=q.parameters)==null?void 0:Aa.docs)==null?void 0:Pa.source}}};var Ia,Ra,_a;b.parameters={...b.parameters,docs:{...(Ia=b.parameters)==null?void 0:Ia.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'merge',
    task: stageTask('merge', {
      mergeSourceBranch: 'feature/CHAT-375',
      activeMergeRunId: 'merge-1'
    })
  }
}`,...(_a=(Ra=b.parameters)==null?void 0:Ra.docs)==null?void 0:_a.source}}};var qa,ba,va;v.parameters={...v.parameters,docs:{...(qa=v.parameters)==null?void 0:qa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'done',
    task: stageTask('done', {
      mergeSourceBranch: 'feature/CHAT-375',
      doneAt: Date.UTC(2026, 7, 29),
      latestRunResult: {
        id: 'run-1',
        kind: 'merge',
        status: 'success',
        outcome: 'success',
        createdAt: 1,
        finishedAt: 2
      }
    })
  }
}`,...(va=(ba=v.parameters)==null?void 0:ba.docs)==null?void 0:va.source}}};var xa,Da,wa;x.parameters={...x.parameters,docs:{...(xa=x.parameters)==null?void 0:xa.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'cancelled',
    task: stageTask('cancelled', {
      taskPreparationError: 'Отменено пользователем'
    })
  }
}`,...(wa=(Da=x.parameters)==null?void 0:Da.docs)==null?void 0:wa.source}}};var Ma,Ea,Oa;D.parameters={...D.parameters,docs:{...(Ma=D.parameters)==null?void 0:Ma.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'decision_required',
    task: stageTask('decision_required', {
      taskPreparationError: 'Нужно выбрать стратегию миграции'
    })
  }
}`,...(Oa=(Ea=D.parameters)==null?void 0:Ea.docs)==null?void 0:Oa.source}}};var Ba,ja,Qa;w.parameters={...w.parameters,docs:{...(Ba=w.parameters)==null?void 0:Ba.docs,source:{originalSource:`{
  args: {
    columnSemanticType: 'development',
    task: stageTask('development', {
      title: 'Длинный мобильный заголовок карточки задачи '.repeat(4)
    }),
    ciSummary: makeCiSummary(),
    onOpenCiRun: () => {}
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile1'
    }
  }
}`,...(Qa=(ja=w.parameters)==null?void 0:ja.docs)==null?void 0:Qa.source}}};const ir=["ExternalManaged","Minimal","WithEpicChip","Flagged","AllAttributes","DoneColumn","LongTitle","Dragging","BrokenData","CiRunning","CiFixing","CiAwaitingInput","CiFailed","CiSuccess","StageBacklog","StagePreparation","StagePreparationError","StageReady","StageInProgress","StageComponentQa","StageIntegrationQa","StageAutomatedQa","StageManualQa","StageAwaitingMerge","StageMerge","StageDone","StageCancelled","StageDecisionRequired","MobileLongTitle"];export{o as AllAttributes,p as BrokenData,l as CiAwaitingInput,g as CiFailed,u as CiFixing,d as CiRunning,k as CiSuccess,i as DoneColumn,m as Dragging,y as ExternalManaged,s as Flagged,c as LongTitle,t as Minimal,w as MobileLongTitle,R as StageAutomatedQa,q as StageAwaitingMerge,T as StageBacklog,x as StageCancelled,P as StageComponentQa,D as StageDecisionRequired,v as StageDone,A as StageInProgress,I as StageIntegrationQa,_ as StageManualQa,b as StageMerge,C as StagePreparation,f as StagePreparationError,h as StageReady,n as WithEpicChip,ir as __namedExportsOrder,or as default};
