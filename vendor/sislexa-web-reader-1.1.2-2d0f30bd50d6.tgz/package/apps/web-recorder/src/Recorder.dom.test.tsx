// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { PREVIEW_ACTION_COMMAND_TYPE, PREVIEW_ACTION_RESULT_TYPE, PREVIEW_PAGE_LOADING_TYPE, PREVIEW_PAGE_READY_TYPE } from '@shared/previewActions'
import { PREVIEW_INSPECTOR_COMMAND_TYPE } from '@shared/previewInspector'
import { WEB_RECORDER_MESSAGE_TYPE, WEB_RECORDER_PROTOCOL_VERSION } from '@shared/webRecorder'
import { Recorder } from './Recorder'

const type = WEB_RECORDER_MESSAGE_TYPE
const ids = { conversationId: 'conv-1', registrationId: 'reg-1' }
const init = { type, ...ids, kind: 'init', protocolVersion: WEB_RECORDER_PROTOCOL_VERSION, previewUrl: 'https://shop.example/', capabilities: ['mcp-actions'] }

/** Сообщение host → Reader; в jsdom parent === window, поэтому source: window. */
function fromHost(data: object): void {
  fireEvent(window, new MessageEvent('message', { origin: window.location.origin, source: window, data }))
}
function fromPage(data: object): void {
  const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
  fireEvent(window, new MessageEvent('message', { origin: window.location.origin, source: frame.contentWindow, data }))
}
/** Отправленные Reader-ом сообщения контракта (parent === window в jsdom). */
function sent(spy: ReturnType<typeof vi.spyOn>): Array<Record<string, unknown>> {
  return spy.mock.calls.map(([message]) => message as Record<string, unknown>).filter((message) => message.type === type)
}

const originalCryptoDescriptor = Object.getOwnPropertyDescriptor(globalThis, 'crypto')

afterEach(() => {
  cleanup()
  vi.restoreAllMocks()
  localStorage.clear() // персист сценариев не должен протекать между тестами
  if (originalCryptoDescriptor) Object.defineProperty(globalThis, 'crypto', originalCryptoDescriptor)
  else delete (globalThis as { crypto?: Crypto }).crypto
})

describe('Recorder handshake', () => {
  it('шлёт ready с версией протокола после установки listener и принимает init', async () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    const ready = sent(post).find((message) => message.kind === 'ready')!
    expect(ready).toMatchObject({ protocolVersion: WEB_RECORDER_PROTOCOL_VERSION, conversationId: null, registrationId: null, capabilities: expect.arrayContaining(['read', 'diagnostics']) })
    fromHost(init)
    await waitFor(() => expect(screen.queryByTitle('Предпросмотр сайта')).toBeTruthy())
    const status = sent(post).find((message) => message.kind === 'page-status')!
    expect(status).toMatchObject({ ...ids, status: 'loading', url: 'https://shop.example/' })
  })

  it('повторный init той же регистрации не перезагружает страницу', async () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE })
    post.mockClear()
    fromHost(init)
    const statuses = sent(post).filter((message) => message.kind === 'page-status')
    expect(statuses).toEqual([expect.objectContaining({ status: 'ready', url: 'https://shop.example/' })])
  })

  it('игнорирует команды с чужими или устаревшими ID', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    post.mockClear()
    fromHost({ type, conversationId: 'other-conv', registrationId: 'reg-1', kind: 'command', requestId: 'r1', action: { kind: 'read' } })
    fromHost({ type, conversationId: 'conv-1', registrationId: 'stale-reg', kind: 'command', requestId: 'r2', action: { kind: 'read' } })
    expect(sent(post).filter((message) => message.kind === 'result')).toHaveLength(0)
  })

  it('игнорирует сообщение host с чужим origin', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fireEvent(window, new MessageEvent('message', { origin: 'https://evil.test', source: window, data: init }))
    expect(sent(post).filter((message) => message.kind === 'page-status')).toHaveLength(0)
  })
})

describe('Recorder reload по set-url', () => {
  it('set-url(null)+set-url(url) в одном тике пересоздают iframe (повторный open = перезагрузка)', async () => {
    render(<Recorder />)
    fromHost(init)
    const before = screen.getByTitle('Предпросмотр сайта')
    // Слипшиеся сообщения host при повторном open того же адреса.
    fromHost({ type, ...ids, kind: 'set-url', url: null })
    fromHost({ type, ...ids, kind: 'set-url', url: 'https://shop.example/' })
    await waitFor(() => expect(screen.getByTitle('Предпросмотр сайта')).not.toBe(before))
  })
})

describe('Recorder commands', () => {
  it('command до готовности страницы получает строго определённую ошибку', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fromHost({ type, ...ids, kind: 'command', requestId: 'r1', action: { kind: 'read' } })
    expect(sent(post).find((message) => message.kind === 'result')).toMatchObject({ ...ids, requestId: 'r1', ok: false, error: 'Страница ещё загружается.' })
  })

  it('после page-ready пересылает command в iframe и возвращает result с ID', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const inner = vi.spyOn(frame.contentWindow as Window, 'postMessage')
    fromPage({ type: PREVIEW_PAGE_READY_TYPE })
    expect(sent(post).some((message) => message.kind === 'page-status' && message.status === 'ready')).toBe(true)
    fromHost({ type, ...ids, kind: 'command', requestId: 'r1', action: { kind: 'read' } })
    expect(inner.mock.calls.some(([message]) => (message as { type?: string; requestId?: string }).type === PREVIEW_ACTION_COMMAND_TYPE && (message as { requestId?: string }).requestId === 'r1')).toBe(true)
    const result = { page: { url: 'https://shop.example/', title: 'Shop' }, headings: [], links: [], buttons: [], inputs: [], text: 'Loaded' }
    fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: 'r1', ok: true, result })
    expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'r1')).toMatchObject({ ...ids, ok: true, result })
  })

  it('dispose отвечает disposed и перестаёт исполнять команды', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE })
    fromHost({ type, ...ids, kind: 'dispose' })
    expect(sent(post).some((message) => message.kind === 'disposed')).toBe(true)
    expect(screen.getByRole('status').textContent).toContain('отключена')
    post.mockClear()
    fromHost({ type, ...ids, kind: 'command', requestId: 'r-late', action: { kind: 'read' } })
    expect(sent(post)).toHaveLength(0)
  })
})

describe('Recorder inspector и запись', () => {
  it('inspector-state пересылается внутрь и включает тумблер', () => {
    render(<Recorder />)
    fromHost(init)
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const inner = vi.spyOn(frame.contentWindow as Window, 'postMessage')
    fromHost({ type, ...ids, kind: 'inspector-state', enabled: true })
    expect(inner.mock.calls.some(([message]) => (message as { type?: string; enabled?: boolean }).type === PREVIEW_INSPECTOR_COMMAND_TYPE && (message as { enabled?: boolean }).enabled === true)).toBe(true)
    expect(screen.getByRole('button', { name: /Выбор элемента/ }).getAttribute('aria-pressed')).toBe('true')
  })

  it('записанный шаг уходит host-у, секретное значение не покидает страницу', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    fromPage({ type: 'voicechat.preview.record.v1', step: { kind: 'click', selector: '#buy', text: 'Купить' } })
    fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    fromPage({ type: 'voicechat.preview.record.v1', step: { kind: 'type', selector: '#password', text: 'hunter2', sensitive: true } })
    const steps = sent(post).filter((message) => message.kind === 'recording-step')
    expect(steps[0]).toMatchObject({ step: { kind: 'click', selector: '#buy', text: 'Купить', sensitive: false } })
    expect(steps[1]).toMatchObject({ step: { kind: 'type', selector: '#password', text: '', sensitive: true } })
    expect(JSON.stringify(steps)).not.toContain('hunter2')
    const secret = screen.getByLabelText('Секретное значение шага 2') as HTMLInputElement
    expect(secret.value).toBe('') // значение поля не пришло и не показано
    expect(secret.getAttribute('placeholder')).toContain('для запуска')
    expect(screen.getByText('секрет не сохраняется')).toBeTruthy()
  })
})

describe('Recorder диагностика', () => {
  it('в режиме диагностики шаги дают diagnostics-progress, не попадают в запись, а стоп — diagnostics-complete', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE })
    fromHost({ type, ...ids, kind: 'diagnostics-start', active: true })
    fromHost({ type, ...ids, kind: 'command', requestId: 'diag-1', action: { kind: 'read', diagnostic: true } })
    fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    fromPage({ type: 'voicechat.preview.record.v1', step: { kind: 'click', selector: '#diag', text: 'x' } })
    fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: 'diag-1', ok: true, result: { text: 'ok' } })
    const progress = sent(post).find((message) => message.kind === 'diagnostics-progress')!
    expect(progress).toMatchObject({ ...ids, requestId: 'diag-1', action: 'read', ok: true, durationMs: expect.any(Number) })
    expect(sent(post).filter((message) => message.kind === 'recording-step')).toHaveLength(0)
    expect(screen.getByRole('region', { name: 'Диагностика Web Reader' }).textContent).toContain('read')
    fromHost({ type, ...ids, kind: 'diagnostics-start', active: false })
    expect(sent(post).find((message) => message.kind === 'diagnostics-complete')).toMatchObject({ ...ids, total: 1 })
  })
})

describe('Recorder edit-режим', () => {
  it('кнопка «Редактировать» включает edit-режим внутреннего iframe', () => {
    render(<Recorder />)
    fromHost(init)
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const inner = vi.spyOn(frame.contentWindow as Window, 'postMessage')
    const toggle = screen.getByRole('button', { name: /Редактировать$/ })
    fireEvent.click(toggle)
    expect(inner.mock.calls.some(([message]) => (message as { type?: string; enabled?: boolean }).type === 'voicechat.preview.edit.v1' && (message as { enabled?: boolean }).enabled === true)).toBe(true)
    expect(toggle.getAttribute('aria-pressed')).toBe('true')
  })

  it('Escape внутри страницы выключает режим: iframe сообщает enabled:false', () => {
    render(<Recorder />)
    fromHost(init)
    fireEvent.click(screen.getByRole('button', { name: /Редактировать$/ }))
    fromPage({ type: 'voicechat.preview.edit.v1', enabled: false })
    expect(screen.getByRole('button', { name: /Редактировать$/ }).getAttribute('aria-pressed')).toBe('false')
  })
})

describe('Recorder скриншот области', () => {
  it('кнопка «📸 Область» включает режим выделения внутри iframe', () => {
    render(<Recorder />)
    fromHost(init)
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const inner = vi.spyOn(frame.contentWindow as Window, 'postMessage')
    const toggle = screen.getByRole('button', { name: /Область/ })
    fireEvent.click(toggle)
    expect(inner.mock.calls.some(([message]) => (message as { type?: string; enabled?: boolean }).type === 'voicechat.preview.capture.v1' && (message as { enabled?: boolean }).enabled === true)).toBe(true)
    expect(toggle.getAttribute('aria-pressed')).toBe('true')
  })

  it('снимок пересылается host сообщением area-screenshot с ID регистрации', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fireEvent.click(screen.getByRole('button', { name: /Область/ }))
    const shot = { dataUrl: 'data:image/png;base64,AAAA', rect: { x: 5, y: 6, width: 70, height: 80 }, pageUrl: 'https://example.test/' }
    fromPage({ type: 'voicechat.preview.capture.v1', enabled: false, shot })
    expect(screen.getByRole('button', { name: /Область/ }).getAttribute('aria-pressed')).toBe('false')
    expect(sent(post).find((message) => message.kind === 'area-screenshot')).toMatchObject({ ...ids, shot })
  })

  it('ошибка снимка показывается пользователю и не уходит host', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fromPage({ type: 'voicechat.preview.capture.v1', error: 'Canvas недоступен', rect: { x: 0, y: 0, width: 1, height: 1 } })
    expect(screen.getByRole('alert').textContent).toContain('Canvas недоступен')
    expect(sent(post).filter((message) => message.kind === 'area-screenshot')).toHaveLength(0)
  })
})

describe('Recorder submit-шаги', () => {
  it('Enter-сабмит авторизации показывается бейджем и уходит host-у с submit', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    fromPage({ type: 'voicechat.preview.record.v1', step: { kind: 'type', selector: '#password', text: '', sensitive: true, submit: true } })
    expect(screen.getByText('⏎ submit')).toBeTruthy()
    const step = sent(post).find((message) => message.kind === 'recording-step')!
    expect(step).toMatchObject({ step: { kind: 'type', selector: '#password', text: '', sensitive: true, submit: true } })
  })

  it('воспроизведение submit-шага отправляет type-действие с submit', async () => {
    render(<Recorder />)
    fromHost(init)
    fireEvent.change(screen.getByPlaceholderText('https://example.com'), { target: { value: 'http://example.test' } })
    fireEvent.click(screen.getByRole('button', { name: 'Открыть' }))
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const inner = vi.spyOn(frame.contentWindow as Window, 'postMessage')
    fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    fromPage({ type: 'voicechat.preview.record.v1', step: { kind: 'type', selector: '#q', text: 'ноутбук', submit: true } })
    fromPage({ type: PREVIEW_PAGE_READY_TYPE })
    fireEvent.click(screen.getByRole('button', { name: 'Запустить' }))
    await waitFor(() => expect(inner.mock.calls.some(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)).toBe(true))
    const action = inner.mock.calls.map(([message]) => message as { type?: string; action?: { kind?: string; submit?: boolean; sensitive?: unknown } }).find((message) => message.type === PREVIEW_ACTION_COMMAND_TYPE)!
    expect(action.action).toEqual({ kind: 'type', selector: '#q', text: 'ноутбук', submit: true })
  })
})

describe('Recorder scenario', () => {
  it('запускает каждый шаг с уникальным локальным requestId без randomUUID', async () => {
    let byte = 0
    vi.stubGlobal('crypto', { getRandomValues: (bytes: Uint8Array) => { bytes.fill(++byte); return bytes } })
    render(<Recorder />)
    fromHost(init)
    fireEvent.change(screen.getByPlaceholderText('https://example.com'), { target: { value: 'http://example.test' } })
    fireEvent.click(screen.getByRole('button', { name: 'Открыть' }))
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const postMessage = vi.spyOn(frame.contentWindow as Window, 'postMessage')
    for (const step of [
      { kind: 'click', selector: '#buy', text: '' },
      { kind: 'type', selector: '#search', text: 'shoes' }
    ]) {
      fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    fromPage({ type: 'voicechat.preview.record.v1', step })
    }
    fromPage({ type: PREVIEW_PAGE_READY_TYPE })
    fireEvent.click(screen.getByRole('button', { name: 'Запустить' }))
    await waitFor(() => expect(postMessage.mock.calls.some(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)).toBe(true))
    const first = postMessage.mock.calls.find(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)![0]
    fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: first.requestId, ok: true })
    await waitFor(() => expect(postMessage.mock.calls.filter(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)).toHaveLength(2))
    const commands = postMessage.mock.calls
      .map(([message]) => message as { type?: string; requestId?: string })
      .filter((message) => message.type === PREVIEW_ACTION_COMMAND_TYPE)
    expect(commands).toHaveLength(2)
    expect(commands.every((command) => command.requestId?.startsWith('local-'))).toBe(true)
    expect(new Set(commands.map((command) => command.requestId))).toHaveLength(2)
  })
})

describe('Recorder viewport-команда', () => {
  it('viewport исполняется самим Reader без загруженной страницы и сужает iframe', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />)
    fromHost(init)
    fromHost({ type, ...ids, kind: 'command', requestId: 'v1', action: { kind: 'viewport', width: 414 } })
    expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'v1')).toMatchObject({ ok: true, result: { width: 414 } })
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    expect(frame.style.width).toBe('414px')
    const select = screen.getByLabelText('Ширина вьюпорта') as HTMLSelectElement
    expect(select.value).toBe('414')
    fromHost({ type, ...ids, kind: 'command', requestId: 'v2', action: { kind: 'viewport', width: 0 } })
    expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'v2')).toMatchObject({ ok: true, result: { width: 0 } })
    expect((screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement).style.width).toBe('')
  })
})

describe('Recorder: результат действия и навигация (круг 1)', () => {
  const ready = () => { render(<Recorder />); fromHost(init); fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/', title: 'Магазин' }) }
  it('клик без перехода отвечает navigated: false после короткой паузы', async () => {
    vi.useFakeTimers()
    try {
      const post = vi.spyOn(window, 'postMessage')
      ready()
      fromHost({ type, ...ids, kind: 'command', requestId: 'c1', action: { kind: 'click', text: 'Купить' } })
      fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: 'c1', ok: true, result: { page: { url: 'https://shop.example/', title: 'Магазин' }, clicked: { selector: 'button', tag: 'button', text: 'Купить' } } })
      expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'c1')).toBeUndefined()
      act(() => { vi.advanceTimersByTime(400) })
      expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'c1')).toMatchObject({ ok: true, result: { navigated: false, clicked: { text: 'Купить' } } })
    } finally { vi.useRealTimers() }
  })
  it('клик, начавший переход, отвечает navigated: true с адресом и заголовком новой страницы', async () => {
    vi.useFakeTimers()
    try {
      const post = vi.spyOn(window, 'postMessage')
      ready()
      fromHost({ type, ...ids, kind: 'command', requestId: 'c2', action: { kind: 'click', text: 'Книги' } })
      fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: 'c2', ok: true, result: { page: { url: 'https://shop.example/', title: 'Магазин' }, clicked: { selector: 'a', tag: 'a', text: 'Книги' } } })
      fromPage({ type: PREVIEW_PAGE_LOADING_TYPE })
      act(() => { vi.advanceTimersByTime(1000) })
      expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'c2')).toBeUndefined()
      fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/books', title: 'Книги — Магазин' })
      const result = sent(post).find((message) => message.kind === 'result' && message.requestId === 'c2')
      expect(result).toMatchObject({ ok: true, result: { navigated: true, page: { url: 'https://shop.example/books', title: 'Книги — Магазин' } } })
      expect(sent(post).find((message) => message.kind === 'page-status' && message.status === 'ready' && message.url === 'https://shop.example/books')).toMatchObject({ title: 'Книги — Магазин' })
    } finally { vi.useRealTimers() }
  })
  it('back ждёт новую страницу и отвечает её адресом', () => {
    vi.useFakeTimers()
    try {
      const post = vi.spyOn(window, 'postMessage')
      ready()
      fromHost({ type, ...ids, kind: 'command', requestId: 'b1', action: { kind: 'back' } })
      fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: 'b1', ok: true, result: { page: { url: 'https://shop.example/', title: 'Магазин' }, navigating: true } })
      fromPage({ type: PREVIEW_PAGE_LOADING_TYPE })
      fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/prev', title: 'Прежняя' })
      expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'b1')).toMatchObject({ ok: true, result: { navigated: true, page: { url: 'https://shop.example/prev', title: 'Прежняя' } } })
    } finally { vi.useRealTimers() }
  })
  it('показывает связь с чатом, прячет файл сценария без шагов и предлагает внешнюю вкладку при ошибке', () => {
    const open = vi.spyOn(window, 'open').mockImplementation(() => null)
    render(<Recorder />)
    expect(screen.getByLabelText('Связи с чатом нет')).toBeTruthy()
    fromHost(init)
    expect(screen.getByLabelText('Связь с чатом есть')).toBeTruthy()
    expect(screen.queryByRole('button', { name: 'Импорт JSON' })).toBeNull()
    fireEvent.click(screen.getByRole('button', { name: 'Файл сценария (JSON)' }))
    expect(screen.getByRole('button', { name: 'Импорт JSON' })).toBeTruthy()
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/', title: 'Магазин' })
    expect(screen.getByText('Открыта страница: Магазин')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Обновить страницу' }))
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const doc = frame.contentDocument!; doc.open(); doc.write('{"message":"Сайт не ответил"}'); doc.close(); fireEvent.load(frame)
    return waitFor(() => screen.getByRole('button', { name: 'Открыть во внешней вкладке' })).then((button) => {
      fireEvent.click(button)
      expect(open).toHaveBeenCalledWith('https://shop.example/', '_blank', 'noopener,noreferrer')
    })
  })
  it('режим «Только я управляю» отклоняет команды модели, кроме status', () => {
    const post = vi.spyOn(window, 'postMessage')
    ready()
    fireEvent.click(screen.getByRole('button', { name: 'Только я управляю' }))
    fromHost({ type, ...ids, kind: 'command', requestId: 'm1', action: { kind: 'read' } })
    expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'm1')).toMatchObject({ ok: false, error: expect.stringContaining('Только я управляю') })
    fireEvent.click(screen.getByRole('button', { name: 'Вернуть ассистенту' }))
    fromHost({ type, ...ids, kind: 'command', requestId: 'm2', action: { kind: 'read' } })
    expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'm2')).toBeUndefined()
  })
  it('смена только hash не пересоздаёт iframe; загрузка называет сайт; Cmd+Enter открывает внешнюю вкладку', () => {
    const open = vi.spyOn(window, 'open').mockImplementation(() => null)
    render(<Recorder />); fromHost(init)
    expect(screen.getByRole('status').textContent).toContain('shop.example')
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/' })
    fromHost({ type, ...ids, kind: 'set-url', url: 'https://shop.example/#/cart' })
    expect(screen.getByTitle('Предпросмотр сайта')).toBe(frame)
    expect((screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement).value).toBe('https://shop.example/#/cart')
    fireEvent.change(screen.getByRole('textbox', { name: 'Адрес превью' }), { target: { value: 'https://other.example/' } })
    fireEvent.keyDown(screen.getByRole('textbox', { name: 'Адрес превью' }), { key: 'Enter', metaKey: true })
    expect(open).toHaveBeenCalledWith('https://other.example/', '_blank', 'noopener,noreferrer')
    expect(screen.getByTitle('Предпросмотр сайта')).toBe(frame)
  })
  it('выделение на странице превращается в вопрос ассистенту сообщением ask', () => {
    const post = vi.spyOn(window, 'postMessage')
    ready()
    fromPage({ type: 'voicechat.preview.selection.v1', text: 'RFC 2606' })
    fireEvent.click(screen.getByRole('button', { name: 'Спросить ассистента' }))
    expect(sent(post).find((message) => message.kind === 'ask')).toMatchObject({ ...ids, text: 'RFC 2606' })
    expect(screen.queryByRole('button', { name: 'Спросить ассистента' })).toBeNull()
  })
  it('стрелки ходят по меню инструментов, ссылка с названием копируется в markdown', async () => {
    const writeText = vi.fn(async () => undefined)
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText } })
    ready()
    const summary = screen.getByText('Инструменты ▾')
    summary.closest('details')!.open = true
    const menu = screen.getByRole('group', { name: 'Инструменты страницы' })
    const buttons = [...menu.querySelectorAll('button:not(:disabled)')] as HTMLButtonElement[]
    buttons[0].focus()
    fireEvent.keyDown(menu, { key: 'ArrowDown' })
    expect(document.activeElement).toBe(buttons[1])
    fireEvent.keyDown(menu, { key: 'End' })
    expect(document.activeElement).toBe(buttons[buttons.length - 1])
    fireEvent.click(screen.getByRole('button', { name: 'Копировать ссылку с названием' }))
    expect(writeText).toHaveBeenCalledWith('[Магазин](https://shop.example/)')
  })
  it('«Снимок страницы в чат» просит снимок у страницы и пересылает его host; редирект называется', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />); fromHost(init)
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const inner = vi.spyOn(frame.contentWindow as Window, 'postMessage')
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/landing', title: 'Магазин', icon: 'https://shop.example/favicon.ico' })
    expect(screen.getByRole('status').textContent).toContain('Перенаправлено с shop.example')
    expect((screen.getByRole('button', { name: /Магазин/ }).querySelector('img') as HTMLImageElement).src).toContain('favicon.ico')
    fireEvent.click(screen.getByRole('button', { name: 'Снимок страницы в чат' }))
    const command = inner.mock.calls.map(([message]) => message as { type?: string; requestId?: string; action?: { kind?: string } }).find((message) => message.type === PREVIEW_ACTION_COMMAND_TYPE && message.action?.kind === 'screenshot')!
    expect(command.requestId).toMatch(/^snap-/)
    fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: command.requestId, ok: true, result: { page: { url: 'https://shop.example/landing', title: 'Магазин' }, rect: { x: 0, y: 0, width: 10, height: 10 }, dataUrl: 'data:image/png;base64,AAAA' } })
    expect(sent(post).find((message) => message.kind === 'area-screenshot')).toMatchObject({ shot: { pageUrl: 'https://shop.example/landing', dataUrl: 'data:image/png;base64,AAAA' } })
  })
  it('ручной режим сообщает host control, вставка адреса открывает его сразу', () => {
    const post = vi.spyOn(window, 'postMessage')
    ready()
    fireEvent.click(screen.getByRole('button', { name: 'Только я управляю' }))
    expect(sent(post).find((message) => message.kind === 'control')).toMatchObject({ manual: true })
    fireEvent.click(screen.getByRole('button', { name: 'Вернуть ассистенту' }))
    expect(sent(post).filter((message) => message.kind === 'control').at(-1)).toMatchObject({ manual: false })
    const address = screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement
    fireEvent.change(address, { target: { value: '' } })
    fireEvent.paste(address, { clipboardData: { getData: () => 'https://pasted.example/page' } })
    expect(sent(post).find((message) => message.kind === 'save-url' && message.url === 'https://pasted.example/page')).toBeTruthy()
  })
  it('«Назад» недоступна до первого перехода внутри страницы; Escape убирает выделение; viewport уходит host', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />); fromHost(init)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/', viewport: { width: 375, height: 700 } })
    expect(sent(post).find((message) => message.kind === 'page-status' && message.status === 'ready')).toMatchObject({ viewport: { width: 375, height: 700 } })
    expect((screen.getByRole('button', { name: 'Назад' }) as HTMLButtonElement).disabled).toBe(true)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/catalog' })
    expect((screen.getByRole('button', { name: 'Назад' }) as HTMLButtonElement).disabled).toBe(false)
    fromPage({ type: 'voicechat.preview.selection.v1', text: 'RFC' })
    expect(screen.getByRole('button', { name: 'Спросить ассистента' })).toBeTruthy()
    fireEvent.keyDown(screen.getByRole('textbox', { name: 'Адрес превью' }), { key: 'Escape' })
    expect(screen.queryByRole('button', { name: 'Спросить ассистента' })).toBeNull()
  })
  it('показывает язык страницы рядом с заголовком и новые пресеты ширины', () => {
    render(<Recorder />); fromHost(init)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/', title: 'Магазин', lang: 'ru' })
    expect(screen.getByTitle('Язык страницы: ru').textContent).toBe('ru')
    const options = [...(screen.getByRole('combobox', { name: 'Ширина вьюпорта' }) as HTMLSelectElement).options].map((option) => option.value)
    expect(options).toEqual(['', '360', '375', '768', '1024', '1280'])
  })
  it('подсказки недавних адресов при вводе, «Открыть» без текста недоступна, выделение-адрес открывается', () => {
    localStorage.setItem('voicechat.reader.recent.v1', JSON.stringify(['https://shop.example/', 'https://docs.example/guide']))
    const post = vi.spyOn(window, 'postMessage')
    ready()
    const address = screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement
    fireEvent.change(address, { target: { value: '' } })
    expect((screen.getByRole('button', { name: 'Открыть' }) as HTMLButtonElement).disabled).toBe(true)
    fireEvent.focus(address)
    fireEvent.change(address, { target: { value: 'docs' } })
    const option = screen.getByRole('option', { name: 'docs.example/guide' })
    fireEvent.click(option.querySelector('button')!)
    expect(sent(post).find((message) => message.kind === 'save-url' && message.url === 'https://docs.example/guide')).toBeTruthy()
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://docs.example/guide' })
    fromPage({ type: 'voicechat.preview.selection.v1', text: 'example.org/about' })
    fireEvent.click(screen.getByRole('button', { name: 'Открыть как адрес' }))
    expect(sent(post).find((message) => message.kind === 'save-url' && message.url === 'https://example.org/about')).toBeTruthy()
  })
  it('Ctrl+F открывает поиск по странице, Alt+Shift+M — ручной режим, drop адреса открывает его', () => {
    const post = vi.spyOn(window, 'postMessage')
    ready()
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const find = vi.fn(() => true)
    Object.defineProperty(frame.contentWindow, 'find', { configurable: true, value: find })
    fireEvent.keyDown(screen.getByRole('textbox', { name: 'Адрес превью' }), { key: 'f', ctrlKey: true })
    const search = screen.getByRole('searchbox', { name: 'Найти на странице' })
    fireEvent.change(search, { target: { value: 'Домены' } })
    fireEvent.click(screen.getByRole('button', { name: 'Следующее совпадение' }))
    expect(find).toHaveBeenCalledWith('Домены', false, false, true)
    fireEvent.keyDown(screen.getByRole('textbox', { name: 'Адрес превью' }), { key: 'm', altKey: true, shiftKey: true })
    expect(sent(post).find((message) => message.kind === 'control')).toMatchObject({ manual: true })
    fireEvent.drop(screen.getByRole('region', { name: 'Web Reader' }), { dataTransfer: { types: ['text/uri-list'], getData: (type: string) => type === 'text/uri-list' ? 'https://dropped.example/page\n' : '' } })
    expect(sent(post).find((message) => message.kind === 'save-url' && message.url === 'https://dropped.example/page')).toBeTruthy()
  })
  it('показывает время чтения из outline, масштабирует страницу и листает подсказки стрелками', () => {
    localStorage.setItem('voicechat.reader.recent.v1', JSON.stringify(['https://shop.example/', 'https://docs.example/guide', 'https://docs.example/api']))
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />); fromHost(init)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/', title: 'Магазин', outline: { headings: ['Магазин'], links: 2, buttons: 1, inputs: 0, words: 1000 } })
    expect(screen.getByTitle('Примерное время чтения').textContent).toBe('~5 мин')
    fireEvent.click(screen.getByRole('button', { name: 'Увеличить текст' }))
    expect(screen.getByRole('group', { name: 'Масштаб страницы' }).textContent).toContain('110%')
    const address = screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement
    fireEvent.focus(address)
    fireEvent.change(address, { target: { value: 'docs' } })
    fireEvent.keyDown(address, { key: 'ArrowDown' })
    fireEvent.keyDown(address, { key: 'ArrowDown' })
    fireEvent.keyDown(address, { key: 'Enter' })
    expect(sent(post).find((message) => message.kind === 'save-url' && message.url === 'https://docs.example/api')).toBeTruthy()
  })
  it('чтение отвечает сразу, а ошибка клика не ждёт навигацию', () => {
    const post = vi.spyOn(window, 'postMessage')
    ready()
    fromHost({ type, ...ids, kind: 'command', requestId: 'r1', action: { kind: 'read' } })
    fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: 'r1', ok: true, result: { page: { url: 'https://shop.example/', title: 'Магазин' }, headings: [], links: [], buttons: [], inputs: [], text: '' } })
    expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'r1')).toBeTruthy()
    fromHost({ type, ...ids, kind: 'command', requestId: 'c3', action: { kind: 'click', text: 'Нет' } })
    fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: 'c3', ok: false, error: 'Элемент не найден' })
    expect(sent(post).find((message) => message.kind === 'result' && message.requestId === 'c3')).toMatchObject({ ok: false, error: 'Элемент не найден' })
  })
  it('показывает заголовок страницы и недавние адреса; чип открывает адрес и сохраняет его', () => {
    const post = vi.spyOn(window, 'postMessage')
    ready()
    expect(screen.getByRole('button', { name: /Магазин/ })).toBeTruthy()
    fromHost({ type, ...ids, kind: 'set-url', url: null })
    const chip = screen.getByRole('button', { name: 'Продолжить: shop.example' })
    expect(screen.getByRole('navigation', { name: 'Недавние адреса' }).contains(chip)).toBe(true)
    post.mockClear()
    fireEvent.click(chip)
    expect(sent(post).find((message) => message.kind === 'save-url')).toMatchObject({ url: 'https://shop.example/' })
    expect((screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement).value).toBe('https://shop.example/')
  })
  it('Alt+стрелки листают историю страницы, чип ширины сбрасывает viewport', () => {
    ready()
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const back = vi.spyOn(frame.contentWindow!.history, 'back').mockImplementation(() => {})
    fireEvent.keyDown(screen.getByRole('textbox', { name: 'Адрес превью' }), { key: 'ArrowLeft', altKey: true })
    expect(back).toHaveBeenCalledOnce()
    fireEvent.change(screen.getByRole('combobox', { name: 'Ширина вьюпорта' }), { target: { value: '375' } })
    fireEvent.click(screen.getByRole('button', { name: 'Сбросить ширину 375 px' }))
    expect((screen.getByRole('combobox', { name: 'Ширина вьюпорта' }) as HTMLSelectElement).value).toBe('')
  })
})

describe('Recorder: подтверждённый адрес навигации', () => {
  it('обновляет адрес без замены или перезагрузки живого iframe', () => {
    render(<Recorder />); fromHost(init)
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const src = frame.src
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/next#/tab' })
    expect((screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement).value).toBe('https://shop.example/next#/tab')
    expect(screen.getByTitle('Предпросмотр сайта')).toBe(frame)
    expect(frame.src).toBe(src)
  })
  it('не затирает незавершённый ввод адреса приходящим ready', () => {
    render(<Recorder />); fromHost(init)
    fireEvent.change(screen.getByRole('textbox', { name: 'Адрес превью' }), { target: { value: 'https://draft.example/' } })
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/next' })
    expect((screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement).value).toBe('https://draft.example/')
  })
  it('принимает старый ready с URL прокси как логический адрес сайта', () => {
    render(<Recorder />); fromHost(init)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: window.location.origin + '/api/preview?url=' + encodeURIComponent('https://shop.example/new') + '#section' })
    expect((screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement).value).toBe('https://shop.example/new#section')
  })
  it('восстанавливает режимы записи и инспектора после новой загрузки', () => {
    render(<Recorder />); fromHost(init)
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const post = vi.spyOn(frame.contentWindow!, 'postMessage')
    fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    fromHost({ type, ...ids, kind: 'inspector-state', enabled: true })
    post.mockClear()
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/next' })
    expect(post).toHaveBeenCalledWith({ type: 'voicechat.preview.record.v1', enabled: true }, window.location.origin)
    expect(post).toHaveBeenCalledWith({ type: PREVIEW_INSPECTOR_COMMAND_TYPE, enabled: true }, window.location.origin)
  })
  it('не сохраняет не-HTTP адрес от страницы', () => {
    const post = vi.spyOn(window, 'postMessage')
    render(<Recorder />); fromHost(init); post.mockClear()
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'javascript:alert(1)' })
    expect(sent(post).find(message => message.kind === 'page-status')).toMatchObject({ url: 'https://shop.example/' })
  })
})

describe('Reader: адрес и состояния загрузки', () => {
  it('адрес без схемы открывается и сохраняется как HTTPS', () => {
    const post = vi.spyOn(window, 'postMessage'); render(<Recorder />); fromHost({ ...init, previewUrl: null })
    fireEvent.change(screen.getByRole('textbox', { name: 'Адрес превью' }), { target: { value: 'gmail.com' } })
    fireEvent.click(screen.getByRole('button', { name: 'Открыть' }))
    expect(sent(post)).toContainEqual(expect.objectContaining({ kind: 'save-url', url: 'https://gmail.com/' }))
  })
  it('относительный путь разрешается от текущей подтверждённой страницы', () => {
    render(<Recorder />); fromHost(init); fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/catalog/page' })
    fireEvent.change(screen.getByRole('textbox', { name: 'Адрес превью' }), { target: { value: '../next' } })
    fireEvent.click(screen.getByRole('button', { name: 'Открыть' }))
    expect((screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement).getAttribute('src')).toBe('/api/preview?url=' + encodeURIComponent('https://shop.example/next'))
  })
  it('обновление использует живой адрес после SPA-перехода', () => {
    render(<Recorder />); fromHost(init); const old = screen.getByTitle('Предпросмотр сайта')
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/new#/tab' })
    fireEvent.click(screen.getByRole('button', { name: 'Обновить страницу' }))
    const next = screen.getByTitle('Предпросмотр сайта'); expect(next).not.toBe(old)
    expect(next.getAttribute('src')).toBe('/api/preview?url=' + encodeURIComponent('https://shop.example/new#/tab'))
  })
  it('индикатор загрузки исчезает после ready', () => {
    render(<Recorder />); fromHost(init); expect(screen.getByRole('status').textContent).toContain('Загружаем')
    fromPage({ type: PREVIEW_PAGE_READY_TYPE }); expect(screen.queryByText('Загружаем страницу…')).toBeNull()
  })
  it('ошибка ответа видна пользователю и host; повтор создаёт новую загрузку', async () => {
    const post = vi.spyOn(window, 'postMessage'); render(<Recorder />); fromHost(init)
    const old = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const document = old.contentDocument!; document.open(); document.write('{"message":"Сайт не ответил"}'); document.close(); fireEvent.load(old)
    expect((await screen.findByRole('alert')).textContent).toContain('Сайт не ответил')
    expect(sent(post)).toContainEqual(expect.objectContaining({ kind: 'page-status', status: 'error' }))
    fireEvent.click(screen.getByRole('button', { name: 'Повторить загрузку' }))
    expect(screen.getByTitle('Предпросмотр сайта')).not.toBe(old); expect(screen.queryByRole('alert')).toBeNull()
  })
  it('зависшая загрузка завершается сообщением, таймеры очищаются при unmount', () => {
    vi.useFakeTimers()
    try {
      const view = render(<Recorder />); fromHost(init)
      act(() => { vi.advanceTimersByTime(12_000) })
      expect(screen.getByRole('alert').textContent).toContain('время ожидания')
      view.unmount(); act(() => { vi.advanceTimersByTime(10) }); expect(vi.getTimerCount()).toBe(0)
      const next = render(<Recorder />); fromHost(init); next.unmount(); act(() => { vi.advanceTimersByTime(10) }); expect(vi.getTimerCount()).toBe(0)
    } finally { vi.useRealTimers() }
  })
  it('отложенный onLoad старого iframe не сообщает ошибку нового адреса', () => {
    vi.useFakeTimers()
    try {
      render(<Recorder />); fromHost(init); fireEvent.load(screen.getByTitle('Предпросмотр сайта'))
      fromHost({ type, ...ids, kind: 'set-url', url: 'https://new.example/' })
      act(() => { vi.advanceTimersByTime(100) }); expect(screen.queryByRole('alert')).toBeNull()
    } finally { vi.useRealTimers() }
  })
})
describe('Reader: инструменты и viewport', () => {
  it('редактирование, выбор и захват не остаются активными одновременно', () => {
    render(<Recorder />); fromHost(init)
    const inspect = screen.getByRole('button', { name: '⌖ Выбор элемента', hidden: true }), edit = screen.getByRole('button', { name: '✎ Редактировать', hidden: true }), capture = screen.getByRole('button', { name: '📸 Область', hidden: true })
    fireEvent.click(inspect); expect(inspect.getAttribute('aria-pressed')).toBe('true')
    fireEvent.click(edit); expect(inspect.getAttribute('aria-pressed')).toBe('false'); expect(edit.getAttribute('aria-pressed')).toBe('true')
    fireEvent.click(capture); expect(edit.getAttribute('aria-pressed')).toBe('false'); expect(capture.getAttribute('aria-pressed')).toBe('true')
  })
  it('Escape закрывает меню, возвращает фокус и выключает интерактивный режим', () => {
    render(<Recorder />); fromHost(init)
    const summary = screen.getByLabelText('Инструменты страницы', { selector: 'summary' }), details = summary.parentElement as HTMLDetailsElement
    fromHost({ type, ...ids, kind: 'inspector-state', enabled: true }); details.open = true
    fireEvent.keyDown(window, { key: 'Escape' })
    expect(details.open).toBe(false); expect(document.activeElement).toBe(summary)
    expect(screen.getByRole('button', { name: '⌖ Выбор элемента', hidden: true }).getAttribute('aria-pressed')).toBe('false')
  })
  it('клик за пределами меню закрывает его', () => {
    render(<Recorder />); const details = document.querySelector('details')!; details.open = true
    fireEvent.pointerDown(screen.getByRole('textbox', { name: 'Адрес превью' })); expect(details.open).toBe(false)
  })
  it('широкий viewport не получает max-width, сжимающий тестовую страницу', () => {
    render(<Recorder />); fromHost(init); fromHost({ type, ...ids, kind: 'command', requestId: 'wide', action: { kind: 'viewport', width: 1024 } })
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    expect(frame.style.width).toBe('1024px'); expect(frame.style.minWidth).toBe('1024px'); expect(frame.style.maxWidth).toBe('')
    expect(frame.parentElement?.className).toBe('webpreview-viewport')
  })
})


describe('Recorder управляемое воспроизведение', () => {
  const seed = () => {
    localStorage.setItem('voicechat.reader.scenario.v1:https://shop.example/', JSON.stringify([
      { kind: 'click', selector: '#one', text: '', sensitive: false },
      { kind: 'type', selector: '#two', text: '', sensitive: true }
    ]))
    render(<Recorder />); fromHost(init); fromPage({ type: PREVIEW_PAGE_READY_TYPE })
    return vi.spyOn((screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement).contentWindow as Window, 'postMessage')
  }
  it('проверяет последний секрет до выполнения первого шага', async () => {
    const inner = seed(); fireEvent.click(screen.getByRole('button', { name: 'Запустить' }))
    await screen.findByText(/Шаг 2: введите секретное/)
    expect(inner.mock.calls.filter(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)).toHaveLength(0)
  })
  it('блокирует повторный запуск и редактирование, но даёт остановить', async () => {
    const inner = seed(); fireEvent.change(screen.getByLabelText('Секретное значение шага 2'), { target: { value: 'temporary' } })
    fireEvent.click(screen.getByRole('button', { name: 'Запустить' }))
    await waitFor(() => expect(inner.mock.calls.some(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)).toBe(true))
    expect((screen.getByRole('button', { name: 'Запустить' }) as HTMLButtonElement).disabled).toBe(true)
    expect((screen.getByLabelText('Селектор шага 1') as HTMLInputElement).disabled).toBe(true)
    fireEvent.click(screen.getByRole('button', { name: 'Остановить сценарий' }))
    await screen.findByText(/Сценарий остановлен/)
    expect((screen.getByLabelText('Секретное значение шага 2') as HTMLInputElement).value).toBe('')
  })
  it('показывает ошибку шага и не отправляет следующий', async () => {
    const inner = seed(); fireEvent.change(screen.getByLabelText('Секретное значение шага 2'), { target: { value: 'temporary' } })
    fireEvent.click(screen.getByRole('button', { name: 'Запустить' }))
    await waitFor(() => expect(inner.mock.calls.some(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)).toBe(true))
    const command = inner.mock.calls.find(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)![0]
    fromPage({ type: PREVIEW_ACTION_RESULT_TYPE, requestId: command.requestId, ok: false, error: 'missing' })
    await screen.findByText(/Шаг 1: missing/)
    expect(inner.mock.calls.filter(([m]) => m.type === PREVIEW_ACTION_COMMAND_TYPE)).toHaveLength(1)
  })
  it('отмена при set-url не ждёт таймаута', async () => {
    seed(); fireEvent.change(screen.getByLabelText('Секретное значение шага 2'), { target: { value: 'temporary' } })
    fireEvent.click(screen.getByRole('button', { name: 'Запустить' }))
    fromHost({ type, ...ids, kind: 'set-url', url: null })
    await screen.findByText(/Открывается другая страница/)
  })
  it('воспроизведение не записывает само себя и не смешивает команды модели', async () => {
    const host = vi.spyOn(window, 'postMessage'); seed()
    fireEvent.change(screen.getByLabelText('Секретное значение шага 2'), { target: { value: 'temporary' } })
    fireEvent.click(screen.getByRole('button', { name: 'Запустить' }))
    fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    fromPage({ type: 'voicechat.preview.record.v1', step: { kind: 'click', selector: '#self', text: '', sensitive: false } })
    expect(screen.queryByLabelText('Селектор шага 3')).toBeNull()
    fromHost({ type, ...ids, kind: 'command', requestId: 'model-during-run', action: { kind: 'click', selector: '#other' } })
    expect(sent(host)).toContainEqual(expect.objectContaining({ kind: 'result', requestId: 'model-during-run', ok: false }))
  })
})


it('старый onLoad не объявляет ошибкой новый медленный переход', async () => {
  vi.useFakeTimers()
  render(<Recorder />); fromHost(init)
  fireEvent.load(screen.getByTitle('Предпросмотр сайта'))
  fromPage({ type: 'voicechat.preview.page-loading.v1' })
  await act(async () => { await vi.advanceTimersByTimeAsync(150) })
  expect(screen.queryByRole('alert')).toBeNull()
  fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/next' })
  cleanup(); vi.useRealTimers()
})


describe('Recorder управление записанным сценарием', () => {
  const step = { kind: 'type', selector: '#field', text: 'value', sensitive: false }
  const record = (value: object) => fromPage({ type: 'voicechat.preview.record.v1', step: value })
  it('игнорирует запись при выключенном режиме', () => {
    render(<Recorder />); fromHost(init); record(step)
    expect(screen.queryByLabelText('Селектор шага 1')).toBeNull()
    fromHost({ type, ...ids, kind: 'recording-state', enabled: true }); record(step)
    expect(screen.getByLabelText('Селектор шага 1')).toBeTruthy()
    fromHost({ type, ...ids, kind: 'recording-state', enabled: false }); record({ ...step, selector: '#other' })
    expect(screen.queryByLabelText('Селектор шага 2')).toBeNull()
  })
  it('склеивает посимвольный ввод одного поля', () => {
    render(<Recorder />); fromHost(init); fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    for (const text of ['А', 'Ан', 'Анна']) record({ ...step, text })
    expect(screen.queryByLabelText('Селектор шага 2')).toBeNull()
    expect((screen.getByLabelText('Значение шага 1') as HTMLInputElement).value).toBe('Анна')
  })
  it('ручная отметка секрета очищает исходный текст в состоянии и storage', async () => {
    render(<Recorder />); fromHost(init); fromHost({ type, ...ids, kind: 'recording-state', enabled: true }); record({ ...step, text: 'manually-secret' })
    fireEvent.click(screen.getByLabelText('Секрет шага 1'))
    expect(screen.queryByLabelText('Значение шага 1')).toBeNull()
    expect((screen.getByLabelText('Секретное значение шага 1') as HTMLInputElement).value).toBe('')
    await waitFor(() => expect(Object.values(localStorage).join('')).not.toContain('manually-secret'))
  })
  it('удаляет и переставляет шаги без переноса секретов к другим полям', () => {
    render(<Recorder />); fromHost(init); fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
    record(step); record({ ...step, selector: '#secret', sensitive: true })
    fireEvent.change(screen.getByLabelText('Секретное значение шага 2'), { target: { value: 'temporary' } })
    fireEvent.click(screen.getByLabelText('Поднять шаг 2'))
    expect((screen.getByLabelText('Селектор шага 1') as HTMLInputElement).value).toBe('#secret')
    expect((screen.getByLabelText('Секретное значение шага 1') as HTMLInputElement).value).toBe('')
    fireEvent.click(screen.getByLabelText('Удалить шаг 1'))
    expect((screen.getByLabelText('Селектор шага 1') as HTMLInputElement).value).toBe('#field')
    expect(screen.queryByLabelText('Селектор шага 2')).toBeNull()
  })
  it('очищенный перенесённый сценарий не восстанавливается из legacy', () => {
    localStorage.setItem('voicechat.reader.scenario.v1:https://shop.example/', JSON.stringify([step]))
    const view = render(<Recorder />); fromHost(init)
    fireEvent.click(screen.getByRole('button', { name: 'Очистить' })); view.unmount()
    render(<Recorder />); fromHost(init)
    expect(screen.queryByLabelText('Селектор шага 1')).toBeNull()
  })
})


it('SPA-навигация выбирает сценарий нового hash без reload iframe', () => {
  localStorage.setItem('voicechat.reader.scenario.v2:https://shop.example/#/next', JSON.stringify([{ kind: 'click', selector: '#next', text: '', sensitive: false }]))
  render(<Recorder />); fromHost(init); fromPage({ type: PREVIEW_PAGE_READY_TYPE })
  const frame = screen.getByTitle('Предпросмотр сайта')
  fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/#/next' })
  expect(screen.getByTitle('Предпросмотр сайта')).toBe(frame)
  expect((screen.getByLabelText('Селектор шага 1') as HTMLInputElement).value).toBe('#next')
})
it('запись сохраняет исходный адрес сценария при переходе', () => {
  render(<Recorder />); fromHost(init); fromPage({ type: PREVIEW_PAGE_READY_TYPE })
  fromHost({ type, ...ids, kind: 'recording-state', enabled: true })
  fromPage({ type: 'voicechat.preview.record.v1', step: { kind: 'click', selector: '#go', text: '', sensitive: false } })
  fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/#/next' })
  expect((screen.getByLabelText('Селектор шага 1') as HTMLInputElement).value).toBe('#go')
  expect(localStorage.getItem('voicechat.reader.scenario.v2:https://shop.example/')).toContain('#go')
  expect(localStorage.getItem('voicechat.reader.scenario.v2:https://shop.example/#/next')).toBeNull()
})


describe('текущее приложение в Reader', () => {
  it('кнопка проекта работает из пустой панели', () => {
    render(<Recorder />); fromHost({ ...init, previewUrl: null })
    fireEvent.click(screen.getByRole('button', { name: 'Текущий проект' }))
    expect((screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement).src).toContain(encodeURIComponent('https://app.internal/'))
  })
  it('адрес host из команды сохраняет deep link на постоянном origin', () => {
    render(<Recorder />); fromHost({ ...init, previewUrl: window.location.origin + '/#/machines' })
    expect((screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement).src).toContain(encodeURIComponent('https://app.internal/#/machines'))
  })
})

describe('Recorder: поведение мобильного браузера (круг 16)', () => {
  const ready = (url = 'https://shop.example/', title = 'Магазин') => fromPage({ type: PREVIEW_PAGE_READY_TYPE, url, title })
  const start = () => { render(<Recorder />); fromHost(init); ready() }
  it('ссылка под курсором показывается строкой состояния с пометками «другой сайт» и «новая вкладка»', () => {
    start()
    fromPage({ type: 'voicechat.preview.link.v1', href: 'https://other.example/docs', text: 'Документация', newTab: true, longPress: false })
    const bar = screen.getByRole('status', { name: '' , hidden: true })
    expect(bar.textContent).toContain('https://other.example/docs'); expect(bar.textContent).toContain('другой сайт'); expect(bar.textContent).toContain('новая вкладка')
    fromPage({ type: 'voicechat.preview.link.v1', href: '', text: '', newTab: false, longPress: false })
    expect(screen.queryByText(/other\.example\/docs/)).toBeNull()
  })
  it('долгое нажатие на ссылку открывает её меню: открыть, скопировать, спросить ассистента', async () => {
    const writeText = vi.fn(async () => undefined)
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText } })
    const post = vi.spyOn(window, 'postMessage')
    start()
    fromPage({ type: 'voicechat.preview.link.v1', href: 'https://shop.example/sale', text: 'Распродажа', newTab: false, longPress: true })
    fireEvent.click(screen.getByRole('button', { name: 'Копировать ссылку' }))
    expect(writeText).toHaveBeenCalledWith('https://shop.example/sale')
    fromPage({ type: 'voicechat.preview.link.v1', href: 'https://shop.example/sale', text: 'Распродажа', newTab: false, longPress: true })
    fireEvent.click(screen.getByRole('button', { name: 'Спросить о ссылке' }))
    expect(sent(post).at(-1)).toMatchObject({ kind: 'ask', text: expect.stringContaining('https://shop.example/sale') })
    fromPage({ type: 'voicechat.preview.link.v1', href: 'https://shop.example/sale', text: 'Распродажа', newTab: false, longPress: true })
    fireEvent.click(screen.getByRole('button', { name: 'Открыть ссылку' }))
    expect(sent(post).filter(message => message.kind === 'save-url').at(-1)).toMatchObject({ url: 'https://shop.example/sale' })
    expect(screen.queryByRole('button', { name: 'Открыть ссылку' })).toBeNull()
  })
  it('свайп от края внутри страницы ведёт назад только когда есть куда', () => {
    start()
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const back = vi.spyOn(frame.contentWindow!.history, 'back').mockImplementation(() => undefined)
    fromPage({ type: 'voicechat.preview.gesture.v1', gesture: 'back' })
    expect(back).not.toHaveBeenCalled()
    ready('https://shop.example/catalog', 'Каталог')
    fromPage({ type: 'voicechat.preview.gesture.v1', gesture: 'back' })
    expect(back).toHaveBeenCalledTimes(1)
  })
  it('режим чтения уходит странице сообщением и переживает загрузку следующей страницы', () => {
    start()
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const inner = vi.spyOn(frame.contentWindow as Window, 'postMessage')
    const toggle = screen.getByRole('button', { name: 'Режим чтения', hidden: true })
    fireEvent.click(toggle)
    expect(inner.mock.calls.map(([message]) => message as Record<string, unknown>).filter(message => message.type === 'voicechat.preview.reader.v1').at(-1)).toMatchObject({ enabled: true })
    expect(screen.getByRole('button', { name: 'Обычный вид', hidden: true }).getAttribute('aria-pressed')).toBe('true')
    inner.mockClear()
    ready('https://shop.example/catalog', 'Каталог')
    expect(inner.mock.calls.map(([message]) => message as Record<string, unknown>).filter(message => message.type === 'voicechat.preview.reader.v1').at(-1)).toMatchObject({ enabled: true })
  })
  it('«Клавиши» показывает шпаргалку сочетаний панели', () => {
    start()
    fireEvent.click(screen.getByRole('button', { name: 'Клавиши', hidden: true }))
    const sheet = screen.getByLabelText('Клавиши панели')
    expect(sheet.textContent).toContain('Ctrl/Cmd+L'); expect(sheet.textContent).toContain('Alt+Shift+M')
    fireEvent.click(screen.getByRole('button', { name: 'Скрыть клавиши' }))
    expect(screen.queryByLabelText('Клавиши панели')).toBeNull()
  })
  it('правый клик по «Назад» показывает историю вкладки, выбор открывает страницу', () => {
    const post = vi.spyOn(window, 'postMessage')
    start()
    ready('https://shop.example/catalog', 'Каталог')
    fireEvent.contextMenu(screen.getByRole('group', { name: 'История' }))
    const list = screen.getByRole('listbox', { name: 'История этой вкладки' })
    expect(list.textContent).toContain('Каталог'); expect(list.textContent).toContain('Магазин')
    fireEvent.click(screen.getByRole('button', { name: /Магазин/ }))
    expect(sent(post).filter(message => message.kind === 'save-url').at(-1)).toMatchObject({ url: 'https://shop.example/' })
    expect(screen.queryByRole('listbox', { name: 'История этой вкладки' })).toBeNull()
  })
  it('масштаб текста запоминается по сайту и возвращается с его страницей', () => {
    localStorage.setItem('voicechat.reader.zoom.v1', JSON.stringify({ 'shop.example': 120 }))
    start()
    expect(screen.getByText('120%')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: 'Увеличить текст', hidden: true }))
    expect(JSON.parse(localStorage.getItem('voicechat.reader.zoom.v1')!)).toEqual({ 'shop.example': 130 })
    ready('https://docs.example/', 'Документы')
    expect(screen.getByText('100%')).toBeTruthy()
  })
  it('на телефоне панель прячется при чтении вниз и возвращается при прокрутке вверх; после полутора экранов есть «К началу»', () => {
    const original = window.matchMedia
    Object.defineProperty(window, 'matchMedia', { configurable: true, writable: true, value: (query: string) => ({ matches: query.includes('560'), media: query, addEventListener: () => undefined, removeEventListener: () => undefined }) })
    try {
      start()
      const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
      const win = frame.contentWindow!
      let top = 0
      // jsdom's iframe document has no layout: hand the Reader a scrolling element with the geometry of a long page.
      Object.defineProperty(win.document, 'scrollingElement', { configurable: true, value: { get scrollTop() { return top }, scrollHeight: 4000 } })
      Object.defineProperty(win, 'innerHeight', { configurable: true, value: 600 })
      const scrollTo = (next: number): void => { top = next; act(() => { win.dispatchEvent(new Event('scroll')) }) }
      scrollTo(300)
      expect(screen.getByRole('button', { name: 'Показать панель' })).toBeTruthy()
      expect(screen.queryByRole('button', { name: 'К началу страницы' })).toBeNull()
      scrollTo(1200)
      expect(screen.getByRole('button', { name: 'К началу страницы' })).toBeTruthy()
      scrollTo(1100)
      expect(screen.queryByRole('button', { name: 'Показать панель' })).toBeNull()
      scrollTo(1300)
      fireEvent.click(screen.getByRole('button', { name: 'Показать панель' }))
      expect(screen.queryByRole('button', { name: 'Показать панель' })).toBeNull()
    } finally {
      if (original) Object.defineProperty(window, 'matchMedia', { configurable: true, writable: true, value: original }); else delete (window as { matchMedia?: unknown }).matchMedia
    }
  })
  it('на телефоне адресная строка показывает только сайт, а в фокусе — полный адрес', () => {
    const original = window.matchMedia
    Object.defineProperty(window, 'matchMedia', { configurable: true, writable: true, value: (query: string) => ({ matches: query.includes('560'), media: query, addEventListener: () => undefined, removeEventListener: () => undefined }) })
    try {
      start()
      const address = screen.getByRole('textbox', { name: 'Адрес превью' }) as HTMLInputElement
      expect(address.value).toBe('shop.example')
      fireEvent.focus(address)
      expect(address.value).toBe('https://shop.example/')
    } finally {
      if (original) Object.defineProperty(window, 'matchMedia', { configurable: true, writable: true, value: original }); else delete (window as { matchMedia?: unknown }).matchMedia
    }
  })
})

describe('Recorder: ориентиры страницы и поиск по сайту (круг 17)', () => {
  const nav = {
    breadcrumbs: [{ text: 'Главная', href: 'https://shop.example/' }, { text: 'Наушники' }],
    pagination: { next: 'https://shop.example/list?page=3', prev: 'https://shop.example/list?page=1', label: '2' },
    published: { date: '2026-09-01', author: 'Редакция' },
    search: '#site-q'
  }
  const ready = (extra: object = {}) => fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/list?page=2', title: 'Наушники', nav, ...extra })
  const start = () => { render(<Recorder />); fromHost(init); ready() }
  const pageMessages = () => {
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    return vi.spyOn(frame.contentWindow as Window, 'postMessage')
  }
  it('показывает путь по сайту, и клик по крошке открывает раздел', () => {
    const post = vi.spyOn(window, 'postMessage')
    start()
    const crumbs = screen.getByRole('navigation', { name: 'Путь по сайту' })
    expect(crumbs.textContent).toContain('Главная'); expect(crumbs.textContent).toContain('Наушники')
    fireEvent.click(screen.getByRole('button', { name: 'Главная' }))
    expect(sent(post).filter(message => message.kind === 'save-url').at(-1)).toMatchObject({ url: 'https://shop.example/' })
  })
  it('листалка открывает соседние страницы кнопками и Alt+Shift+стрелками', () => {
    const post = vi.spyOn(window, 'postMessage')
    start()
    const pager = screen.getByRole('group', { name: 'Страницы' })
    expect(pager.textContent).toContain('2')
    fireEvent.click(screen.getByRole('button', { name: 'Дальше →' }))
    expect(sent(post).filter(message => message.kind === 'save-url').at(-1)).toMatchObject({ url: 'https://shop.example/list?page=3' })
    ready()
    fireEvent.keyDown(screen.getByRole('region', { name: 'Web Reader' }) ?? document.body, { key: 'ArrowLeft', altKey: true, shiftKey: true })
    expect(sent(post).filter(message => message.kind === 'save-url').at(-1)).toMatchObject({ url: 'https://shop.example/list?page=1' })
  })
  it('дата, автор и номер страницы стоят рядом с названием', () => {
    start()
    const title = screen.getByRole('button', { name: /Скопировать ссылку/ })
    expect(title.textContent).toContain('2026-09-01'); expect(title.textContent).toContain('Редакция'); expect(title.textContent).toContain('стр. 2')
  })
  it('«Искать на сайте» отправляет запрос в поле поиска самой страницы', () => {
    start()
    const inner = pageMessages()
    fireEvent.change(screen.getByRole('searchbox', { name: 'Искать на сайте' }), { target: { value: 'наушники' } })
    fireEvent.click(screen.getByRole('button', { name: 'Искать' }))
    expect(inner.mock.calls.map(([message]) => message as { action?: { kind?: string; text?: string } }).find(message => message.action?.kind === 'search')?.action).toMatchObject({ kind: 'search', text: 'наушники' })
  })
  it('клавиша «/» ставит курсор в поле поиска сайта, но не мешает печатать в панели', () => {
    start()
    const inner = pageMessages()
    fireEvent.keyDown(screen.getByRole('region', { name: 'Web Reader' }), { key: '/' })
    expect(inner.mock.calls.map(([message]) => message as { action?: { kind?: string; selector?: string } }).find(message => message.action?.kind === 'focus')?.action).toMatchObject({ kind: 'focus', selector: '#site-q' })
    inner.mockClear()
    fireEvent.keyDown(screen.getByRole('textbox', { name: 'Адрес превью' }), { key: '/' })
    expect(inner.mock.calls.some(([message]) => (message as { action?: { kind?: string } }).action?.kind === 'focus')).toBe(false)
  })
  it('выделение ассистента подписано, выделение человека — нет', () => {
    start()
    fromPage({ type: 'voicechat.preview.selection.v1', text: 'Важное условие', by: 'assistant' })
    expect(screen.getByText('Ассистент выделил')).toBeTruthy()
    fromPage({ type: 'voicechat.preview.selection.v1', text: 'Другое место', by: 'user' })
    expect(screen.queryByText('Ассистент выделил')).toBeNull()
  })
  it('возврат на страницу этого сеанса восстанавливает место чтения', () => {
    start()
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const win = frame.contentWindow!
    let top = 0
    const scrollTo = vi.fn((options: { top?: number } | number) => { top = typeof options === 'number' ? options : options.top ?? 0 })
    Object.defineProperty(win, 'scrollTo', { configurable: true, value: scrollTo })
    Object.defineProperty(win.document, 'scrollingElement', { configurable: true, value: { get scrollTop() { return top }, scrollHeight: 4000 } })
    Object.defineProperty(win, 'innerHeight', { configurable: true, value: 600 })
    top = 900
    act(() => { win.dispatchEvent(new Event('scroll')) })
    fromHost({ type, ...ids, kind: 'set-url', url: 'https://shop.example/other' })
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/other', title: 'Другая' })
    scrollTo.mockClear()
    // Каждый переход пересоздаёт iframe, поэтому место чтения проверяем на окне новой страницы.
    fromHost({ type, ...ids, kind: 'set-url', url: 'https://shop.example/list?page=2' })
    const returned = (screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement).contentWindow!
    const restore = vi.fn()
    Object.defineProperty(returned, 'scrollTo', { configurable: true, value: restore })
    Object.defineProperty(returned.document, 'scrollingElement', { configurable: true, value: { scrollTop: 0, scrollHeight: 4000 } })
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://shop.example/list?page=2', title: 'Наушники', nav })
    expect(restore).toHaveBeenCalledWith({ top: 900 })
  })
})

describe('Recorder: длинная страница и оглавление (круг 18)', () => {
  const nav = {
    breadcrumbs: [],
    toc: [{ level: 1, text: 'Инструкция', selector: '#t' }, { level: 2, text: 'Доставка', selector: '#a' }, { level: 2, text: 'Оплата', selector: '#b' }]
  }
  const start = () => {
    render(<Recorder />); fromHost(init)
    fromPage({ type: PREVIEW_PAGE_READY_TYPE, url: 'https://docs.example/guide', title: 'Инструкция', nav, outline: { headings: [], links: 0, buttons: 0, inputs: 0, words: 4000 } })
  }
  const pageMessages = () => {
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    return vi.spyOn(frame.contentWindow as Window, 'postMessage')
  }
  it('оглавление раскрывается и прокручивает страницу к выбранному заголовку', () => {
    start()
    const inner = pageMessages()
    fireEvent.click(screen.getByRole('button', { name: 'Оглавление (3)' }))
    const toc = screen.getByRole('navigation', { name: 'Оглавление страницы' })
    expect(toc.textContent).toContain('Доставка')
    fireEvent.click(screen.getByRole('button', { name: 'Оплата' }))
    expect(inner.mock.calls.map(([message]) => message as { action?: { kind?: string; selector?: string; to?: string } }).find(message => message.action?.kind === 'scroll')?.action)
      .toMatchObject({ kind: 'scroll', to: 'element', selector: '#b' })
  })
  it('Escape закрывает оглавление и возвращает фокус на кнопку', () => {
    start()
    const toggle = screen.getByRole('button', { name: 'Оглавление (3)' })
    fireEvent.click(toggle)
    fireEvent.keyDown(screen.getByRole('region', { name: 'Web Reader' }), { key: 'Escape' })
    expect(screen.queryByRole('navigation', { name: 'Оглавление страницы' })).toBeNull()
    expect(document.activeElement).toBe(toggle)
  })
  it('«Листать до…» просит страницу пролистать ленту до текста', () => {
    start()
    const inner = pageMessages()
    fireEvent.change(screen.getByRole('searchbox', { name: 'Листать до текста' }), { target: { value: 'Отзывы' } })
    fireEvent.click(screen.getByRole('button', { name: 'Листать' }))
    expect(inner.mock.calls.map(([message]) => message as { action?: { kind?: string; until?: string } }).find(message => message.action?.until)?.action)
      .toMatchObject({ kind: 'scroll', until: 'Отзывы' })
  })
  it('полоса чтения говорит, сколько прочитано и сколько осталось', () => {
    start()
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const win = frame.contentWindow!
    let top = 0
    Object.defineProperty(win.document, 'scrollingElement', { configurable: true, value: { get scrollTop() { return top }, scrollHeight: 4000 } })
    Object.defineProperty(win, 'innerHeight', { configurable: true, value: 600 })
    top = 1700
    act(() => { win.dispatchEvent(new Event('scroll')) })
    const bar = screen.getByRole('progressbar', { name: 'Прочитано страницы' })
    expect(bar.getAttribute('aria-valuetext')).toContain('Прочитано 50%')
    expect(bar.getAttribute('aria-valuetext')).toContain('осталось около 10 мин')
    expect(screen.getByTitle('Примерное время чтения').textContent).toContain('осталось ~10 мин')
  })
  it('Alt+End прокручивает страницу в конец', () => {
    start()
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    const win = frame.contentWindow!
    const scrollTo = vi.fn()
    Object.defineProperty(win, 'scrollTo', { configurable: true, value: scrollTo })
    Object.defineProperty(win.document, 'scrollingElement', { configurable: true, value: { scrollTop: 0, scrollHeight: 5000 } })
    fireEvent.keyDown(screen.getByRole('region', { name: 'Web Reader' }), { key: 'End', altKey: true })
    expect(scrollTo).toHaveBeenCalledWith({ top: 5000, behavior: 'smooth' })
  })
  it('«Копировать текст страницы» кладёт видимый текст в буфер', () => {
    const writeText = vi.fn(async () => undefined)
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText } })
    start()
    const frame = screen.getByTitle('Предпросмотр сайта') as HTMLIFrameElement
    // В jsdom у документа iframe нет body до записи, а innerText не реализован — подставляем оба.
    Object.defineProperty(frame, 'contentDocument', { configurable: true, value: { body: { innerText: 'Текст длинной страницы' } } })
    fireEvent.click(screen.getByRole('button', { name: 'Копировать текст страницы', hidden: true }))
    expect(writeText).toHaveBeenCalledWith('Текст длинной страницы')
  })
})
