import { fileURLToPath } from 'node:url'
import { createComponentRuntime } from '@sislexa/component-runtime'
// У Reader нет подключения к БД: авторизацию, права и машины проверяет владелец данных — ядро.
import { existsSync } from 'node:fs'
import Fastify from 'fastify'
import fastifyStatic from '@fastify/static'
import { applicationRuntimeMetadata } from '@voicechat/shared'
import { HttpReaderCore, READER_HEALTH_PATH, type ReaderCore } from '@voicechat/web-reader-contracts'
import { createRemotePlaywrightReader, type PlaywrightReaderService } from '@voicechat/playwright-reader-contracts'
import { createReaderModule } from '../module.js'
import { registerForwardedAuth } from './auth.js'
import type { WebReaderConfig } from './config.js'

export interface BuildReaderServerOptions {
  config: WebReaderConfig
  core?: ReaderCore
  browser?: PlaywrightReaderService
  fetchImpl?: typeof fetch
  logger?: boolean
}
export type ReaderServer = Awaited<ReturnType<typeof buildReaderServer>>
export async function buildReaderServer(opts: BuildReaderServerOptions) {
  const config = { ...opts.config }
  if (!config.componentConfigPath && !config.internalToken) throw new Error('Web Reader требует VC_INTERNAL_TOKEN (тот же, что у ядра)')
  if (!config.mcpSecret) throw new Error('Web Reader требует VC_MCP_SECRET (тот же, что у ядра)')
  const app = Fastify({ logger: opts.logger ?? false })
  const component = config.componentConfigPath ? await createComponentRuntime({
    contractFile: fileURLToPath(new URL('../../component-contract.json', import.meta.url)),
    configFile: config.componentConfigPath, metadata: applicationRuntimeMetadata('web-reader', process.env), fetchImpl: opts.fetchImpl,
  }) : undefined
  component?.register(app)
  const coreDependency = component?.dependency('core')
  if (coreDependency) { config.coreUrl = coreDependency.url; config.internalToken = coreDependency.token }
  const fetchImpl = coreDependency?.fetchImpl ?? opts.fetchImpl ?? fetch
  const browserDependency = component?.dependency('playwright-reader')
  if (browserDependency) config.playwrightReaderUrl = browserDependency.url
  const core = opts.core ?? new HttpReaderCore({ coreUrl: config.coreUrl, token: config.internalToken, fetchImpl })
  const browser = opts.browser ?? createRemotePlaywrightReader({ baseUrl: config.playwrightReaderUrl, token: browserDependency?.token ?? config.internalToken, fetchImpl: browserDependency?.fetchImpl ?? opts.fetchImpl })
  registerForwardedAuth(app, { coreUrl: config.coreUrl, token: config.internalToken, fetchImpl })
  createReaderModule({ app, core, browser, mcpSecret: config.mcpSecret })
  // Прокси ядра сохраняет origin postMessage и cookie. Артефакт рекордера обновляется с Web Reader.
  if (existsSync(config.webRecorderDir)) await app.register(fastifyStatic, { root: config.webRecorderDir, prefix: '/web-recorder/', decorateReply: false, cacheControl: false })
  app.get(READER_HEALTH_PATH, async () => ({ ok: true, service: 'web-reader', version: config.version, application: applicationRuntimeMetadata('web-reader', process.env) }))
  return { app, core }
}
