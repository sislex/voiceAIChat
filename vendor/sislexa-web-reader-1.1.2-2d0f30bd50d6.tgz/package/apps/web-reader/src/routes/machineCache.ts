// Короткий кэш ответов машины для прокси превью.
//
// Зачем: Storybook в dev-режиме отдаёт сотни отдельных ESM-модулей, и каждый идёт
// до машины пользователя через WebSocket агента. На проде один `iframe.html` шёл
// 5,6 секунды — при таком RTT кадр не успевает собраться, часть запросов упирается
// в таймаут моста. Модули между запросами не меняются, поэтому повторные обращения
// (смена стори, перезагрузка кадра) берём из памяти.
//
// Кэшируем осознанно узко: только GET, только успех, только статические типы и
// небольшие тела. HTML не кэшируем никогда — в него инъецируются шимы и он зависит
// от сессии.

export interface CachedMachineResponse {
  status: number
  headers: Record<string, string | string[]>
  body: Buffer
  /** Валидатор для браузера: считается от уже переписанного тела. */
  etag: string
}

/** Что не изменится за минуту: модули, стили, карты, шрифты, картинки. */
const CACHEABLE_TYPE = /javascript|ecmascript|text\/css|font|image\//i
const MAX_ENTRY_BYTES = 2 * 1024 * 1024
const MAX_TOTAL_BYTES = 64 * 1024 * 1024
const TTL_MS = 60_000

export function isCacheableMachineResponse(method: string, status: number, type: string, size: number): boolean {
  if (method !== 'GET') return false
  if (status !== 200) return false
  if (size > MAX_ENTRY_BYTES) return false
  // HTML — только через полный путь: там инъекция шимов и контекст сессии.
  if (/text\/html|xhtml/i.test(type)) return false
  return CACHEABLE_TYPE.test(type)
}

interface Entry extends CachedMachineResponse {
  expiresAt: number
  bytes: number
}

/**
 * Кэш живёт в памяти процесса и намеренно мал: он снимает повторные round-trip,
 * а не заменяет CDN. Ключ включает машину и пользователя — авторизованные ответы не смешиваются.
 */
export class MachineResponseCache {
  private readonly entries = new Map<string, Entry>()
  private bytes = 0

  constructor(private readonly now: () => number = Date.now, private readonly ttlMs: number = TTL_MS) {}

  private static key(agentId: string, url: string, userId = ''): string {
    return `${agentId}\0${userId}\0${url}`
  }

  get(agentId: string, url: string, userId = ''): CachedMachineResponse | null {
    const key = MachineResponseCache.key(agentId, url, userId)
    const entry = this.entries.get(key)
    if (!entry) return null
    if (entry.expiresAt <= this.now()) {
      this.entries.delete(key)
      this.bytes -= entry.bytes
      return null
    }
    // Свежее использование — в конец: Map хранит порядок вставки, и вытеснение
    // сносит самые давние записи.
    this.entries.delete(key)
    this.entries.set(key, entry)
    return { status: entry.status, headers: entry.headers, body: entry.body, etag: entry.etag }
  }

  put(agentId: string, url: string, value: CachedMachineResponse, userId = ''): void {
    const bytes = value.body.length
    if (bytes > MAX_ENTRY_BYTES) return
    const key = MachineResponseCache.key(agentId, url, userId)
    const existing = this.entries.get(key)
    if (existing) this.bytes -= existing.bytes
    this.entries.set(key, { ...value, bytes, expiresAt: this.now() + this.ttlMs })
    this.bytes += bytes
    while (this.bytes > MAX_TOTAL_BYTES) {
      const oldest = this.entries.keys().next()
      if (oldest.done) break
      const victim = this.entries.get(oldest.value)!
      this.entries.delete(oldest.value)
      this.bytes -= victim.bytes
    }
  }

  /** Забыть всё по машине: она могла перезапустить dev-сервер с другим кодом. */
  dropAgent(agentId: string): void {
    for (const [key, entry] of this.entries) {
      if (!key.startsWith(`${agentId}\0`)) continue
      this.entries.delete(key)
      this.bytes -= entry.bytes
    }
  }

  get size(): number {
    return this.entries.size
  }
}
