import { afterEach, describe, expect, it, vi } from 'vitest'
import { act, cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { WEB_RECORDER_MESSAGE_TYPE, WEB_RECORDER_PROTOCOL_VERSION } from '@shared/webRecorder'
import { WebReaderFrame, type WebReaderFramePlatform } from './WebReaderFrame'
import type { ReaderHostRegistration } from './hostBridge'

const type = WEB_RECORDER_MESSAGE_TYPE
const readyMessage = { type, kind: 'ready', protocolVersion: WEB_RECORDER_PROTOCOL_VERSION, conversationId: null, registrationId: null, capabilities: ['read'] }
const platform: WebReaderFramePlatform = {
  origin: window.location.origin,
  subscribeMessages: (listener) => {
    window.addEventListener('message', listener)
    return () => window.removeEventListener('message', listener)
  }
}

function frameEl(): HTMLIFrameElement {
  return screen.getByTitle('Web Reader') as HTMLIFrameElement
}
function emit(data: object, overrides: { origin?: string; source?: MessageEventSource | null } = {}): void {
  fireEvent(window, new MessageEvent('message', {
    origin: overrides.origin ?? window.location.origin,
    source: overrides.source === undefined ? frameEl().contentWindow : overrides.source,
    data
  }))
}

afterEach(() => cleanup())

describe('WebReaderFrame', () => {
  it('показывает неудачу действия ассистента с кнопкой повтора и секунды долгого действия', () => {
    vi.useFakeTimers()
    try {
      const onSave = vi.fn(async () => undefined), onRetryAction = vi.fn()
      const { rerender } = render(<WebReaderFrame platform={platform} conversationId="conv-fail" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} actionError={{ action: { kind: 'click', text: 'Купить' }, error: 'Элемент не найден' }} onRetryAction={onRetryAction} />)
      expect(screen.getByText(/Ассистент не смог: нажимает Купить — Элемент не найден/)).toBeTruthy()
      fireEvent.click(screen.getByRole('button', { name: 'Повторить' }))
      expect(onRetryAction).toHaveBeenCalledWith({ kind: 'click', text: 'Купить' })
      rerender(<WebReaderFrame platform={platform} conversationId="conv-fail" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} pendingAction={{ kind: 'read' }} />)
      act(() => { vi.advanceTimersByTime(3500) })
      expect(screen.getByRole('status').textContent).toContain('3 с')
    } finally { vi.useRealTimers() }
  })
  it('живая строка показывает шаг последовательности', async () => {
    let registration: ReaderHostRegistration | null = null
    const onSave = vi.fn(async () => undefined)
    render(<WebReaderFrame platform={platform} conversationId="conv-seq" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} onRegisterHost={(r) => { registration = r }} pendingAction={{ kind: 'sequence', steps: [{ kind: 'click', text: 'Войти' }, { kind: 'read' }] }} />)
    const post = vi.spyOn(frameEl().contentWindow as Window, 'postMessage')
    emit(readyMessage)
    await waitFor(() => expect(registration).toBeTruthy())
    emit({ type, conversationId: 'conv-seq', registrationId: registration!.registrationId, kind: 'page-status', status: 'ready', url: 'https://shop.example/' })
    void registration!.run({ kind: 'sequence', steps: [{ kind: 'click', text: 'Войти' }, { kind: 'read' }] })
    await waitFor(() => expect(screen.getByRole('status').textContent).toContain('шаг 1 из 2: нажимает Войти'))
    expect(post).toHaveBeenCalled()
  })
  it('закладки сеанса видны человеку: «Запомнить страницу» кладёт, крестик убирает (круг 18)', async () => {
    let registration: ReaderHostRegistration | null = null
    const onSave = vi.fn(async () => undefined)
    render(<WebReaderFrame platform={platform} conversationId="conv-marks" conversationUrl="https://docs.example/guide" projectUrl={null} onSave={onSave} onPageTitle={() => undefined} onRegisterHost={(r) => { registration = r }} />)
    emit(readyMessage)
    await waitFor(() => expect(registration).toBeTruthy())
    emit({ type, conversationId: 'conv-marks', registrationId: registration!.registrationId, kind: 'page-status', status: 'ready', url: 'https://docs.example/guide', title: 'Руководство' })
    fireEvent.click(screen.getByRole('button', { name: 'Запомнить страницу' }))
    const marks = await screen.findByRole('navigation', { name: 'Закладки страницы' })
    expect(marks.textContent).toContain('Руководство')
    fireEvent.click(screen.getByRole('button', { name: 'Убрать закладку Руководство' }))
    await waitFor(() => expect(screen.queryByRole('navigation', { name: 'Закладки страницы' })).toBeNull())
  })
  it('вопрос ассистента отвечается кнопкой, полем и Escape; передача шага ждёт «Готово» (круг 19)', async () => {
    let registration: ReaderHostRegistration | null = null
    const onSave = vi.fn(async () => undefined)
    render(<WebReaderFrame platform={platform} conversationId="conv-ask" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} onRegisterHost={(r) => { registration = r }} />)
    emit(readyMessage)
    await waitFor(() => expect(registration).toBeTruthy())
    const quick = registration!.run({ kind: 'question', question: 'Какой размер брать?', options: ['M', 'L'] })
    const card = await screen.findByRole('group', { name: 'Вопрос ассистента' })
    expect(card.textContent).toContain('Какой размер брать?')
    expect(document.activeElement).toBe(screen.getByRole('textbox', { name: 'Ответ ассистенту' }))
    fireEvent.click(screen.getByRole('button', { name: 'L' }))
    await expect(quick).resolves.toMatchObject({ ok: true, result: { answer: 'L', answered: true } })
    const typed = registration!.run({ kind: 'question', question: 'Адрес доставки?' })
    await screen.findByRole('group', { name: 'Вопрос ассистента' })
    fireEvent.change(screen.getByRole('textbox', { name: 'Ответ ассистенту' }), { target: { value: 'Ленина 1' } })
    fireEvent.click(screen.getByRole('button', { name: 'Ответить' }))
    await expect(typed).resolves.toMatchObject({ ok: true, result: { answer: 'Ленина 1' } })
    const skipped = registration!.run({ kind: 'question', question: 'Продолжаем?' })
    await screen.findByRole('group', { name: 'Вопрос ассистента' })
    fireEvent.keyDown(screen.getByRole('textbox', { name: 'Ответ ассистенту' }), { key: 'Escape' })
    await expect(skipped).resolves.toMatchObject({ ok: true, result: { answered: false } })
    const handed = registration!.run({ kind: 'handover', reason: 'войдите в аккаунт' })
    expect((await screen.findByText(/Ассистент ждёт вас/)).textContent).toContain('войдите в аккаунт')
    expect(screen.queryByText(/ждёт \d+ с/)).toBeNull()
    fireEvent.click(screen.getByRole('button', { name: 'Готово, продолжай' }))
    await expect(handed).resolves.toMatchObject({ ok: true, result: { returned: true } })
    await waitFor(() => expect(screen.queryByRole('group', { name: 'Вопрос ассистента' })).toBeNull())
  })
  it('заметки ассистента видны человеку, а отчёт собирается текстом и копируется (круг 20)', async () => {
    let registration: ReaderHostRegistration | null = null
    const writeText = vi.fn(async () => undefined)
    Object.defineProperty(navigator, 'clipboard', { configurable: true, value: { writeText } })
    const onSave = vi.fn(async () => undefined), onAsk = vi.fn()
    render(<WebReaderFrame platform={platform} conversationId="conv-note" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} onAsk={onAsk} onRegisterHost={(r) => { registration = r }} actions={[{ id: 'a', action: { kind: 'read' }, address: 'https://shop.example/', title: 'Магазин' }]} />)
    emit(readyMessage)
    await waitFor(() => expect(registration).toBeTruthy())
    emit({ type, conversationId: 'conv-note', registrationId: registration!.registrationId, kind: 'page-status', status: 'ready', url: 'https://shop.example/', title: 'Магазин' })
    await registration!.run({ kind: 'note', text: 'Цена без доставки' })
    const notes = await screen.findByRole('region', { name: 'Заметки ассистента' })
    expect(notes.textContent).toContain('Цена без доставки')
    fireEvent.click(screen.getByRole('button', { name: 'Скопировать отчёт' }))
    await waitFor(() => expect(writeText).toHaveBeenCalledWith(expect.stringContaining('Сеанс Web Reader')))
    expect((await screen.findByLabelText('Текст отчёта')).textContent).toContain('Заметка: Цена без доставки')
    fireEvent.click(screen.getByRole('button', { name: 'Отчёт в чат' }))
    await waitFor(() => expect(onAsk).toHaveBeenCalledWith(expect.stringContaining('Сеанс Web Reader')))
    fireEvent.click(screen.getByRole('button', { name: 'Скрыть отчёт' }))
    expect(screen.queryByLabelText('Текст отчёта')).toBeNull()
  })
  it('показывает запрос подтверждения опасного действия с кнопками разрешить и отказать', () => {
    const onSave = vi.fn(async () => undefined), onConfirmAction = vi.fn(), onDenyAction = vi.fn()
    render(<WebReaderFrame platform={platform} conversationId="conv-confirm" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} confirmRequest={{ action: { kind: 'click', text: 'Оплатить' }, reason: 'оплата или перевод', target: 'Оплатить' }} onConfirmAction={onConfirmAction} onDenyAction={onDenyAction} />)
    expect(screen.getByRole('alertdialog').textContent).toContain('нажимает Оплатить')
    fireEvent.click(screen.getByRole('button', { name: 'Разрешить' }))
    expect(onConfirmAction).toHaveBeenCalledWith({ kind: 'click', text: 'Оплатить', confirm: true })
    fireEvent.click(screen.getByRole('button', { name: 'Отказать' }))
    expect(onDenyAction).toHaveBeenCalled()
  })
  it('ошибку страницы можно скрыть; новая ошибка появляется снова', () => {
    const onSave = vi.fn(async () => undefined)
    const { rerender } = render(<WebReaderFrame platform={platform} conversationId="conv-err" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} pageError="TypeError: boom" />)
    expect(screen.getByRole('alert').textContent).toContain('boom')
    fireEvent.click(screen.getByRole('button', { name: 'Скрыть ошибку страницы' }))
    expect(screen.queryByRole('alert')).toBeNull()
    rerender(<WebReaderFrame platform={platform} conversationId="conv-err" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} pageError="ReferenceError: other" />)
    expect(screen.getByRole('alert').textContent).toContain('other')
  })
  it('показывает живой статус выполняемого действия ассистента', () => {
    const onSave = vi.fn(async () => undefined)
    const { rerender } = render(<WebReaderFrame platform={platform} conversationId="conv-live" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} pendingAction={{ kind: 'click', text: 'Купить' }} />)
    expect(screen.getByRole('status', { name: '' }).textContent).toContain('Ассистент нажимает Купить')
    rerender(<WebReaderFrame platform={platform} conversationId="conv-live" conversationUrl="https://shop.example/" projectUrl={null} onSave={onSave} pendingAction={null} />)
    expect(screen.queryByText(/Ассистент нажимает/)).toBeNull()
  })

  // @testCase TC3
  it('восстанавливает сохранённый публичный URL беседы с hash, не подменяя его адресом проекта', async () => {
    const saved = 'http://89.125.68.35:8787/#/chat/81caab96-6d29-4054-a5bd-8da334caaf79'
    const onSave = vi.fn(async () => undefined)
    render(<WebReaderFrame platform={platform} conversationId="conv-restored" conversationUrl={saved} projectUrl="http://agent-1.machine.internal:5173/" onSave={onSave} />)
    const post = vi.spyOn(frameEl().contentWindow as Window, 'postMessage')
    emit(readyMessage)
    await waitFor(() => expect(post).toHaveBeenCalledWith(expect.objectContaining({ kind: 'init', previewUrl: saved }), platform.origin))
    expect(onSave).not.toHaveBeenCalled()
  })

  it('после handshake регистрирует host и отвечает init на том же origin', async () => {
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>()
    render(<WebReaderFrame platform={platform} conversationId="conv-1" conversationUrl="https://shop.example/" projectUrl={null} onSave={vi.fn()} onRegisterHost={register} />)
    const post = vi.spyOn(frameEl().contentWindow as Window, 'postMessage')
    emit(readyMessage)
    await waitFor(() => expect(register).toHaveBeenCalled())
    const registration = register.mock.calls.at(-1)?.[0]!
    expect(registration).toMatchObject({ conversationId: 'conv-1', registrationId: expect.any(String) })
    const [init, target] = post.mock.calls.find(([message]) => (message as { kind?: string }).kind === 'init')!
    expect(init).toMatchObject({ conversationId: 'conv-1', registrationId: registration.registrationId, previewUrl: 'https://shop.example/' })
    expect(target).toBe(window.location.origin)
  })

  it('игнорирует ready с чужим origin и от чужого окна', () => {
    const register = vi.fn()
    render(<WebReaderFrame platform={platform} conversationId="conv-1" conversationUrl={null} projectUrl={null} onSave={vi.fn()} onRegisterHost={register} />)
    emit(readyMessage, { origin: 'https://evil.test' })
    emit(readyMessage, { source: window })
    expect(register).not.toHaveBeenCalled()
  })

  it('не передаёт целевой URL до успешного выпуска preview-cookie', async () => {
    let release: (ok: boolean) => void = () => undefined
    const ensurePreview = vi.fn(() => new Promise<boolean>((resolve) => { release = resolve }))
    render(<WebReaderFrame platform={platform} conversationId="conv-1" conversationUrl="https://shop.example/" projectUrl={null} ensurePreview={ensurePreview} onSave={vi.fn()} />)
    const post = vi.spyOn(frameEl().contentWindow as Window, 'postMessage')
    emit(readyMessage)
    expect(screen.getByRole('status')).toHaveTextContent('Подключение Web Preview')
    expect(post.mock.calls.some(([m]) => (m as { previewUrl?: string; url?: string }).previewUrl === 'https://shop.example/' || (m as { url?: string }).url === 'https://shop.example/')).toBe(false)
    release(true)
    await waitFor(() => expect(post.mock.calls.some(([m]) => (m as { kind?: string; url?: string }).kind === 'set-url' && (m as { url?: string }).url === 'https://shop.example/')).toBe(true))
    expect(ensurePreview).toHaveBeenCalledTimes(1)
  })

  it('отказ ensurePreview показывает ошибку, «Повторить» выпускает cookie заново', async () => {
    const ensurePreview = vi.fn()
      .mockRejectedValueOnce(new Error('network'))
      .mockResolvedValueOnce(true)
    render(<WebReaderFrame platform={platform} conversationId="conv-1" conversationUrl={null} projectUrl="https://project.example/" ensurePreview={ensurePreview} onSave={vi.fn()} />)
    const post = vi.spyOn(frameEl().contentWindow as Window, 'postMessage')
    emit(readyMessage)
    await waitFor(() => expect(screen.getByRole('alert')).toHaveTextContent('Не удалось подготовить'))
    expect(post.mock.calls.some(([m]) => (m as { url?: string }).url === 'https://project.example/')).toBe(false)
    await userEvent.click(screen.getByRole('button', { name: 'Повторить' }))
    await waitFor(() => expect(post.mock.calls.some(([m]) => (m as { kind?: string; url?: string }).kind === 'set-url' && (m as { url?: string }).url === 'https://project.example/')).toBe(true))
    expect(ensurePreview).toHaveBeenCalledTimes(2)
  })

  it('save-url и element-selected доходят только с актуальными ID', async () => {
    const onSave = vi.fn(async () => undefined)
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>()
    render(<WebReaderFrame platform={platform} conversationId="conv-1" conversationUrl={null} projectUrl={null} onSave={onSave} onRegisterHost={register} />)
    emit(readyMessage)
    await waitFor(() => expect(register).toHaveBeenCalled())
    const { registrationId } = register.mock.calls.at(-1)?.[0]!
    emit({ type, kind: 'save-url', conversationId: 'conv-1', registrationId: 'stale', url: 'https://old.example/' })
    expect(onSave).not.toHaveBeenCalled()
    emit({ type, kind: 'save-url', conversationId: 'conv-1', registrationId, url: 'https://new.example/' })
    await waitFor(() => expect(onSave).toHaveBeenCalledWith('https://new.example/'))
  })

  it('показывает понятную ленту действий и позволяет повторить шаг', async () => {
    const repeat = vi.fn()
    render(<WebReaderFrame platform={platform} conversationId="conv-1" conversationUrl={null} projectUrl={null} onSave={vi.fn()} actions={[{ id: 'a1', action: { kind: 'click', text: 'Купить' }, address: null, title: null }]} onRepeatAction={repeat} />)
    expect(screen.getByRole('region', { name: 'Действия ассистента' })).toHaveTextContent('Нажал Купить')
    await userEvent.click(screen.getByRole('button', { name: 'Повторить действие 1: Нажал Купить' }))
    expect(repeat).toHaveBeenCalledWith({ kind: 'click', text: 'Купить' })
  })

  it('размонтирование dispose-ит мост: регистрация снимается, pending закрывается', async () => {
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>()
    const view = render(<WebReaderFrame platform={platform} conversationId="conv-1" conversationUrl={null} projectUrl={null} onSave={vi.fn()} onRegisterHost={register} />)
    emit(readyMessage)
    await waitFor(() => expect(register).toHaveBeenCalled())
    const registration = register.mock.calls.at(-1)?.[0]!
    const pending = registration.run({ kind: 'open', url: 'https://shop.example/' })
    view.unmount()
    await expect(pending).resolves.toMatchObject({ ok: false, error: expect.stringContaining('закрыта') })
    expect(register.mock.calls.at(-1)?.[0]).toBeNull()
  })
})

describe('WebReaderFrame: эхо сохранённого адреса', () => {
  it('сохранение навигации не запускает cookie-гейт и set-url снова', async () => {
    const ensurePreview = vi.fn(async () => true)
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>()
    const onSave = vi.fn(async () => undefined)
    const props = { platform, conversationId: 'navigation', conversationUrl: 'https://shop.example/', projectUrl: null, ensurePreview, onSave, onRegisterHost: register }
    const view = render(<WebReaderFrame {...props} />)
    const original = frameEl()
    const post = vi.spyOn(original.contentWindow!, 'postMessage')
    emit(readyMessage)
    await waitFor(() => expect(post).toHaveBeenCalledWith(expect.objectContaining({ kind: 'set-url', url: props.conversationUrl }), platform.origin))
    const registrationId = register.mock.calls.at(-1)![0]!.registrationId
    emit({ type, kind: 'page-status', conversationId: 'navigation', registrationId, status: 'ready', url: 'https://shop.example/next' })
    await waitFor(() => expect(onSave).toHaveBeenCalledWith('https://shop.example/next'))
    post.mockClear()
    view.rerender(<WebReaderFrame {...props} conversationUrl="https://shop.example/next" />)
    await waitFor(() => expect(ensurePreview).toHaveBeenCalledTimes(1))
    expect(post.mock.calls.filter(([message]) => (message as { kind?: string }).kind === 'set-url')).toHaveLength(0)
    expect(frameEl()).toBe(original)
  })
  it('новый внешний адрес продолжает проходить cookie-гейт', async () => {
    const ensurePreview = vi.fn(async () => true)
    const props = { platform, conversationId: 'external', conversationUrl: 'https://shop.example/', projectUrl: null, ensurePreview, onSave: vi.fn(async () => undefined) }
    const view = render(<WebReaderFrame {...props} />)
    await waitFor(() => expect(ensurePreview).toHaveBeenCalledTimes(1))
    view.rerender(<WebReaderFrame {...props} conversationUrl="https://other.example/" />)
    await waitFor(() => expect(ensurePreview).toHaveBeenCalledTimes(2))
  })
})

describe('WebReaderFrame: открытие моделью и сохранение', () => {
  it('open из пустой панели ждёт cookie, сохраняет только подтверждённый конечный адрес', async () => {
    let release!: (ok: boolean) => void
    const ensurePreview = vi.fn(() => new Promise<boolean>(resolve => { release = resolve }))
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>(), save = vi.fn(async () => {})
    render(<WebReaderFrame platform={platform} conversationId="model" conversationUrl={null} projectUrl={null} ensurePreview={ensurePreview} onSave={save} onRegisterHost={register} />)
    const post = vi.spyOn(frameEl().contentWindow!, 'postMessage'); emit(readyMessage)
    const registration = register.mock.calls.at(-1)![0]!
    const pending = registration.run({ kind: 'open', url: 'https://first.test/' })
    await waitFor(() => expect(ensurePreview).toHaveBeenCalledOnce())
    expect(save).not.toHaveBeenCalled(); expect(post.mock.calls.some(([m]) => (m as { url?: string }).url === 'https://first.test/')).toBe(false)
    release(true)
    await waitFor(() => expect(post.mock.calls.filter(([m]) => (m as { url?: string }).url === 'https://first.test/')).toHaveLength(1))
    emit({ type, conversationId: 'model', registrationId: registration.registrationId, kind: 'page-status', status: 'ready', url: 'https://final.test/' })
    await expect(pending).resolves.toMatchObject({ ok: true, result: { url: 'https://final.test/' } })
    expect(save).toHaveBeenCalledTimes(1); expect(save).toHaveBeenCalledWith('https://final.test/')
  })
  it('отказ cookie модели виден даже у пустой страницы и повторяет тот же open', async () => {
    const ensurePreview = vi.fn().mockResolvedValueOnce(false).mockResolvedValueOnce(true)
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>(), save = vi.fn(async () => {})
    render(<WebReaderFrame platform={platform} conversationId="model" conversationUrl={null} projectUrl={null} ensurePreview={ensurePreview} onSave={save} onRegisterHost={register} />)
    const post = vi.spyOn(frameEl().contentWindow!, 'postMessage'); emit(readyMessage)
    const registration = register.mock.calls.at(-1)![0]!
    await expect(registration.run({ kind: 'open', url: 'https://retry.test/' })).resolves.toMatchObject({ ok: false })
    expect(await screen.findByRole('alert')).toHaveTextContent('Не удалось подготовить')
    expect(save).not.toHaveBeenCalled()
    await userEvent.click(screen.getByRole('button', { name: 'Повторить' }))
    await waitFor(() => expect(post).toHaveBeenCalledWith(expect.objectContaining({ kind: 'set-url', url: 'https://retry.test/' }), platform.origin))
    emit({ type, conversationId: 'model', registrationId: registration.registrationId, kind: 'page-status', status: 'ready', url: 'https://retry.test/' })
    await waitFor(() => expect(save).toHaveBeenCalledWith('https://retry.test/'))
  })
  it('не сохраняет адрес страницы, которая вернула ошибку загрузки', async () => {
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>(), save = vi.fn(async () => {})
    render(<WebReaderFrame platform={platform} conversationId="model" conversationUrl={null} projectUrl={null} onSave={save} onRegisterHost={register} />)
    emit(readyMessage); const registration = register.mock.calls.at(-1)![0]!
    const pending = registration.run({ kind: 'open', url: 'https://broken.test/' })
    emit({ type, conversationId: 'model', registrationId: registration.registrationId, kind: 'page-status', status: 'error', url: 'https://broken.test/', error: 'offline' })
    await expect(pending).resolves.toMatchObject({ ok: false }); expect(save).not.toHaveBeenCalled()
  })
  it('ошибка сохранения видна и повторяется без перезагрузки страницы', async () => {
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>()
    const save = vi.fn().mockRejectedValueOnce(new Error('offline')).mockResolvedValueOnce(undefined)
    render(<WebReaderFrame platform={platform} conversationId="model" conversationUrl={null} projectUrl={null} onSave={save} onRegisterHost={register} />)
    const post = vi.spyOn(frameEl().contentWindow!, 'postMessage'); emit(readyMessage)
    const registration = register.mock.calls.at(-1)![0]!
    emit({ type, conversationId: 'model', registrationId: registration.registrationId, kind: 'save-url', url: 'https://save.test/' })
    expect(await screen.findByRole('alert')).toHaveTextContent('адрес не удалось сохранить'); post.mockClear()
    await userEvent.click(screen.getByRole('button', { name: 'Повторить сохранение' }))
    await waitFor(() => expect(save).toHaveBeenCalledTimes(2)); expect(post).not.toHaveBeenCalled()
    await waitFor(() => expect(screen.queryByRole('alert')).toBeNull())
  })
  it('быстрые сохранения идут последовательно и с исходным callback разговора', async () => {
    let release!: () => void
    const save = vi.fn().mockImplementationOnce(() => new Promise<void>(resolve => { release = resolve })).mockResolvedValue(undefined)
    const register = vi.fn<(registration: ReaderHostRegistration | null) => void>()
    const props = { platform, conversationId: 'model', conversationUrl: null, projectUrl: null, onSave: save, onRegisterHost: register }
    const view = render(<WebReaderFrame {...props} />); emit(readyMessage)
    const registrationId = register.mock.calls.at(-1)![0]!.registrationId
    emit({ type, conversationId: 'model', registrationId, kind: 'save-url', url: 'https://first.test/' })
    await waitFor(() => expect(save).toHaveBeenCalledTimes(1))
    emit({ type, conversationId: 'model', registrationId, kind: 'save-url', url: 'https://second.test/' })
    const newer = vi.fn(async () => {}); view.rerender(<WebReaderFrame {...props} onSave={newer} />)
    expect(save).toHaveBeenCalledTimes(1); release()
    await waitFor(() => expect(save).toHaveBeenCalledTimes(2)); expect(newer).not.toHaveBeenCalled()
    expect(save.mock.calls.map(call => call[0])).toEqual(['https://first.test/', 'https://second.test/'])
  })
})
