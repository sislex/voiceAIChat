export type ApiTokenAccess = 'full' | 'read'

export interface ApiTokenInfo {
  sid: string
  user: string
  name: string
  createdAt: number
  expiresAt: number
  lastSeen: number
  access: ApiTokenAccess
}

export interface ApiTokenCreateRequest {
  name: string
  ttlDays?: number
  access?: ApiTokenAccess
}

export interface ApiTokenCreateResponse {
  token: string
  item: ApiTokenInfo
}

export const API_TOKENS_PATH = '/api/session/api-tokens'
export const apiTokenPath = (sid: string): string => `${API_TOKENS_PATH}/${encodeURIComponent(sid)}`

export interface ApiTokensClient {
  list(user?: string): Promise<ApiTokenInfo[]>
  create(input: ApiTokenCreateRequest, user?: string): Promise<ApiTokenCreateResponse>
  revoke(sid: string, user?: string): Promise<void>
}
