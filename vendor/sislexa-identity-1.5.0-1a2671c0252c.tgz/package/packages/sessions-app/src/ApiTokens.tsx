import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { Button } from '@voicechat/ui-kit'
import type { ApiTokenAccess } from '../../contracts/src/apiTokens.js'
import type { SessionsStore } from './store/sessionsStore'
import type { SessionsTexts } from './texts'
import type { SessionsConfirm } from './SessionsPanel'

export function ApiTokens({ store, texts, locale, confirm, readOnly }: {
  store: SessionsStore; texts: SessionsTexts; locale: string; confirm?: SessionsConfirm; readOnly: boolean
}): JSX.Element {
  const state = useSyncExternalStore(store.subscribe, store.getState, store.getState)
  const [name, setName] = useState('')
  const [ttlDays, setTtlDays] = useState(365)
  const [access, setAccess] = useState<ApiTokenAccess>('full')
  const [secret, setSecret] = useState<string | null>(null)
  const [copyStatus, setCopyStatus] = useState('')
  const [pending, setPending] = useState<string | null>(null)
  const mounted = useRef(false)
  useEffect(() => {
    mounted.current = true
    void store.actions.listApiTokens()
    return () => { mounted.current = false }
  }, [store])
  const date = (at: number): string => at ? new Date(at).toLocaleString(locale) : texts.tokenNever
  const revoke = async (sid: string): Promise<void> => {
    setSecret(null)
    await store.actions.revokeApiToken(sid)
    setPending(null)
  }
  return <section className="vcs-tokens" aria-label={texts.tokensTitle}>
    <h2>{texts.tokensTitle}</h2>
    {state.apiTokensError && <p role="alert">{texts.tokensError}</p>}
    <Button size="sm" type="button" disabled={state.apiTokensBusy} onClick={() => void store.actions.listApiTokens()}>{texts.refresh}</Button>
    {state.apiTokensBusy && <p>{texts.loading}</p>}
    <div className="vcs-tokens-table"><table>
      <caption>{texts.tokensTitle}</caption>
      <thead><tr>{[texts.tokenName, texts.tokenCreated, texts.tokenExpires, texts.tokenUsed, texts.tokenAccess, texts.tokenActions].map(label => <th key={label} scope="col">{label}</th>)}</tr></thead>
      <tbody>{state.apiTokens.map(item => <tr key={item.sid}>
        <th scope="row">{item.name}</th><td>{date(item.createdAt)}</td><td>{date(item.expiresAt)}</td><td>{date(item.lastSeen)}</td>
        <td><span className="vcs-badge">{item.access === 'read' ? texts.tokenRead : texts.tokenFull}</span></td>
        <td>{!readOnly && <Button size="sm" type="button" disabled={state.apiTokensBusy} onClick={async () => {
          if (confirm) { if (await confirm({ title: texts.tokenConfirm, text: item.name, variant: 'danger' })) await revoke(item.sid) }
          else setPending(item.sid)
        }}>{texts.tokenRevoke}</Button>}</td>
      </tr>)}</tbody>
    </table></div>
    {!state.apiTokensBusy && !state.apiTokens.length && <p>{texts.tokensEmpty}</p>}
    {pending && <div role="group" aria-label={texts.tokenConfirm}>
      <p>{texts.tokenConfirm}</p>
      <Button size="sm" type="button" disabled={state.apiTokensBusy} onClick={() => void revoke(pending)}>{texts.tokenConfirm}</Button>
      <Button size="sm" type="button" onClick={() => setPending(null)}>{texts.renameCancel}</Button>
    </div>}
    {!readOnly && <form onSubmit={async event => {
      event.preventDefault()
      setSecret(null); setCopyStatus('')
      const result = await store.actions.createApiToken({ name: name.trim(), ttlDays, access })
      if (result && mounted.current) { setSecret(result.token); setName('') }
    }}>
      <label>{texts.tokenName}<input className="vcs-input" required maxLength={80} value={name} onChange={event => setName(event.target.value)} /></label>
      <label>{texts.tokenTtl}<select className="vcs-input" value={ttlDays} onChange={event => setTtlDays(Number(event.target.value))}>
        {[30, 90, 365, 3650].map(days => <option key={days} value={days}>{texts.tokenDays(days)}</option>)}
      </select></label>
      <label>{texts.tokenAccess}<select className="vcs-input" value={access} onChange={event => setAccess(event.target.value as ApiTokenAccess)}>
        <option value="full">{texts.tokenFull}</option><option value="read">{texts.tokenRead}</option>
      </select></label>
      <Button size="sm" type="submit" disabled={state.apiTokensBusy || !name.trim()}>{texts.tokenCreate}</Button>
    </form>}
    {secret && <div role="group" aria-label={texts.tokenReveal}>
      <p>{texts.tokenWarning}</p><code className="vcs-token-secret">{secret}</code>
      <Button size="sm" type="button" disabled={!store.capabilities.copy} onClick={async () => setCopyStatus(await store.actions.copyApiToken(secret) ? texts.tokenCopied : texts.tokenCopyError)}>{texts.tokenCopy}</Button>
      <Button size="sm" type="button" onClick={() => { setSecret(null); setCopyStatus('') }}>{texts.tokenHide}</Button>
      <p role="status">{copyStatus}</p>
    </div>}
  </section>
}
