import { isDelegationIdentifier, isDelegationPermissions } from '../../contracts/src/delegation.js'
import type { PublicClientAuthorization, PublicClientBrowser, PublicClientTokens } from '../../contracts/src/publicClient.js'

const verifierPattern = /^[A-Za-z0-9._~-]{43,128}$/
const credentialPattern = /^[A-Za-z0-9_-]{43}$/
const statePattern = /^[A-Za-z0-9._~-]{8,256}$/
const encode = (bytes: Uint8Array) => btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
const random = () => encode(crypto.getRandomValues(new Uint8Array(32)))
const validRedirect = (value: string) => {
  try { const url = new URL(value); return !['code','state','error','error_description'].some(key=>url.searchParams.has(key)) && !value.includes('#') && url.protocol === 'https:' && !!url.hostname && !url.username && !url.password && url.toString() === value && value.length <= 2048 }
  catch { return false }
}
function tokens(value: unknown): value is PublicClientTokens {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const v = value as Record<string, unknown>
  return Object.keys(v).sort().join(',') === 'access_token,expires_in,refresh_token,token_type' && credentialPattern.test(String(v.access_token)) && credentialPattern.test(String(v.refresh_token)) && v.token_type === 'Bearer' && v.expires_in === 300
}

/** Holds the PKCE transaction and credentials only in this instance's memory. */
export function createPublicClientBrowser(input: PublicClientAuthorization, options: { identityOrigin: string; fetchImpl?: typeof fetch; now?: () => number }): PublicClientBrowser {
  if (!isDelegationIdentifier(input.clientId) || !validRedirect(input.redirectUri) || !isDelegationPermissions(input.permissions)) throw new TypeError('Invalid public client configuration')
  input = structuredClone(input)
  const origin = new URL(options.identityOrigin)
  if (origin.protocol !== 'https:' || origin.origin !== options.identityOrigin) throw new TypeError('Identity origin must be HTTPS')
  const fetchImpl = options.fetchImpl ?? fetch
  const now = options.now ?? Date.now
  let pending: { verifier: string; state: string } | null = null
  let current: { access: string; refresh: string; expiresAt: number } | null = null
  let generation = 0
  let refreshing: Promise<string> | null = null
  const reset = () => { generation++; pending = null; current = null; refreshing = null }
  const endpoint = origin.origin + '/api/session/oauth/token'
  const request = async (body: unknown): Promise<PublicClientTokens> => {
    const response = await fetchImpl(endpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), credentials: 'omit', redirect: 'error', cache: 'no-store' })
    if (!response.ok) throw new Error(`Public client HTTP ${response.status}`)
    const value: unknown = await response.json()
    if (!tokens(value)) throw new Error('Invalid public client response')
    return value
  }
  const accept = (value: PublicClientTokens) => { current = { access: value.access_token, refresh: value.refresh_token, expiresAt: now() + value.expires_in * 1000 } }
  return {
    async authorize() {
      reset()
      const epoch = generation
      const verifier = random(), state = random()
      if (!verifierPattern.test(verifier) || !statePattern.test(state)) throw new Error('Secure random source unavailable')
      const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier))
      if (epoch !== generation) throw new Error('Authorization superseded')
      pending = { verifier, state }
      const url = new URL('/api/session/oauth/authorize', origin)
      for (const [key, value] of Object.entries({ client_id: input.clientId, redirect_uri: input.redirectUri, code_challenge: encode(new Uint8Array(digest)), code_challenge_method: 'S256', audience: 'core', permissions: JSON.stringify(input.permissions), state })) url.searchParams.set(key, value)
      return url.toString()
    },
    async complete(callbackUrl) {
      const transaction = pending
      reset()
      const epoch = generation
      const expected = new URL(input.redirectUri), callback = new URL(callbackUrl)
      const denied = callback.searchParams.get('error') === 'access_denied'
      const originalQuery = [...callback.searchParams].filter(([key]) => !['code','state','error'].includes(key))
      if (!transaction || callback.origin !== expected.origin || callback.pathname !== expected.pathname || callback.hash || callback.username || callback.password || callback.searchParams.size !== expected.searchParams.size + 2 || JSON.stringify(originalQuery) !== JSON.stringify([...expected.searchParams]) || callback.searchParams.getAll(denied ? 'error' : 'code').length !== 1 || callback.searchParams.has(denied ? 'code' : 'error') || callback.searchParams.getAll('state').length !== 1 || callback.searchParams.get('state') !== transaction.state) throw new Error('Invalid authorization callback')
      if (typeof window !== 'undefined' && window.location.href === callbackUrl) window.history.replaceState(window.history.state, '', input.redirectUri)
      if (denied) throw new Error('Authorization denied')
      const code = callback.searchParams.get('code')!
      if (!credentialPattern.test(code)) throw new Error('Invalid authorization code')
      const value = await request({ grant_type: 'authorization_code', code, client_id: input.clientId, redirect_uri: input.redirectUri, code_verifier: transaction.verifier })
      if (epoch !== generation) throw new Error('Authorization superseded')
      accept(value)
    },
    async accessToken() {
      if (refreshing) return refreshing
      if (!current) throw new Error('Reconnect required')
      if (now() < current.expiresAt - 30_000) return current.access
      const refresh = current.refresh
      current = null
      const epoch = generation
      refreshing = (async () => {
        try {
          const value = await request({ grant_type: 'refresh_token', refresh_token: refresh, client_id: input.clientId })
          if (epoch !== generation) throw new Error('Authorization superseded')
          accept(value)
          return value.access_token
        } catch { throw new Error('Reconnect required') }
        finally { if (epoch === generation) refreshing = null }
      })()
      return refreshing
    },
    reconnect() { return this.authorize() },
    disconnect() { reset() }
  }
}
