import {
  IDENTITY_DELEGATION_PATHS as paths, isManagedApplication, isApplicationGrant,
  isCreateApplicationInput, isCreateApplicationGrantInput, isDelegationIdentifier,
  type ApplicationManagementClient, type IssuedApplicationGrant, type ManagedApplication, type ApplicationGrant
} from '../../contracts/src/delegation.js'
import { authHeaders, credentialedFetch } from './browser.js'
import type { PublicRedirectManagement } from '../../contracts/src/publicClient.js'

function identifier(value: string): string {
  if (!isDelegationIdentifier(value)) throw new TypeError('Invalid application or grant ID')
  return value
}
function arrayOf<T>(guard: (value: unknown) => value is T) {
  return (value: unknown): value is T[] => Array.isArray(value) && value.every(guard)
}
function issued(value: unknown): value is IssuedApplicationGrant {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const v = value as Record<string, unknown>
  return Object.keys(v).length === 2 && isApplicationGrant(v.grant) && v.grant.revokedAt === null && typeof v.token === 'string' && v.token.trim().length > 0 && v.token.length <= 16384
}

/** Uses existing browser session, tenant selection, and CSRF handling. */
export function makeApplicationManagementClient(httpBase = '', now: () => number = Date.now, tenantId?: string): ApplicationManagementClient {
  if (tenantId !== undefined && !isDelegationIdentifier(tenantId)) throw new TypeError('Invalid tenant ID')
  async function request<T>(path: string, method: string, guard: (value: unknown) => value is T, body?: unknown): Promise<T> {
    const response = await credentialedFetch(httpBase + path, {
      method, headers: { ...authHeaders(), ...(tenantId === undefined ? {} : { 'x-sislexa-tenant-id': tenantId }), ...(body === undefined ? {} : { 'content-type': 'application/json' }) },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      redirect: 'error', cache: 'no-store', signal: AbortSignal.timeout(15000)
    })
    if (!response.ok) throw Object.assign(new Error(`Application HTTP ${response.status}`), { status: response.status })
    const value: unknown = response.status === 204 ? undefined : await response.json()
    if (!guard(value)) throw new Error('Invalid application response')
    return value
  }
  const empty = (v: unknown): v is undefined => v === undefined
  const application = (v: unknown): v is ManagedApplication => isManagedApplication(v) && (tenantId === undefined || v.tenantId === tenantId)
  const applicationFor = (id: string) => (v: unknown): v is ManagedApplication => application(v) && v.id === id
  const grantFor = (id: string) => (v: unknown): v is ApplicationGrant => isApplicationGrant(v) && v.applicationId === id && (tenantId === undefined || v.tenantId === tenantId)
  const issuedFor = (id: string) => (v: unknown): v is IssuedApplicationGrant => issued(v) && grantFor(id)(v.grant) && v.grant.issuedAt <= now() && v.grant.expiresAt > now()
  return {
    list: () => request(paths.applications, 'GET', arrayOf(application)),
    create(input) {
      if (!isCreateApplicationInput(input)) throw new TypeError('Invalid application input')
      return request(paths.applications, 'POST', application, input)
    },
    rename(id, input) {
      if (!isCreateApplicationInput(input)) throw new TypeError('Invalid application input')
      return request(paths.application(identifier(id)), 'PATCH', applicationFor(id), input)
    },
    revoke: id => request(paths.application(identifier(id)), 'DELETE', empty),
    grants: id => request(paths.grants(identifier(id)), 'GET', arrayOf(grantFor(id))),
    issueGrant(id, input) {
      if (!isCreateApplicationGrantInput(input, now()) || (tenantId !== undefined && input.permissions.some(p => p.resource.tenantId !== tenantId))) throw new TypeError('Invalid application grant input')
      return request(paths.grants(identifier(id)), 'POST', issuedFor(id), input)
    },
    rotateGrant: (id, grantId) => request(paths.rotateGrant(identifier(id), identifier(grantId)), 'POST', (v): v is IssuedApplicationGrant => issuedFor(id)(v) && v.grant.id === grantId),
    revokeGrant: (id, grantId) => request(paths.grant(identifier(id), identifier(grantId)), 'DELETE', empty)
  }
}

const redirectUri = (value: string): boolean => {
  try { const url = new URL(value); return !['code','state','error','error_description'].some(key=>url.searchParams.has(key)) && !value.includes('#') && url.protocol === 'https:' && !!url.hostname && !url.username && !url.password && url.toString() === value && value.length <= 2048 }
  catch { return false }
}
export function makePublicRedirectManagementClient(httpBase = ''): PublicRedirectManagement {
  async function request(id: string, method: string, uri?: string): Promise<unknown> {
    const response = await credentialedFetch(`${httpBase}${paths.application(identifier(id))}/redirect-uris`, {
      method, headers: { ...authHeaders(), ...(uri === undefined ? {} : { 'content-type': 'application/json' }) },
      ...(uri === undefined ? {} : { body: JSON.stringify({ uri }) }),
      redirect: 'error', cache: 'no-store'
    })
    if (!response.ok) throw Object.assign(new Error(`Redirect HTTP ${response.status}`), { status: response.status })
    return response.status === 204 ? undefined : response.json()
  }
  return {
    async listRedirects(id) {
      const value = await request(id, 'GET')
      if (!Array.isArray(value) || !value.every(v => typeof v === 'string' && redirectUri(v))) throw new Error('Invalid redirect response')
      return value
    },
    async registerRedirect(id, uri) {
      if (!redirectUri(uri)) throw new TypeError('Invalid redirect URI')
      const value = await request(id, 'POST', uri)
      if (!value || typeof value !== 'object' || Object.keys(value).length !== 1 || (value as {uri?: unknown}).uri !== uri) throw new Error('Invalid redirect response')
      return uri
    },
    async removeRedirect(id, uri) {
      if (!redirectUri(uri)) throw new TypeError('Invalid redirect URI')
      if (await request(id, 'DELETE', uri) !== undefined) throw new Error('Invalid redirect response')
    }
  }
}
