import { useEffect, useRef, useState } from 'react'
import type { ApplicationGrant, ApplicationManagementClient, DelegationResource, DelegationScope, ManagedApplication } from '../../../packages/contracts/src/delegation.js'

type ResourceType = DelegationResource['type']
const scopeOptions: readonly DelegationScope[] = ['read', 'write', 'execute']
const status = (grant: ApplicationGrant, now: number) => grant.revokedAt !== null ? 'Отозван' : grant.expiresAt <= now ? 'Истёк' : 'Активен'
const date = (value: number) => new Date(value).toLocaleString('ru-RU')

export interface MyApplicationsProps {
  client: ApplicationManagementClient
  tenantId: string
  onClose: () => void
  now?: () => number
  confirm?: (message: string) => boolean | Promise<boolean>
}

export function MyApplications(props: MyApplicationsProps): JSX.Element {
  return <ApplicationsPanel key={props.tenantId} {...props} />
}

/** The issued bearer exists in component memory only until dismissed or unmounted. */
function ApplicationsPanel({ client, tenantId, onClose, now = Date.now, confirm = message => window.confirm(message) }: MyApplicationsProps): JSX.Element {
  const epoch = useRef(0)
  const grantRead = useRef(0)
  const pending = useRef(false)
  const [grantsLoading, setGrantsLoading] = useState(false)
  const [grantsError, setGrantsError] = useState(false)
  const [grantRetry, setGrantRetry] = useState(0)
  const [applications, setApplications] = useState<ManagedApplication[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [grants, setGrants] = useState<ApplicationGrant[]>([])
  const [name, setName] = useState('')
  const [rename, setRename] = useState('')
  const [resourceType, setResourceType] = useState<ResourceType>('conversation')
  const [resourceId, setResourceId] = useState('')
  const [scopes, setScopes] = useState<DelegationScope[]>(['read'])
  const [days, setDays] = useState(7)
  const [issued, setIssued] = useState<{ token: string; grantId: string } | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const selected = applications.find(item => item.id === selectedId) ?? null

  const reload = async (preferredId?: string | null) => {
    const version = epoch.current
    const rows = await client.list()
    if (version !== epoch.current) return
    setApplications(rows.filter(item => item.tenantId === tenantId))
    setSelectedId(current => {
      const candidate = preferredId === undefined ? current : preferredId
      return rows.some(row => row.id === candidate && row.tenantId === tenantId) ? candidate : null
    })
  }
  useEffect(() => {
    let live = true
    setIssued(null); setSelectedId(null); setApplications([]); setGrants([]); setLoading(true); setError(null); setBusy(false); pending.current = false
    void client.list().then(rows => { if (live) setApplications(rows.filter(item => item.tenantId === tenantId)) })
      .catch(() => { if (live) setError('Не удалось загрузить приложения.') })
      .finally(() => { if (live) setLoading(false) })
    return () => { live = false; epoch.current++ }
  }, [client, tenantId])
  useEffect(() => {
    let live = true
    const read = ++grantRead.current
    setGrants([]); setGrantsError(false); setGrantsLoading(!!selectedId)
    if (selectedId) void client.grants(selectedId).then(rows => { if (live && read === grantRead.current) setGrants(rows.filter(row => row.applicationId === selectedId && row.tenantId === tenantId)) })
      .catch(() => { if (live && read === grantRead.current) setGrantsError(true) })
      .finally(() => { if (live && read === grantRead.current) setGrantsLoading(false) })
    return () => { live = false }
  }, [client, selectedId, tenantId, grantRetry])

  const mutate = async (operation: (checked: <T>(promise: Promise<T>) => Promise<T>) => Promise<void>) => {
    if (pending.current) return
    const version = epoch.current
    pending.current = true
    setBusy(true); setError(null); setIssued(null)
    const checked = async <T,>(promise: Promise<T>): Promise<T> => {
      const value = await promise
      if (version !== epoch.current) throw Error('Stale application operation')
      return value
    }
    try { await operation(checked) }
    catch { if (version === epoch.current) setError('Не удалось выполнить запрос. Проверьте состояние перед повтором: операция могла завершиться на сервере.') }
    finally { if (version === epoch.current) { pending.current = false; setBusy(false) } }
  }
  const refreshGrants = async (id: string) => {
    const version = epoch.current
    const read = ++grantRead.current
    setGrantsLoading(true)
    try {
      const rows = await client.grants(id)
      if (version === epoch.current && read === grantRead.current) { setGrants(rows.filter(row => row.applicationId === id && row.tenantId === tenantId)); setGrantsError(false) }
    } catch { if (version === epoch.current && read === grantRead.current) { setGrants([]); setGrantsError(true) } }
    finally { if (version === epoch.current && read === grantRead.current) setGrantsLoading(false) }
  }
  const checkedIssue = (grant: ApplicationGrant, id: string) => {
    if (grant.applicationId !== id || grant.tenantId !== tenantId || grant.revokedAt !== null || grant.audience !== 'core' || grant.expiresAt <= now()) throw Error('Invalid grant context')
  }
  const showIssued = (token: string, grantId: string) => setIssued({ token, grantId })
  const close = () => { epoch.current++; setIssued(null); onClose() }
  useEffect(() => {
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') close() }
    window.addEventListener('keydown', escape)
    return () => window.removeEventListener('keydown', escape)
  }, [onClose])
  const toggleScope = (scope: DelegationScope) => setScopes(current => current.includes(scope) ? current.filter(value => value !== scope) : [...current, scope])
  const permission = () => ({ resource: { tenantId, type: resourceType, id: resourceId.trim() }, scopes })

  return <div className="my-applications-backdrop"><section className="my-applications" role="dialog" aria-modal="true" aria-label="Мои приложения" data-testid="my-applications">
    <header><h2>Мои приложения</h2><button type="button" autoFocus onClick={close}>Закрыть</button></header>
    <p>Приложения получают доступ только к указанным ресурсам. Секрет выдаётся один раз; храните его на сервере приложения.</p>
    {error && <p role="alert">Ошибка: {error} <button type="button" disabled={busy} onClick={() => void mutate(async checked => { await checked(reload()); if (selectedId) setGrantRetry(value => value + 1) })}>Повторить</button></p>}
    {loading && <p role="status">Загружаем приложения…</p>}
    {!loading && !error && applications.length === 0 && <p>У вас пока нет приложений.</p>}
    <form onSubmit={event => { event.preventDefault(); void mutate(async checked => {
      const app = await checked(client.create({ name: name.trim() })); setName(''); setRename(app.name); await reload(app.id)
    }) }}>
      <label>Название приложения<input value={name} maxLength={80} required disabled={busy || loading} onChange={event => setName(event.target.value)} /></label>
      <button type="submit" disabled={busy || loading || !name.trim()}>Создать приложение</button>
    </form>
    <ul aria-label="Список приложений">{applications.map(app => <li key={app.id}>
      <button type="button" disabled={busy} aria-pressed={app.id === selectedId} onClick={() => { setIssued(null); setSelectedId(app.id); setRename(app.name) }}>
        {app.name} · {app.revokedAt === null ? 'Активно' : 'Отозвано'}
      </button> <code>{app.id}</code>
    </li>)}</ul>
    {selected && <div className="my-applications__detail">
      <h3>{selected.name}</h3><p>Приложение: <code>{selected.id}</code>. Пространство: <code>{tenantId}</code>.</p>
      {selected.revokedAt !== null ? <p>Приложение отозвано {date(selected.revokedAt)}. Исторические отчёты сохраняют его ID и название.</p> : <>
        <form onSubmit={event => { event.preventDefault(); void mutate(async checked => { await checked(client.rename(selected.id, { name: rename.trim() })); await reload(selected.id) }) }}>
          <label>Новое название<input value={rename} maxLength={80} required disabled={busy} onChange={event => setRename(event.target.value)} /></label>
          <button type="submit" disabled={busy || !rename.trim() || rename.trim() === selected.name}>Переименовать</button>
        </form>
        <button type="button" disabled={busy} onClick={() => void mutate(async checked => {
          if (!await checked(Promise.resolve(confirm(`Отозвать приложение «${selected.name}» и все его ключи?`)))) return
          setIssued(null); await checked(client.revoke(selected.id)); await checked(reload(selected.id)); await refreshGrants(selected.id)
        })}>Удалить и отозвать доступ</button>
        <form onSubmit={event => { event.preventDefault(); void mutate(async checked => {
          const result = await checked(client.issueGrant(selected.id, { audience: 'core', permissions: [permission()], expiresAt: now() + days * 86_400_000 }))
          checkedIssue(result.grant, selected.id)
          showIssued(result.token, result.grant.id); setResourceId(''); await refreshGrants(selected.id)
        }) }}>
          <h4>Новый ключ доступа</h4>
          <label>Ресурс<select value={resourceType} disabled={busy} onChange={event => setResourceType(event.target.value as ResourceType)}>
            <option value="conversation">Разговор</option><option value="project">Проект</option><option value="task">Задача</option><option value="machine">Машина</option>
          </select></label>
          <label>ID ресурса<input value={resourceId} required maxLength={128} disabled={busy} onChange={event => setResourceId(event.target.value)} /></label>
          <fieldset><legend>Разрешения</legend>{scopeOptions.map(scope => <label key={scope}>
            <input type="checkbox" checked={scopes.includes(scope)} disabled={busy} onChange={() => toggleScope(scope)} />{scope}
          </label>)}</fieldset>
          <label>Срок действия<select value={days} disabled={busy} onChange={event => setDays(Number(event.target.value))}>
            <option value={1}>1 день</option><option value={7}>7 дней</option><option value={30}>30 дней</option><option value={90}>90 дней</option>
          </select></label>
          <button type="submit" disabled={busy || !resourceId.trim() || scopes.length === 0}>Выпустить ключ</button>
        </form>
      </>}
      {issued && <div role="status" className="my-applications__secret">
        <p>Ключ {issued.grantId} показан только сейчас. После закрытия получить его повторно нельзя.</p>
        <code data-testid="issued-application-token">{issued.token}</code>
        <button type="button" onClick={() => setIssued(null)}>Скрыть ключ</button>
      </div>}
      <h4>Ключи</h4>
      {grantsLoading && <p role="status">Загружаем ключи…</p>}
      {grantsError && <p role="alert">Не удалось загрузить ключи. <button type="button" disabled={busy} onClick={() => setGrantRetry(value => value + 1)}>Повторить загрузку ключей</button></p>}
      {!grantsLoading && !grantsError && grants.length === 0 && <p>Ключей пока нет.</p>}
      <ul>{grants.map(grant => <li key={grant.id}>
        <code>{grant.id}</code> · {status(grant, now())} · до {date(grant.expiresAt)} · {grant.permissions.map(row => `${row.resource.type}:${row.resource.id} (${row.scopes.join(', ')})`).join('; ')}
        {selected.revokedAt === null && grant.revokedAt === null && grant.expiresAt > now() && <>
          <button type="button" disabled={busy} onClick={() => void mutate(async checked => {
            if (!await checked(Promise.resolve(confirm('Заменить ключ? Старый немедленно перестанет работать.')))) return
            const result = await checked(client.rotateGrant(selected.id, grant.id)); checkedIssue(result.grant, selected.id)
            showIssued(result.token, result.grant.id); await refreshGrants(selected.id)
          })}>Заменить</button>
          <button type="button" disabled={busy} onClick={() => void mutate(async checked => {
            if (!await checked(Promise.resolve(confirm('Отозвать этот ключ?')))) return
            setIssued(null); await checked(client.revokeGrant(selected.id, grant.id)); await refreshGrants(selected.id)
          })}>Отозвать</button>
        </>}
      </li>)}</ul>
      <aside><h4>Подключение</h4>
        <p>Сервер приложения хранит выданный ключ в закрытой конфигурации и передаёт его только в запросах к Core для разрешённых ресурсов. Не помещайте его в браузерный код, localStorage или URL. Ключ приложения не заменяет вход пользователя. Браузерная авторизация использует отдельный публичный поток.</p>
        <p>Передавайте ключ в заголовке <code>Authorization</code> со схемой <code>Bearer</code> и выданным ключом по HTTPS на адрес Core, указанный оператором, только в маршруты с поддержкой делегированного доступа. Не используйте его для API управления аккаунтом. После замены обновите конфигурацию приложения: старый ключ сразу недействителен.</p>
        <p>Аудитория ключа: <code>core</code>. Указывайте точный ID разговора или проекта и только необходимые разрешения. Отзыв ключа прекращает новые запросы; уже списанное использование остаётся в отчётах.</p>
      </aside>
    </div>}
  </section></div>
}
