// Task gate for Delivery Control: typecheck and tests of the workspaces touched since --base.
// Prints exactly one `GATE-TASK: tests=N seconds=S` line; on a budget breach prints the
// selected test files under `GATE-TASK-SLOW:` and exits with 2.
import { spawn, execFileSync } from 'node:child_process'
import { mkdtempSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const MAX_MS = 300_000
const MAX_TESTS = 1000
const args = process.argv.slice(2)
const baseAt = args.indexOf('--base')
const base = baseAt >= 0 ? args[baseAt + 1] : undefined
if (!base || base.startsWith('-')) { console.error('Usage: npm run gate:task -- --base <git revision>'); process.exit(1) }

const workspaces = JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8')).workspaces
const git = (...a) => execFileSync('git', a, { cwd: root, encoding: 'utf8' }).trim().split('\n').filter(Boolean)
const changed = [...new Set([...git('diff', '--name-only', '--diff-filter=ACMRD', base, '--'), ...git('ls-files', '--others', '--exclude-standard')])]
const rootLevel = changed.some(f => !workspaces.some(w => f.startsWith(w + '/')))
const affected = rootLevel ? workspaces : workspaces.filter(w => changed.some(f => f.startsWith(w + '/')))

const started = Date.now()
let tests = 0
const files = []
const elapsed = () => Date.now() - started
const run = (cmd, argv, cwd) => new Promise((resolve, reject) => {
  const child = spawn(cmd, argv, { cwd, stdio: 'inherit', env: { ...process.env, CI: '1' } })
  const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('budget')) }, Math.max(1, MAX_MS - elapsed()))
  child.on('error', e => { clearTimeout(timer); reject(e) })
  child.on('close', code => { clearTimeout(timer); code === 0 ? resolve() : reject(new Error(`${cmd} ${argv.join(' ')} failed (${code})`)) })
})

const report = (status) => {
  const seconds = (elapsed() / 1000).toFixed(1)
  if (status === 'budget') {
    console.log('GATE-TASK-SLOW:')
    for (const f of files) console.log(f)
  }
  console.log(`GATE-TASK: tests=${tests} seconds=${seconds}`)
}

try {
  for (const ws of affected) {
    await run('npm', ['run', '--silent', 'typecheck'], path.join(root, ws))
    const out = mkdtempSync(path.join(tmpdir(), 'gate-task-'))
    const json = path.join(out, 'vitest.json')
    try {
      await run('npx', ['vitest', 'run', '--passWithNoTests', '--reporter=default', '--reporter=json', `--outputFile.json=${json}`], path.join(root, ws))
      let result = null
      try { result = JSON.parse(readFileSync(json, 'utf8')) } catch { result = null }
      if (result) {
        tests += Number(result.numTotalTests ?? 0)
        for (const file of result.testResults ?? []) files.push(path.relative(root, file.name).replace(/\\/g, '/'))
      }
    } finally { rmSync(out, { recursive: true, force: true }) }
    if (tests > MAX_TESTS || elapsed() > MAX_MS) throw new Error('budget')
  }
  report('passed')
  process.exit(0)
} catch (error) {
  const budget = error instanceof Error && error.message === 'budget'
  if (!budget) console.error(error instanceof Error ? error.message : String(error))
  report(budget ? 'budget' : 'failed')
  process.exit(budget ? 2 : 1)
}
