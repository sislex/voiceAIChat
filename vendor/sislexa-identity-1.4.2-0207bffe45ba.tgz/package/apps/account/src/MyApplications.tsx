import { useEffect, useState } from 'react'
import type { ApplicationGrant, ApplicationManagementClient, DelegationResource, DelegationScope, ManagedApplication } from '../../../packages/contracts/src/delegation.js'

type ResourceType = DelegationResource['type']
const scopeOptions: readonly DelegationScope[] = ['read', 'write', 'execute']
const status = (grant: ApplicationGrant, now: number) => grant.revokedAt !== null ? 'Отозван' : grant.expiresAt <= now ? 'Истёк' : 'Активен'
const date = (value: number) => new Date(value).toLocaleString('ru-RU')

export interface MyApplicationsProps {
  client: ApplicationManagementClient
  tenantId: string
  onClose: () => void
  now?: () => number
  confirm?: (message: string) => boolean | Promise<boolean>
}

/** The issued bearer exists in component memory only until dismissed or unmounted. */
export function MyApplications({ client, tenantId, onClose, now = Date.now, confirm = message => window.confirm(message) }: MyApplicationsProps): JSX.Element {
  const [applications, setApplications] = useState<ManagedApplication[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [grants, setGrants] = useState<ApplicationGrant[]>([])
  const [name, setName] = useState('')
  const [rename, setRename] = useState('')
  const [resourceType, setResourceType] = useState<ResourceType>('conversation')
  const [resourceId, setResourceId] = useState('')
  const [scopes, setScopes] = useState<DelegationScope[]>(['read'])
  const [days, setDays] = useState(7)
  const [issued, setIssued] = useState<{ token: string; grantId: string } | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [loading, setLoading] = useState(true)
  const selected = applications.find(item => item.id === selectedId) ?? null

  const reload = async (preferredId?: string | null) => {
    const rows = await client.list()
    setApplications(rows.filter(item => item.tenantId === tenantId))
    setSelectedId(current => {
      const candidate = preferredId === undefined ? current : preferredId
      return rows.some(row => row.id === candidate && row.tenantId === tenantId) ? candidate : null
    })
  }
  useEffect(() => {
    let live = true
    setIssued(null); setSelectedId(null); setApplications([]); setGrants([]); setLoading(true)
    void client.list().then(rows => { if (live) setApplications(rows.filter(item => item.tenantId === tenantId)) })
      .catch(reason => { if (live) setError(reason instanceof Error ? reason.message : String(reason)) })
      .finally(() => { if (live) setLoading(false) })
    return () => { live = false }
  }, [client, tenantId])
  useEffect(() => {
    let live = true
    setIssued(null); setGrants([])
    if (selectedId) void client.grants(selectedId).then(rows => { if (live) setGrants(rows.filter(row => row.applicationId === selectedId && row.tenantId === tenantId)) })
      .catch(reason => { if (live) setError(reason instanceof Error ? reason.message : String(reason)) })
    return () => { live = false }
  }, [client, selectedId, tenantId])

  const mutate = async (operation: () => Promise<void>) => {
    setBusy(true); setError(null); setIssued(null)
    try { await operation() }
    catch (reason) { setError(reason instanceof Error ? reason.message : String(reason)) }
    finally { setBusy(false) }
  }
  const refreshGrants = async (id: string) => setGrants((await client.grants(id)).filter(row => row.applicationId === id && row.tenantId === tenantId))
  const checkedIssue = (grant: ApplicationGrant, id: string) => {
    if (grant.applicationId !== id || grant.tenantId !== tenantId || grant.revokedAt !== null) throw Error('Неверный контекст ключа')
  }
  const showIssued = (token: string, grantId: string) => setIssued({ token, grantId })
  const close = () => { setIssued(null); onClose() }
  useEffect(() => {
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') close() }
    window.addEventListener('keydown', escape)
    return () => window.removeEventListener('keydown', escape)
  }, [onClose])
  const toggleScope = (scope: DelegationScope) => setScopes(current => current.includes(scope) ? current.filter(value => value !== scope) : [...current, scope])
  const permission = () => ({ resource: { tenantId, type: resourceType, id: resourceId.trim() }, scopes })

  return <div className="my-applications-backdrop"><section className="my-applications" role="dialog" aria-modal="true" aria-label="Мои приложения" data-testid="my-applications">
    <header><h2>Мои приложения</h2><button type="button" autoFocus onClick={close}>Закрыть</button></header>
    <p>Приложения получают доступ только к указанным ресурсам. Секрет выдаётся один раз; храните его на сервере приложения.</p>
    {error && <p role="alert">Ошибка: {error} <button type="button" onClick={() => void mutate(() => reload())}>Повторить</button></p>}
    {loading && <p role="status">Загружаем приложения…</p>}
    <form onSubmit={event => { event.preventDefault(); void mutate(async () => {
      const app = await client.create({ name: name.trim() }); setName(''); await reload(app.id)
    }) }}>
      <label>Название приложения<input value={name} maxLength={80} required disabled={busy} onChange={event => setName(event.target.value)} /></label>
      <button type="submit" disabled={busy || !name.trim()}>Создать приложение</button>
    </form>
    <ul aria-label="Список приложений">{applications.map(app => <li key={app.id}>
      <button type="button" disabled={busy} aria-pressed={app.id === selectedId} onClick={() => { setIssued(null); setSelectedId(app.id); setRename(app.name) }}>
        {app.name} · {app.revokedAt === null ? 'Активно' : 'Отозвано'}
      </button> <code>{app.id}</code>
    </li>)}</ul>
    {selected && <div className="my-applications__detail">
      <h3>{selected.name}</h3><p>Приложение: <code>{selected.id}</code>. Пространство: <code>{tenantId}</code>.</p>
      {selected.revokedAt !== null ? <p>Приложение отозвано {date(selected.revokedAt)}. Исторические отчёты сохраняют его ID и название.</p> : <>
        <form onSubmit={event => { event.preventDefault(); void mutate(async () => { await client.rename(selected.id, { name: rename.trim() }); await reload(selected.id) }) }}>
          <label>Новое название<input value={rename} maxLength={80} required disabled={busy} onChange={event => setRename(event.target.value)} /></label>
          <button type="submit" disabled={busy || !rename.trim() || rename.trim() === selected.name}>Переименовать</button>
        </form>
        <button type="button" disabled={busy} onClick={() => void mutate(async () => {
          if (!await confirm(`Отозвать приложение «${selected.name}» и все его ключи?`)) return
          setIssued(null); await client.revoke(selected.id); await reload(selected.id); setGrants([])
        })}>Удалить и отозвать доступ</button>
        <form onSubmit={event => { event.preventDefault(); void mutate(async () => {
          const result = await client.issueGrant(selected.id, { audience: 'core', permissions: [permission()], expiresAt: now() + days * 86_400_000 })
          checkedIssue(result.grant, selected.id)
          showIssued(result.token, result.grant.id); setResourceId(''); await refreshGrants(selected.id)
        }) }}>
          <h4>Новый ключ доступа</h4>
          <label>Ресурс<select value={resourceType} disabled={busy} onChange={event => setResourceType(event.target.value as ResourceType)}>
            <option value="conversation">Разговор</option><option value="project">Проект</option><option value="task">Задача</option><option value="machine">Машина</option>
          </select></label>
          <label>ID ресурса<input value={resourceId} required maxLength={128} disabled={busy} onChange={event => setResourceId(event.target.value)} /></label>
          <fieldset><legend>Разрешения</legend>{scopeOptions.map(scope => <label key={scope}>
            <input type="checkbox" checked={scopes.includes(scope)} disabled={busy} onChange={() => toggleScope(scope)} />{scope}
          </label>)}</fieldset>
          <label>Срок действия<select value={days} disabled={busy} onChange={event => setDays(Number(event.target.value))}>
            <option value={1}>1 день</option><option value={7}>7 дней</option><option value={30}>30 дней</option><option value={90}>90 дней</option>
          </select></label>
          <button type="submit" disabled={busy || !resourceId.trim() || scopes.length === 0}>Выпустить ключ</button>
        </form>
      </>}
      {issued && <div role="status" className="my-applications__secret">
        <p>Ключ {issued.grantId} показан только сейчас. После закрытия получить его повторно нельзя.</p>
        <code data-testid="issued-application-token">{issued.token}</code>
        <button type="button" onClick={() => setIssued(null)}>Скрыть ключ</button>
      </div>}
      <h4>Ключи</h4><ul>{grants.map(grant => <li key={grant.id}>
        <code>{grant.id}</code> · {status(grant, now())} · до {date(grant.expiresAt)} · {grant.permissions.map(row => `${row.resource.type}:${row.resource.id} (${row.scopes.join(', ')})`).join('; ')}
        {selected.revokedAt === null && grant.revokedAt === null && grant.expiresAt > now() && <>
          <button type="button" disabled={busy} onClick={() => void mutate(async () => {
            if (!await confirm('Заменить ключ? Старый немедленно перестанет работать.')) return
            const result = await client.rotateGrant(selected.id, grant.id); checkedIssue(result.grant, selected.id)
            showIssued(result.token, result.grant.id); await refreshGrants(selected.id)
          })}>Заменить</button>
          <button type="button" disabled={busy} onClick={() => void mutate(async () => {
            if (!await confirm('Отозвать этот ключ?')) return
            setIssued(null); await client.revokeGrant(selected.id, grant.id); await refreshGrants(selected.id)
          })}>Отозвать</button>
        </>}
      </li>)}</ul>
      <aside><h4>Подключение</h4>
        <p>Сервер приложения хранит выданный ключ в закрытой конфигурации и передаёт его только в запросах к Core для разрешённых ресурсов. Не помещайте его в браузерный код, localStorage или URL. Для браузера используйте короткую пользовательскую сессию через SDK после выпуска публичного потока авторизации.</p>
        <p>Аудитория ключа: <code>core</code>. Указывайте точный ID разговора или проекта и только необходимые разрешения. Отзыв ключа прекращает новые запросы; уже списанное использование остаётся в отчётах.</p>
      </aside>
    </div>}
  </section></div>
}
