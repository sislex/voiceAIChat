import {useEffect,useState} from 'react'
import {Button} from '@voicechat/ui-kit'
import {authHeaders,credentialedFetch} from '../../../packages/client/src/browser.js'

interface Connection {id:string;applicationId:string;applicationName:string;redirectUri:string;permissions:Array<{resource:{type:string;id:string};scopes:string[]}>;expiresAt:number}

export function PublicConnections({onClose}:{onClose:()=>void}) {
  const [connections,setConnections]=useState<Connection[]>([])
  const [error,setError]=useState('')
  const [busy,setBusy]=useState<string|null>(null)
  const load=async()=>{
    const response=await credentialedFetch('/api/session/oauth/connections',{headers:authHeaders(),cache:'no-store'})
    if(!response.ok)throw new Error('Не удалось загрузить подключения')
    setConnections(await response.json() as Connection[])
  }
  useEffect(()=>{let active=true;void load().catch(e=>{if(active)setError(String(e))});return()=>{active=false}},[])
  const revoke=async(id:string)=>{
    setBusy(id);setError('')
    try {
      const response=await credentialedFetch(`/api/session/oauth/connections/${encodeURIComponent(id)}`,{method:'DELETE',headers:authHeaders(),cache:'no-store'})
      if(!response.ok)throw new Error('Не удалось отозвать подключение')
      await load()
    } catch(e) {setError(String(e))} finally {setBusy(null)}
  }
  return <section role="dialog" aria-modal="true" aria-labelledby="public-connections-title">
    <h2 id="public-connections-title">Подключённые приложения</h2>
    <p>Подключения для выбранной организации. Отзыв сразу прекращает доступ приложения.</p>
    {error&&<p role="alert">{error}</p>}
    {connections.length===0&&!error&&<p>Активных подключений нет.</p>}
    <ul>{connections.map(item=><li key={item.id}>
      <strong>{item.applicationName}</strong> · {new URL(item.redirectUri).origin}<br/>
      <small>Действует до {new Date(item.expiresAt).toLocaleString()}</small>
      <ul>{item.permissions.map((permission,index)=><li key={index}>{permission.resource.type} / {permission.resource.id}: {permission.scopes.join(', ')}</li>)}</ul>
      <Button size="sm" disabled={busy!==null} onClick={()=>void revoke(item.id)}>Отозвать</Button>
    </li>)}</ul>
    <Button size="sm" onClick={onClose}>Закрыть</Button>
  </section>
}
