import {useEffect,useMemo,useState} from 'react'
import {Button} from '@voicechat/ui-kit'
import {makeApplicationManagementClient,makePublicRedirectManagementClient} from '../../../packages/client/src/applications.js'
import type {ManagedApplication} from '../../../packages/contracts/src/delegation.js'

export function PublicApplications({tenantId,onClose}:{tenantId:string;onClose:()=>void}) {
  const applications=useMemo(()=>makeApplicationManagementClient(),[])
  const redirects=useMemo(()=>makePublicRedirectManagementClient(),[])
  const [items,setItems]=useState<ManagedApplication[]>([])
  const [selected,setSelected]=useState('')
  const [uris,setUris]=useState<string[]>([])
  const [uri,setUri]=useState('')
  const [busy,setBusy]=useState(false)
  const [error,setError]=useState('')
  useEffect(()=>{let active=true;void applications.list().then(value=>{if(active)setItems(value.filter(item=>item.tenantId===tenantId&&item.revokedAt===null))}).catch(()=>{if(active)setError('Не удалось загрузить приложения')});return()=>{active=false}},[applications,tenantId])
  useEffect(()=>{let active=true;setUris([]);if(selected)void redirects.listRedirects(selected).then(value=>{if(active)setUris(value)}).catch(()=>{if(active)setError('Не удалось загрузить адреса')});return()=>{active=false}},[selected,redirects])
  const run=async(action:()=>Promise<void>)=>{setBusy(true);setError('');try{await action()}catch{setError('Не удалось сохранить изменения')}finally{setBusy(false)}}
  return <section role="dialog" aria-modal="true" aria-labelledby="public-applications-title" className="public-applications">
    <h2 id="public-applications-title">Адреса возврата приложений</h2>
    <p>Укажите точные HTTPS адреса возврата. Для каждого приложения доступно до десяти адресов.</p>
    {items.length===0&&<p>Сначала создайте приложение в разделе «Мои приложения».</p>}
    {error&&<p role="alert">{error}</p>}
    <label>Приложение<select value={selected} onChange={event=>setSelected(event.target.value)}><option value="">Выберите приложение</option>{items.map(item=><option value={item.id} key={item.id}>{item.name}</option>)}</select></label>
    {selected&&<><form onSubmit={event=>{event.preventDefault();void run(async()=>{await redirects.registerRedirect(selected,uri);setUris(await redirects.listRedirects(selected));setUri('')})}}>
      <label>Точный HTTPS адрес возврата<input type="url" value={uri} onChange={event=>setUri(event.target.value)} placeholder="https://example.com/callback" required/></label>
      <Button size="sm" type="submit" disabled={busy||uris.length>=10}>Добавить адрес</Button>
    </form><ul>{uris.map(value=><li key={value}><code>{value}</code> <Button size="sm" disabled={busy} onClick={()=>void run(async()=>{await redirects.removeRedirect(selected,value);setUris(await redirects.listRedirects(selected))})}>Удалить</Button></li>)}</ul></>}
    <Button size="sm" onClick={onClose}>Закрыть</Button>
  </section>
}
