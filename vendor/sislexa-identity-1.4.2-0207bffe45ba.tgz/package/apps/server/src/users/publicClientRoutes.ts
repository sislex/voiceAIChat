import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify'
import { isDelegationIdentifier, isDelegationPermissions, type DelegationPermission } from '../../../../packages/contracts/src/delegation.js'
import type { AuthDatabase } from '../ports.js'
import type { AuthenticateFn } from './auth.js'

type Dict = Record<string, unknown>
const object = (value: unknown): value is Dict => value !== null && typeof value === 'object' && !Array.isArray(value)
const exact = (value: Dict, keys: string[]) => Object.keys(value).sort().join(',') === keys.sort().join(',')
const challenge = (value: unknown): value is string => typeof value === 'string' && /^[A-Za-z0-9_-]{43}$/.test(value)
const verifier = (value: unknown): value is string => typeof value === 'string' && /^[A-Za-z0-9._~-]{43,128}$/.test(value)
const uri = (value: unknown): value is string => {
  if (typeof value !== 'string' || value.length > 2048 || value.includes('#')) return false
  try {
    const parsed = new URL(value)
    return parsed.protocol === 'https:' && Boolean(parsed.hostname) && !parsed.username && !parsed.password && parsed.toString() === value
  } catch { return false }
}
interface Consent {client_id:string;redirect_uri:string;code_challenge:string;code_challenge_method:'S256';audience:string;permissions:DelegationPermission[];state:string;decision:'approve'}
const consent = (v:unknown): v is Consent => object(v) && exact(v,['client_id','redirect_uri','code_challenge','code_challenge_method','audience','permissions','state','decision']) && isDelegationIdentifier(v.client_id) && uri(v.redirect_uri) && challenge(v.code_challenge) && v.code_challenge_method === 'S256' && v.audience === 'core' && isDelegationPermissions(v.permissions) && typeof v.state === 'string' && /^[A-Za-z0-9._~-]{8,256}$/.test(v.state) && v.decision === 'approve'
const tokenRequest = (v:unknown): v is {grant_type:'authorization_code';code:string;client_id:string;redirect_uri:string;code_verifier:string} => object(v) && exact(v,['grant_type','code','client_id','redirect_uri','code_verifier']) && v.grant_type === 'authorization_code' && typeof v.code === 'string' && /^[A-Za-z0-9_-]{43}$/.test(v.code) && isDelegationIdentifier(v.client_id) && uri(v.redirect_uri) && verifier(v.code_verifier)
const refreshRequest = (v:unknown): v is {grant_type:'refresh_token';refresh_token:string;client_id:string} => object(v) && exact(v,['grant_type','refresh_token','client_id']) && v.grant_type === 'refresh_token' && typeof v.refresh_token === 'string' && /^[A-Za-z0-9_-]{43}$/.test(v.refresh_token) && isDelegationIdentifier(v.client_id)
const html = (value:string) => value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!))
const consentScript = `document.getElementById('approve').addEventListener('click', async () => {
  const button = document.getElementById('approve');
  const error = document.getElementById('error');
  button.disabled = true;
  try {
    const session = await fetch('/api/session/me', {credentials:'same-origin',cache:'no-store'}).then(r => r.json());
    if (!session.csrf) throw new Error('Session expired. Sign in and reopen this page.');
    const body = JSON.parse(document.getElementById('consent').dataset.request);
    const response = await fetch('/api/session/oauth/authorize', {method:'POST',credentials:'same-origin',cache:'no-store',headers:{'content-type':'application/json','x-vc-csrf':session.csrf},body:JSON.stringify(body)});
    if (!response.ok) throw new Error('Authorization denied. Reopen this page and try again.');
    const result = await response.json();
    window.location.assign(result.redirect_uri);
  } catch (problem) { error.textContent = problem.message; button.disabled = false; }
});`

export function registerPublicClientRoutes(app:FastifyInstance, db:AuthDatabase, authenticate:AuthenticateFn, sessionId:(req:FastifyRequest)=>string|null):void {
  const actor=async(req:FastifyRequest,reply:FastifyReply)=>{
    const verdict=await authenticate(req)
    if(!verdict.ok){reply.code(verdict.status).send({error:verdict.error});return null}
    const sid=sessionId(req),tenantId=verdict.user.account?.tenantId
    if(!sid||!tenantId){reply.code(403).send({error:'session_required'});return null}
    return {user:verdict.user.name,tenantId,sid}
  }
  app.get('/api/session/oauth/consent.js',async(_req,reply)=>reply.header('cache-control','no-store').header('x-content-type-options','nosniff').type('application/javascript').send(consentScript))
  app.get<{Querystring:Record<string,unknown>}>('/api/session/oauth/authorize',async(req,reply)=>{
    reply.header('cache-control','no-store').header('referrer-policy','no-referrer').header('x-content-type-options','nosniff').header('content-security-policy',"default-src 'none'; script-src 'self'; connect-src 'self'; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'")
    const a=await actor(req,reply);if(!a)return
    let permissions:unknown
    try {permissions=typeof req.query.permissions==='string'?JSON.parse(req.query.permissions):null}catch{return reply.code(400).send({error:'invalid_request'})}
    const input={...req.query,permissions,decision:'approve'}
    if(!consent(input)||!input.permissions.every(p=>p.resource.tenantId===a.tenantId))return reply.code(400).send({error:'invalid_request'})
    try {
      const name=await db.identity.publicClientName(input.client_id,a.tenantId,input.redirect_uri)
      if(!name)return reply.code(403).send({error:'authorization_denied'})
      const items=input.permissions.map(p=>'<li>'+html(p.resource.type)+' / '+html(p.resource.id)+': '+p.scopes.map(html).join(', ')+'</li>').join('')
      const document='<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Authorize application</title><style>body{font:16px system-ui;max-width:42rem;margin:3rem auto;padding:0 1rem;line-height:1.5}button{font:inherit;padding:.6rem 1rem}li{margin:.4rem 0}#error{color:#a00}</style><main id="consent" data-request="'+html(JSON.stringify(input))+'"><h1>Authorize '+html(name)+'</h1><p>This application requests access to these exact resources in tenant '+html(a.tenantId)+'.</p><ul>'+items+'</ul><p>Access lasts five minutes. Reconnection expires after twelve hours or when this login session ends.</p><button id="approve" type="button">Approve access</button><p id="error" role="alert"></p></main><script src="/api/session/oauth/consent.js" defer></script></html>'
      return reply.type('text/html; charset=utf-8').send(document)
    }catch{return reply.code(503).send({error:'dependency_unavailable'})}
  })
  app.post<{Params:{id:string};Body:unknown}>('/api/session/applications/:id/redirect-uris',async(req,reply)=>{
    reply.header('cache-control','no-store')
    const a=await actor(req,reply);if(!a)return
    if(!isDelegationIdentifier(req.params.id)||!object(req.body)||!exact(req.body,['uri'])||!uri(req.body.uri))return reply.code(400).send({error:'invalid_request'})
    try {return await db.identity.registerPublicRedirect(a.user,a.tenantId,req.params.id,req.body.uri)?reply.code(201).send({uri:req.body.uri}):reply.code(404).send({error:'not_found'})}
    catch {return reply.code(503).send({error:'dependency_unavailable'})}
  })
  app.get<{Params:{id:string}}>('/api/session/applications/:id/redirect-uris',async(req,reply)=>{
    reply.header('cache-control','no-store')
    const a=await actor(req,reply);if(!a)return
    if(!isDelegationIdentifier(req.params.id))return reply.code(400).send({error:'invalid_request'})
    try {const uris=await db.identity.listPublicRedirects(a.user,a.tenantId,req.params.id);return uris??reply.code(404).send({error:'not_found'})}
    catch {return reply.code(503).send({error:'dependency_unavailable'})}
  })
  app.delete<{Params:{id:string};Body:unknown}>('/api/session/applications/:id/redirect-uris',async(req,reply)=>{
    reply.header('cache-control','no-store')
    const a=await actor(req,reply);if(!a)return
    if(!isDelegationIdentifier(req.params.id)||!object(req.body)||!exact(req.body,['uri'])||!uri(req.body.uri))return reply.code(400).send({error:'invalid_request'})
    try {return await db.identity.removePublicRedirect(a.user,a.tenantId,req.params.id,req.body.uri)?reply.code(204).send():reply.code(404).send({error:'not_found'})}
    catch {return reply.code(503).send({error:'dependency_unavailable'})}
  })
  app.get('/api/session/oauth/connections',async(req,reply)=>{
    reply.header('cache-control','no-store')
    const a=await actor(req,reply);if(!a)return
    try{return await db.identity.listPublicConnections(a.user,a.tenantId)}
    catch{return reply.code(503).send({error:'dependency_unavailable'})}
  })
  app.delete<{Params:{id:string}}>('/api/session/oauth/connections/:id',async(req,reply)=>{
    reply.header('cache-control','no-store')
    const a=await actor(req,reply);if(!a)return
    if(!isDelegationIdentifier(req.params.id))return reply.code(400).send({error:'invalid_request'})
    try{return await db.identity.revokePublicConnection(a.user,a.tenantId,req.params.id)?reply.code(204).send():reply.code(404).send({error:'not_found'})}
    catch{return reply.code(503).send({error:'dependency_unavailable'})}
  })
  app.post<{Body:unknown}>('/api/session/oauth/authorize',async(req,reply)=>{
    reply.header('cache-control','no-store')
    const a=await actor(req,reply);if(!a)return
    if(!consent(req.body)||!req.body.permissions.every(p=>p.resource.tenantId===a.tenantId))return reply.code(400).send({error:'invalid_request'})
    try {
      const code=await db.identity.authorizePublicClient({applicationId:req.body.client_id,redirectUri:req.body.redirect_uri,user:a.user,tenantId:a.tenantId,sessionSid:a.sid,challenge:req.body.code_challenge,audience:req.body.audience,permissions:req.body.permissions})
      if(!code)return reply.code(403).send({error:'authorization_denied'})
      const target=new URL(req.body.redirect_uri);target.searchParams.append('code',code);target.searchParams.append('state',req.body.state)
      return {redirect_uri:target.toString()}
    } catch {return reply.code(503).send({error:'dependency_unavailable'})}
  })
  app.options('/api/session/oauth/token',async(req,reply)=>{
    reply.header('cache-control','no-store').header('vary','Origin')
    const origin=req.headers.origin
    if(typeof origin!=='string'||!uri(origin+'/')||new URL(origin).origin!==origin)return reply.code(403).send()
    return reply.header('access-control-allow-origin',origin).header('access-control-allow-methods','POST, OPTIONS').header('access-control-allow-headers','content-type').code(204).send()
  })
  app.post<{Body:unknown}>('/api/session/oauth/token',async(req,reply)=>{
    reply.header('cache-control','no-store').header('vary','Origin')
    if(!tokenRequest(req.body)&&!refreshRequest(req.body))return reply.code(400).send({error:'invalid_request'})
    try {
      const origin=req.headers.origin
      if(origin!==undefined){
        const redirect=req.body.grant_type==='authorization_code'?req.body.redirect_uri:await db.identity.publicRefreshRedirect(req.body.refresh_token,req.body.client_id)
        if(typeof origin!=='string'||!redirect||new URL(redirect).origin!==origin)return reply.code(403).send({error:'origin_denied'})
        reply.header('access-control-allow-origin',origin)
      }
      const issued=req.body.grant_type==='authorization_code'?await db.identity.exchangePublicCode(req.body.code,req.body.client_id,req.body.redirect_uri,req.body.code_verifier):await db.identity.refreshPublicToken(req.body.refresh_token,req.body.client_id)
      return issued?{access_token:issued.accessToken,refresh_token:issued.refreshToken,token_type:'Bearer',expires_in:issued.expiresIn}:reply.code(400).send({error:'invalid_grant'})
    }
    catch {return reply.code(503).send({error:'dependency_unavailable'})}
  })
}
