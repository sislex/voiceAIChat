import { createHash, randomBytes, timingSafeEqual } from 'node:crypto'
import type { DelegatedPrincipal, DelegationPermission } from '../../../../packages/contracts/src/delegation.js'
import { BaseRepo } from './context.js'

const digest = (value: string) => createHash('sha256').update(value).digest('hex')
const secret = () => randomBytes(32).toString('base64url')
export const CODE_TTL_MS = 60_000
export const ACCESS_TTL_MS = 5 * 60_000
export const REFRESH_TTL_MS = 12 * 60 * 60_000
export const PUBLIC_CLIENT_REPLAY_RETENTION_MS = 24 * 60 * 60_000
export const PUBLIC_CLIENT_CLEANUP_BATCH = 100

export interface PublicAuthorization {
  applicationId: string
  redirectUri: string
  user: string
  tenantId: string
  sessionSid: string
  challenge: string
  audience: string
  permissions: DelegationPermission[]
}

interface CodeRow {
  application_id: string; redirect_uri: string; user_name: string; tenant_id: string
  session_sid: string; challenge: string; audience: string; permissions: string
  expires_at: number; consumed_at: number | null
}
interface AccessRow {
  grant_id: string; application_id: string; user_name: string; tenant_id: string
  session_sid: string; audience: string; permissions: string; issued_at: number; expires_at: number
}
interface FamilyRow {
  id:string; application_id:string; redirect_uri:string; user_name:string; tenant_id:string
  session_sid:string; audience:string; permissions:string; expires_at:number; revoked_at:number|null
}

export class PublicClientStore extends BaseRepo {
  async listConnections(user:string,tenantId:string) {
    return this.sql.all<{id:string;applicationId:string;applicationName:string;redirectUri:string;permissions:string;expiresAt:number}>(
      'SELECT f.id, f.application_id AS "applicationId", a.name AS "applicationName", f.redirect_uri AS "redirectUri", f.permissions, f.expires_at AS "expiresAt" FROM public_client_families f JOIN applications a ON a.id = f.application_id JOIN sessions s ON s.sid = f.session_sid AND s.user_name = f.user_name WHERE f.user_name = ? AND f.tenant_id = ? AND f.revoked_at IS NULL AND f.expires_at > ? AND a.revoked_at IS NULL AND s.revoked_at IS NULL AND s.expires_at > ? ORDER BY f.expires_at DESC, f.id',
      [user,tenantId,this.now(),this.now()])
  }
  async revokeConnection(user:string,tenantId:string,id:string):Promise<boolean> {
    const result=await this.sql.run('UPDATE public_client_families SET revoked_at = ? WHERE id = ? AND user_name = ? AND tenant_id = ? AND revoked_at IS NULL AND expires_at > ?',[this.now(),id,user,tenantId,this.now()])
    return result.changes===1
  }
  async cleanupExpired(batch=PUBLIC_CLIENT_CLEANUP_BATCH):Promise<{codes:number;access:number;families:number}> {
    if(!Number.isSafeInteger(batch)||batch<1||batch>PUBLIC_CLIENT_CLEANUP_BATCH)throw new Error('Invalid cleanup batch')
    const now=this.now()
    return this.sql.transaction(async()=>{
      const codes=await this.sql.run('DELETE FROM public_client_codes WHERE code_hash IN (SELECT code_hash FROM public_client_codes WHERE expires_at <= ? ORDER BY expires_at LIMIT ?)',[now,batch])
      const access=await this.sql.run('DELETE FROM public_client_access WHERE token_hash IN (SELECT token_hash FROM public_client_access WHERE expires_at <= ? ORDER BY expires_at LIMIT ?)',[now,batch])
      const families=await this.sql.run('DELETE FROM public_client_families WHERE id IN (SELECT id FROM public_client_families WHERE expires_at <= ? ORDER BY expires_at LIMIT ?)',[now-PUBLIC_CLIENT_REPLAY_RETENTION_MS,batch])
      return {codes:codes.changes,access:access.changes,families:families.changes}
    })
  }
  async clientName(applicationId:string,tenantId:string,redirectUri:string):Promise<string|null>{
    const row=await this.sql.get<{name:string}>('SELECT a.name FROM applications a JOIN public_client_redirects r ON r.application_id = a.id WHERE a.id = ? AND a.tenant_id = ? AND a.revoked_at IS NULL AND r.uri = ?',[applicationId,tenantId,redirectUri])
    return row?.name??null
  }
  async registerRedirect(owner: string, tenantId: string, applicationId: string, uri: string): Promise<boolean> {
    return this.sql.transaction(async () => {
      const app = await this.sql.get<{revoked_at: number | null}>('SELECT revoked_at FROM applications WHERE id = ? AND owner_user_name = ? AND tenant_id = ?', [applicationId, owner, tenantId])
      if (!app || app.revoked_at !== null) return false
      const count = await this.sql.get<{n: number}>('SELECT COUNT(*) AS n FROM public_client_redirects WHERE application_id = ?', [applicationId])
      if (Number(count?.n) >= 10) return false
      await this.sql.run('INSERT INTO public_client_redirects (application_id, uri) VALUES (?, ?) ON CONFLICT DO NOTHING', [applicationId, uri])
      return true
    })
  }
  async listRedirects(owner: string, tenantId: string, applicationId: string): Promise<string[] | null> {
    const app = await this.sql.get('SELECT 1 FROM applications WHERE id = ? AND owner_user_name = ? AND tenant_id = ?', [applicationId, owner, tenantId])
    if (!app) return null
    return (await this.sql.all<{uri: string}>('SELECT uri FROM public_client_redirects WHERE application_id = ? ORDER BY uri', [applicationId])).map(row => row.uri)
  }
  async removeRedirect(owner: string, tenantId: string, applicationId: string, uri: string): Promise<boolean> {
    const result = await this.sql.run('DELETE FROM public_client_redirects WHERE application_id = ? AND uri = ? AND EXISTS (SELECT 1 FROM applications WHERE id = ? AND owner_user_name = ? AND tenant_id = ? AND revoked_at IS NULL)', [applicationId, uri, applicationId, owner, tenantId])
    return result.changes === 1
  }
  async authorize(input: PublicAuthorization): Promise<string | null> {
    return this.sql.transaction(async () => {
      const live = await this.sql.get('SELECT 1 FROM applications a JOIN public_client_redirects r ON r.application_id = a.id JOIN sessions s ON s.sid = ? AND s.user_name = ? JOIN users u ON u.name = ? WHERE a.id = ? AND a.tenant_id = ? AND a.revoked_at IS NULL AND r.uri = ? AND s.revoked_at IS NULL AND s.expires_at > ? AND u.blocked = 0', [input.sessionSid, input.user, input.user, input.applicationId, input.tenantId, input.redirectUri, this.now()])
      if (!live) return null
      const code = secret()
      await this.sql.run('INSERT INTO public_client_codes (code_hash, application_id, redirect_uri, user_name, tenant_id, session_sid, challenge, audience, permissions, expires_at, consumed_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)', [digest(code), input.applicationId, input.redirectUri, input.user, input.tenantId, input.sessionSid, input.challenge, input.audience, JSON.stringify(input.permissions), this.now() + CODE_TTL_MS])
      return code
    })
  }
  private async issue(family:FamilyRow):Promise<{accessToken:string;refreshToken:string;expiresIn:number}> {
    const accessToken=secret(),refreshToken=secret(),now=this.now()
    await this.sql.run('INSERT INTO public_client_access (token_hash, grant_id, family_id, application_id, user_name, tenant_id, session_sid, audience, permissions, issued_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', [digest(accessToken), this.newId(), family.id, family.application_id, family.user_name, family.tenant_id, family.session_sid, family.audience, family.permissions, now, now+ACCESS_TTL_MS])
    await this.sql.run('INSERT INTO public_client_refresh (token_hash, family_id, consumed_at) VALUES (?, ?, NULL)',[digest(refreshToken),family.id])
    return {accessToken,refreshToken,expiresIn:ACCESS_TTL_MS/1000}
  }
  async exchange(code: string, applicationId: string, redirectUri: string, verifier: string): Promise<{accessToken: string;refreshToken:string; expiresIn: number} | null> {
    return this.sql.transaction(async () => {
      // Consume first. A bad verifier burns the code, so guessing cannot be retried.
      const claimed = await this.sql.run('UPDATE public_client_codes SET consumed_at = ? WHERE code_hash = ? AND consumed_at IS NULL', [this.now(), digest(code)])
      if (claimed.changes !== 1) return null
      const row = await this.sql.get<CodeRow>('SELECT * FROM public_client_codes WHERE code_hash = ?', [digest(code)])
      if (!row || row.expires_at <= this.now() || row.application_id !== applicationId || row.redirect_uri !== redirectUri) return null
      const computed = createHash('sha256').update(verifier, 'ascii').digest('base64url')
      if (!timingSafeEqual(Buffer.from(computed), Buffer.from(row.challenge))) return null
      const live = await this.sql.get('SELECT 1 FROM applications a JOIN public_client_redirects r ON r.application_id = a.id JOIN sessions s ON s.sid = ? AND s.user_name = ? JOIN users u ON u.name = ? WHERE a.id = ? AND a.tenant_id = ? AND a.revoked_at IS NULL AND r.uri = ? AND s.revoked_at IS NULL AND s.expires_at > ? AND u.blocked = 0', [row.session_sid, row.user_name, row.user_name, applicationId, row.tenant_id, redirectUri, this.now()])
      if (!live) return null
      const family:FamilyRow={id:this.newId(),application_id:applicationId,redirect_uri:redirectUri,user_name:row.user_name,tenant_id:row.tenant_id,session_sid:row.session_sid,audience:row.audience,permissions:row.permissions,expires_at:this.now()+REFRESH_TTL_MS,revoked_at:null}
      await this.sql.run('INSERT INTO public_client_families (id, application_id, redirect_uri, user_name, tenant_id, session_sid, audience, permissions, expires_at, revoked_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)',[family.id,family.application_id,family.redirect_uri,family.user_name,family.tenant_id,family.session_sid,family.audience,family.permissions,family.expires_at])
      return this.issue(family)
    })
  }
  async codeSubject(code:string):Promise<{user:string;tenantId:string}|null>{
    const row=await this.sql.get<{user_name:string;tenant_id:string}>('SELECT user_name, tenant_id FROM public_client_codes WHERE code_hash = ?',[digest(code)])
    return row?{user:row.user_name,tenantId:row.tenant_id}:null
  }
  async refresh(refreshToken:string,applicationId:string):Promise<{accessToken:string;refreshToken:string;expiresIn:number}|null>{
    return this.sql.transaction(async()=>{
      const token=await this.sql.get<{family_id:string;consumed_at:number|null}>('SELECT family_id, consumed_at FROM public_client_refresh WHERE token_hash = ?',[digest(refreshToken)])
      if(!token)return null
      if(token.consumed_at!==null){await this.sql.run('UPDATE public_client_families SET revoked_at = ? WHERE id = ? AND revoked_at IS NULL',[this.now(),token.family_id]);return null}
      const family=await this.sql.get<FamilyRow>('SELECT * FROM public_client_families WHERE id = ?',[token.family_id])
      if(!family||family.application_id!==applicationId||family.revoked_at!==null||family.expires_at<=this.now())return null
      const live=await this.sql.get('SELECT 1 FROM applications a JOIN sessions s ON s.sid = ? AND s.user_name = ? JOIN users u ON u.name = ? WHERE a.id = ? AND a.tenant_id = ? AND a.revoked_at IS NULL AND s.revoked_at IS NULL AND s.expires_at > ? AND u.blocked = 0',[family.session_sid,family.user_name,family.user_name,family.application_id,family.tenant_id,this.now()])
      if(!live)return null
      const claimed=await this.sql.run('UPDATE public_client_refresh SET consumed_at = ? WHERE token_hash = ? AND consumed_at IS NULL',[this.now(),digest(refreshToken)])
      if(claimed.changes!==1){await this.sql.run('UPDATE public_client_families SET revoked_at = ? WHERE id = ? AND revoked_at IS NULL',[this.now(),family.id]);return null}
      return this.issue(family)
    })
  }
  async refreshSubject(refreshToken:string):Promise<{user:string;tenantId:string}|null>{
    const row=await this.sql.get<{user_name:string;tenant_id:string}>('SELECT f.user_name, f.tenant_id FROM public_client_refresh r JOIN public_client_families f ON f.id = r.family_id WHERE r.token_hash = ?',[digest(refreshToken)])
    return row?{user:row.user_name,tenantId:row.tenant_id}:null
  }
  async refreshRedirect(refreshToken:string,applicationId:string):Promise<string|null>{
    const row=await this.sql.get<{redirect_uri:string}>('SELECT f.redirect_uri FROM public_client_refresh r JOIN public_client_families f ON f.id = r.family_id WHERE r.token_hash = ? AND f.application_id = ?',[digest(refreshToken),applicationId])
    return row?.redirect_uri??null
  }
  async introspect(token: string, audience: string): Promise<DelegatedPrincipal | null> {
    const row = await this.sql.get<AccessRow>('SELECT p.* FROM public_client_access p JOIN public_client_families f ON f.id = p.family_id JOIN applications a ON a.id = p.application_id JOIN sessions s ON s.sid = p.session_sid AND s.user_name = p.user_name JOIN users u ON u.name = p.user_name WHERE p.token_hash = ? AND p.audience = ? AND p.expires_at > ? AND f.revoked_at IS NULL AND f.expires_at > ? AND a.revoked_at IS NULL AND s.revoked_at IS NULL AND s.expires_at > ? AND u.blocked = 0', [digest(token), audience, this.now(), this.now(), this.now()])
    if (!row) return null
    return {kind: 'delegated', userId: row.user_name, tenantId: row.tenant_id, applicationId: row.application_id, grantId: row.grant_id, audience: row.audience, permissions: JSON.parse(row.permissions), issuedAt: row.issued_at, expiresAt: row.expires_at}
  }
}
