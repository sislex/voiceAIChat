import Fastify from 'fastify'
import {randomUUID} from 'node:crypto'
import {IDENTITY_PATHS, type IdentityEvent, type IdentitySessionRequest, type IdentitySessionResponse} from '../../../packages/contracts/src/index.js'
import {registerAuth} from './users/auth.js'
import {SessionHub} from './users/sessionHub.js'
import {IDENTITY_STORE_METHODS} from './store/methods.js'
import type {AuthDatabase} from './ports.js'
import type {AuthOptions} from './users/auth.js'
import {registerApplicationRoutes} from './users/applicationRoutes.js'
import {registerPublicClientRoutes} from './users/publicClientRoutes.js'
import {IDENTITY_DELEGATION_PATHS, isDelegationIdentifier, type DelegatedBillingAdmissionRequest} from '../../../packages/contracts/src/delegation.js'
export interface IdentityServerOptions extends AuthOptions {
 database:AuthDatabase;secret:string
 authorize:(header:string|undefined,scope:string)=>{ok:true}|{ok:false;status:401|403}
 authorizeDelegationAudience?:(header:string|undefined,audience:string)=>boolean
 registerComponent?:(app:ReturnType<typeof Fastify>)=>void
 accountFetch?:typeof fetch;coreUrl?:string
}
export async function buildIdentityServer(options:IdentityServerOptions){
 const app=Fastify({logger:false,bodyLimit:1024*1024})
 // A one-use in-process nonce carries Core's validated CORS decision across
 // Fastify injection without trusting a client-supplied public header.
 const forwardedCors=new Map<string,boolean>()
 app.addHook('onRequest',async req=>{
  const nonce=req.headers['x-identity-forwarded-request']
  req.corsAllowed=typeof nonce==='string'&&forwardedCors.get(nonce)===true
  if(typeof nonce==='string')forwardedCors.delete(nonce)
 })
 options.registerComponent?.(app)
 const hub=options.sessions??new SessionHub(),events:IdentityEvent[]=[],epoch=randomUUID();let sequence=0
 hub.onChange(event=>{events.push({...event,sequence:++sequence});if(events.length>1024)events.shift()})
 const {authenticate,sessionId}=await registerAuth(app,options.database,options.secret,{...options,sessions:hub})
 await options.database.identity.prunePublicClientRecords()
 const publicClientCleanup=setInterval(()=>{void options.database.identity.prunePublicClientRecords().catch(error=>app.log.error(error,'Public client cleanup failed'))},60_000)
 publicClientCleanup.unref()
 app.addHook('onClose',async()=>clearInterval(publicClientCleanup))
 registerApplicationRoutes(app,options.database,authenticate)
 registerPublicClientRoutes(app,options.database,authenticate,sessionId)
 app.post<{Body:{token?:unknown;audience?:unknown}}>(IDENTITY_DELEGATION_PATHS.introspect,async(req,reply)=>{
  reply.header('cache-control','no-store')
  const service=options.authorize(req.headers.authorization,'identity.delegation.introspect')
  if(!service.ok)return reply.code(service.status).send({error:'component_access_denied'})
  const {token,audience}=req.body??{}
  if(typeof token!=='string'||!token||token.length>16384||typeof audience!=='string'||!/^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,127}$/.test(audience))return reply.code(400).send({error:'invalid_request'})
  if(!options.authorizeDelegationAudience?.(req.headers.authorization,audience))return reply.code(403).send({error:'audience_access_denied'})
  try{const principal=await options.database.identity.introspectPublicAccess(token,audience)??await options.database.identity.introspectApplicationGrant(token,audience);return principal?{version:1,active:true,principal}:{version:1,active:false}}catch{return reply.code(503).send({error:'dependency_unavailable'})}
 })
 app.post<{Body:DelegatedBillingAdmissionRequest}>(IDENTITY_DELEGATION_PATHS.billingAdmission,async(req,reply)=>{
  reply.header('cache-control','no-store')
  const service=options.authorize(req.headers.authorization,'identity.delegation.billing-admission')
  if(!service.ok)return reply.code(service.status).send({error:'component_access_denied'})
  const input=req.body
  if(!input||Object.keys(input).sort().join(',')!=='applicationId,grantId,token'||
   typeof input.token!=='string'||!input.token||input.token.length>16384||
   ![input.applicationId,input.grantId].every(isDelegationIdentifier))return reply.code(400).send({error:'invalid_request'})
  try{
   const principal=await options.database.identity.introspectApplicationGrant(input.token,'core')
   if(!principal||!principal.permissions.some(permission=>permission.scopes.includes('execute'))||
    principal.applicationId!==input.applicationId||principal.grantId!==input.grantId)return {version:1,active:false}
   const [row,access]=await Promise.all([options.database.identity.getUser(principal.userId),
    options.database.identity.getAccountAccess(principal.userId,principal.tenantId)])
   if(!row||row.blocked||row.mustChangePassword||!access?.userId||access.tenant.id!==principal.tenantId)return {version:1,active:false}
   return {version:1,active:true,user:{userId:access.userId,tenantId:principal.tenantId,
    role:access.systemRole,capabilities:[...access.capabilities]}}
  }catch{return reply.code(503).send({error:'dependency_unavailable'})}
 })
 app.register(async internal=>{
  internal.addHook('onRequest',async(req,reply)=>{
   const path=req.url.split('?')[0]
   const scope=path===IDENTITY_PATHS.verify?'identity.verify':path===IDENTITY_PATHS.session?'identity.session':path===IDENTITY_PATHS.events?'identity.events':'identity.store'
   const verdict=options.authorize(req.headers.authorization,scope)
   if(!verdict.ok)return reply.code(verdict.status).send({error:'component_access_denied'})
  })
  internal.post<{Body:{request:Parameters<typeof authenticate>[0]}}>(IDENTITY_PATHS.verify,async(req,reply)=>{
   const input=req.body?.request;if(!input||typeof input.url!=='string'||typeof input.method!=='string'||!input.headers)return reply.code(400).send({error:'invalid_request'})
   return authenticate(input)
  })
  internal.post<{Body:IdentitySessionRequest}>(IDENTITY_PATHS.session,async(req,reply):Promise<IdentitySessionResponse|unknown>=>{
   const input=req.body
   if(!input||!/^\/api\/session(?:[/?]|$)/.test(input.url)||!['GET','HEAD','POST','PATCH','DELETE','PUT','OPTIONS'].includes(input.method)||typeof input.ip!=='string')return reply.code(400).send({error:'invalid_session_request'})
   const nonce=randomUUID();forwardedCors.set(nonce,input.corsAllowed===true)
   try {
    const result=await app.inject({method:input.method as 'POST',url:input.url,headers:{...input.headers,'x-identity-forwarded-request':nonce},remoteAddress:input.ip,...(input.body===undefined?{}:{payload:JSON.stringify(input.body)})})
    return {status:result.statusCode,headers:result.headers,body:result.body}
   }finally{forwardedCors.delete(nonce)}
  })
  internal.post<{Body:{method:string;args:unknown[]}}>(IDENTITY_PATHS.store,async(req,reply)=>{
   const {method,args}=req.body??{}
   if(!IDENTITY_STORE_METHODS.includes(method as typeof IDENTITY_STORE_METHODS[number])||!Array.isArray(args))return reply.code(400).send({error:'unknown_method'})
   const session=method==='revokeSessionById'?await options.database.identity.getSession(String(args[0])):null
   const methodFn=options.database.identity[method as keyof AuthDatabase['identity']] as (...args:unknown[])=>Promise<unknown>
   const result=await methodFn.apply(options.database.identity,args)
   if(session)hub.emit(session.user,session.sid)
   if(['assignUserTariff','setUserBlocked','setUserPassword','setUserRole','deleteUser','deleteUserData','revokeUserSessions','updateSession','untrustAllSessions'].includes(method)&&typeof args[0]==='string')hub.emit(args[0])
   if(method==='saveTariffPlan'&&result){for(const assignment of await options.database.identity.listTariffAssignments())if(assignment.tariffId===(result as {id:string}).id)hub.emit(assignment.userName)}
   // Preserve the repository's Map across the JSON boundary without exposing
   // transport-specific types to embedded consumers.
   return {result:result instanceof Map?Array.from(result.entries()):result??null}
  })
  internal.get<{Querystring:{after?:string;epoch?:string}}>(IDENTITY_PATHS.events,async(req)=>({epoch,sequence,events:events.filter(e=>e.sequence>(req.query.epoch===epoch?Number(req.query.after??0):0))}))
 })
 if(options.accountFetch&&options.coreUrl){
  for(const url of ['/api/me/profile','/api/me/security','/api/me/usage','/api/llm-access','/api/agents'])app.get(url,async(req,reply)=>{
   const headers=new Headers();for(const name of ['authorization','cookie','x-vc-csrf']){const value=req.headers[name];if(typeof value==='string')headers.set(name,value)}
   const response=await options.accountFetch!(new URL(req.url,options.coreUrl),{headers,redirect:'error',signal:AbortSignal.timeout(15000)})
   return reply.code(response.status).type(response.headers.get('content-type')??'application/json').send(Buffer.from(await response.arrayBuffer()))
  })
 }
 app.get('/v1/health',async()=>({ok:true,service:'identity'}))
 return {app,authenticate,hub}
}
