import type { DelegationPermission } from './delegation.js'

export interface PublicClientTokens {
  access_token: string
  refresh_token: string
  token_type: 'Bearer'
  expires_in: number
}
export interface PublicClientAuthorization {
  clientId: string
  redirectUri: string
  permissions: DelegationPermission[]
}
export interface PublicClientBrowser {
  authorize(): Promise<string>
  complete(callbackUrl: string): Promise<void>
  accessToken(): Promise<string>
  reconnect(): Promise<string>
  disconnect(): void
}
export interface PublicRedirectManagement {
  listRedirects(applicationId: string): Promise<string[]>
  registerRedirect(applicationId: string, uri: string): Promise<string>
  removeRedirect(applicationId: string, uri: string): Promise<void>
}
