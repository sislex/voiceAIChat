import Fastify, { type FastifyRequest } from 'fastify'
import { BillingError, BillingStore } from './store.js'
import type { BillingPolicy, BillingPrincipal } from '@sislexa/sdk'

export interface VerifiedUser { userId: string; tenantId: string; role: string; capabilities: readonly string[] }
export interface BillingAuthority {
  environmentId: string
  /** Resolve the live Identity account; service tokens cannot authenticate here. */
  verifyUser(authorization: string): Promise<VerifiedUser>
  /** Verify provider-local grants; return the actual token consumer, never a body field. */
  verifyComponent(authorization: string | undefined, scope: string): Promise<{ consumerId: string }>
}
const capability: Record<string, string> = { chat: 'chat.use', make: 'make.use', 'image-studio': 'image-studio.use',
  'web-reader': 'web-reader.use', 'playwright-reader': 'playwright-reader.use', projects: 'projects.use', machines: 'machines.use',
  stt: 'voice.stt', tts: 'voice.tts' }
function bearer(value: unknown): string {
  if (typeof value !== 'string' || !/^Bearer \S+$/.test(value) || value.length > 8192) throw new BillingError(401, 'user_session_required')
  return value
}
const idSchema = { type: 'string', minLength: 1, maxLength: 256, pattern: '^[A-Za-z0-9][A-Za-z0-9._:-]*$', not: { pattern: '[\\r\\n]' } }
const amountSchema = { type: 'integer', minimum: 0, maximum: 1_000_000_000_000 }
const empty = { type: 'object', additionalProperties: false, properties: {} }

export function buildBillingServer(store: BillingStore, authority: BillingAuthority) {
  const app = Fastify({ logger: false, bodyLimit: 16384, ajv: { customOptions: { removeAdditional: false, coerceTypes: false, useDefaults: false } } })
  app.addHook('onSend', async (_req, reply) => { reply.header('cache-control', 'no-store') })
  app.setErrorHandler((error, _req, reply) => {
    const code = error instanceof BillingError ? error.statusCode : error && typeof error === 'object' && 'validation' in error ? 400 : 503
    return reply.code(code).send({ error: error instanceof BillingError ? error.message : code === 400 ? 'invalid_request' : 'billing_unavailable' })
  })
  const user = async (req: FastifyRequest, delegated = false): Promise<VerifiedUser> => {
    const result = await authority.verifyUser(bearer(delegated ? req.headers['x-sislexa-user-authorization'] : req.headers.authorization))
    if (!result.userId || !result.tenantId) throw new BillingError(503, 'stable_identity_required')
    const hint = req.headers['x-sislexa-tenant-id']
    if (hint !== undefined && hint !== result.tenantId) throw new BillingError(403, 'tenant_access_denied')
    return result
  }
  const executor = async (req: FastifyRequest<{ Params: { id: string } }>) => {
    const actor = await authority.verifyComponent(req.headers.authorization, 'billing.execute')
    return store.executorPrincipal(authority.environmentId, actor.consumerId, req.params.id)
  }
  app.get('/api/health', async () => ({ ok: true, applicationId: 'billing' }))
  app.get('/api/billing/account', async req => {
    const account = await user(req)
    return { tenantId: account.tenantId, ...store.balance(authority.environmentId, account.tenantId) }
  })
  app.put<{ Body: { policy: BillingPolicy; expectedRevision: number } }>('/api/billing/policy', {
    schema: { body: { type: 'object', required: ['policy', 'expectedRevision'], additionalProperties: false, properties: {
      policy: { type: 'object', required: ['monthlyMicroUsd', 'monthlyRequests', 'maxConcurrent'], additionalProperties: false,
        properties: Object.fromEntries(['monthlyMicroUsd', 'monthlyRequests', 'maxConcurrent'].map(key => [key, { anyOf: [amountSchema, { type: 'null' }] }])) },
      expectedRevision: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER - 1 }
    } } }
  }, async req => {
    const account = await user(req)
    if (account.role !== 'admin') throw new BillingError(403, 'administrator_required')
    return { revision: store.setPolicy(authority.environmentId, account.tenantId, req.body.policy, req.body.expectedRevision) }
  })
  app.post<{ Body: { operationId: string; maxMicroUsd: number; expiresAt: number; originModuleId: string } }>('/v1/billing/reservations', {
    schema: { body: { type: 'object', additionalProperties: false, required: ['operationId', 'maxMicroUsd', 'expiresAt', 'originModuleId'], properties: {
      operationId: idSchema, maxMicroUsd: amountSchema, expiresAt: { type: 'integer', minimum: 0, maximum: Number.MAX_SAFE_INTEGER },
      originModuleId: { type: 'string', enum: Object.keys(capability) }
    } } }
  }, async (req, reply) => {
    const actor = await authority.verifyComponent(req.headers.authorization, 'billing.reserve')
    const account = await user(req, true), origin = req.body.originModuleId
    if (actor.consumerId !== 'core' && actor.consumerId !== origin) throw new BillingError(403, 'origin_not_allowed')
    if (!account.capabilities.includes(capability[origin]!)) throw new BillingError(403, 'product_access_denied')
    const principal: BillingPrincipal = { userId: account.userId, tenantId: account.tenantId, environmentId: authority.environmentId,
      actorClientId: actor.consumerId, originModuleId: origin }
    return reply.code(201).send(store.reserve(principal, req.body))
  })
  for (const action of ['start', 'uncertain', 'release'] as const) {
    app.post<{ Params: { id: string }; Body: Record<string, never> }>('/v1/billing/reservations/:id/'+action, { schema: { body: empty } }, async req => {
      const principal = await executor(req)
      if (action === 'start') {
        const account = await user(req, true)
        if (account.userId !== principal.userId || account.tenantId !== principal.tenantId) throw new BillingError(404, 'reservation_not_found')
        if (!account.capabilities.includes(capability[principal.originModuleId]!)) throw new BillingError(403, 'product_access_denied')
      }
      return store.transition(principal, req.params.id, action)
    })
  }
  app.post<{ Params: { id: string }; Body: { eventId: string; actualMicroUsd: number } }>('/v1/billing/reservations/:id/settle', {
    schema: { body: { type: 'object', additionalProperties: false, required: ['eventId', 'actualMicroUsd'], properties: { eventId: idSchema, actualMicroUsd: amountSchema } } }
  }, async req => {
    const principal = await executor(req)
    return store.settle(principal, req.params.id, req.body.eventId, req.body.actualMicroUsd)
  })
  return app
}
