import { afterEach, describe, expect, it, vi } from 'vitest'
import { mkdtempSync, writeFileSync, rmSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import Fastify from 'fastify'
import { createComponentRuntime } from '@sislexa/component-runtime'
import * as readerModule from '../module.js'
import { buildPlaywrightReaderServer } from './server.js'
const cleanups: (() => unknown | Promise<unknown>)[] = []
afterEach(async () => { for (const close of cleanups.splice(0).reverse()) await close(); vi.unstubAllEnvs(); vi.restoreAllMocks() })

describe('managed standalone component configuration', () => {
  it('uses configured dependencies, separates user and component credentials, and rejects legacy RPC access', async () => {
    const root = mkdtempSync(join(tmpdir(), 'sislexa-playwright-reader-')); cleanups.push(() => rmSync(root, { recursive: true, force: true }))
    const contractFile = fileURLToPath(new URL('../../component-contract.json', import.meta.url))
    const contract = JSON.parse(readFileSync(contractFile, 'utf8')) as { dependencies: { applicationId: string; scopes: string[] }[] }
    const configFile = join(root, 'component.json')
    const dependencies: { applicationId: string; url: string; tokenFile: string }[] = []
    let coreToken = ''
    for (const required of contract.dependencies) {
      const providerFile = join(root, required.applicationId + '.contract.json'), settingsFile = join(root, required.applicationId + '.config.json')
      writeFileSync(providerFile, JSON.stringify({ schemaVersion: 1, applicationId: required.applicationId, provides: required.scopes, legacyScopes: [], dependencies: [] }))
      writeFileSync(settingsFile, JSON.stringify({ schemaVersion: 1, environmentId: 'test', registryDirectory: join(root, required.applicationId), grants: [{ consumerId: 'playwright-reader', scopes: required.scopes, maxTtlSeconds: 3600 }], legacyScopes: [], dependencies: [] }))
      const runtime = await createComponentRuntime({ contractFile: providerFile, configFile: settingsFile, metadata: { applicationId: required.applicationId, version: required.applicationId === 'core' ? '0.1.312' : '1.1.0', apiVersion: '1.1.0', dataVersion: '1.0.0', commit: 'a'.repeat(40) } })
      const provider = Fastify(); runtime.register(provider); cleanups.push(() => provider.close())
      provider.post<{ Body: { headers?: { authorization?: string } } }>('/internal/whoami', async (req, reply) => {
        const result = runtime.authorize(req.headers.authorization, 'identity.verify')
        if (!result.ok) return reply.code(result.status).send({ error: 'denied' })
        return req.body.headers?.authorization === 'Bearer user-session' ? { ok: true, user: { name: 'ann', role: 'developer' } } : { ok: false, status: 401, error: 'unauthorized' }
      })
      provider.post('/*', async () => ({ result: null }))
      const url = await provider.listen({ host: '127.0.0.1', port: 0 })
      const token = runtime.registry!.issue('playwright-reader', required.scopes, 3600).token
      if (required.applicationId === 'core') coreToken = token
      const tokenFile = join(root, required.applicationId + '.token'); writeFileSync(tokenFile, token, { mode: 0o600 })
      dependencies.push({ applicationId: required.applicationId, url, tokenFile })
    }
    writeFileSync(configFile, JSON.stringify({ schemaVersion: 1, environmentId: 'test', registryDirectory: join(root, 'own-registry'), grants: [{ consumerId: 'core', scopes: ['playwright-reader.service'], maxTtlSeconds: 3600 }], legacyScopes: [], dependencies }))
    for (const [key, value] of Object.entries({ VC_APPLICATION_VERSION: '1.1.0', VC_APPLICATION_API_VERSION: '1.1.0', VC_APPLICATION_COMMIT: 'b'.repeat(40) })) vi.stubEnv(key, value)
    const createModule = vi.spyOn(readerModule, 'createPlaywrightReaderModule')
    const { app } = await buildPlaywrightReaderServer({ config: { host: '127.0.0.1', port: 0, coreUrl: 'http://invalid', internalToken: 'legacy', runnerFacingBase: 'http://invalid', version: '1.1.0', componentConfigPath: configFile } })
    cleanups.push(() => app.close())
    expect(createModule.mock.calls[0][0].runnerFacingBase).toBe(dependencies.find(d => d.applicationId === 'core')!.url)
    expect((await app.inject({ url: '/v1/ready' })).statusCode).toBe(200)
    expect((await app.inject({ url: '/v1/component' })).json()).toMatchObject({ application: { applicationId: 'playwright-reader', version: '1.1.0' }, environmentId: 'test' })
    expect((await app.inject({ method: 'POST', url: '/api/browser/missing/start', headers: { authorization: 'Bearer ' + coreToken } })).statusCode).toBe(401)
    const issuer = await createComponentRuntime({ contractFile, configFile, metadata: { applicationId: 'playwright-reader', version: '1.1.0', apiVersion: '1.1.0', dataVersion: '1.0.0', commit: 'b'.repeat(40) } })
    cleanups.push(() => issuer.close())
    const issued = issuer.registry!.issue('core', ['playwright-reader.service'], 60)
    const request = { method: 'POST' as const, url: '/v1/component/authorize', payload: { scopes: ['playwright-reader.service'] } }
    expect((await app.inject({ ...request, headers: { authorization: 'Bearer legacy' } })).statusCode).toBe(401)
    expect((await app.inject({ ...request, headers: { authorization: 'Bearer ' + coreToken } })).statusCode).toBe(401)
    expect((await app.inject({ ...request, headers: { authorization: 'Bearer ' + issued.token } })).statusCode).toBe(200)
    expect((await app.inject({ method: 'POST', url: '/internal/playwright-reader/service', headers: { authorization: 'Bearer legacy' }, payload: { method: 'unknown', args: [] } })).statusCode).toBe(401)
    issuer.registry!.revoke(issued.principal.tokenId)
    expect((await app.inject({ ...request, headers: { authorization: 'Bearer ' + issued.token } })).statusCode).toBe(401)
  })
})
