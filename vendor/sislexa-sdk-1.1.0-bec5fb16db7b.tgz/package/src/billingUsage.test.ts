import { expect, it } from 'vitest'
import { parseBillingUsageEvidence, priceUsageMicroUsd } from './billingUsage.js'
const tokens = { inputTokens: 101, outputTokens: 3, cacheReadTokens: 99, cacheWriteTokens: 7 }
const prices = { inputTokens: 200_000, outputTokens: 1_200_000, cacheReadTokens: 20_000, cacheWriteTokens: 250_000 }

it('keeps provider charges distinct from estimates and requires a complete immutable price snapshot', () => {
  const provider = { model: 'test-model', tokens, costSource: 'provider' }
  const parsed = parseBillingUsageEvidence(provider)
  expect(parsed).toEqual(provider)
  expect(parsed.tokens).not.toBe(tokens)
  expect(parseBillingUsageEvidence({ ...provider, costSource: 'estimate', prices }).prices).toEqual(prices)
  for (const patch of [{ prices }, { costSource: 'estimate' }, { costSource: 'free' },
    { tokens: { ...tokens, inputTokens: -1 } }, { tokens: { ...tokens, outputTokens: 0.1 } },
    { tokens: { ...tokens, totalTokens: 500 } }, { model: '' }, { userId: 'forged' }]) {
    expect(() => parseBillingUsageEvidence({ ...provider, ...patch })).toThrow()
  }
})

it('prices disjoint usage using integer arithmetic and rounds only the final amount', () => {
  expect(priceUsageMicroUsd(tokens, prices)).toBe(28)
  expect(priceUsageMicroUsd({ inputTokens: 1, outputTokens: 1, cacheReadTokens: 0, cacheWriteTokens: 0 },
    { inputTokens: 1, outputTokens: 1, cacheReadTokens: 0, cacheWriteTokens: 0 })).toBe(1)
  expect(priceUsageMicroUsd({ inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }, prices)).toBe(0)
  expect(() => priceUsageMicroUsd({ ...tokens, inputTokens: Number.MAX_SAFE_INTEGER }, { ...prices, inputTokens: 1_000_000_000_000 })).toThrow('range')
})
