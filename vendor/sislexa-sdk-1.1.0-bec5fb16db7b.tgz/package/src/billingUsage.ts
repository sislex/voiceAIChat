import { BILLING_MAX_AMOUNT, billingAmount } from './billing.js'
import { assertPlatformIdentifier } from './platformOperation.js'
import type { PlatformTokenCounts } from './platformUsage.js'

/** Rates are integer micro-USD per million tokens, captured before settlement. */
export type BillingTokenPrices = PlatformTokenCounts
export interface BillingUsageEvidence {
  model: string
  tokens: PlatformTokenCounts
  costSource: 'provider' | 'estimate'
  prices?: BillingTokenPrices
}
const fields = ['inputTokens', 'outputTokens', 'cacheReadTokens', 'cacheWriteTokens'] as const
function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw Error('Invalid usage evidence')
  return value as Record<string, unknown>
}
function counters(value: unknown): PlatformTokenCounts {
  const source = record(value)
  if (Object.keys(source).some(key => !(fields as readonly string[]).includes(key))) throw Error('Unknown token field')
  for (const key of fields) {
    if (!Number.isSafeInteger(source[key]) || Number(source[key]) < 0) throw Error('Invalid token value')
  }
  return Object.fromEntries(fields.map(key => [key, source[key]])) as unknown as PlatformTokenCounts
}
/** Numeric validation does not authenticate the producer or establish a model price. */
export function parseBillingUsageEvidence(value: unknown): BillingUsageEvidence {
  const source = record(value)
  if (Object.keys(source).some(key => !['model', 'tokens', 'costSource', 'prices'].includes(key))) throw Error('Unknown usage field')
  assertPlatformIdentifier(source.model, 'model')
  const tokens = counters(source.tokens)
  if (source.costSource === 'provider' && source.prices === undefined) return { model: source.model, tokens, costSource: 'provider' }
  if (source.costSource !== 'estimate') throw Error('Invalid cost source')
  const prices = counters(source.prices)
  for (const key of fields) if (!billingAmount(prices[key])) throw Error('Invalid token price')
  return { model: source.model, tokens, costSource: 'estimate', prices }
}
/** Round the complete charge upward once; never round each token or use float arithmetic. */
export function priceUsageMicroUsd(tokens: PlatformTokenCounts, prices: BillingTokenPrices): number {
  const checkedTokens = counters(tokens), checkedPrices = counters(prices)
  let numerator = 0n
  for (const key of fields) {
    if (!billingAmount(checkedPrices[key])) throw Error('Invalid token price')
    numerator += BigInt(checkedTokens[key]) * BigInt(checkedPrices[key])
  }
  const amount = (numerator + 999_999n) / 1_000_000n
  if (amount > BigInt(BILLING_MAX_AMOUNT)) throw Error('Usage price exceeds ledger range')
  return Number(amount)
}
