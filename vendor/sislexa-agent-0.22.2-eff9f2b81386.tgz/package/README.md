# Sislexa Agent

The independent machine companion: command execution, files, optional PTY,
telemetry, VPN recovery guard, installers, tray and device enrollment client.
The server remains responsible for user authorization and machine policy.

The agent sends a WebSocket ping every 15 seconds. After 30 seconds without an
inbound message, ping or pong, it terminates the socket and reconnects using the
existing exponential backoff (1 second initially, capped at 30 seconds). It logs
`нет ответа сервера N с, переподключение` once per silent connection. Heartbeat
timers are cleared on close and shutdown. Embedders and tests can override
`heartbeatIntervalMs` and `heartbeatTimeoutMs` in the third `startConnection`
argument. This also recovers from a lost network route without restarting the
agent process; release rollout and verification on the target machine remain
operator tasks.

## Development

Use Node 22 or later. Run `npm run setup`, then `npm run gate`.
For a focused local check, run `npm run gate:quick -- --base <sha>`. It uses
the Git diff from that revision to run changed tests and tests related to changed
sources. Agent changes also run runtime/contracts typechecks, the agent build and
artifact smoke; tray and login typechecks/builds run only when their directories
change. Run specific tests with `npm run test:files -- <file> [...]`; files are
automatically dispatched to the root, agent, contracts, tray or login Vitest
configuration. Both focused commands print `GATE-FAILED-TESTS` JSON on failure.
Run `npm -w @voicechat/agent start -- --server wss://host/agent --token <machine-token>`.
`VC_AGENT_SERVER` and `VC_AGENT_TOKEN` are equivalent settings. Tokens are issued
by the target server; do not commit them. All API access uses that server origin.

Tray and login application are separate Electron installations. Run
`npm --prefix apps/agent-tray run dev` or
`npm --prefix apps/login-application run dev` after setup.
The renderer never receives the persistent machine token.

Project Git access verification reads the remote, then creates a private temporary
repository, fetches the refspec's source branch with `--depth 1`, and runs
`git push --dry-run <url> FETCH_HEAD:<destination ref>` there. It never updates
the remote and removes the temporary repository on success or failure. A single
branch or `source:destination` refspec is supported; short destinations resolve
under `refs/heads/`. Git usage errors (`not a git repository`, unmatched source
refspec, or missing remote ref) return `invalid_repository` with access `unknown`,
separately from `insufficient_permissions` for a denied push (including HTTP 403).
Credentials remain in the configured helper and raw Git output is not returned.

## Releases and compatibility

Runtime 0.22.0 implements contracts 1.2.0 and consumes Core API 1.x. Existing
0.19 clients remain wire-compatible. Protocol additions require versioned contracts
and minimum feature versions. `packages/contracts` is the protocol source of truth.

Environment links require capability `environment-link: 0.21.0`.
VPN-backed environment links require capability `environment-vpn: 0.22.0`.
`tunnel.listen` accepts optional `host` (`loopback` by default) and `port`
(omitted or zero selects an ephemeral port). `docker-host` binds the Linux
`docker0` IPv4 gateway, failing if unavailable; Docker Desktop on macOS/Windows
uses `127.0.0.1`. A taken fixed port returns `tunnel.error` with `Port is busy`.
`vpn` binds the machine's Tailscale IPv4 and fails closed when Tailscale has no
IPv4 address. Telemetry and VPN inspect observations include Tailscale addresses
and the normalized MagicDNS `hostName`; unavailable Tailscale reports empty
addresses and a null name.
Both directions accept `tunnel.pause` and `tunnel.resume`, scoped by tunnel and
connection IDs. TCP write queues request a pause at 4 MiB and resume after drain;
readers honor peer pauses. Each connection also pauses TCP reads while 4 MiB of
payload is awaiting WebSocket send completion. The threshold is a high-water
mark, not a hard cap: in-flight frames can arrive after a pause. Core must relay
flow-control messages for environment links before operator commissioning.

`npm run build` produces standalone `dist/voicechat-agent.cjs` and VPN guard,
plus the Electron bundles. `npm run pack:release` packs clean committed inputs,
source provenance and integrity. Core serves the released agent bytes without
compiling this repository. Native PTY is optional; command execution still works
when it is unavailable. On macOS `npm --prefix apps/agent-tray run dist` and
`npm --prefix apps/login-application run dist` create DMG installers. Developer
certificate signing/notarization is a separate distribution prerequisite.

Tests for this runtime, protocol and installers live here. Tests of server token
validation, user isolation and live server integration remain with Core.
