// WS-соединение с сервером: регистрация токеном, приём exec.*, реконнект с backoff.
// Побочные эффекты вынесены в handlers, чтобы ядро переиспользовалось и в CLI,
// и в трей-приложении (Electron).

import WebSocket from 'ws'
import { attachTunnelFlow, tunnelBindHost, TUNNEL_HIGH_WATER_MARK } from './tunnel.js'
import { createSystemVpn } from './vpn/system.js'
import { createServer, connect as connectSocket, isIP, type Server, type Socket } from 'node:net'
import { lookup as dnsLookup } from 'node:dns'
import { randomUUID } from 'node:crypto'
import {
  evaluateAgentCommand,
  AGENT_VERSION,
  DEFAULT_AGENT_POLICY,
  type AgentPolicy,
  type AgentToServer,
  type ServerToAgent
} from '@sislexa/agent-contracts'
import type { AgentConfig } from './config.js'
import { runCommand, cancelCommand, runningCount } from './exec.js'
import { startPty, writePty, resizePty, killPty, ptyCount } from './pty.js'
import { fsDelete, fsDeleteFileSafe, fsTrash, fsList, fsMkdir, fsRead, fsReadPrefix, fsRename, fsWrite } from './fileOps.js'
import { createTelemetryCollector, withVpnTelemetry } from './telemetry.js'
import { resolveShellInfo } from './platform.js'
import { ensureImageDir, localAddresses, startImageHost, type ImageHost } from './imageHost.js'
import { handleGitAccess } from './gitAccess.js'
import { fetchLocal } from './httpProxy.js'

const BACKOFF_START_MS = 1_000
const BACKOFF_MAX_MS = 30_000
/** Период отправки телеметрии машины на сервер. */
const TELEMETRY_INTERVAL_MS = 30_000

interface LocalTunnel { server: Server; sockets: Map<string, Socket> }
const localTunnels = new Map<string, LocalTunnel>()
const tunnelFlows = new WeakMap<Socket, ReturnType<typeof attachTunnelFlow>>()
const targetSockets = new Map<string, Socket>()
const tunnelKey = (tunnelId: string, connectionId: string): string => `${tunnelId}:${connectionId}`
function closeTunnel(tunnelId: string): void {
  const local = localTunnels.get(tunnelId)
  if (local) {
    for (const socket of local.sockets.values()) socket.destroy()
    local.server.close(); localTunnels.delete(tunnelId)
  }
  for (const [key, socket] of targetSockets) if (key.startsWith(tunnelId + ':')) { socket.destroy(); targetSockets.delete(key) }
}

/** Статус соединения агента для индикации в UI. */
export type AgentStatus = 'connecting' | 'online' | 'offline' | 'stopped'

/** Колбэки жизненного цикла соединения (все необязательны). */
export interface AgentHandlers {
  onStatus?(status: AgentStatus): void
  onRegistered?(name: string, id?: string): void
  onDenied?(reason: string): void
  onExec?(command: string): void
  onExecDone?(command: string, exitCode: number | null, timedOut: boolean, ms: number): void
  /** Сервер сообщил, что доступна новая версия агента. */
  onUpdateAvailable?(version: string): void
  /** Текущая политика изменилась (регистрация/пуш сервера/локальная правка). */
  onPolicy?(policy: AgentPolicy): void
  /** Свободная строка лога (для консоли/журнала). */
  onLog?(line: string): void
}

/** Управление запущенным соединением. */
export interface AgentConnection {
  /** Остановить: закрыть сокет, отменить reconnect (статус → stopped). */
  stop(): void
  /** Текущая политика возможностей машины. */
  getPolicy(): AgentPolicy
  /** Задать политику локально и отправить её серверу (правка с машины). */
  setPolicy(policy: AgentPolicy): void
}

/** Дефолтные handlers для CLI: печать в консоль, выход при отказе. */
export function consoleHandlers(): AgentHandlers {
  return {
    onRegistered: (name) => console.log(`[agent] подключён как «${name}»`),
    onDenied: (reason) => {
      console.error(`[agent] сервер отклонил подключение: ${reason}`)
      process.exit(1)
    },
    // Commands can be multi-kilobyte scripts; the log keeps their head only (it grew to gigabytes).
    onExec: (command) => console.log(`[agent] $ ${command.length > 300 ? `${command.slice(0, 300)}… (${command.length} chars)` : command}`),
    onExecDone: (_c, exitCode, timedOut, ms) =>
      console.log(
        `[agent] → exit ${exitCode ?? '?'}${timedOut ? ' (таймаут)' : ''} (${(ms / 1000).toFixed(1)}с)`
      ),
    onUpdateAvailable: (version) =>
      console.log(`[agent] доступно обновление v${version} — перекачайте и перезапустите скрипт агента`),
    onLog: (line) => console.log(`[agent] ${line}`)
  }
}

/** Heartbeat timing overrides for embedders and tests. */
export interface ConnectionOptions {
  heartbeatIntervalMs?: number
  heartbeatTimeoutMs?: number
}

export function startConnection(config: AgentConfig, handlers: AgentHandlers = {}, options: ConnectionOptions = {}): AgentConnection {
  const heartbeatIntervalMs = options.heartbeatIntervalMs ?? 15_000
  const heartbeatTimeoutMs = options.heartbeatTimeoutMs ?? 30_000
  if (![heartbeatIntervalMs, heartbeatTimeoutMs].every(value => Number.isFinite(value) && value > 0)) {
    throw new RangeError('Heartbeat intervals must be positive finite milliseconds')
  }
  let stopHeartbeat = (): void => {}
  let backoff = BACKOFF_START_MS
  let stopped = false
  let cleanupExclusive = false
  let socket: WebSocket | null = null
  let reconnectTimer: ReturnType<typeof setTimeout> | null = null
  let policy: AgentPolicy = DEFAULT_AGENT_POLICY
  // Ссылка на send текущего соединения — для отправки вне обработчика сообщений.
  let activeSend: ((msg: AgentToServer) => void) | null = null
  let telemetryTimer: ReturnType<typeof setInterval> | null = null
  // Раздача картинок поднимается один раз на процесс и переживает реконнекты;
  // при каждой регистрации сообщаем серверу порт и текущие адреса машины.
  let imageHost: ImageHost | null = null
  // Разрешаем shell один раз на процесс — и логируем деградацию/игнор override
  // сразу, не дожидаясь первого подключения (пользователю важно увидеть это
  // в логе агента, даже если WS ещё не поднялся).
  const shellInfo = resolveShellInfo()
  if (shellInfo.ignoredOverride) {
    handlers.onLog?.(
      `переменная SHELL/VC_PTY_SHELL="${shellInfo.ignoredOverride}" — Unix-путь, на Windows не применяется; использую ${shellInfo.shell}`
    )
  }
  if (shellInfo.degraded) {
    handlers.onLog?.(
      `bash.exe не найден (PATH и стандартные пути Git for Windows) — команды и терминал идут через ${shellInfo.shell}, ` +
        'функциональность ограничена. Поставьте Git for Windows для полноценной работы.'
    )
  }
  const collectTelemetry = createTelemetryCollector(config.rootDir, shellInfo)
  const vpn = createSystemVpn(config.rootDir, config.serverUrl)

  /** Описание раздачи для agent.register (адреса пересчитываем каждый раз: IP меняется). */
  const imageHostInfo = (): { port: number; hosts: string[] } | undefined => {
    if (!imageHost) return undefined
    ensureImageDir(config.rootDir) // каталог могли удалить между подключениями
    return { port: imageHost.port, hosts: localAddresses() }
  }

  /** Собирает и шлёт телеметрию (ошибки сбора не критичны — просто пропускаем). */
  const pushTelemetry = async (send: (msg: AgentToServer) => void): Promise<void> => {
    try {
      send({ t: 'agent.telemetry', telemetry: withVpnTelemetry(await collectTelemetry(), await vpn.handle({ action: 'inspect' })) })
    } catch {
      /* телеметрия best-effort */
    }
  }

  /** Останавливает периодическую отправку телеметрии. */
  const stopTelemetry = (): void => {
    if (telemetryTimer) clearInterval(telemetryTimer)
    telemetryTimer = null
  }

  /** Применяет политику локально (+ уведомляет UI); при emit — шлёт серверу. */
  const applyPolicy = (p: AgentPolicy, emit: boolean): void => {
    policy = p
    handlers.onPolicy?.(p)
    if (emit) activeSend?.({ t: 'agent.setPolicy', policy: p })
  }

  const connect = (): void => {
    handlers.onStatus?.('connecting')
    // Самоподписанный TLS (Caddy `tls internal`): VC_AGENT_INSECURE_TLS=1 отключает
    // проверку сертификата для wss:// — иначе Node ws рвёт соединение. Нужно на телефоне.
    const wsOpts =
      process.env.VC_AGENT_INSECURE_TLS && config.serverUrl.startsWith('wss:')
        ? { rejectUnauthorized: false }
        : undefined
    const pinnedControlIp = process.env.VC_VPN_CONTROL_IP
    const controlHost = new URL(config.serverUrl).hostname
    // Keep TLS hostname verification while reconnecting without direct DNS.
    const lookup: typeof dnsLookup = pinnedControlIp && isIP(pinnedControlIp)
      ? ((hostname: string, options: unknown, callback: (...args: unknown[]) => void) => {
          if (hostname !== controlHost) { callback(new Error('unexpected control host')); return }
          const address = { address: pinnedControlIp, family: isIP(pinnedControlIp) }
          if ((options as { all?: boolean })?.all) callback(null, [address])
          else callback(null, address.address, address.family)
        }) as typeof dnsLookup
      : dnsLookup
    const ws = new WebSocket(config.serverUrl, { ...wsOpts, lookup })
    socket = ws
    const send = (msg: AgentToServer, done?: () => void): void => {
      if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(msg), () => done?.())
      else done?.()
    }
    activeSend = send

    let heartbeatTimer: ReturnType<typeof setInterval> | null = null
    let silenceTimer: ReturnType<typeof setTimeout> | null = null
    let lastInbound = 0
    const clearHeartbeat = (): void => {
      if (heartbeatTimer !== null) clearInterval(heartbeatTimer)
      if (silenceTimer !== null) clearTimeout(silenceTimer)
      heartbeatTimer = null
      silenceTimer = null
    }
    stopHeartbeat = clearHeartbeat
    const receivedFrame = (): void => {
      if (stopped || ws.readyState !== WebSocket.OPEN) return
      lastInbound = performance.now()
      if (silenceTimer !== null) clearTimeout(silenceTimer)
      silenceTimer = setTimeout(() => {
        clearHeartbeat()
        if (stopped || ws.readyState !== WebSocket.OPEN) return
        const seconds = Math.round((performance.now() - lastInbound) / 1000)
        handlers.onLog?.(`нет ответа сервера ${seconds} с, переподключение`)
        ws.terminate() // The close event enters the existing reconnect backoff.
      }, heartbeatTimeoutMs)
    }
    ws.on('pong', receivedFrame)
    ws.on('ping', receivedFrame)

    ws.on('open', () => {
      if (stopped) { ws.terminate(); return }
      receivedFrame()
      heartbeatTimer = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) ws.ping()
      }, heartbeatIntervalMs)
      const images = imageHostInfo()
      send({
        t: 'agent.register',
        token: config.token,
        version: AGENT_VERSION,
        ...(images ? { imageHost: images } : {})
      })
    })

    ws.on('message', (data) => {
      receivedFrame()
      let msg: ServerToAgent
      try {
        msg = JSON.parse(data.toString()) as ServerToAgent
      } catch {
        return
      }
      switch (msg.t) {
        case 'vpn.request':
          void vpn.handle(msg.request).then(observation => send({ t: 'vpn.result', requestId: msg.requestId, observation }))
          break
        case 'agent.registered':
          backoff = BACKOFF_START_MS
          applyPolicy(msg.policy ?? DEFAULT_AGENT_POLICY, false)
          handlers.onStatus?.('online')
          if (msg.id) handlers.onRegistered?.(msg.name, msg.id)
          else handlers.onRegistered?.(msg.name)
          // Телеметрия: сразу снимок и далее по таймеру (пере-регистрация обнуляет).
          stopTelemetry()
          void pushTelemetry(send)
          telemetryTimer = setInterval(() => void pushTelemetry(send), TELEMETRY_INTERVAL_MS)
          // Адреса машины могли смениться, пока агент был офлайн.
          {
            const info = imageHostInfo()
            if (info) send({ t: 'agent.imageHost', imageHost: info })
          }
          break
        case 'agent.policy':
          applyPolicy(msg.policy, false)
          handlers.onLog?.('политика обновлена')
          break
        case 'agent.denied':
          clearHeartbeat()
          stopped = true // не переподключаемся с заведомо неверным токеном
          handlers.onDenied?.(msg.reason)
          break
        case 'agent.updateAvailable':
          handlers.onUpdateAvailable?.(msg.version)
          break
        case 'exec.start': {
          let command = msg.command
          const cleanupNonce = /^# voicechat-cleanup-v1 ([a-f0-9-]{36})\n/.exec(command)?.[1]
          if (cleanupExclusive || (cleanupNonce && (runningCount() > 0 || ptyCount() > 0))) {
            send({ t: 'exec.error', execId: msg.execId, message: 'cleanup_or_consumer_busy' })
            break
          }
          // Локальная проверка политики — жёсткая граница на клиенте (второй барьер).
          const verdict = evaluateAgentCommand(policy, command)
          if (!verdict.allowed) {
            handlers.onExec?.(command)
            handlers.onExecDone?.(command, null, false, 0)
            handlers.onLog?.(`команда отклонена политикой: ${verdict.reason}`)
            send({ t: 'exec.error', execId: msg.execId, message: `Запрещено политикой: ${verdict.reason}` })
            break
          }
          handlers.onExec?.(command)
          const started = Date.now()
          if (cleanupNonce) {
            cleanupExclusive = true
            command = 'export VC_CLEANUP_ADMISSION=' + cleanupNonce + '\n' + command
          }
          runCommand(msg.execId, command, msg.timeoutMs, (out) => {
            if (cleanupNonce && (out.t === 'exec.done' || (out.t === 'exec.error' && runningCount() === 0))) cleanupExclusive = false
            if (out.t === 'exec.done') {
              handlers.onExecDone?.(command, out.exitCode, out.timedOut === true, Date.now() - started)
            }
            send(out)
          })
          break
        }
        case 'exec.cancel':
          handlers.onLog?.('отмена команды')
          cancelCommand(msg.execId)
          break
        case 'git.access':
          // Секретная специализированная операция: не логируем request и не строим shell-команду.
          send({ t: 'git.access.result', requestId: msg.requestId, result: handleGitAccess(msg.request) })
          break
        case 'pty.start':
          if (cleanupExclusive) { send({ t: 'pty.error', ptyId: msg.ptyId, message: 'cleanup_or_consumer_busy' }); break }
          // Живой терминал: доверенный shell без per-command гейта (см. docs/plans/PTY_CONSOLE.md).
          handlers.onLog?.(`терминал открыт (${msg.ptyId})`)
          startPty(msg.ptyId, msg.cols, msg.rows, msg.cwd || config.rootDir, send)
          break
        case 'pty.input':
          writePty(msg.ptyId, msg.data)
          break
        case 'pty.resize':
          resizePty(msg.ptyId, msg.cols, msg.rows)
          break
        case 'pty.kill':
          handlers.onLog?.('терминал закрыт')
          killPty(msg.ptyId)
          break
        case 'tunnel.listen': {
          const existing = localTunnels.get(msg.tunnelId)
          const address = existing?.server.address()
          if (address && typeof address !== 'string') {
            send({ t: 'tunnel.listening', tunnelId: msg.tunnelId, port: address.port }); break
          }
          let host: string
          try {
            host = tunnelBindHost(msg.host)
            if (msg.port !== undefined && (!Number.isInteger(msg.port) || msg.port < 0 || msg.port > 65535)) throw new Error('Invalid tunnel port')
          } catch (error) {
            send({ t: 'tunnel.error', tunnelId: msg.tunnelId, message: (error as Error).message }); break
          }
          if (existing) break
          const tunnel: LocalTunnel = { server: createServer({ highWaterMark: TUNNEL_HIGH_WATER_MARK }), sockets: new Map() }
          localTunnels.set(msg.tunnelId, tunnel)
          tunnel.server.on('connection', (client) => {
            const connectionId = randomUUID(); tunnel.sockets.set(connectionId, client)
            send({ t: 'tunnel.open', tunnelId: msg.tunnelId, connectionId })
            tunnelFlows.set(client, attachTunnelFlow(client, msg.tunnelId, connectionId, send))
            client.on('close', () => tunnel.sockets.delete(connectionId))
            client.on('end', () => send({ t: 'tunnel.end', tunnelId: msg.tunnelId, connectionId }))
            client.on('error', () => send({ t: 'tunnel.end', tunnelId: msg.tunnelId, connectionId }))
          })
          tunnel.server.listen(msg.port ?? 0, host, () => {
            const bound = tunnel.server.address()
            if (bound && typeof bound !== 'string') send({ t: 'tunnel.listening', tunnelId: msg.tunnelId, port: bound.port })
          })
          tunnel.server.on('error', (error: NodeJS.ErrnoException) => {
            closeTunnel(msg.tunnelId)
            send({ t: 'tunnel.error', tunnelId: msg.tunnelId, message: error.code === 'EADDRINUSE' ? 'Port is busy' : error.message })
          })
          break
        }
        case 'tunnel.connect': {
          const key = tunnelKey(msg.tunnelId, msg.connectionId)
          const target = connectSocket({ host: '127.0.0.1', port: msg.port }); targetSockets.set(key, target)
          target.on('connect', () => send({ t: 'tunnel.connected', tunnelId: msg.tunnelId, connectionId: msg.connectionId }))
          tunnelFlows.set(target, attachTunnelFlow(target, msg.tunnelId, msg.connectionId, send))
          target.on('close', () => { if (targetSockets.get(key) === target) targetSockets.delete(key) })
          target.on('end', () => send({ t: 'tunnel.end', tunnelId: msg.tunnelId, connectionId: msg.connectionId }))
          target.on('error', (error) => send({ t: 'tunnel.connectionError', tunnelId: msg.tunnelId, connectionId: msg.connectionId, message: error.message }))
          break
        }
        case 'tunnel.data': {
          const socket = targetSockets.get(tunnelKey(msg.tunnelId, msg.connectionId)) ?? localTunnels.get(msg.tunnelId)?.sockets.get(msg.connectionId)
          if (socket) tunnelFlows.get(socket)?.write(Buffer.from(msg.data, 'base64')); break
        }
        case 'tunnel.pause':
        case 'tunnel.resume': {
          const socket = targetSockets.get(tunnelKey(msg.tunnelId, msg.connectionId)) ?? localTunnels.get(msg.tunnelId)?.sockets.get(msg.connectionId)
          if (socket) tunnelFlows.get(socket)?.pause(msg.t === 'tunnel.pause')
          break
        }
        case 'tunnel.end': {
          const key = tunnelKey(msg.tunnelId, msg.connectionId)
          const socket = targetSockets.get(key) ?? localTunnels.get(msg.tunnelId)?.sockets.get(msg.connectionId)
          socket?.end(); targetSockets.delete(key); localTunnels.get(msg.tunnelId)?.sockets.delete(msg.connectionId); break
        }
        case 'tunnel.close':
          closeTunnel(msg.tunnelId); break
        case 'http.request':
          // Loopback-мост тестовых окружений: запрос идёт строго на 127.0.0.1.
          void fetchLocal(msg.request).then(
            (response) => send({ t: 'http.result', requestId: msg.requestId, response }),
            (error: unknown) => send({ t: 'http.error', requestId: msg.requestId, message: error instanceof Error ? error.message : String(error) })
          )
          break
        case 'fs.list':
        case 'fs.read-prefix':
        case 'fs.read':
        case 'fs.write':
        case 'fs.delete':
        case 'fs.delete-file-safe':
        case 'fs.trash':
        case 'fs.rename':
        case 'fs.mkdir': {
          const root = config.rootDir
          try {
            if (cleanupExclusive) throw new Error('cleanup_or_consumer_busy')
            let result
            switch (msg.t) {
              case 'fs.list':
                result = fsList(root, policy, msg.path)
                break
              case 'fs.read-prefix':
                result = fsReadPrefix(root, policy, msg.path)
                break
              case 'fs.read':
                result = fsRead(root, policy, msg.path)
                break
              case 'fs.write':
                result = fsWrite(root, policy, msg.path, msg.dataBase64)
                break
              case 'fs.delete':
                result = fsDelete(root, policy, msg.path)
                break
              case 'fs.delete-file-safe':
                result = fsDeleteFileSafe(root, policy, msg.path)
                break
              case 'fs.trash':
                result = fsTrash(root, policy, msg.path)
                break
              case 'fs.rename':
                result = fsRename(root, policy, msg.from, msg.to)
                break
              case 'fs.mkdir':
                result = fsMkdir(root, policy, msg.path)
                break
            }
            send({ t: 'fs.result', opId: msg.opId, result })
          } catch (err) {
            const code = typeof err === 'object' && err !== null && 'code' in err && typeof err.code === 'string'
              ? err.code
              : undefined
            send({ t: 'fs.error', opId: msg.opId, message: err instanceof Error ? err.message : String(err), ...(code ? { code } : {}) })
          }
          break
        }
      }
    })

    const reconnect = (): void => {
      clearHeartbeat()
      activeSend = null
      stopTelemetry()
      for (const id of [...localTunnels.keys()]) closeTunnel(id)
      for (const socket of targetSockets.values()) socket.destroy()
      targetSockets.clear()
      if (stopped) return
      handlers.onStatus?.('offline')
      handlers.onLog?.(`соединение потеряно, повтор через ${Math.round(backoff / 1000)}с`)
      reconnectTimer = setTimeout(connect, backoff)
      backoff = Math.min(backoff * 2, BACKOFF_MAX_MS)
    }

    ws.on('close', reconnect)
    ws.on('error', (err) => {
      handlers.onLog?.(`ошибка соединения: ${err.message}`)
      ws.close() // close-событие вызовет reconnect
    })
  }

  connect()

  // Раздача картинок поднимается параллельно подключению: слушающий сокет — это
  // асинхронно, а держать из-за него реконнект нельзя. Поднялась — досылаем порт
  // и адреса отдельным сообщением. Не поднялась — сервер просто не увидит
  // imageHost и оставит картинки у себя (прежний путь через REST).
  void startImageHost(config.rootDir)
    .then((host) => {
      if (!host || stopped) return
      imageHost = host
      handlers.onLog?.(`раздача картинок на :${host.port}`)
      const info = imageHostInfo()
      if (info) activeSend?.({ t: 'agent.imageHost', imageHost: info })
    })
    .catch(() => undefined)

  return {
    stop: () => {
      stopped = true
      if (reconnectTimer) clearTimeout(reconnectTimer)
      stopHeartbeat()
      stopTelemetry()
      imageHost?.stop()
      for (const id of [...localTunnels.keys()]) closeTunnel(id)
      for (const target of targetSockets.values()) target.destroy()
      targetSockets.clear()
      handlers.onStatus?.('stopped')
      try {
        socket?.terminate()
      } catch {
        /* уже закрыт */
      }
    },
    getPolicy: () => policy,
    setPolicy: (p: AgentPolicy) => applyPolicy(p, true)
  }
}
