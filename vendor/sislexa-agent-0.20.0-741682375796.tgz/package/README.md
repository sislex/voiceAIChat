# Sislexa Agent

The independent machine companion: command execution, files, optional PTY,
telemetry, VPN recovery guard, installers, tray and device enrollment client.
The server remains responsible for user authorization and machine policy.

## Development

Use Node 22 or later. Run `npm run setup`, then `npm run gate`.
Run `npm -w @voicechat/agent start -- --server wss://host/agent --token <machine-token>`.
`VC_AGENT_SERVER` and `VC_AGENT_TOKEN` are equivalent settings. Tokens are issued
by the target server; do not commit them. All API access uses that server origin.

Tray and login application are separate Electron installations. Run
`npm --prefix apps/agent-tray run dev` or
`npm --prefix apps/login-application run dev` after setup.
The renderer never receives the persistent machine token.

## Releases and compatibility

Runtime 0.20.0 implements protocol 1.0.0 and consumes Core API 1.x. Existing
0.19 clients remain wire-compatible. Protocol additions require versioned contracts
and minimum feature versions. `packages/contracts` is the protocol source of truth.

`npm run build` produces standalone `dist/voicechat-agent.cjs` and VPN guard,
plus the Electron bundles. `npm run pack:release` packs clean committed inputs,
source provenance and integrity. Core serves the released agent bytes without
compiling this repository. Native PTY is optional; command execution still works
when it is unavailable. On macOS `npm --prefix apps/agent-tray run dist` and
`npm --prefix apps/login-application run dist` create DMG installers. Developer
certificate signing/notarization is a separate distribution prerequisite.

Tests for this runtime, protocol and installers live here. Tests of server token
validation, user isolation and live server integration remain with Core.
