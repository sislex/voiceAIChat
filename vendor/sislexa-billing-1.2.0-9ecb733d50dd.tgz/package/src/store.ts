import { createRequire } from 'node:module'
import type { DatabaseSync as SqliteDatabase } from 'node:sqlite'
import { createHash, randomUUID } from 'node:crypto'
import { billingAmount, parseBillingPolicy, parseBillingPrincipal, assertPlatformIdentifier,
  parseBillingReservationInput, parseBillingUsageEvidence, priceUsageMicroUsd,
  summarizeBillingUsage, type BillingUsageEvent, type BillingUsageReport,
  type BillingUsageEvidence, type BillingPolicy, type BillingPrincipal, type BillingReservation, type BillingReservationInput } from '@sislexa/sdk'

export class BillingError extends Error {
  constructor(readonly statusCode: number, message: string) { super(message) }
}
const fail = (code: number, message: string): never => { throw new BillingError(code, message) }
const fingerprint = (value: unknown): string => createHash('sha256').update(JSON.stringify(value)).digest('hex')
const periodOf = (time: number): string => new Date(time).toISOString().slice(0, 7)
const unlimited: BillingPolicy = { monthlyMicroUsd: null, monthlyRequests: null, maxConcurrent: null }
// Load the Node built-in directly; older Vite resolvers do not recognize node:sqlite.
const { DatabaseSync } = createRequire(import.meta.url)('node:sqlite') as typeof import('node:sqlite')
interface Row { id: string; principal: string; input: string; fingerprint: string; period: string; state: BillingReservation['state']; created_at: number; actual: number | null }
export interface BillingBalance {
  period: string; policy: BillingPolicy; policyRevision: number
  spentMicroUsd: number; reservedMicroUsd: number; availableMicroUsd: number | null
  requests: number; active: number
}

/** One durable SQLite database, serialized across processes with BEGIN IMMEDIATE. */
export class BillingStore {
  private readonly db: SqliteDatabase
  constructor(filename: string, private readonly now: () => number = Date.now) {
    this.db = new DatabaseSync(filename)
    this.db.exec(`PRAGMA busy_timeout = 10000; PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;
      CREATE TABLE IF NOT EXISTS policies (
        environment TEXT NOT NULL, tenant TEXT NOT NULL, value TEXT NOT NULL, revision INTEGER NOT NULL,
        PRIMARY KEY(environment, tenant));
      CREATE TABLE IF NOT EXISTS reservations (
        id TEXT PRIMARY KEY, environment TEXT NOT NULL, tenant TEXT NOT NULL, operation TEXT NOT NULL,
        principal TEXT NOT NULL, input TEXT NOT NULL, fingerprint TEXT NOT NULL, period TEXT NOT NULL,
        state TEXT NOT NULL CHECK(state IN ('reserved','running','uncertain','settled','released')),
        created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL, maximum INTEGER NOT NULL CHECK(maximum >= 0),
        actual INTEGER CHECK(actual >= 0), UNIQUE(environment, tenant, operation));
      CREATE INDEX IF NOT EXISTS reservation_account ON reservations(environment, tenant, period, state);
      CREATE TABLE IF NOT EXISTS settlements (
        environment TEXT NOT NULL, tenant TEXT NOT NULL, event_id TEXT NOT NULL,
        reservation_id TEXT NOT NULL UNIQUE REFERENCES reservations(id), fingerprint TEXT NOT NULL,
        actual INTEGER NOT NULL CHECK(actual >= 0), recorded_at INTEGER NOT NULL,
        PRIMARY KEY(environment, tenant, event_id));
      CREATE TABLE IF NOT EXISTS settlement_evidence (
        reservation_id TEXT PRIMARY KEY REFERENCES reservations(id), evidence TEXT NOT NULL);
      CREATE INDEX IF NOT EXISTS settlement_account_time ON settlements(environment, tenant, recorded_at);`)
  }
  close(): void { this.db.close() }
  private tx<T>(work: () => T): T {
    this.db.exec('BEGIN IMMEDIATE')
    try { const result = work(); this.db.exec('COMMIT'); return result }
    catch (error) { this.db.exec('ROLLBACK'); throw error }
  }
  private account(environment: string, tenant: string): void {
    assertPlatformIdentifier(environment, 'environmentId'); assertPlatformIdentifier(tenant, 'tenantId')
  }
  private expire(): void {
    // Running and uncertain work retain funds and concurrency slots until reconciliation.
    this.db.prepare("UPDATE reservations SET state = 'released' WHERE state = 'reserved' AND expires_at <= ?").run(this.now())
  }
  private policy(environment: string, tenant: string): { value: BillingPolicy; revision: number } {
    const row = this.db.prepare('SELECT value, revision FROM policies WHERE environment = ? AND tenant = ?').get(environment, tenant)
    return row ? { value: parseBillingPolicy(JSON.parse(String(row.value))), revision: Number(row.revision) } : { value: { ...unlimited }, revision: 0 }
  }
  /** Authorization belongs to the API boundary; updates use optimistic revisions. */
  setPolicy(environment: string, tenant: string, value: BillingPolicy, expectedRevision: number): number {
    this.account(environment, tenant); const normalized = parseBillingPolicy(value)
    if (!Number.isSafeInteger(expectedRevision) || expectedRevision < 0) fail(400, 'invalid_revision')
    return this.tx(() => {
      const current = this.policy(environment, tenant)
      if (current.revision !== expectedRevision) fail(409, 'policy_revision_conflict')
      this.expire()
      if (normalized.monthlyMicroUsd !== null) {
        const active = this.db.prepare("SELECT input FROM reservations WHERE environment = ? AND tenant = ? AND state IN ('reserved','running','uncertain')").all(environment, tenant)
        if (active.some(row => JSON.parse(String(row.input)).executionBound === 'unbounded')) fail(409, 'unbounded_execution_active')
      }
      const revision = current.revision + 1
      this.db.prepare(`INSERT INTO policies VALUES (?, ?, ?, ?) ON CONFLICT(environment, tenant)
        DO UPDATE SET value = excluded.value, revision = excluded.revision`).run(environment, tenant, JSON.stringify(normalized), revision)
      return revision
    })
  }
  private balanceInside(environment: string, tenant: string): BillingBalance {
    const period = periodOf(this.now()), policy = this.policy(environment, tenant)
    const row = this.db.prepare(`SELECT
      COALESCE(SUM(CASE WHEN period = ? AND state = 'settled' THEN actual ELSE 0 END), 0) AS spent,
      COALESCE(SUM(CASE WHEN period = ? AND state IN ('reserved','running','uncertain') THEN maximum ELSE 0 END), 0) AS held,
      COALESCE(SUM(CASE WHEN period = ? THEN 1 ELSE 0 END), 0) AS requests,
      COALESCE(SUM(CASE WHEN state IN ('reserved','running','uncertain') THEN 1 ELSE 0 END), 0) AS active
      FROM reservations WHERE environment = ? AND tenant = ?`).get(period, period, period, environment, tenant)!
    const spent = Number(row.spent), held = Number(row.held), active = Number(row.active), requests = Number(row.requests)
    if (![spent, held, spent + held, active, requests].every(Number.isSafeInteger)) fail(503, 'ledger_range_exceeded')
    return { period, policy: policy.value, policyRevision: policy.revision, spentMicroUsd: spent, reservedMicroUsd: held,
      availableMicroUsd: policy.value.monthlyMicroUsd === null ? null : Math.max(0, policy.value.monthlyMicroUsd - spent - held), active, requests }
  }
  balance(environment: string, tenant: string): BillingBalance {
    this.account(environment, tenant)
    return this.tx(() => { this.expire(); return this.balanceInside(environment, tenant) })
  }
  usageReport(authority: Pick<BillingPrincipal, 'userId' | 'tenantId' | 'environmentId'>, from: number, to: number): BillingUsageReport {
    const principal = parseBillingPrincipal({ ...authority, actorClientId: 'billing-report', originModuleId: 'billing-report' })
    if (![from, to].every(value => Number.isSafeInteger(value) && value >= 0) || to <= from || to - from > 366 * 24 * 60 * 60 * 1000) {
      return fail(400, 'invalid_report_period')
    }
    const rows = this.db.prepare(`SELECT s.event_id, s.reservation_id, s.actual, s.recorded_at,
      r.operation, r.principal, e.evidence
      FROM settlements s
      JOIN reservations r ON r.id = s.reservation_id
      LEFT JOIN settlement_evidence e ON e.reservation_id = s.reservation_id
      WHERE s.environment = ? AND s.tenant = ? AND s.recorded_at >= ? AND s.recorded_at < ?
      ORDER BY s.recorded_at, s.event_id`).all(principal.environmentId, principal.tenantId, from, to) as Array<Record<string, unknown>>
    const events: BillingUsageEvent[] = []
    for (const row of rows) {
      const owner = parseBillingPrincipal(JSON.parse(String(row.principal)))
      if (owner.userId !== principal.userId) continue
      events.push({ version: 1, eventId: String(row.event_id), reservationId: String(row.reservation_id), operationId: String(row.operation),
        userId: owner.userId, tenantId: owner.tenantId, environmentId: owner.environmentId, actorClientId: owner.actorClientId,
        originModuleId: owner.originModuleId, occurredAt: Number(row.recorded_at), actualMicroUsd: Number(row.actual),
        ...(row.evidence === null ? {} : { usage: parseBillingUsageEvidence(JSON.parse(String(row.evidence))) }) })
    }
    return summarizeBillingUsage(events, { userId: principal.userId, tenantId: principal.tenantId,
      environmentId: principal.environmentId, from, to })
  }
  private result(row: Row): BillingReservation {
    const usage = row.state === 'settled' ? this.db.prepare('SELECT evidence FROM settlement_evidence WHERE reservation_id = ?').get(row.id) : undefined
    return { ...JSON.parse(row.principal), ...JSON.parse(row.input), id: row.id, period: row.period,
      state: row.state, createdAt: row.created_at, actualMicroUsd: row.actual,
      ...(usage ? { usage: parseBillingUsageEvidence(JSON.parse(String(usage.evidence))) } : {}) }
  }
  private owned(principal: BillingPrincipal, id: string): Row {
    const row = this.db.prepare('SELECT * FROM reservations WHERE id = ? AND environment = ? AND tenant = ?').get(id, principal.environmentId, principal.tenantId) as unknown as Row | undefined
    if (!row || row.principal !== JSON.stringify(principal)) fail(404, 'reservation_not_found')
    return row!
  }
  /** Executor authorization is required even after the initiating session is revoked. */
  executorPrincipal(environment: string, actorClientId: string, id: string): BillingPrincipal {
    this.account(environment, actorClientId)
    const row = this.db.prepare('SELECT principal FROM reservations WHERE id = ? AND environment = ?').get(id, environment)
    if (!row) fail(404, 'reservation_not_found')
    const principal = parseBillingPrincipal(JSON.parse(String(row!.principal)))
    if (principal.actorClientId !== actorClientId) fail(404, 'reservation_not_found')
    return principal
  }
  reserve(authority: BillingPrincipal, value: BillingReservationInput): BillingReservation {
    const principal = parseBillingPrincipal(authority)
    let input: BillingReservationInput
    try { input = parseBillingReservationInput({ operationId: value.operationId, maxMicroUsd: value.maxMicroUsd,
      expiresAt: value.expiresAt, ...(value.executionBound !== undefined ? { executionBound: value.executionBound } : {}) }) }
    catch { return fail(400, 'invalid_reservation') }
    const hash = fingerprint({ principal, input })
    return this.tx(() => {
      this.expire()
      const previous = this.db.prepare('SELECT * FROM reservations WHERE environment = ? AND tenant = ? AND operation = ?')
        .get(principal.environmentId, principal.tenantId, input.operationId) as unknown as Row | undefined
      if (previous) {
        if (previous.fingerprint !== hash) fail(409, 'operation_replay_conflict')
        return this.result(previous)
      }
      const now = this.now()
      if (input.expiresAt <= now || input.expiresAt > now + 300_000) fail(400, 'invalid_reservation_expiry')
      const b = this.balanceInside(principal.environmentId, principal.tenantId)
      if (input.executionBound === 'unbounded' && b.policy.monthlyMicroUsd !== null) fail(402, 'execution_cost_not_bounded')
      if (!Number.isSafeInteger(b.spentMicroUsd + b.reservedMicroUsd + input.maxMicroUsd)) fail(503, 'ledger_range_exceeded')
      if (b.policy.monthlyMicroUsd !== null && b.spentMicroUsd + b.reservedMicroUsd + input.maxMicroUsd > b.policy.monthlyMicroUsd) fail(402, 'budget_exhausted')
      if (b.policy.monthlyRequests !== null && b.requests >= b.policy.monthlyRequests) fail(429, 'request_limit_reached')
      if (b.policy.maxConcurrent !== null && b.active >= b.policy.maxConcurrent) fail(429, 'concurrency_limit_reached')
      const id = randomUUID()
      this.db.prepare(`INSERT INTO reservations (id, environment, tenant, operation, principal, input, fingerprint, period, state, created_at, expires_at, maximum)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'reserved', ?, ?, ?)`).run(id, principal.environmentId, principal.tenantId, input.operationId, JSON.stringify(principal), JSON.stringify(input), hash, b.period, now, input.expiresAt, input.maxMicroUsd)
      return this.result(this.owned(principal, id))
    })
  }
  reservation(authority: BillingPrincipal, id: string): BillingReservation {
    const principal = parseBillingPrincipal(authority)
    return this.tx(() => { this.expire(); return this.result(this.owned(principal, id)) })
  }
  transition(authority: BillingPrincipal, id: string, action: 'start' | 'uncertain' | 'release'): BillingReservation & { transitioned: boolean } {
    const principal = parseBillingPrincipal(authority)
    return this.tx(() => {
      this.expire(); const row = this.owned(principal, id)
      const target = { start: 'running', uncertain: 'uncertain', release: 'released' }[action]
      if (!target) fail(400, 'invalid_transition')
      if (row.state !== target) {
        if (action === 'start' && row.state !== 'reserved' || action === 'uncertain' && row.state !== 'running' || action === 'release' && row.state !== 'reserved') fail(409, 'invalid_reservation_state')
        this.db.prepare('UPDATE reservations SET state = ? WHERE id = ?').run(target, id)
      }
      // A replayed start is not permission to execute a second provider call.
      return { ...this.result(this.owned(principal, id)), transitioned: row.state !== target }
    })
  }
  /** Only the authenticated executor may report actual incurred cost, including overage. */
  settle(authority: BillingPrincipal, id: string, eventId: string, actualMicroUsd: number, evidence?: BillingUsageEvidence): BillingReservation {
    const principal = parseBillingPrincipal(authority)
    assertPlatformIdentifier(eventId, 'eventId')
    if (!billingAmount(actualMicroUsd)) fail(400, 'invalid_actual_cost')
    let usage: BillingUsageEvidence | undefined
    try {
      usage = evidence === undefined ? undefined : parseBillingUsageEvidence(evidence)
      if (usage?.costSource === 'estimate' && priceUsageMicroUsd(usage.tokens, usage.prices!) !== actualMicroUsd) fail(400, 'usage_price_mismatch')
    }
    catch (error) { if (error instanceof BillingError) throw error; return fail(400, 'invalid_usage_evidence') }
    const hash = fingerprint({ principal, id, actualMicroUsd, ...(usage ? { usage } : {}) })
    return this.tx(() => {
      const row = this.owned(principal, id)
      const previous = this.db.prepare('SELECT fingerprint FROM settlements WHERE environment = ? AND tenant = ? AND event_id = ?').get(principal.environmentId, principal.tenantId, eventId)
      if (previous) {
        if (previous.fingerprint !== hash) fail(409, 'settlement_replay_conflict')
        return this.result(row)
      }
      if (!['running', 'uncertain'].includes(row.state)) fail(409, 'invalid_reservation_state')
      this.db.prepare('INSERT INTO settlements VALUES (?, ?, ?, ?, ?, ?, ?)').run(principal.environmentId, principal.tenantId, eventId, id, hash, actualMicroUsd, this.now())
      if (usage) this.db.prepare('INSERT INTO settlement_evidence VALUES (?, ?)').run(id, JSON.stringify(usage))
      this.db.prepare("UPDATE reservations SET state = 'settled', actual = ? WHERE id = ?").run(actualMicroUsd, id)
      return this.result(this.owned(principal, id))
    })
  }
}
