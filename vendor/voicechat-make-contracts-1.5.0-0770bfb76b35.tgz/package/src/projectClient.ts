import { z } from 'zod'
import { makeProjectSchema, projectSubprojectSchema, projectDesignSchema, projectGitOperationSchema, projectGitResultSchema, projectPathSchema, type MakeProjectCore, type ProjectDesign } from './projectMode.js'

export type ProjectInventory = { [K in 'listProjects' | 'projectStructure' | 'projectDesign' | 'projectGit']: MakeProjectCore[K] extends (user: string, ...args: infer A) => infer R ? (...args: A) => R : never }
export interface ProjectFiles {
  read(projectId: string, path: string): Promise<string>
  write(projectId: string, path: string, content: string): Promise<void>
}
export type MakeProjectClient = ProjectInventory & ProjectFiles

/** The host may supply its authenticated fetch implementation, including desktop transport. */
export function createProjectHttpClient(fetchImpl: typeof fetch = globalThis.fetch): ProjectInventory {
  async function call(method: string, args: unknown[]) {
    const response = await fetchImpl('/api/make/projects/operation', {
      method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ method, args }),
    })
    const body = await response.json()
    if (!response.ok) {
      const error = z.object({ error: z.string() }).safeParse(body)
      throw new Error(error.success ? error.data.error : `HTTP ${response.status}`)
    }
    return body
  }
  return {
    listProjects: async () => z.array(makeProjectSchema).parse(await call('listProjects', [])),
    projectStructure: async id => z.array(projectSubprojectSchema).parse(await call('projectStructure', [id])),
    projectDesign: async (id, path) => projectDesignSchema.parse(await call('projectDesign', [id, projectPathSchema.parse(path)])),
    projectGit: async (id, operation) => {
      const result = projectGitResultSchema.parse(await call('projectGit', [id, projectGitOperationSchema.parse(operation)]))
      if (result.op !== operation.op) throw new Error('Mismatched project Git result')
      return result
    },
  }
}

/** A variant overrides discovered CSS variables without rewriting their source files. */
export function projectThemeFile(subproject: string, name: string, design: ProjectDesign, values: Record<string, string>, theme?: string) {
  projectPathSchema.parse(subproject)
  if (!/^[a-zA-Z0-9_-]{1,80}$/.test(name)) throw new Error('Invalid theme file name')
  const discovered = new Set(design.tokens.filter(token => token.theme === theme && /^--[\w-]+$/.test(token.name)).map(token => token.name))
  const declarations = Object.entries(values).map(([key, value]) => {
    if (!discovered.has(key) || !value.trim() || /[{};\x00-\x1f]|\/\*/.test(value)) throw new Error(`Invalid token override: ${key}`)
    return `  ${key}: ${value};`
  })
  if (!declarations.length) throw new Error('No CSS variable overrides')
  if (theme && !/^[\w-]+$/.test(theme)) throw new Error('Invalid theme selector')
  return { path: `${subproject === '.' ? '' : `${subproject}/`}themes/${name}.css`, content: `${theme ? `[data-theme="${theme}"]` : ':root'} {\n${declarations.join('\n')}\n}\n` }
}
