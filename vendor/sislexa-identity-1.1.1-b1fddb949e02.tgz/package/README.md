# Sislexa Identity

Identity owns user registration, authentication, recovery, TOTP, sessions, device
trust, login UI, account UI and reusable profile/session components. Core owns
project/resource authorization and account report aggregation. Service grants and
user credentials are distinct: a component grant never signs a user in.

## Run independently

Use Node 22.13+ and npm. `npm ci && npm run build`, then:

```sh
npm run init:local
IDENTITY_DATA_DIR="$PWD/data" \
SISLEXA_COMPONENT_CONFIG="$PWD/data/components.json" \
npm start
```

The server listens on `127.0.0.1:8798`; open `/login/`. Set
`IDENTITY_ADMIN_PASSWORD` for the initial admin, or enable self-registration with
`IDENTITY_SIGNUP_ENABLED=true`. Without SMTP, verification links go to the server
log. Set `IDENTITY_PUBLIC_URL=http://localhost:8798/login` so those links open the
standalone login screen. Never expose a development server with console mail.
`VC_SMTP_URL` and `VC_MAIL_FROM` configure production mail.

`npm run dev:login` and `npm run dev:account` run independent Vite clients;
`IDENTITY_API_URL` points their `/api` proxy to Identity. The account's session,
password and 2FA controls work independently. Usage, project/machine summaries and
security reports require the declared Core dependency; their data remains in Core.

## Dependencies and permissions

`apps/server/component-contract.json` fixes supported Core/API ranges and exact
scopes. Installation configuration selects dependency URLs and private token files;
it cannot widen a release's scopes or version range. Declare the optional Core
dependency to enable registration policy, invitations, account reports and deletion
cleanup. Core must provide `identity.core`. Core consumes Identity with
`identity.verify`, `identity.session`, `identity.store` and `identity.events`.
Provider-owned grants are issued/revoked with the component-runtime CLI. Store
registries and token files outside this checkout; no credentials belong in Git.
`config/standalone.json` exposes no service RPC grants.

Core mounts `/login/` and `/account/` from Identity on its public origin, preserving
same-origin HttpOnly cookies. Per-request authentication fails closed on an Identity
outage. CSRF and login rate limits run in Identity; forwarded IPs are accepted only
through the protected session RPC. Core keeps its resource permission checks and
checks WebSocket commands again. The event cursor includes a server epoch so a
restart cannot silently skip new revocations.

## Storage and migration

SQLite (`IDENTITY_DATA_DIR/identity.db`) is the local default. Production can set
`IDENTITY_DATABASE_URL` to PostgreSQL. The first extraction deliberately retains
the existing PostgreSQL database and its user keys/foreign keys; this is a shared
storage trust boundary, not independent databases. Identity owns the identity DDL
and repository; Core imports the DDL for schema composition and retains existing
historical migrations. Both initializers use the same PostgreSQL advisory lock.

Set `IDENTITY_SESSION_SECRET_FILE` to the existing Core `session.secret` during
migration. Do not generate a new secret: that would invalidate active sessions.
Identity's remote store port replaces both Core's public repository and inter-domain
identity calls. The embedded compatibility mode imports this repository's source;
there is no second local implementation.

Remote user deletion quarantines the account and revokes sessions before asking
Core to delete domain data. Those steps are idempotent. If Core fails, the account
remains blocked and retryable; credentials are deleted only after cleanup succeeds.
No distributed transaction is claimed. Embedded deletion retains its local SQL
transaction. Run one Identity writer per installation until credential flows are
made safe for multiple writers; TOTP tickets and rate-limit windows are in memory.

## Personal tenants and tariffs

Identity 1.1 owns `tenants`, `tenant_memberships`, `tariff_plans` and
`tenant_tariffs`. Every existing and newly created user receives one stable personal
tenant, its owner membership and the Standard tariff. User creation and tenant
provisioning share a transaction; repeat initialization inserts missing rows only.
SQLite and PostgreSQL enforce unique ownership and cascading user deletion.
Existing password hashes, system roles, sessions and per-user LLM spend limits
are preserved. Core's embedded database initializer must call the exported
`initializePersonalTenants` after schema migration using the same SQL connection.

System role, tenant membership and product capabilities are separate. Standard
initially enables all current modules. A tariff never grants administration,
project membership or provider scopes. Existing resource ownership remains scoped
to users; this release does not introduce shared organizational tenants or move
project data. Billing prices, payment collection and credit purchases are outside
this release. The existing monthly LLM spend limit remains an independent check.

`GET /api/session/account-access` reads the authenticated user's current tenant,
system role, tariff and effective capabilities. Admin-only `/api/session/tariffs`
supports listing and creation, and `PUT .../tariffs/:id` requires `expectedRevision`.
`/api/session/tariff-assignments` lists assignments; `PUT .../:user` accepts only
`tariffId`. Cookie mutations require CSRF. Capability IDs are allowlisted product
operations, never permission strings. Assignment and plan edits emit user events.
Account and administration routes remain reachable without product capabilities
so administrators can repair their own assignments.

User authentication resolves account context from current storage on every request;
tokens do not contain authoritative tariff claims. A supplied `x-sislexa-tenant-id`
must match that user's personal tenant. Product HTTP routes enforce capabilities;
the Core host additionally checks conversation kind, WebSocket commands and queued
execution. The server client fails closed if an older provider omits account context.
The embeddable account screen accepts the host-injected `AccountTariffClient`, shows
role/workspace/tariff separately, and lazy-loads the administrator editor. Standalone
Account uses the same bridge and interface.

## Packages and release

- `apps/server`: standalone API and identity storage.
- `apps/login`, `apps/account`: independent Vite builds and embeddable components.
- `packages/client`, `packages/contracts`: browser/server bridges and RPC contract.
- `packages/profile-app`, `packages/sessions-app`, `packages/sessions-core`: reusable UI/policy.
- `packages/storage-sql`: shared SQL drivers/schema translator used by Core and Identity.

`npm run gate` runs all type checks, tests, builds and a real standalone process smoke. PostgreSQL integration tests
use `VC_TEST_DB_URL`; unit tests never require production credentials.
The source archive is `@sislexa/identity`. `npm pack` requires a clean commit and
records its full SHA in `release-source.json`. Consumers pin the archive integrity,
version and SHA. `dependency-snapshots.json` records immutable shared dependency sources.

After `npm pack`, run `node scripts/pack-sessions-core.mjs <output-directory>`
to publish the dependency-free `@sislexa/identity-sessions-core` archive from the
same clean commit. API consumers use it without pulling in browser or SQL drivers.

The account summary reuses shared UI-kit layout and badges. Tariff editor CSS is
loaded with its lazy dialog so ordinary account navigation stays within the host
Web/Electron route budgets.
