import { afterEach, expect, it } from 'vitest'
import Database from 'better-sqlite3'
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { PRODUCT_CAPABILITIES } from '@voicechat/shared'
import { openIdentityStore } from './open.js'
import { hashPassword } from '../users/passwords.js'

const cleanup = {
  chat: { deleteConversationsOfUser: async () => {} }, machines: { deleteAgentsOfUser: async () => {} },
  settings: { deleteUserSettings: async () => {} }, tasks: { unassignUser: async () => {} }, projects: { detachDeletedUser: async () => {} }
}
const disposers: Array<() => void | Promise<void>> = []
afterEach(async () => { for (const dispose of disposers.splice(0).reverse()) await dispose() })
async function fixture(filename = ':memory:') {
  const storage = await openIdentityStore({ filename, cleanup })
  disposers.push(storage.close)
  return storage
}

it('backfills personal tenants without changing legacy credentials, roles or spend limits and preserves later assignments', async () => {
  const directory = mkdtempSync(join(tmpdir(), 'identity-tenants-'))
  disposers.push(() => rmSync(directory, { recursive: true, force: true }))
  const filename = join(directory, 'identity.sqlite'), legacy = new Database(filename)
  legacy.exec(`CREATE TABLE users (name TEXT PRIMARY KEY, password_hash TEXT NOT NULL, role TEXT NOT NULL,
    blocked INTEGER NOT NULL, created_at INTEGER NOT NULL, email TEXT, llm_limit_usd REAL)`)
  legacy.prepare('INSERT INTO users VALUES (?, ?, ?, 0, 123, NULL, 17)').run('existing', hashPassword('Preserved-password-947!'), 'observer')
  const before = legacy.prepare('SELECT * FROM users').get()
  legacy.close()
  let storage = await openIdentityStore({ filename, cleanup })
  try {
    const original = await storage.store.getAccountAccess('existing')
    expect(original).toMatchObject({ systemRole: 'observer', tenant: { kind: 'personal', owner: 'existing' }, tariff: { id: 'standard' }, capabilities: [...PRODUCT_CAPABILITIES] })
    expect(await storage.sql.get('SELECT * FROM users')).toEqual(before)
    await storage.store.saveTariffPlan({ id: 'chat', name: 'Chat', capabilities: ['chat.use'] })
    await storage.store.assignUserTariff('existing', 'chat')
    await storage.close()
    storage = await openIdentityStore({ filename, cleanup })
    expect(await storage.store.getAccountAccess('existing')).toMatchObject({ tenant: { id: original!.tenant.id }, tariff: { id: 'chat' }, capabilities: ['chat.use'] })
    expect(await storage.sql.get('SELECT * FROM users')).toEqual(before)
    expect(await storage.sql.get<{ n: number }>('SELECT COUNT(*) AS n FROM tenants')).toEqual({ n: 1 })
  } finally { await storage.close() }
})

it('provisions bootstrap, ordinary and email-verified users with distinct owner tenants', async () => {
  const { store, sql } = await fixture()
  await store.ensureAdmin('Preserved-password-947!')
  const first = await store.getAccountAccess('admin')
  await store.ensureAdmin('Ignored-new-password-946!')
  expect((await store.getAccountAccess('admin'))!.tenant.id).toBe(first!.tenant.id)
  expect(await store.verifyUserPassword('admin', 'Preserved-password-947!')).not.toBeNull()
  await store.createUser('invited', 'Invitation-password-937!', 'developer')
  await store.createEmailVerification({ token: 'email-token', name: 'registered', email: 'registered@example.test', password: 'Registration-password-937!', ttlMs: 60_000 })
  expect(await store.redeemEmailVerification('email-token', 'tester')).toMatchObject({ name: 'registered' })
  expect(await store.redeemEmailVerification('email-token', 'admin')).toBeNull()
  const assignments = await store.listTariffAssignments()
  expect(assignments).toHaveLength(3)
  expect(new Set(assignments.map(item => item.tenantId)).size).toBe(3)
  expect(await sql.all('SELECT user_name, role FROM tenant_memberships ORDER BY user_name')).toEqual([
    { user_name: 'admin', role: 'owner' }, { user_name: 'invited', role: 'owner' }, { user_name: 'registered', role: 'owner' }
  ])
  const concurrent = await Promise.allSettled([1, 2].map(() => store.createUser('same', 'Concurrent-password-937!', 'observer')))
  expect(concurrent.filter(result => result.status === 'fulfilled')).toHaveLength(1)
  expect(await sql.get('SELECT COUNT(*) AS n FROM tenants WHERE owner_user_name = ?', ['same'])).toEqual({ n: 1 })
})

it('rolls back the user when tenant provisioning fails and cascades account relationships on deletion', async () => {
  const { store, sql } = await fixture()
  await sql.exec(`CREATE TRIGGER reject_broken_membership BEFORE INSERT ON tenant_memberships
    WHEN NEW.user_name = 'broken' BEGIN SELECT RAISE(ABORT, 'membership failure'); END`)
  await expect(store.createUser('broken', 'Atomic-password-937!', 'developer')).rejects.toThrow('membership failure')
  expect(await store.getUser('broken')).toBeNull()
  expect(await sql.get('SELECT COUNT(*) AS n FROM tenants')).toEqual({ n: 0 })
  await store.createUser('alice', 'Deletion-password-937!', 'developer')
  await store.deleteUser('alice')
  for (const table of ['tenants', 'tenant_memberships', 'tenant_tariffs']) expect(await sql.get(`SELECT COUNT(*) AS n FROM ${table}`)).toEqual({ n: 0 })
})

it('changes entitlements without system privilege escalation and rejects stale plan edits', async () => {
  const { store } = await fixture()
  await store.createUser('alice', 'Tariff-password-937!', 'observer')
  const plan = await store.saveTariffPlan({ id: 'chat', name: 'Chat', capabilities: ['chat.use'] })
  expect(await store.assignUserTariff('alice', plan.id)).toMatchObject({ systemRole: 'observer', capabilities: ['chat.use'] })
  expect(await store.getUser('alice')).toMatchObject({ role: 'observer', llmLimitUsd: null })
  await expect(store.assignUserTariff('missing', plan.id)).rejects.toMatchObject({ statusCode: 404 })
  await expect(store.assignUserTariff('alice', 'missing')).rejects.toMatchObject({ statusCode: 404 })
  await store.saveTariffPlan({ id: plan.id, name: 'Read only', capabilities: [], expectedRevision: plan.revision })
  await expect(store.saveTariffPlan({ id: plan.id, name: 'Stale', capabilities: ['make.use'], expectedRevision: plan.revision })).rejects.toMatchObject({ statusCode: 409 })
  expect(await store.getAccountAccess('alice')).toMatchObject({ tariff: { revision: 2 }, capabilities: [] })
  await expect(store.saveTariffPlan({ id: 'bad', name: 'Bad', capabilities: ['identity.store'] as never })).rejects.toMatchObject({ statusCode: 400 })
})
