import { expect, it } from 'vitest'
import type { SessionUser } from '@voicechat/shared'
import { conversationCapability, productAccessError, requestCapability, sameAccountContext } from './productPolicy.js'

const user: SessionUser = { name: 'alice', role: 'developer', account: { tenantId: 'tenant-alice', tariffId: 'chat', tariffRevision: 1, capabilities: ['chat.use'] } }
it('enforces product access independently of roles while retaining account and administration access', () => {
  expect(productAccessError(user, 'POST', '/api/make/work?x=1', {})).toBe('capability_unavailable')
  expect(productAccessError({ ...user, role: 'admin' }, 'POST', '/api/make/work', {})).toBe('capability_unavailable')
  expect(productAccessError(user, 'GET', '/api/session/account-access', {})).toBeNull()
  expect(productAccessError(user, 'GET', '/api/admin/users', {})).toBeNull()
  expect(productAccessError({ name: 'alice', role: 'admin' }, 'GET', '/api/admin/users', {})).toBe('account_unavailable')
  expect(productAccessError(user, 'GET', '/api/session/account-access', { 'x-sislexa-tenant-id': ['tenant-alice'] })).toBe('tenant_not_allowed')
})
it.each([
  ['/api/image-studio/a', 'image-studio.use'], ['/api/browser/open', 'playwright-reader.use'],
  ['/api/preview/frame', 'web-reader.use'], ['/api/preview/make/a', 'make.use'], ['/api/preview/make-shared/a', 'make.use'],
  ['/api/stt/models', 'voice.stt'], ['/api/tts/voices', 'voice.tts'],
  ['/api/projects/x', 'projects.use'], ['/api/agents/x', 'machines.use']
])('maps HTTP resource %s to %s', (url, capability) => {
  expect(requestCapability('GET', url)).toBe(capability)
})
it('maps conversation kinds and detects stale sockets without depending on capability order', () => {
  expect(conversationCapability('make')).toBe('make.use')
  expect(conversationCapability('images')).toBe('image-studio.use')
  expect(conversationCapability()).toBe('chat.use')
  expect(sameAccountContext(user, { ...user, account: { ...user.account!, capabilities: ['chat.use'] } })).toBe(true)
  for (const next of [null, { ...user, role: 'admin' as const }, { ...user, account: undefined }, { ...user, account: { ...user.account!, tariffRevision: 2 } }, { ...user, account: { ...user.account!, tenantId: 'bob' } }]) expect(sameAccountContext(user, next)).toBe(false)
})
