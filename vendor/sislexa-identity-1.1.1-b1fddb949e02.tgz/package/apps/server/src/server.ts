import Fastify from 'fastify'
import {randomUUID} from 'node:crypto'
import {IDENTITY_PATHS, type IdentityEvent, type IdentitySessionRequest, type IdentitySessionResponse} from '@voicechat/identity-contracts'
import {registerAuth} from './users/auth.js'
import {SessionHub} from './users/sessionHub.js'
import {IDENTITY_STORE_METHODS} from './store/methods.js'
import type {AuthDatabase} from './ports.js'
import type {AuthOptions} from './users/auth.js'
export interface IdentityServerOptions extends AuthOptions {
 database:AuthDatabase;secret:string
 authorize:(header:string|undefined,scope:string)=>{ok:true}|{ok:false;status:401|403}
 registerComponent?:(app:ReturnType<typeof Fastify>)=>void
 accountFetch?:typeof fetch;coreUrl?:string
}
export async function buildIdentityServer(options:IdentityServerOptions){
 const app=Fastify({logger:false,bodyLimit:1024*1024})
 // A one-use in-process nonce carries Core's validated CORS decision across
 // Fastify injection without trusting a client-supplied public header.
 const forwardedCors=new Map<string,boolean>()
 app.addHook('onRequest',async req=>{
  const nonce=req.headers['x-identity-forwarded-request']
  req.corsAllowed=typeof nonce==='string'&&forwardedCors.get(nonce)===true
  if(typeof nonce==='string')forwardedCors.delete(nonce)
 })
 options.registerComponent?.(app)
 const hub=options.sessions??new SessionHub(),events:IdentityEvent[]=[],epoch=randomUUID();let sequence=0
 hub.onChange(event=>{events.push({...event,sequence:++sequence});if(events.length>1024)events.shift()})
 const {authenticate}=await registerAuth(app,options.database,options.secret,{...options,sessions:hub})
 app.register(async internal=>{
  internal.addHook('onRequest',async(req,reply)=>{
   const path=req.url.split('?')[0]
   const scope=path===IDENTITY_PATHS.verify?'identity.verify':path===IDENTITY_PATHS.session?'identity.session':path===IDENTITY_PATHS.events?'identity.events':'identity.store'
   const verdict=options.authorize(req.headers.authorization,scope)
   if(!verdict.ok)return reply.code(verdict.status).send({error:'component_access_denied'})
  })
  internal.post<{Body:{request:Parameters<typeof authenticate>[0]}}>(IDENTITY_PATHS.verify,async(req,reply)=>{
   const input=req.body?.request;if(!input||typeof input.url!=='string'||typeof input.method!=='string'||!input.headers)return reply.code(400).send({error:'invalid_request'})
   return authenticate(input)
  })
  internal.post<{Body:IdentitySessionRequest}>(IDENTITY_PATHS.session,async(req,reply):Promise<IdentitySessionResponse|unknown>=>{
   const input=req.body
   if(!input||!/^\/api\/session(?:[/?]|$)/.test(input.url)||!['GET','HEAD','POST','PATCH','DELETE','PUT'].includes(input.method)||typeof input.ip!=='string')return reply.code(400).send({error:'invalid_session_request'})
   const nonce=randomUUID();forwardedCors.set(nonce,input.corsAllowed===true)
   try {
    const result=await app.inject({method:input.method as 'POST',url:input.url,headers:{...input.headers,'x-identity-forwarded-request':nonce},remoteAddress:input.ip,...(input.body===undefined?{}:{payload:JSON.stringify(input.body)})})
    return {status:result.statusCode,headers:result.headers,body:result.body}
   }finally{forwardedCors.delete(nonce)}
  })
  internal.post<{Body:{method:string;args:unknown[]}}>(IDENTITY_PATHS.store,async(req,reply)=>{
   const {method,args}=req.body??{}
   if(!IDENTITY_STORE_METHODS.includes(method as typeof IDENTITY_STORE_METHODS[number])||!Array.isArray(args))return reply.code(400).send({error:'unknown_method'})
   const session=method==='revokeSessionById'?await options.database.identity.getSession(String(args[0])):null
   const methodFn=options.database.identity[method as keyof AuthDatabase['identity']] as (...args:unknown[])=>Promise<unknown>
   const result=await methodFn.apply(options.database.identity,args)
   if(session)hub.emit(session.user,session.sid)
   if(['assignUserTariff','setUserBlocked','setUserPassword','setUserRole','deleteUser','deleteUserData','revokeUserSessions','updateSession','untrustAllSessions'].includes(method)&&typeof args[0]==='string')hub.emit(args[0])
   if(method==='saveTariffPlan'&&result){for(const assignment of await options.database.identity.listTariffAssignments())if(assignment.tariffId===(result as {id:string}).id)hub.emit(assignment.userName)}
   return {result:result??null}
  })
  internal.get<{Querystring:{after?:string;epoch?:string}}>(IDENTITY_PATHS.events,async(req)=>({epoch,sequence,events:events.filter(e=>e.sequence>(req.query.epoch===epoch?Number(req.query.after??0):0))}))
 })
 if(options.accountFetch&&options.coreUrl){
  for(const url of ['/api/me/profile','/api/me/security','/api/me/usage','/api/llm-access','/api/agents'])app.get(url,async(req,reply)=>{
   const headers=new Headers();for(const name of ['authorization','cookie','x-vc-csrf']){const value=req.headers[name];if(typeof value==='string')headers.set(name,value)}
   const response=await options.accountFetch!(new URL(req.url,options.coreUrl),{headers,redirect:'error',signal:AbortSignal.timeout(15000)})
   return reply.code(response.status).type(response.headers.get('content-type')??'application/json').send(Buffer.from(await response.arrayBuffer()))
  })
 }
 app.get('/v1/health',async()=>({ok:true,service:'identity'}))
 return {app,authenticate,hub}
}
