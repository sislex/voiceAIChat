import {IDENTITY_PATHS} from '@voicechat/identity-contracts'
import type {IdentityStore, IdentityCore} from '../../../apps/server/src/ports.js'
export interface IdentityTransport {url:string;token:string;fetchImpl?:typeof fetch}
export async function identityRpc<T>(transport:IdentityTransport,path:string,body:unknown):Promise<T>{
 const response=await(transport.fetchImpl??fetch)(new URL(path,transport.url),{method:'POST',headers:{authorization:'Bearer '+transport.token,'content-type':'application/json'},body:JSON.stringify(body),redirect:'error',signal:AbortSignal.timeout(15000)})
 if(!response.ok)throw Object.assign(new Error('Identity dependency HTTP '+response.status),{statusCode:503})
 return response.json() as Promise<T>
}
export function createIdentityStoreClient(transport:IdentityTransport):IdentityStore{
 return new Proxy({} as IdentityStore,{get:(_target,key)=>key==='then'?undefined:(...args:unknown[])=>identityRpc<{result:unknown}>(transport,IDENTITY_PATHS.store,{method:key,args}).then(r=>r.result)})
}
export function createIdentityCoreClient(transport:IdentityTransport):IdentityCore{
 return new Proxy({} as IdentityCore,{get:(_target,domain)=>new Proxy({},{get:(_target,method)=>(...args:unknown[])=>identityRpc<{result:unknown}>(transport,IDENTITY_PATHS.core,{method:String(domain)+'.'+String(method),args}).then(r=>r.result)})})
}
