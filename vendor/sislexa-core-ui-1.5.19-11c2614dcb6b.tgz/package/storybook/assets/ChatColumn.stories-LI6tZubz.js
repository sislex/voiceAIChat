import{j as c}from"./jsx-runtime-BYYWji4R.js";import{r as Ca}from"./index-ClcD9ViR.js";import{within as r,userEvent as s,expect as n,fn as o,waitFor as Y}from"./index-DeN4tkzB.js";import{C as ka}from"./ChatColumn-CEJ71U8y.js";import{V as Aa}from"./VoiceBar-BXSfylpN.js";import{A as fa,S as Ha,m as l,e as d,f as Q,g as La,h as Ma,i as Sa,j as Ia,k as Ua,l as Va,T as Da,n as Wa,b as K}from"./chat-COYZgq2j.js";import"./ci-DFdZK10C.js";import{m as Ra,a as qa,b as Na,c as Fa}from"./machines-lfjfj7ts.js";import"./clarification-g58U83f7.js";import{T as _a}from"./time-CfyNS7J_.js";import{A as Oa}from"./version-8RazoPAq.js";import"./devProcess-DlbHViLE.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./iframe-B2wSx022.js";import"./questions-Bk4wc6lB.js";import"./tools-D2dVYbOd.js";import"./images-CH23vBlI.js";import"./view-BrHz5xl6.js";import"./Toast-CcZfB6x2.js";import"./index-Brl4xq4Y.js";import"./clipboard-OV73WQR5.js";import"./Markdown-D3RuqcxH.js";import"./core-BwXZ_Otv.js";import"./lazyScreen-CooZxeYV.js";import"./Skeleton-42oMjovX.js";import"./ErrorState-CqsakWkx.js";import"./autoGrow-CoBFBF9S.js";import"./MessageMeta-Dv9RcPkx.js";import"./kb-FQoQkx7T.js";import"./MessageImage-IAGpHILj.js";import"./animations-CzQhBjHJ.js";import"./ToolFrame-CqCmqPT9.js";import"./QuestionsForm-BIFaA7UX.js";import"./MessageTimeline-DfHSVMjJ.js";import"./MessageActivity-5vFHiusu.js";import"./machineHealth-CCKIyBId.js";import"./uiPerformance-R53OMrUM.js";import"./useDismissibleMenu-BjxVjS3A.js";import"./useHotkeys-CjtRU-3i.js";import"./hotkeys-4oJJtujI.js";import"./useCommands-DzUlj2j8.js";import"./commands-BOmIcTa-.js";import"./persistence-Y4P2JfJq.js";import"./mediaQuery-CCkbYk-e.js";import"./types-DFdjDDUq.js";import"./icons-M-fant0Z.js";import"./agentProtocol-ChPLBt7B.js";const m=()=>{};function q(a="idle"){return c.jsx(Aa,{defaultCollapsed:!1,state:a,draft:"",diarization:!0,detectedSpeakers:a==="listening"?[1,2]:[],attachments:[],onDraftChange:m,onSubmitText:m,onStartVoice:m,onStopVoice:m,onStopSpeak:m,onCancelRequest:m,onAddFiles:m,onRemoveAttachment:m})}const ja=[Ra({id:"m1",name:"MacBook",version:Oa,lastSeen:Date.now(),telemetry:Na({ts:Date.now()})}),Fa({id:"m2",name:"Сборочный сервер"})];function Qa(){return[l({id:"u1",text:"Почему на последнем ране упал шаг с тестами?",execTarget:"m1"}),d({id:"a1",text:Da,execTarget:"m1",createdAt:_a+45e3,meta:Q({activity:Wa,durationMs:45e3,costUsd:.183,inputTokens:82400,outputTokens:1240})})]}const Nn={title:"Chat/ChatColumn",component:ka,parameters:{layout:"fullscreen"},args:{title:"Разбор упавшего рана",state:"idle",messages:Qa(),liveSegments:[],diarization:!0,agents:ja,execTarget:"m1",aiLabel:"Claude",canSpeak:!0,permissionMode:"acceptEdits",voiceBar:q(),onSpeakMessage:o(),onDeleteMessage:o(),onEditMessage:o(),onExport:o(),onRenameTitle:o(),onOpenConversationSettings:o(),onChangeExecTarget:o()},decorators:[(a,t)=>c.jsx("div",{className:"app","data-testid":"chat-column-frame",style:{width:t.parameters.columnWidth??"100%",height:"90vh",display:"grid",gridTemplateColumns:"minmax(0, 1fr)"},children:c.jsx("div",{className:"chat-page",style:{gridColumn:1},children:c.jsx(a,{})})})]},F={render:a=>{const[t,e]=Ca.useState(!1);return c.jsxs("div",{style:{height:700,display:"flex",flexDirection:"column",minWidth:0},children:[c.jsx("button",{onClick:()=>e(!0),children:"Получить новый ответ"}),c.jsx(ka,{...a,conversationId:"story-unread",messages:[...Ma(),...t?[d({id:"new-story-reply",text:"Новый ответ"})]:[]]})]})},play:async({canvasElement:a})=>{const t=r(a),e=t.getByTestId("scroll");e.dispatchEvent(new Event("wheel",{bubbles:!0})),e.scrollTop=0,e.dispatchEvent(new Event("scroll",{bubbles:!0})),await s.click(t.getByText("Получить новый ответ")),await n(t.findByText("↓ Новые сообщения (1)")).resolves.toBeTruthy()}},_={args:{messages:[d({text:K})]},play:async({canvasElement:a})=>{const t=r(a);t.queryByRole("button",{name:"Действия чата"})&&await s.click(t.getByRole("button",{name:"Действия чата"})),await s.click(t.getByText("Поиск")),await s.type(t.getByLabelText("Найти в беседе"),"код"),await s.click(t.queryByRole("button",{name:"Действия чата"})??t.getByLabelText("Меню беседы")),await s.click(t.getByText("Компактная лента"))}},O={args:{conversationId:"failed",failedSubmits:[{operationId:"op",conversationId:"failed",text:"Сообщение с вложением",attachmentIds:["upload"],error:"Нет соединения",retrying:!1}],onRetryFailedSubmit:o(),onDeleteFailedSubmit:o()}},j={decorators:[a=>c.jsx("div",{style:{width:"100%",maxWidth:390,minWidth:0,height:750},children:c.jsx(a,{})})],args:{messages:[d({text:K})]}},u={play:async({canvasElement:a})=>{const t=r(a).getByRole("button",{name:"Копировать вопрос"});await n(t).toHaveClass("copymsg"),await n(t).not.toHaveClass("copymsg--copied")}},g={play:async({canvasElement:a})=>{const e=r(a).getByRole("button",{name:"Копировать вопрос"}),i=e.closest(".me .bub");if(!i)throw new Error("User message bubble not found");await s.hover(i),await n(e).toHaveClass("copymsg")}},b={play:async({canvasElement:a})=>{const t=r(a).getByRole("button",{name:"Копировать вопрос"});t.focus(),await n(t).toHaveFocus()}},y={decorators:[a=>c.jsx("div",{"data-theme":"dark",style:{height:"100%"},children:c.jsx(a,{})})],play:async({canvasElement:a})=>{const i=r(a).getByRole("button",{name:"Копировать вопрос"}).closest(".me .bub");if(!i)throw new Error("User message bubble not found");await s.hover(i)}},v={play:async({canvasElement:a})=>{const e=r(a).getByRole("button",{name:"Копировать ответ"}),i=e.closest(".ai .bub");if(!i)throw new Error("Model message bubble not found");await s.hover(i),e.focus(),await n(e).toHaveFocus()}},w={play:async({canvasElement:a})=>{const e=r(a).getByRole("button",{name:"Копировать вопрос"});await s.click(e),await n(e).toHaveClass("copymsg--copied")}},h={args:{messages:[],onExport:void 0}},B={args:{messages:[],loadingMessages:!0}},x={args:{loadingMessages:!0}},E={args:{state:"thinking",streamingReply:Ha,liveActivity:fa,liveUsage:Sa(),voiceBar:q("thinking")}},T={args:{state:"thinking",liveActivity:fa,liveUsage:Sa(),voiceBar:q("thinking")}},k={args:{state:"listening",liveSegments:La(),voiceBar:q("listening")}},f={args:{error:"Микрофон недоступен: браузер не дал доступ к устройству записи",onDismissError:o()}},M={args:{modelMissing:!0,modelLabel:"large-v3-turbo",onDownloadModel:o()}},S={args:{modelMissing:!0,modelLabel:"large-v3-turbo",downloading:!0,downloadPercent:42}},I={args:{messages:[l({text:"Сделай CI-шаг для витрины"}),Ia()],onAnswerQuestions:o()}},R={args:{messages:[l({text:"старт"}),Ia({id:"a-ci",meta:{ciInteraction:{runId:"run-1",interactionId:"it-1"}}}),l({id:"u-after",text:"а пока посмотрю лог"})],onAnswerCiInteraction:o()}},C={args:{messages:[l({text:"Построй график и открой консоль"}),Ua(),Va("console")],machineOps:qa(),agents:[Ra({id:"m1",name:"MacBook"})],onSwitchUtility:o(),onOpenMachines:o(),onOpenImageInExplorer:o()}},A={args:{permissionMode:"plan",messages:[l({text:"Составь план"}),d({id:"a-plan",text:K,meta:Q({request:{...Q().request,permissionMode:"plan"}})})],onExecutePlan:o(),voiceBar:q()}},H={args:{messages:[l({text:"Опиши архитектуру"}),d({id:"a-int",text:"Начал описывать, но не успел закон",meta:Q({interrupted:!0})})]}},L={args:{messages:Ma()}},U={args:{onToggleSidebar:o(),messages:[l({id:"u-mobile-copy",text:"Проверь перенос длинной ссылки: https://example.test/very/long/unbroken/path/that/must/not/escape/the/message/bubble?query=mobile-copy-button"}),d({id:"a-mobile-copy",text:"Кнопка остаётся внутри пузыря, а текст переносится."})]},parameters:{viewport:{defaultViewport:"mobile2"}},play:async({canvasElement:a})=>{const i=r(a).getByRole("button",{name:"Копировать вопрос"}).closest(".me .bub");if(!i)throw new Error("User message bubble not found");await s.hover(i)}},V={play:async({canvasElement:a})=>{const t=r(a);await s.click(t.getByLabelText("Изменить сообщение"));const e=t.getByLabelText("Редактирование сообщения");await s.clear(e),await s.type(e,"Почему упал шаг npm test и как это починить?"),await n(e).toHaveValue("Почему упал шаг npm test и как это починить?"),await n(t.getByRole("button",{name:"Отправить"})).toBeEnabled()}},D={play:async({canvasElement:a})=>{const t=r(a),e=t.getByLabelText("Переключить вид действий");await s.click(e),await n(t.getAllByTestId("activity-brief")).toHaveLength(2),await s.click(e),await n(t.getAllByTestId("activity-section").length).toBeGreaterThan(1)}},W={parameters:{columnWidth:599},args:{onToggleSidebar:o()},play:async({canvasElement:a,args:t})=>{const e=r(a),i=e.getByTestId("chat-column-frame"),p=await e.findByRole("button",{name:"Действия чата"});await n(e.getByRole("button",{name:/боковую панель/})).toBeVisible(),await s.click(e.getByRole("button",{name:/боковую панель/})),await n(t.onToggleSidebar).toHaveBeenCalled(),await Y(()=>n(e.queryByRole("button",{name:"Настройки разговора"})).not.toBeInTheDocument()),await s.click(p);const N=r(e.getByTestId("chat-header-actions")),P=e.getByRole("button",{name:/боковую панель/});await n(P).toBeVisible(),await n(e.getByTestId("chat-header-actions")).not.toContainElement(P);for(const G of e.getByTestId("chat-header-actions").querySelectorAll("button"))await n(G).toHaveStyle({textAlign:"left",display:"grid"}),await n(G.firstElementChild).toHaveAttribute("aria-hidden","true");await n(N.getByRole("combobox",{name:"Машина активного чата"})).toBeEnabled(),await n(N.getByRole("button",{name:"Компактная лента"})).toBeVisible(),await n(N.getByRole("button",{name:"JSON (.json)"})).toBeVisible(),await s.click(N.getByRole("button",{name:"Настройки разговора"})),await n(t.onOpenConversationSettings).toHaveBeenCalled(),await n(e.queryByTestId("chat-header-actions")).not.toBeInTheDocument(),await s.click(p),await s.keyboard("{Escape}"),await n(p).toHaveFocus(),await n(e.queryByTestId("chat-header-actions")).not.toBeInTheDocument(),await s.click(p),await s.click(r(e.getByTestId("chat-header-actions")).getByRole("button",{name:"Markdown (.md)"})),await n(t.onExport).toHaveBeenCalledWith("md"),await s.click(p),await s.click(r(e.getByTestId("chat-header-actions")).getByRole("button",{name:"Поиск"})),await n(e.getByRole("textbox",{name:"Найти в беседе"})).toBeVisible(),i.style.width="700px",await Y(()=>n(e.queryByRole("button",{name:"Действия чата"})).not.toBeInTheDocument()),await n(e.getByRole("button",{name:"Настройки разговора"})).toBeVisible(),i.style.width="699px",await n(await e.findByRole("button",{name:"Действия чата"})).toHaveAttribute("aria-expanded","false")}};var X,z,J;F.parameters={...F.parameters,docs:{...(X=F.parameters)==null?void 0:X.docs,source:{originalSource:`{
  render: args => {
    const [extra, setExtra] = useState(false);
    return <div style={{
      height: 700,
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0
    }}>
      <button onClick={() => setExtra(true)}>Получить новый ответ</button>
      <ChatColumn {...args} conversationId="story-unread" messages={[...makeLongThread(), ...(extra ? [makeAiMessage({
        id: 'new-story-reply',
        text: 'Новый ответ'
      })] : [])]} />
    </div>;
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const scroll = canvas.getByTestId('scroll');
    scroll.dispatchEvent(new Event('wheel', {
      bubbles: true
    }));
    scroll.scrollTop = 0;
    scroll.dispatchEvent(new Event('scroll', {
      bubbles: true
    }));
    await userEvent.click(canvas.getByText('Получить новый ответ'));
    await expect(canvas.findByText('↓ Новые сообщения (1)')).resolves.toBeTruthy();
  }
}`,...(J=(z=F.parameters)==null?void 0:z.docs)==null?void 0:J.source}}};var Z,$,ee;_.parameters={..._.parameters,docs:{...(Z=_.parameters)==null?void 0:Z.docs,source:{originalSource:`{
  args: {
    messages: [makeAiMessage({
      text: MD_KITCHEN_SINK
    })]
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    if (canvas.queryByRole('button', {
      name: 'Действия чата'
    })) await userEvent.click(canvas.getByRole('button', {
      name: 'Действия чата'
    }));
    await userEvent.click(canvas.getByText('Поиск'));
    await userEvent.type(canvas.getByLabelText('Найти в беседе'), 'код');
    await userEvent.click(canvas.queryByRole('button', {
      name: 'Действия чата'
    }) ?? canvas.getByLabelText('Меню беседы'));
    await userEvent.click(canvas.getByText('Компактная лента'));
  }
}`,...(ee=($=_.parameters)==null?void 0:$.docs)==null?void 0:ee.source}}};var te,ae,ne;O.parameters={...O.parameters,docs:{...(te=O.parameters)==null?void 0:te.docs,source:{originalSource:`{
  args: {
    conversationId: 'failed',
    failedSubmits: [{
      operationId: 'op',
      conversationId: 'failed',
      text: 'Сообщение с вложением',
      attachmentIds: ['upload'],
      error: 'Нет соединения',
      retrying: false
    }],
    onRetryFailedSubmit: fn(),
    onDeleteFailedSubmit: fn()
  }
}`,...(ne=(ae=O.parameters)==null?void 0:ae.docs)==null?void 0:ne.source}}};var se,oe,re;j.parameters={...j.parameters,docs:{...(se=j.parameters)==null?void 0:se.docs,source:{originalSource:`{
  decorators: [Story => <div style={{
    width: '100%',
    maxWidth: 390,
    minWidth: 0,
    height: 750
  }}><Story /></div>],
  args: {
    messages: [makeAiMessage({
      text: MD_KITCHEN_SINK
    })]
  }
}`,...(re=(oe=j.parameters)==null?void 0:oe.docs)==null?void 0:re.source}}};var ie,ce,me,le,de;u.parameters={...u.parameters,docs:{...(ie=u.parameters)==null?void 0:ie.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const button = within(canvasElement).getByRole('button', {
      name: 'Копировать вопрос'
    });
    await expect(button).toHaveClass('copymsg');
    await expect(button).not.toHaveClass('copymsg--copied');
  }
}`,...(me=(ce=u.parameters)==null?void 0:ce.docs)==null?void 0:me.source},description:{story:"Обычная беседа: кнопка вопроса есть в DOM, но в покое визуально скрыта.",...(de=(le=u.parameters)==null?void 0:le.docs)==null?void 0:de.description}}};var pe,ue,ge,be,ye;g.parameters={...g.parameters,docs:{...(pe=g.parameters)==null?void 0:pe.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
    await expect(button).toHaveClass('copymsg');
  }
}`,...(ge=(ue=g.parameters)==null?void 0:ue.docs)==null?void 0:ge.source},description:{story:"Наведение на пользовательский пузырь раскрывает кнопку вопроса.",...(ye=(be=g.parameters)==null?void 0:be.docs)==null?void 0:ye.description}}};var ve,we,he,Be,xe;b.parameters={...b.parameters,docs:{...(ve=b.parameters)==null?void 0:ve.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const button = within(canvasElement).getByRole('button', {
      name: 'Копировать вопрос'
    });
    button.focus();
    await expect(button).toHaveFocus();
  }
}`,...(he=(we=b.parameters)==null?void 0:we.docs)==null?void 0:he.source},description:{story:"Клавиатурный фокус раскрывает кнопку и сохраняет нативную активацию.",...(xe=(Be=b.parameters)==null?void 0:Be.docs)==null?void 0:xe.description}}};var Ee,Te,ke,fe,Me;y.parameters={...y.parameters,docs:{...(Ee=y.parameters)==null?void 0:Ee.docs,source:{originalSource:`{
  decorators: [Story => <div data-theme="dark" style={{
    height: '100%'
  }}><Story /></div>],
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
  }
}`,...(ke=(Te=y.parameters)==null?void 0:Te.docs)==null?void 0:ke.source},description:{story:"Тёмная тема сохраняет контраст пользовательской кнопки в видимом состоянии.",...(Me=(fe=y.parameters)==null?void 0:fe.docs)==null?void 0:Me.description}}};var Se,Ie,Re,Ce,Ae;v.parameters={...v.parameters,docs:{...(Se=v.parameters)==null?void 0:Se.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать ответ'
    });
    const bubble = button.closest('.ai .bub');
    if (!bubble) throw new Error('Model message bubble not found');
    await userEvent.hover(bubble);
    button.focus();
    await expect(button).toHaveFocus();
  }
}`,...(Re=(Ie=v.parameters)==null?void 0:Ie.docs)==null?void 0:Re.source},description:{story:"Ответ модели сохраняет прежнее раскрытие при наведении и фокусе.",...(Ae=(Ce=v.parameters)==null?void 0:Ce.docs)==null?void 0:Ae.description}}};var He,Le,Ue,Ve,De;w.parameters={...w.parameters,docs:{...(He=w.parameters)==null?void 0:He.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    await userEvent.click(button);
    await expect(button).toHaveClass('copymsg--copied');
  }
}`,...(Ue=(Le=w.parameters)==null?void 0:Le.docs)==null?void 0:Ue.source},description:{story:"Успешное копирование вопроса: видимое подтверждение закреплено для visual-check.",...(De=(Ve=w.parameters)==null?void 0:Ve.docs)==null?void 0:De.description}}};var We,qe,Ne,Fe,_e;h.parameters={...h.parameters,docs:{...(We=h.parameters)==null?void 0:We.docs,source:{originalSource:`{
  args: {
    messages: [],
    onExport: undefined
  }
}`,...(Ne=(qe=h.parameters)==null?void 0:qe.docs)==null?void 0:Ne.source},description:{story:"Пустая беседа: подсказка объясняет следующий шаг, а не констатирует пустоту.",...(_e=(Fe=h.parameters)==null?void 0:Fe.docs)==null?void 0:_e.description}}};var Oe,je,Qe,Ke,Pe;B.parameters={...B.parameters,docs:{...(Oe=B.parameters)==null?void 0:Oe.docs,source:{originalSource:`{
  args: {
    messages: [],
    loadingMessages: true
  }
}`,...(Qe=(je=B.parameters)==null?void 0:je.docs)==null?void 0:Qe.source},description:{story:"Первая загрузка истории: скелетон реплик той же геометрии, что у сообщений.",...(Pe=(Ke=B.parameters)==null?void 0:Ke.docs)==null?void 0:Pe.description}}};var Ge,Ye,Xe,ze,Je;x.parameters={...x.parameters,docs:{...(Ge=x.parameters)==null?void 0:Ge.docs,source:{originalSource:`{
  args: {
    loadingMessages: true
  }
}`,...(Xe=(Ye=x.parameters)==null?void 0:Ye.docs)==null?void 0:Xe.source},description:{story:"Повторная загрузка: лента остаётся на месте, сверху — индикатор обновления.",...(Je=(ze=x.parameters)==null?void 0:ze.docs)==null?void 0:Je.description}}};var Ze,$e,et,tt,at;E.parameters={...E.parameters,docs:{...(Ze=E.parameters)==null?void 0:Ze.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    streamingReply: STREAMING_TEXT,
    liveActivity: ACTIVITY_LIVE,
    liveUsage: makeUsage(),
    voiceBar: bar('thinking')
  }
}`,...(et=($e=E.parameters)==null?void 0:$e.docs)==null?void 0:et.source},description:{story:`Стриминг ответа: токены идут, действия чередуются с текстом, внизу пузыря
дубль статуса — при длинном ответе верхняя строка уезжает из вида.`,...(at=(tt=E.parameters)==null?void 0:tt.docs)==null?void 0:at.description}}};var nt,st,ot,rt,it;T.parameters={...T.parameters,docs:{...(nt=T.parameters)==null?void 0:nt.docs,source:{originalSource:`{
  args: {
    state: 'thinking',
    liveActivity: ACTIVITY_LIVE,
    liveUsage: makeUsage(),
    voiceBar: bar('thinking')
  }
}`,...(ot=(st=T.parameters)==null?void 0:st.docs)==null?void 0:ot.source},description:{story:"Запрос ушёл, токенов ещё нет: блок «обрабатывает запрос» с живой активностью.",...(it=(rt=T.parameters)==null?void 0:rt.docs)==null?void 0:it.description}}};var ct,mt,lt,dt,pt;k.parameters={...k.parameters,docs:{...(ct=k.parameters)==null?void 0:ct.docs,source:{originalSource:`{
  args: {
    state: 'listening',
    liveSegments: makeLiveSegments(),
    voiceBar: bar('listening')
  }
}`,...(lt=(mt=k.parameters)==null?void 0:mt.docs)==null?void 0:lt.source},description:{story:"Запись голоса: живой транскрипт по говорящим над композером.",...(pt=(dt=k.parameters)==null?void 0:dt.docs)==null?void 0:pt.description}}};var ut,gt,bt,yt,vt;f.parameters={...f.parameters,docs:{...(ut=f.parameters)==null?void 0:ut.docs,source:{originalSource:`{
  args: {
    error: 'Микрофон недоступен: браузер не дал доступ к устройству записи',
    onDismissError: fn()
  }
}`,...(bt=(gt=f.parameters)==null?void 0:gt.docs)==null?void 0:bt.source},description:{story:"Ошибка движка баннером над лентой (закрывается крестиком).",...(vt=(yt=f.parameters)==null?void 0:yt.docs)==null?void 0:vt.description}}};var wt,ht,Bt,xt,Et;M.parameters={...M.parameters,docs:{...(wt=M.parameters)==null?void 0:wt.docs,source:{originalSource:`{
  args: {
    modelMissing: true,
    modelLabel: 'large-v3-turbo',
    onDownloadModel: fn()
  }
}`,...(Bt=(ht=M.parameters)==null?void 0:ht.docs)==null?void 0:Bt.source},description:{story:"Модель распознавания не скачана — баннер первого запуска с кнопкой.",...(Et=(xt=M.parameters)==null?void 0:xt.docs)==null?void 0:Et.description}}};var Tt,kt,ft,Mt,St;S.parameters={...S.parameters,docs:{...(Tt=S.parameters)==null?void 0:Tt.docs,source:{originalSource:`{
  args: {
    modelMissing: true,
    modelLabel: 'large-v3-turbo',
    downloading: true,
    downloadPercent: 42
  }
}`,...(ft=(kt=S.parameters)==null?void 0:kt.docs)==null?void 0:ft.source},description:{story:"Скачивание модели идёт: вместо кнопки — процент.",...(St=(Mt=S.parameters)==null?void 0:Mt.docs)==null?void 0:St.description}}};var It,Rt,Ct,At,Ht;I.parameters={...I.parameters,docs:{...(It=I.parameters)==null?void 0:It.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Сделай CI-шаг для витрины'
    }), makeQuestionsMessage()],
    onAnswerQuestions: fn()
  }
}`,...(Ct=(Rt=I.parameters)==null?void 0:Rt.docs)==null?void 0:Ct.source},description:{story:"Уточняющие вопросы модели: форма ответов под последним сообщением.",...(Ht=(At=I.parameters)==null?void 0:At.docs)==null?void 0:Ht.description}}};var Lt,Ut,Vt,Dt,Wt;R.parameters={...R.parameters,docs:{...(Lt=R.parameters)==null?void 0:Lt.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'старт'
    }), makeQuestionsMessage({
      id: 'a-ci',
      meta: {
        ciInteraction: {
          runId: 'run-1',
          interactionId: 'it-1'
        }
      }
    }), makeUserMessage({
      id: 'u-after',
      text: 'а пока посмотрю лог'
    })],
    onAnswerCiInteraction: fn()
  }
}`,...(Vt=(Ut=R.parameters)==null?void 0:Ut.docs)==null?void 0:Vt.source},description:{story:"Вопрос CI-рана, продублированный в чат: ответ уйдёт в ран, а не новым ходом.",...(Wt=(Dt=R.parameters)==null?void 0:Dt.docs)==null?void 0:Wt.description}}};var qt,Nt,Ft,_t,Ot;C.parameters={...C.parameters,docs:{...(qt=C.parameters)==null?void 0:qt.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Построй график и открой консоль'
    }), makeImageMessage(), makeToolMessage('console')],
    machineOps: makeMachineOps(),
    // Машина нужна самой карточке: её шапка называет, где выполняются команды.
    agents: [makeAgent({
      id: 'm1',
      name: 'MacBook'
    })],
    onSwitchUtility: fn(),
    onOpenMachines: fn(),
    onOpenImageInExplorer: fn()
  }
}`,...(Ft=(Nt=C.parameters)==null?void 0:Nt.docs)==null?void 0:Ft.source},description:{story:"Ответ с картинкой и встроенной консолью машины (оба блока вырезаны из текста).",...(Ot=(_t=C.parameters)==null?void 0:_t.docs)==null?void 0:Ot.description}}};var jt,Qt,Kt,Pt,Gt;A.parameters={...A.parameters,docs:{...(jt=A.parameters)==null?void 0:jt.docs,source:{originalSource:`{
  args: {
    permissionMode: 'plan',
    messages: [makeUserMessage({
      text: 'Составь план'
    }), makeAiMessage({
      id: 'a-plan',
      text: MD_KITCHEN_SINK,
      meta: makeTurnMeta({
        request: {
          ...makeTurnMeta().request!,
          permissionMode: 'plan'
        }
      })
    })],
    onExecutePlan: fn(),
    voiceBar: bar()
  }
}`,...(Kt=(Qt=A.parameters)==null?void 0:Qt.docs)==null?void 0:Kt.source},description:{story:"Плановый ответ: под ним предложение выполнить тот же запрос в разработке.",...(Gt=(Pt=A.parameters)==null?void 0:Pt.docs)==null?void 0:Gt.description}}};var Yt,Xt,zt,Jt,Zt;H.parameters={...H.parameters,docs:{...(Yt=H.parameters)==null?void 0:Yt.docs,source:{originalSource:`{
  args: {
    messages: [makeUserMessage({
      text: 'Опиши архитектуру'
    }), makeAiMessage({
      id: 'a-int',
      text: 'Начал описывать, но не успел закон',
      meta: makeTurnMeta({
        interrupted: true
      })
    })]
  }
}`,...(zt=(Xt=H.parameters)==null?void 0:Xt.docs)==null?void 0:zt.source},description:{story:"Ход прерван перезапуском сервера: сохранена набранная часть, есть пометка.",...(Zt=(Jt=H.parameters)==null?void 0:Jt.docs)==null?void 0:Zt.description}}};var $t,ea,ta,aa,na;L.parameters={...L.parameters,docs:{...($t=L.parameters)==null?void 0:$t.docs,source:{originalSource:`{
  args: {
    messages: makeLongThread()
  }
}`,...(ta=(ea=L.parameters)==null?void 0:ea.docs)==null?void 0:ta.source},description:{story:"Длинная переписка: 24 сообщения — скролл и автоскролл вниз.",...(na=(aa=L.parameters)==null?void 0:aa.docs)==null?void 0:na.description}}};var sa,oa,ra,ia,ca;U.parameters={...U.parameters,docs:{...(sa=U.parameters)==null?void 0:sa.docs,source:{originalSource:`{
  args: {
    onToggleSidebar: fn(),
    messages: [makeUserMessage({
      id: 'u-mobile-copy',
      text: 'Проверь перенос длинной ссылки: https://example.test/very/long/unbroken/path/that/must/not/escape/the/message/bubble?query=mobile-copy-button'
    }), makeAiMessage({
      id: 'a-mobile-copy',
      text: 'Кнопка остаётся внутри пузыря, а текст переносится.'
    })]
  },
  parameters: {
    viewport: {
      defaultViewport: 'mobile2'
    }
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByRole('button', {
      name: 'Копировать вопрос'
    });
    const bubble = button.closest('.me .bub');
    if (!bubble) throw new Error('User message bubble not found');
    await userEvent.hover(bubble);
  }
}`,...(ra=(oa=U.parameters)==null?void 0:oa.docs)==null?void 0:ra.source},description:{story:"Телефон: сайдбар выдвижной, поэтому в шапке появляется ☰.",...(ca=(ia=U.parameters)==null?void 0:ia.docs)==null?void 0:ca.description}}};var ma,la,da,pa,ua;V.parameters={...V.parameters,docs:{...(ma=V.parameters)==null?void 0:ma.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByLabelText('Изменить сообщение'));
    const area = canvas.getByLabelText('Редактирование сообщения');
    await userEvent.clear(area);
    await userEvent.type(area, 'Почему упал шаг npm test и как это починить?');
    await expect(area).toHaveValue('Почему упал шаг npm test и как это починить?');
    await expect(canvas.getByRole('button', {
      name: 'Отправить'
    })).toBeEnabled();
  }
}`,...(da=(la=V.parameters)==null?void 0:la.docs)==null?void 0:da.source},description:{story:`Правка своей реплики: ✏️ открывает поле на месте пузыря (2–4 строки),
«Отправить» перезапускает ход с новым текстом.`,...(ua=(pa=V.parameters)==null?void 0:pa.docs)==null?void 0:ua.description}}};var ga,ba,ya,va,wa;D.parameters={...D.parameters,docs:{...(ga=D.parameters)==null?void 0:ga.docs,source:{originalSource:`{
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const button = canvas.getByLabelText('Переключить вид действий');
    await userEvent.click(button);
    // Секций действий в ответе две (по обе стороны абзацев) — обе сворачиваются
    // в свою строку-сводку, поэтому здесь \`getAllBy\`, а не \`getBy\`.
    await expect(canvas.getAllByTestId('activity-brief')).toHaveLength(2);
    await userEvent.click(button);
    await expect(canvas.getAllByTestId('activity-section').length).toBeGreaterThan(1);
  }
}`,...(ya=(ba=D.parameters)==null?void 0:ba.docs)==null?void 0:ya.source},description:{story:"Переключение вида действий у ответа: минимально → кратко → подробно.",...(wa=(va=D.parameters)==null?void 0:va.docs)==null?void 0:wa.description}}};var ha,Ba,xa,Ea,Ta;W.parameters={...W.parameters,docs:{...(ha=W.parameters)==null?void 0:ha.docs,source:{originalSource:`{
  parameters: {
    columnWidth: 599
  },
  args: {
    onToggleSidebar: fn()
  },
  play: async ({
    canvasElement,
    args
  }) => {
    const canvas = within(canvasElement);
    const frame = canvas.getByTestId('chat-column-frame');
    const trigger = await canvas.findByRole('button', {
      name: 'Действия чата'
    });
    await expect(canvas.getByRole('button', {
      name: /боковую панель/
    })).toBeVisible();
    await userEvent.click(canvas.getByRole('button', {
      name: /боковую панель/
    }));
    await expect(args.onToggleSidebar).toHaveBeenCalled();
    await waitFor(() => expect(canvas.queryByRole('button', {
      name: 'Настройки разговора'
    })).not.toBeInTheDocument());
    await userEvent.click(trigger);
    const actions = within(canvas.getByTestId('chat-header-actions'));
    const sidebar = canvas.getByRole('button', {
      name: /боковую панель/
    });
    await expect(sidebar).toBeVisible();
    await expect(canvas.getByTestId('chat-header-actions')).not.toContainElement(sidebar);
    for (const button of canvas.getByTestId('chat-header-actions').querySelectorAll('button')) {
      await expect(button).toHaveStyle({
        textAlign: 'left',
        display: 'grid'
      });
      await expect(button.firstElementChild).toHaveAttribute('aria-hidden', 'true');
    }
    await expect(actions.getByRole('combobox', {
      name: 'Машина активного чата'
    })).toBeEnabled();
    await expect(actions.getByRole('button', {
      name: 'Компактная лента'
    })).toBeVisible();
    await expect(actions.getByRole('button', {
      name: 'JSON (.json)'
    })).toBeVisible();
    await userEvent.click(actions.getByRole('button', {
      name: 'Настройки разговора'
    }));
    await expect(args.onOpenConversationSettings).toHaveBeenCalled();
    await expect(canvas.queryByTestId('chat-header-actions')).not.toBeInTheDocument();
    await userEvent.click(trigger);
    await userEvent.keyboard('{Escape}');
    await expect(trigger).toHaveFocus();
    await expect(canvas.queryByTestId('chat-header-actions')).not.toBeInTheDocument();
    await userEvent.click(trigger);
    await userEvent.click(within(canvas.getByTestId('chat-header-actions')).getByRole('button', {
      name: 'Markdown (.md)'
    }));
    await expect(args.onExport).toHaveBeenCalledWith('md');
    await userEvent.click(trigger);
    await userEvent.click(within(canvas.getByTestId('chat-header-actions')).getByRole('button', {
      name: 'Поиск'
    }));
    await expect(canvas.getByRole('textbox', {
      name: 'Найти в беседе'
    })).toBeVisible();
    frame.style.width = '700px';
    await waitFor(() => expect(canvas.queryByRole('button', {
      name: 'Действия чата'
    })).not.toBeInTheDocument());
    await expect(canvas.getByRole('button', {
      name: 'Настройки разговора'
    })).toBeVisible();
    frame.style.width = '699px';
    await expect(await canvas.findByRole('button', {
      name: 'Действия чата'
    })).toHaveAttribute('aria-expanded', 'false');
  }
}`,...(xa=(Ba=W.parameters)==null?void 0:Ba.docs)==null?void 0:xa.source},description:{story:"All header actions remain available when the column crosses 700px.",...(Ta=(Ea=W.parameters)==null?void 0:Ea.docs)==null?void 0:Ta.description}}};const Fn=["NewMessages","SearchAndCompact","FailedSubmission","MobileComposer390","Conversation","UserMessageHovered","UserMessageFocused","UserMessageHoveredDark","ModelMessageHovered","UserMessageCopied","EmptyConversation","LoadingMessages","RefreshingMessages","Streaming","Thinking","Listening","WithError","ModelMissing","ModelDownloading","WithQuestions","WithCiQuestion","WithMachineWidgets","PlanReady","InterruptedAnswer","LongThread","MobileViewport","EditingMessage","ActivityModeSwitch","NarrowHeaderActions"];export{D as ActivityModeSwitch,u as Conversation,V as EditingMessage,h as EmptyConversation,O as FailedSubmission,H as InterruptedAnswer,k as Listening,B as LoadingMessages,L as LongThread,j as MobileComposer390,U as MobileViewport,S as ModelDownloading,v as ModelMessageHovered,M as ModelMissing,W as NarrowHeaderActions,F as NewMessages,A as PlanReady,x as RefreshingMessages,_ as SearchAndCompact,E as Streaming,T as Thinking,w as UserMessageCopied,b as UserMessageFocused,g as UserMessageHovered,y as UserMessageHoveredDark,R as WithCiQuestion,f as WithError,C as WithMachineWidgets,I as WithQuestions,Fn as __namedExportsOrder,Nn as default};
